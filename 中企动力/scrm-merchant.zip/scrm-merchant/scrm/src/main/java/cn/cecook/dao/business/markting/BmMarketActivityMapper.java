package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.bean.business.markting.MarketFlowData;
import cn.cecook.bean.business.markting.SmartActivityBean;
import cn.cecook.model.business.markting.BmActivity;

/**
 * 
* @explain 智能营销活动表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BmMarketActivityMapper {

    int insertSelective(BmActivity record);
    
    SmartActivityBean getDetail(long id);
    
    Map<String,Object> getDetail22(Long id);
    
    int insertRule(Map<String, Object> map);

    int deleteRule(long market_id);

    int deleteSmartActivity(long id);
    //获取智能营销列表
    List<SmartActivityBean> getMarketActivityList(List<Long> ids);
    //获取单个智能营销活动集合
    List<Map<String,Object>> marketActivityList(List<Long> ids);
    //批量删除
    int deleteByCollection(List<Long> ids);

    int updateMarketIdByCollection(Map<String, Object> map);

    Map<String,Object> queryMartketByActivityId(long activity_id);
    //根据活动id 获取智能营销的流程参数
    MarketFlowData queryMarketFlowData(long activity_id);


    int updateUrl(Map<String, Object> map);
    
    
    BmActivity getMarketActivityDetail(long id);
}