package cn.cecook.dao.open.mp;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpMaterialNewsDetail;

public interface MpMaterialNewsDetailMapper {

	public MpMaterialNewsDetail selectNewsDetailById(@Param(value = "tenant_id") String tenant_id, @Param(value = "id") int id);
	public List<MpMaterialNewsDetail> selectNewsDetailByNewsId(@Param(value = "tenant_id") String tenant_id, @Param(value = "news_id") int newsId);
	public void insertNewsDetail(MpMaterialNewsDetail mpMaterialNewsDetail);
	public void delAll(String tenant_id);
	
	public void delById(@Param(value = "tenant_id") String tenant_id, @Param(value = "id") int id);
	public void delByNewsId(@Param(value = "tenant_id") String tenant_id, @Param(value = "news_id") int newsId);
	public void delByMediaId(@Param(value = "tenant_id") String tenant_id, @Param(value = "media_id") String mediaId);
}
