package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmActivityStore;

public interface BmActivityStoreMapper {

    int deleteByPrimaryKey(Long id);


    int insertSelective(BmActivityStore record);


    List<Map<String,Object>> selectByPrimaryKey(Long id);


    int updateByPrimaryKeySelective(BmActivityStore record);
    
    int updateDeleted(long id);

}