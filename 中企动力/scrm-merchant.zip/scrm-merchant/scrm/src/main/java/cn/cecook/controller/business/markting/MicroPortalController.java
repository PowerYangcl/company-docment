package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.markting.BmMicroPortal;
import cn.cecook.service.business.markting.MicroPortalService;

/**
 * 
 * @Title MicroPortalController.java
 * @Description 微门户
 * @author wschenyongyin
 * @date 2017年7月12日
 * @version 1.0
 */
@Controller
@RequestMapping("/api/microportal")
public class MicroPortalController {
	@Autowired
	MicroPortalService microPortalService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		BmMicroPortal bmMicroPortal = new BmMicroPortal();
		String business_hours = request.getParameter("business_hours");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String tag = request.getParameter("tag");
		String pic = request.getParameter("pic");
		String name = request.getParameter("store_name");
		String store_id = request.getParameter("store_id");

		bmMicroPortal.setBusinessHours(business_hours);
		bmMicroPortal.setAddress(address);
		bmMicroPortal.setPhone(phone);
		bmMicroPortal.setTag(tag);
		bmMicroPortal.setPic(pic);
		bmMicroPortal.setName(name);
		bmMicroPortal.setStore_id(store_id);

		BaseResultModel objetc = microPortalService.getDetail();
		if (objetc.getError_code().equals("0")) {
			return (microPortalService.update(bmMicroPortal));
		} else {
			return (microPortalService.create(bmMicroPortal));
		}

	}

	@RequestMapping(value = "/edit")
	@ResponseBody
	public Object edit(HttpServletRequest request, HttpServletResponse response) {
		BmMicroPortal bmMicroPortal = new BmMicroPortal();
		String business_hours = request.getParameter("business_hours");
		String address = request.getParameter("address");
		String phone = request.getParameter("phone");
		String tag = request.getParameter("tag");
		String pic = request.getParameter("pic");
		String name = request.getParameter("store_name");

		bmMicroPortal.setBusinessHours(business_hours);
		bmMicroPortal.setAddress(address);
		bmMicroPortal.setPhone(phone);
		bmMicroPortal.setTag(tag);
		bmMicroPortal.setPic(pic);
		bmMicroPortal.setName(name);
		return (microPortalService.update(bmMicroPortal));
	}

	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object detail() {
		return (microPortalService.getDetail());
	}

	@RequestMapping(value = "/updateIds")
	@ResponseBody
	public Object updateIds(String ids) {
		return (microPortalService.updateIds(ids));
	}

}
