package cn.cecook.controller.open;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.common.collect.Lists;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpEmoji;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.thirdparty.open.MenuUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.EmojiUtil;
import cn.cecook.uitls.redis.RedisStringUtil;
import net.sf.json.JSONArray;

@Controller
@RequestMapping("/weixin")
public class WeixinMenuController {

	@Autowired
	private IMpAccountService mpAccountService;
	
	@RequestMapping(value = "/menu")
    public String focusUser(HttpServletRequest request, HttpServletResponse response) {
		Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String tenantId = String.valueOf(session.getAttribute("tenantId"));
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenantId);
		if(mpAccount != null) {
			String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
			JsonObject menuData = MenuUtil.get(authorizer_access_token);
			JsonArray buttons = menuData.getAsJsonObject("menu").getAsJsonArray("button");
			for (int i = 0; i<buttons.size();i++) {
				JsonObject button = buttons.get(i).getAsJsonObject();
				JsonArray subButton = button.getAsJsonArray("sub_button");
				if (subButton.size() > 0) {
					for(int j=0;j<subButton.size();j++){
						JsonElement subMenu = subButton.get(j);
						String type = subMenu.getAsJsonObject().get("type").getAsString();
						if("view".equals(type)){
							//链接形式
							String eventType = "link";
							String eventContent = subMenu.getAsJsonObject().get("url").getAsString();
							subMenu.getAsJsonObject().addProperty("menuType", eventType);
							subMenu.getAsJsonObject().addProperty("menuContent", eventContent);
							
						}else if("media_id".equals(type)){
							//链接形式
							String eventType = "image";
							String eventContent = subMenu.getAsJsonObject().get("media_id").getAsString();
							subMenu.getAsJsonObject().addProperty("menuType", eventType);
							subMenu.getAsJsonObject().addProperty("menuContent", eventContent);
							
						}else {
							String menuKey = subMenu.getAsJsonObject().get("key").getAsString();
							String eventType =RedisStringUtil.getValue( menuKey+"_type");
							String eventContent = RedisStringUtil.getValue(menuKey+"_content");
							
							if(menuKey.startsWith("text-")){
								eventContent = EmojiUtil.formatEmoji(eventContent);
							}
							subMenu.getAsJsonObject().addProperty("menuType", eventType);
							subMenu.getAsJsonObject().addProperty("menuContent", eventContent);
						}
					}
				}else{
					String type = button.getAsJsonObject().get("type").getAsString();
					if("view".equals(type)){
						//链接形式
						String eventType ="link";
						String eventContent = button.getAsJsonObject().get("url").getAsString();;
						button.getAsJsonObject().addProperty("menuType", eventType);
						button.getAsJsonObject().addProperty("menuContent", eventContent);
						
					}else if("media_id".equals(type)){
						//链接形式
						String eventType ="image";
						String eventContent = button.getAsJsonObject().get("media_id").getAsString();;
						button.getAsJsonObject().addProperty("menuType", eventType);
						button.getAsJsonObject().addProperty("menuContent", eventContent);
						
					}else{
						String menuKey = button.get("key").getAsString();
						String eventType =RedisStringUtil.getValue( menuKey+"_type");
						String eventContent = RedisStringUtil.getValue(menuKey+"_content");
						button.getAsJsonObject().addProperty("menuType", eventType);
						button.getAsJsonObject().addProperty("menuContent", eventContent);
					}
				}
			}
			List<MpEmoji> emojiList = EmojiUtil.getEmojiList();
			List<Map<String,String>> emojiMapList = Lists.newArrayList();
			for (MpEmoji mpEmoji : emojiList) {
				Map<String,String> emoji = new HashMap<String,String>();
				emoji.put("src", mpEmoji.getImage());
				emoji.put("alt", mpEmoji.getEmoji());
				emojiMapList.add(emoji);
			}
			request.setAttribute("emojiList", JSONArray.fromObject(emojiMapList));
			request.setAttribute("menuData", menuData.toString());
		}
		return "open/wxMenu";
	}
	
	@ResponseBody
	@RequestMapping(value = "/createMenu")
    public Object createMenu(HttpServletRequest request, HttpServletResponse response) {
		String menuData = ServletRequestUtils.getStringParameter(request, "menuData", "");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		boolean success = MenuUtil.create(authorizer_access_token, menuData);	
		//存储menu信息到redis
		JsonObject menuDataJson  = new JsonParser().parse(menuData).getAsJsonObject();
		JsonArray buttons = menuDataJson.getAsJsonArray("button");
		for(int i = 0;i<buttons.size();i++){
			JsonObject menu = buttons.get(i).getAsJsonObject();
			JsonArray subButtons = menu.getAsJsonArray("sub_button");
			if (subButtons!=null && subButtons.size() > 0) {
				for(int j=0; j<subButtons.size();j++){
					JsonObject subMenu = subButtons.get(j).getAsJsonObject();
					String menuKey = subMenu.get("key").getAsString();
					String menuType = subMenu.get("menuType").getAsString();
					String menuContent = subMenu.get("menuContent").getAsString();
					RedisStringUtil.setData(menuKey+"_type", menuType);
					RedisStringUtil.setData(menuKey+"_content", menuContent);
				}
			}else{
				String menuKey = menu.get("key").getAsString();
				String menuType = menu.get("menuType").getAsString();
				String menuContent = menu.get("menuContent").getAsString();
				RedisStringUtil.setData(menuKey+"_type", menuType);
				RedisStringUtil.setData(menuKey+"_content", menuContent);
			}
		}
		Map<String,Object> result = new HashMap<String,Object>();
		result.put("success", success);
		return result;
	}
	
	@RequestMapping(value = "/emoji", method = RequestMethod.GET)
	@ResponseBody
	public Object emoji(HttpServletRequest request, HttpServletResponse response) {
		return  EmojiUtil.getEmojiList();
	}
}
