/**
 * @Title: BmActivity.java
 * @Description: 活动
 * @author peng
 * @date 2107/5/23 
 * @version V1.0
 */
package cn.cecook.model.business.markting;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;
import java.util.Date;

/**
 * 活动
 * 
 * @author peng
 *
 */
@Component
public class BmActivity {

	
	private String activity_tag;
	private Integer couponFlag;
	
	
	public Integer getCouponFlag() {
		return couponFlag;
	}

	public void setCouponFlag(Integer couponFlag) {
		this.couponFlag = couponFlag;
	}

	public String getActivity_tag() {
		return activity_tag;
	}

	public void setActivity_tag(String activity_tag) {
		this.activity_tag = activity_tag;
	}

	// id
	private Long id;

	// uuid
	private String uuid;

	// 租户ID
	private String tenantId;

	// 删除标记
	private Integer isDeleted;

	// 创建人ID
	private Long createId;

	// 创建时间
	private Date createTime;

	// 排序标示
	private String orderCode;

	// 删除时间
	private Date deleteTime;

	// 备注
	private String remarks;

	// 附件
	private String attachment;

	// 名称
	private String name;
	// 活动头图
	private String head_pic;
	// 描述
	private String description;

	// 活动页面地址
	private String webUrl;

	// 图片地址集合
	private String picUrl;

	// 优惠券发送方式
	private String couponSendType;

	// 活动开始时间
	private String startDate;

	// 有效天数
	private Integer effectiveDay;

	// 有效状态
	private Integer effectiveStatus;

	// 优惠券数量
	private Integer couponNumber;

	// 活动标签（酷客定义）
	private String tag;

	// 自定义标签
	private String tagDefined;

	// 分享显示的标题
	private String title;

	// 分享显示的文案
	private String content;

	// 分享显示的图
	private String pic;

	// 活动状态
	private Integer status;

	// 审核状态
	private Integer checkStatus;

	// 审核描述
	private String checkDescrption;

	// 活动概览
	private String overview;

	// 统计值
	private String statistic;

	// 分享渠道
	private String shareChannel;

	// 打开数
	private String browseNumber;

	// 提交表单数
	private String submitNumer;

	// 活动模板id
	private Integer model_id;
	// 转化比例
	private String ratio;
	// 智能营销活动规则id
	private Long market_rule_id;
	// 备用字段
	private String bak1;

	// 备用字段
	private String bak2;

	// 备用字段
	private String bak3;

	// 备用字段
	private String bak4;

	// 备用字段
	private String bak5;
	// 活动类型
	private Integer type;

	private Integer transmit_rule;

	private Timestamp start_time;
	private Timestamp end_time;
	private Integer coupon_expire_day;
	private String equipment_facilities;
	private String original_price;
	private String discount_price;
	private String activity_restrict;
	private String commit_info;
	private String weibo_qrcode;
	private String weixin_qrcode;
	private String detail_rule;
	private Integer browse_num;
	private Integer receive_coupon_num;
	private Integer write_off_num;
	private String background_pic;
	private String background_music;
	private String protrait_tag;
	
	private String button_text;
	private String button_css;
	private String theme_info;
	private String theme_info_color;
	private String text_info_color;
	private String start_time_tag;
	private String end_time_tag;
	
	
	private int coupon_id;
	private String coupon_name;
	private int sms_batch_id;
	private Integer face_value;
	

	private Integer distinction;
	
	private Integer thirdId;

	public Integer getThirdId() {
		return thirdId;
	}

	public void setThirdId(Integer thirdId) {
		this.thirdId = thirdId;
	}

	public Integer getDistinction() {
		return distinction;
	}

	public void setDistinction(Integer distinction) {
		this.distinction = distinction;
	}


	public int getCoupon_id() {
		return coupon_id;
	}

	public Integer getFace_value() {
		return face_value;
	}

	public void setFace_value(Integer face_value) {
		this.face_value = face_value;
	}

	public void setCoupon_id(int coupon_id) {
		this.coupon_id = coupon_id;
	}

	public String getCoupon_name() {
		return coupon_name;
	}

	public void setCoupon_name(String coupon_name) {
		this.coupon_name = coupon_name;
	}

	public int getSms_batch_id() {
		return sms_batch_id;
	}

	public void setSms_batch_id(int sms_batch_id) {
		this.sms_batch_id = sms_batch_id;
	}

	public String getTheme_info() {
		return theme_info;
	}

	public void setTheme_info(String theme_info) {
		this.theme_info = theme_info;
	}

	public String getTheme_info_color() {
		return theme_info_color;
	}

	public String getStart_time_tag() {
		return start_time_tag;
	}

	public void setStart_time_tag(String start_time_tag) {
		this.start_time_tag = start_time_tag;
	}

	public String getEnd_time_tag() {
		return end_time_tag;
	}

	public void setEnd_time_tag(String end_time_tag) {
		this.end_time_tag = end_time_tag;
	}

	public void setTheme_info_color(String theme_info_color) {
		this.theme_info_color = theme_info_color;
	}

	public String getText_info_color() {
		return text_info_color;
	}

	public void setText_info_color(String text_info_color) {
		this.text_info_color = text_info_color;
	}

	public String getButton_text() {
		return button_text;
	}

	public void setButton_text(String button_text) {
		this.button_text = button_text;
	}

	public String getButton_css() {
		return button_css;
	}

	public void setButton_css(String button_css) {
		this.button_css = button_css;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Long getCreateId() {
		return createId;
	}

	public void setCreateId(Long createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHead_pic() {
		return head_pic;
	}

	public void setHead_pic(String head_pic) {
		this.head_pic = head_pic;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getWebUrl() {
		return webUrl;
	}

	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl;
	}

	public String getPicUrl() {
		return picUrl;
	}

	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl;
	}

	public String getCouponSendType() {
		return couponSendType;
	}

	public void setCouponSendType(String couponSendType) {
		this.couponSendType = couponSendType;
	}

	public String getStartDate() {
		return startDate;
	}

	public void setStartDate(String startDate) {
		this.startDate = startDate;
	}

	public Integer getEffectiveDay() {
		return effectiveDay;
	}

	public void setEffectiveDay(Integer effectiveDay) {
		this.effectiveDay = effectiveDay;
	}

	public Integer getEffectiveStatus() {
		return effectiveStatus;
	}

	public void setEffectiveStatus(Integer effectiveStatus) {
		this.effectiveStatus = effectiveStatus;
	}

	public Integer getCouponNumber() {
		return couponNumber;
	}

	public void setCouponNumber(Integer couponNumber) {
		this.couponNumber = couponNumber;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getTagDefined() {
		return tagDefined;
	}

	public void setTagDefined(String tagDefined) {
		this.tagDefined = tagDefined;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCheckStatus() {
		return checkStatus;
	}

	public void setCheckStatus(Integer checkStatus) {
		this.checkStatus = checkStatus;
	}

	public String getCheckDescrption() {
		return checkDescrption;
	}

	public void setCheckDescrption(String checkDescrption) {
		this.checkDescrption = checkDescrption;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getStatistic() {
		return statistic;
	}

	public void setStatistic(String statistic) {
		this.statistic = statistic;
	}

	public String getShareChannel() {
		return shareChannel;
	}

	public void setShareChannel(String shareChannel) {
		this.shareChannel = shareChannel;
	}

	public String getBrowseNumber() {
		return browseNumber;
	}

	public void setBrowseNumber(String browseNumber) {
		this.browseNumber = browseNumber;
	}

	public String getSubmitNumer() {
		return submitNumer;
	}

	public void setSubmitNumer(String submitNumer) {
		this.submitNumer = submitNumer;
	}

	public Integer getModel_id() {
		return model_id;
	}

	public void setModel_id(Integer model_id) {
		this.model_id = model_id;
	}

	public String getRatio() {
		return ratio;
	}

	public void setRatio(String ratio) {
		this.ratio = ratio;
	}

	public Long getMarket_rule_id() {
		return market_rule_id;
	}

	public void setMarket_rule_id(Long market_rule_id) {
		this.market_rule_id = market_rule_id;
	}

	public String getBak1() {
		return bak1;
	}

	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}

	public String getBak2() {
		return bak2;
	}

	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}

	public String getBak3() {
		return bak3;
	}

	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}

	public String getBak4() {
		return bak4;
	}

	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}

	public String getBak5() {
		return bak5;
	}

	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}

	public Integer getType() {
		return type;
	}

	public void setType(Integer type) {
		this.type = type;
	}

	public Integer getTransmit_rule() {
		return transmit_rule;
	}

	public void setTransmit_rule(Integer transmit_rule) {
		this.transmit_rule = transmit_rule;
	}

	public Timestamp getStart_time() {
		return start_time;
	}

	public void setStart_time(Timestamp start_time) {
		if(start_time!=null){
			start_time_tag="true";
		}else{
			start_time_tag=null;
		}
		this.start_time = start_time;
	}

	public Timestamp getEnd_time() {
		return end_time;
	}

	public void setEnd_time(Timestamp end_time) {
		
		if(end_time!=null){
			end_time_tag="true";
		}else{
			end_time_tag=null;
		}
		this.end_time = end_time;
	}

	public Integer getCoupon_expire_day() {
		return coupon_expire_day;
	}

	public void setCoupon_expire_day(Integer coupon_expire_day) {
		this.coupon_expire_day = coupon_expire_day;
	}

	public String getEquipment_facilities() {
		return equipment_facilities;
	}

	public void setEquipment_facilities(String equipment_facilities) {
		this.equipment_facilities = equipment_facilities;
	}

	public String getOriginal_price() {
		return original_price;
	}

	public void setOriginal_price(String original_price) {
		this.original_price = original_price;
	}

	public String getDiscount_price() {
		return discount_price;
	}

	public void setDiscount_price(String discount_price) {
		this.discount_price = discount_price;
	}

	public String getActivity_restrict() {
		return activity_restrict;
	}

	public void setActivity_restrict(String activity_restrict) {
		this.activity_restrict = activity_restrict;
	}

	public String getCommit_info() {
		return commit_info;
	}

	public void setCommit_info(String commit_info) {
		this.commit_info = commit_info;
	}

	public String getWeibo_qrcode() {
		return weibo_qrcode;
	}

	public void setWeibo_qrcode(String weibo_qrcode) {
		this.weibo_qrcode = weibo_qrcode;
	}

	public String getWeixin_qrcode() {
		return weixin_qrcode;
	}

	public void setWeixin_qrcode(String weixin_qrcode) {
		this.weixin_qrcode = weixin_qrcode;
	}

	public String getDetail_rule() {
		return detail_rule;
	}

	public void setDetail_rule(String detail_rule) {
		this.detail_rule = detail_rule;
	}

	public Integer getBrowse_num() {
		return browse_num;
	}

	public void setBrowse_num(Integer browse_num) {
		this.browse_num = browse_num;
	}

	public Integer getReceive_coupon_num() {
		return receive_coupon_num;
	}

	public void setReceive_coupon_num(Integer receive_coupon_num) {
		this.receive_coupon_num = receive_coupon_num;
	}

	public Integer getWrite_off_num() {
		return write_off_num;
	}

	public void setWrite_off_num(Integer write_off_num) {
		this.write_off_num = write_off_num;
	}

	public String getBackground_pic() {
		return background_pic;
	}

	public void setBackground_pic(String background_pic) {
		this.background_pic = background_pic;
	}

	public String getBackground_music() {
		return background_music;
	}

	public void setBackground_music(String background_music) {
		this.background_music = background_music;
	}

	public String getProtrait_tag() {
		return protrait_tag;
	}

	public void setProtrait_tag(String protrait_tag) {
		this.protrait_tag = protrait_tag;
	}

	@Override
	public String toString() {
		return "BmActivity [id=" + id + ", uuid=" + uuid + ", tenantId="
				+ tenantId + ", isDeleted=" + isDeleted + ", createId="
				+ createId + ", createTime=" + createTime + ", orderCode="
				+ orderCode + ", deleteTime=" + deleteTime + ", remarks="
				+ remarks + ", attachment=" + attachment + ", name=" + name
				+ ", head_pic=" + head_pic + ", description=" + description
				+ ", webUrl=" + webUrl + ", picUrl=" + picUrl
				+ ", couponSendType=" + couponSendType + ", startDate="
				+ startDate + ", effectiveDay=" + effectiveDay
				+ ", effectiveStatus=" + effectiveStatus + ", couponNumber="
				+ couponNumber + ", tag=" + tag + ", tagDefined=" + tagDefined
				+ ", title=" + title + ", content=" + content + ", pic=" + pic
				+ ", status=" + status + ", checkStatus=" + checkStatus
				+ ", checkDescrption=" + checkDescrption + ", overview="
				+ overview + ", statistic=" + statistic + ", shareChannel="
				+ shareChannel + ", browseNumber=" + browseNumber
				+ ", submitNumer=" + submitNumer + ", model_id=" + model_id
				+ ", ratio=" + ratio + ", market_rule_id=" + market_rule_id
				+ ", bak1=" + bak1 + ", bak2=" + bak2 + ", bak3=" + bak3
				+ ", bak4=" + bak4 + ", bak5=" + bak5 + ", type=" + type
				+ ", transmit_rule=" + transmit_rule + ", start_time="
				+ start_time + ", end_time=" + end_time
				+ ", coupon_expire_day=" + coupon_expire_day
				+ ", equipment_facilities=" + equipment_facilities
				+ ", original_price=" + original_price + ", discount_price="
				+ discount_price + ", activity_restrict=" + activity_restrict
				+ ", commit_info=" + commit_info + ", weibo_qrcode="
				+ weibo_qrcode + ", weixin_qrcode=" + weixin_qrcode
				+ ", detail_rule=" + detail_rule + ", browse_num=" + browse_num
				+ ", receive_coupon_num=" + receive_coupon_num
				+ ", write_off_num=" + write_off_num + "]";
	}

}