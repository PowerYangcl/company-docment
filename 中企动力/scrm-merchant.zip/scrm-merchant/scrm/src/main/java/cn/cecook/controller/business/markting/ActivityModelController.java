package cn.cecook.controller.business.markting;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.ActivityModelService;

@Controller
@RequestMapping("/api/activity_model")
public class ActivityModelController {
	@Resource
	ActivityModelService activityModelService;

	@RequestMapping(value="/copy")
	@ResponseBody
	public Object copyModel(String tenant_id, String model_id, String uid) {

		return (activityModelService
				.copyActivityDefinedModel(tenant_id, uid, model_id));
	}

	@RequestMapping(value="/detail")
	@ResponseBody
	public Object modelDetail(String uid, String model_id) {
		System.out.println("sys---------->");
		return (activityModelService
				.getActivityModelDetail(uid, model_id));
	}

	@RequestMapping(value="/list")
	@ResponseBody
	public Object modelList(String uid, String self_id, String key_word,
			String tenant_id, String page_size) {
		return (activityModelService
				.getBmActivityModelList(tenant_id, uid, self_id, key_word, key_word, page_size));
	}

}
