package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.Medicine;


/**
 * 
 * @作者	马杰
 * @时间	2017年5月13日-下午4:47:46
 * @介绍	dao方法接口
 */
@Repository("imedicineDao")
public interface ImedicineDao {	
	/**
	 * 查询(可分页)
	 * @param medicine	条件模糊查询
	 * @return
	 */
	public List<Medicine> findAll(Medicine medicine);
	/**
	 * 获取记录总数
	 * @param medicine	多条件获取
	 * @return
	 */
	public int getCount(Medicine medicine);
	/**
	 * 添加
	 * @param medicine
	 * @return
	 */
	public int addMedicine(Medicine medicine);
	/**
	 * 删除信息
	 * @param id
	 * @return
	 */
	public int delete(int id);
	/**
	 * 查询单条记录
	 * @param medicine
	 * @return
	 */
	public Medicine findOne(Medicine medicine);
	/**
	 * 修改信息
	 * @return
	 */
	public int update(Medicine medicine);
	/**
	 * 
	* Title: getMedicineRuleList
	* Description:查询药品短信发送规则
	* @param id
	* @return
	 */
	
	public List<Map<String,Object>> getMedicineRuleList(int id);
	
	public Map<String,Object> getMedicineRule(Map<String, Object> map);


	public Map<String,Object> getNameAndTaskId(@Param("id") int id, @Param("tenantId") String tenantId);
	/**
	 *
	* Title: isAppraiseByMedicineId
	* Description:根据药品id判断订单是否评价
	* @param medicineId
	* @return
	 */
	public int isAppraiseByMedicineId(int medicineId);

	public int countMedicineList(Map<String, Object> map);

	public List<Map<String,Object>> medicineList(Map<String, Object> map);

	public List<Medicine> findByName(Map<String, Object> map);
	/**
	 * 根据一定规则匹配药品数据
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> findByProp(Map<String, Object> map);
	
	
	Map<String,Object> getTaskMedicinesByIds(List<Integer> ids);

	String getMedicineNameById(int id);
	}
