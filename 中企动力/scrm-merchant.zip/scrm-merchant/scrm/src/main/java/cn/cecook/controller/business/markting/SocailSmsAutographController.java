package cn.cecook.controller.business.markting;



import cn.cecook.uitls.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.markting.SocialSmsAutograph;
import cn.cecook.service.business.markting.SocialSmsAutographService;

@Controller
@RequestMapping("/social/autograph")
public class SocailSmsAutographController {

	@Autowired
	SocialSmsAutographService socailSmsAutographService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(String uid, String name) {
		SocialSmsAutograph socailSmsAutograph = new SocialSmsAutograph();
		if (StringUtils.isEmpty(uid))
			socailSmsAutograph.setCreateId(Long.parseLong(uid));
		socailSmsAutograph.setName(name);

		return (socailSmsAutographService
				.create(socailSmsAutograph));

	}

	@RequestMapping(value = "/update")
	@ResponseBody
	public Object update(String uid, String name) {
		SocialSmsAutograph socailSmsAutograph = new SocialSmsAutograph();
		if (StringUtils.isEmpty(uid))
			socailSmsAutograph.setCreateId(Long.parseLong(uid));
		socailSmsAutograph.setName(name);

		return (socailSmsAutographService
				.update(socailSmsAutograph));

	}

	@RequestMapping(value = "/delete")
	@ResponseBody
	public Object delete(String id) {

		return (socailSmsAutographService.delete(id));

	}

	@RequestMapping(value = "/list")
	@ResponseBody
	public Object getList() {
          System.out.println("短信标签controller");
		return (socailSmsAutographService.getList());

	}

}
