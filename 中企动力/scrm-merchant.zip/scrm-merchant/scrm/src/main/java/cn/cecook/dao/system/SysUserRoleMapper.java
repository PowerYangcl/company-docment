package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysUserRole;
import cn.cecook.model.system.SysUserRoleExample;

/**
 * 
* @explain 用户-角色映射表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysUserRoleMapper {
    int countByExample(SysUserRoleExample example);

    int deleteByExample(SysUserRoleExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysUserRole record);

    int insertSelective(SysUserRole record);

    List<SysUserRole> selectByExample(SysUserRoleExample example);

    SysUserRole selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysUserRole record, @Param("example") SysUserRoleExample example);

    int updateByExample(@Param("record") SysUserRole record, @Param("example") SysUserRoleExample example);

    int updateByPrimaryKeySelective(SysUserRole record);

    int updateByPrimaryKey(SysUserRole record);
    //根据roleid查询用户
	List selectByRoleId(Map<String, Object> map);
    /**
     * 根据userID删除
     * @explain 
     * @author sunny
     * @date 2017年6月13日
     */
    int deleteByUserId(long user_id);
    /**
     * 
     * @explain 根据uid和tid查询
     * @author LeeX
     * @date 2017年6月22日 下午2:03:00
     */
	List<Long> selectRoleByUid(Map<String, Object> map);
	/**
     * 根据userID查询对应的角色关联表集合
     * @explain 
     * @author sunny
     * @date 2017年6月13日
     */
    List selectByUserId(long user_id);

	void selectByProductRoleId(String storeId);

	List<Map<String, Object>> getAllUser(@Param("storeId") Long storeId,@Param("userDate") String userDate);
}
