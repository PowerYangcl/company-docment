package cn.cecook.controller.open;

import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpStatistic;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpStatisticService;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.StringUtils;

/**
 * 统计相关
 */
@Controller
@RequestMapping("/statistic")
public class StatisticController {

	@Autowired
	private IMpAccountService iMpAccountService;
	
	@Autowired
	private IMpStatisticService iMpStatisticService;
	
	@RequestMapping(value = "/listByTime", method = RequestMethod.GET)
	@ResponseBody
	public String listByTime(HttpServletRequest request, HttpServletResponse response) {
		JSONObject resultObject = new JSONObject();
		String rangeParam = request.getParameter("range");
		if(StringUtils.isEmpty(rangeParam)) {
			return resultObject.toString();
		}
		Cookie[] cookies = request.getCookies();
		String tenantId = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenantId);
		if(mpAccount != null){			
			Calendar startCalendar = Calendar.getInstance();
			startCalendar.setTime(new Date());
			Calendar endCalendar = Calendar.getInstance();
			endCalendar.setTime(new Date());
			if("week".equals(rangeParam)) {
				startCalendar.add(Calendar.DAY_OF_MONTH, -7);
				endCalendar.add(Calendar.DAY_OF_MONTH, -1);
			}else if("month".equals(rangeParam)) {
				startCalendar.add(Calendar.MONTH, -1);
				endCalendar.add(Calendar.DAY_OF_MONTH, -1);
			}else if("month3".equals(rangeParam)) {
				startCalendar.add(Calendar.MONTH, -3);
				endCalendar.add(Calendar.DAY_OF_MONTH, -1);
			}else{
				String[] rangeSplit = rangeParam.split("_");
				if(rangeSplit.length == 2) {
					Date start = DateUtils.toDate(rangeSplit[0]);
					Date end = DateUtils.toDate(rangeSplit[1]);
					startCalendar.setTime(start);
					endCalendar.setTime(end);
				}
			}
			List<MpStatistic> selectByTime = iMpStatisticService.selectByTime(mpAccount.getTenantId(), startCalendar.getTime(), endCalendar.getTime());
			System.out.println(selectByTime.size());
			JSONArray statArray = new JSONArray();
			Map<String, List<Integer>> dayDataMap = new HashMap<String, List<Integer>>();//类别->数字
			List<String> tagList = new ArrayList<String>();
			for (int i = 0; i < selectByTime.size(); i++) {
				MpStatistic mpStatistic_  = selectByTime.get(i);
				tagList.add(DateUtils.toDateString(mpStatistic_.getRefDate()));
				
				List<Integer> newUserList = dayDataMap.get("newUser");
				if(newUserList == null) {
					newUserList = new ArrayList<Integer>();
				}
				newUserList.add(mpStatistic_.getNewUser());
				dayDataMap.put("newUser", newUserList);
				
				List<Integer> cancelUserList = dayDataMap.get("cancelUser");
				if(cancelUserList == null) {
					cancelUserList = new ArrayList<Integer>();
				}
				cancelUserList.add(mpStatistic_.getCancelUser());
				dayDataMap.put("cancelUser", cancelUserList);
				
				List<Integer> addUserList = dayDataMap.get("addUser");
				if(addUserList == null) {
					addUserList = new ArrayList<Integer>();
				}
				addUserList.add(mpStatistic_.getNewUser() - mpStatistic_.getCancelUser());
				dayDataMap.put("addUser", addUserList);
				
				List<Integer> cumulateUserList = dayDataMap.get("cumulateUser");
				if(cumulateUserList == null) {
					cumulateUserList = new ArrayList<Integer>();
				}
				cumulateUserList.add(mpStatistic_.getCumulateUser());
				dayDataMap.put("cumulateUser", cumulateUserList);
				
			}
			resultObject.put("dayDataMap", dayDataMap);
			resultObject.put("datas", tagList);
		}
		return resultObject.toString();
	}
}
