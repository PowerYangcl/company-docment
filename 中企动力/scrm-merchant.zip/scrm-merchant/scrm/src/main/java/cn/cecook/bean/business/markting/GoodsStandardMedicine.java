package cn.cecook.bean.business.markting;

import java.util.Date;

public class GoodsStandardMedicine {
    private Long id;

    private String tenantId;

    private String uuid;

    private Integer isDeleted;

    private Date createTime;

    private Long goodsId;

    private String generalName;

    private String englishName;

    private String component;

    private String adaptationSymptoms;

    private String usageDosage;

    private String adverseReaction;

    private String taboo;

    private String mattersAttention;

    private String storagec;

    private String termValidity;

    private String approvalNumber;

    private String productionCompany;

    private String productionAddress;

    private String enterprisePhone;

    private String courseCycle;

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId == null ? null : tenantId.trim();
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public Long getGoodsId() {
        return goodsId;
    }

    public void setGoodsId(Long goodsId) {
        this.goodsId = goodsId;
    }

    public String getGeneralName() {
        return generalName;
    }

    public void setGeneralName(String generalName) {
        this.generalName = generalName == null ? null : generalName.trim();
    }

    public String getEnglishName() {
        return englishName;
    }

    public void setEnglishName(String englishName) {
        this.englishName = englishName == null ? null : englishName.trim();
    }

    public String getComponent() {
        return component;
    }

    public void setComponent(String component) {
        this.component = component == null ? null : component.trim();
    }

    public String getAdaptationSymptoms() {
        return adaptationSymptoms;
    }

    public void setAdaptationSymptoms(String adaptationSymptoms) {
        this.adaptationSymptoms = adaptationSymptoms == null ? null : adaptationSymptoms.trim();
    }

    public String getUsageDosage() {
        return usageDosage;
    }

    public void setUsageDosage(String usageDosage) {
        this.usageDosage = usageDosage == null ? null : usageDosage.trim();
    }

    public String getAdverseReaction() {
        return adverseReaction;
    }

    public void setAdverseReaction(String adverseReaction) {
        this.adverseReaction = adverseReaction == null ? null : adverseReaction.trim();
    }

    public String getTaboo() {
        return taboo;
    }

    public void setTaboo(String taboo) {
        this.taboo = taboo == null ? null : taboo.trim();
    }

    public String getMattersAttention() {
        return mattersAttention;
    }

    public void setMattersAttention(String mattersAttention) {
        this.mattersAttention = mattersAttention == null ? null : mattersAttention.trim();
    }

    public String getStoragec() {
        return storagec;
    }

    public void setStoragec(String storagec) {
        this.storagec = storagec == null ? null : storagec.trim();
    }

    public String getTermValidity() {
        return termValidity;
    }

    public void setTermValidity(String termValidity) {
        this.termValidity = termValidity == null ? null : termValidity.trim();
    }

    public String getApprovalNumber() {
        return approvalNumber;
    }

    public void setApprovalNumber(String approvalNumber) {
        this.approvalNumber = approvalNumber == null ? null : approvalNumber.trim();
    }

    public String getProductionCompany() {
        return productionCompany;
    }

    public void setProductionCompany(String productionCompany) {
        this.productionCompany = productionCompany == null ? null : productionCompany.trim();
    }

    public String getProductionAddress() {
        return productionAddress;
    }

    public void setProductionAddress(String productionAddress) {
        this.productionAddress = productionAddress == null ? null : productionAddress.trim();
    }

    public String getEnterprisePhone() {
        return enterprisePhone;
    }

    public void setEnterprisePhone(String enterprisePhone) {
        this.enterprisePhone = enterprisePhone == null ? null : enterprisePhone.trim();
    }

    public String getCourseCycle() {
        return courseCycle;
    }

    public void setCourseCycle(String courseCycle) {
        this.courseCycle = courseCycle == null ? null : courseCycle.trim();
    }
}