package cn.cecook.dao.business.automation;

import java.util.List;

import cn.cecook.model.business.automation.BaseMedicineDosage;

/**
 * 药品用法用量mapper
 * @author majie
 * @date 2018年3月24日-下午3:57:26
 */
public interface BaseMedicineDosageMapper {
	/**
	 * 根据药品名称模糊查询
	 * @param name
	 * @return
	 */
	public List<BaseMedicineDosage> getMedicineByName(String name);
	/**
	 * 根据药品条形码查询药品信息
	 * @param barCode
	 * @return
	 */
	public BaseMedicineDosage getMedicineByBarCode(String barCode);
	/**
	 * 获取所有药品信息
	 * @return
	 */
	public List<BaseMedicineDosage> getAll();
}
