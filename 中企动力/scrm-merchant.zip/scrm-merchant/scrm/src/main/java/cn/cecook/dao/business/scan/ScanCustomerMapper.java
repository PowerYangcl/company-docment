package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.scan.ScanCustomer;
import cn.cecook.model.business.scan.ScanCustomerExample;

public interface ScanCustomerMapper {
    long countByExample(ScanCustomerExample example);

    int deleteByExample(ScanCustomerExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ScanCustomer record);

    int insertSelective(ScanCustomer record);

    List<ScanCustomer> selectByExample(ScanCustomerExample example);

    ScanCustomer selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ScanCustomer record, @Param("example") ScanCustomerExample example);

    int updateByExample(@Param("record") ScanCustomer record, @Param("example") ScanCustomerExample example);

    int updateByPrimaryKeySelective(ScanCustomer record);

    int updateByPrimaryKey(ScanCustomer record);
    
    /**
     * 	根据微博用户id，统计
     * @param uid
     * @return
     */
    int countWbUser(String user_id);
    
    /**
     *	根据微博用户id，获取当前记录 
     * @param user_id
     * @return
     */
    ScanCustomer getByWbUserId(Map<String, Object> map);
    
    /**
     * 	更改人的状态
     * @param type
     */
    void updateType(Map<String, Object> map);

    /**
     * 根据开始时间、结束时间、状态、规则Id、获取微博找人回复线索数量
     * @param startTime
     * @param endTime
     * @param type
     * @param ruleId
     * @return
     */
	List<ScanCustomer> getFindPeoChartList(@Param("startTime") String startTime, @Param("endTime") String endTime,
                                           @Param("type") String type, @Param("ruleId") String ruleId);

	/**
	 * 拿到所有挖掘用户的时间
	 * @return
	 */
	List<Map<String, Object>> getScanCustomerDate();
}