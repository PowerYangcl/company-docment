package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

public interface ScanChatMapper {
	List<Map<String, Object>> getChat(Map<String, Object> param);
	Map<String, Object> getLastWeibo(Map<String, Object> param);	//微博找人表
	Map<String, Object> getWeibo(String statusId);	//微博找事
	void saveChat(Map<String, Object> param);
	/**
	 * 设置微博accessToken
	 * @param param
	 */
	void updateWeiboAccessToken(Map<String, Object> param);
	Map<String, Object> getAccessToken(String tenantId);
	void updateUnbind(String tenantId);
}