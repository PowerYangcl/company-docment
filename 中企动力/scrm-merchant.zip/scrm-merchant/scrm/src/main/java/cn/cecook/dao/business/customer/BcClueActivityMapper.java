package cn.cecook.dao.business.customer;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcClueActivity;
import cn.cecook.model.business.customer.BcClueActivityExample;
import cn.cecook.model.business.customer.BcCustomerAction;
import cn.cecook.uitls.Pages;

/**
 * 
* @explain 活动线索
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcClueActivityMapper {
    int countByExample(BcClueActivityExample example);

    int deleteByExample(BcClueActivityExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcClueActivity record);

    int insertSelective(BcClueActivity record);

    List<BcClueActivity> selectByExample(BcClueActivityExample example);

    BcClueActivity selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcClueActivity record, @Param("example") BcClueActivityExample example);

    int updateByExample(@Param("record") BcClueActivity record, @Param("example") BcClueActivityExample example);

    int updateByPrimaryKeySelective(BcClueActivity record);

    int updateByPrimaryKey(BcClueActivity record);
    
    /**
     *  根据当前登录用户，获取活动名称
     * @param userId
     * @return
     */
    List<Map<String, Object>> getActivity(Map<String, Object> map);
    
    /**
     *  根据活动名称统计
     * @param userId
     * @return
     */
    List<Map<String, Object>> getActivityCount(Map<String, Object> map);
    
    /**
     *  分页统计
     * @param page
     * @return
     */
    List<BcCustomerAction> getPage(Pages<BcCustomerAction> page);
    int count(Map<String, Object> map);
    
    /**
     *  删除活动线索
     * @param id
     */
    void delClueActivity(int id);
    
    /**
     * 	这个用于智能营销线索里面的客户资料
     * @param page
     * @return
     */
    List<Map<String, Object>> getPage2(Pages<Map<String, Object>> page);
    int count2(Map<String, Object> map);
}