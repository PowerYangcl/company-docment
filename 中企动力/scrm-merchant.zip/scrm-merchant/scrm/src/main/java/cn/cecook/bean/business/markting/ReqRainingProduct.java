package cn.cecook.bean.business.markting;

public class ReqRainingProduct {


    private int id;

    private String product_name;

    private String product_id;

    private String product_brand;

    private int count;

    private int unit_price;

    private int contriAmount;

    private int isGift;//是否为赠品1代表是赠品 0代表是货品

    @Override
    public String toString() {
        return "ReqRainingProduct{" +
                "id=" + id +
                ", product_name='" + product_name + '\'' +
                ", product_id='" + product_id + '\'' +
                ", product_brand='" + product_brand + '\'' +
                ", count=" + count +
                ", unit_price=" + unit_price +
                ", contriAmount=" + contriAmount +
                ", isGift=" + isGift +
                '}';
    }

    public int getIsGift() {
        return isGift;
    }

    public void setIsGift(int isGift) {
        this.isGift = isGift;
    }

    public int getContriAmount() {
        return contriAmount;
    }

    public void setContriAmount(int contriAmount) {
        this.contriAmount = contriAmount;
    }

    public int getUnit_price() {
        return unit_price;
    }

    public void setUnit_price(int unit_price) {
        this.unit_price = unit_price;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getProduct_name() {
        return product_name;
    }

    public void setProduct_name(String product_name) {
        this.product_name = product_name;
    }

    public String getProduct_id() {
        return product_id;
    }

    public void setProduct_id(String product_id) {
        this.product_id = product_id;
    }

    public String getProduct_brand() {
        return product_brand;
    }

    public void setProduct_brand(String product_brand) {
        this.product_brand = product_brand;
    }

    public int getCount() {
        return count;
    }

    public void setCount(int count) {
        this.count = count;
    }
}
