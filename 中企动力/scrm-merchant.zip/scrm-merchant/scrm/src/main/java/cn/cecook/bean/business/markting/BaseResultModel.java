package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import cn.cecook.uitls.ConfigUtil;

import java.io.Serializable;

/**
 * 
 * @Title BaseResultModel.java
 * @Description
 * @author wschenyongyin
 * @date 2017年5月23日
 * @version 1.0
 */
@Component
public class BaseResultModel implements Serializable {
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	// 错误代码
	private String error_code;
	// 错误描述
	private String error_msg;
	
	private final String file_url="";
	
	private int totalCount;

	private Object data;

	public String getFile_url() {
		return file_url;
	}

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public String getError_code() {
		return error_code;
	}

	public void setError_code(String error_code) {
		this.error_code = error_code;
	}

	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "BaseResultModel [error_code=" + error_code + ", error_msg="
				+ error_msg + ", data=" + data + "]";
	}

}
