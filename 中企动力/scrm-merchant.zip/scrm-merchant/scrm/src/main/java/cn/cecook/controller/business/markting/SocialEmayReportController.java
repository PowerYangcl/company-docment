package cn.cecook.controller.business.markting;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.SocialEmayReportService;
import cn.cecook.thirdparty.emay.EmaySmsUtils;
import cn.cecook.uitls.FastJsonUtil;

/**
 * 
 * @Title SocialEmayReportController.java
 * @Description 提供给易美推送数据
 * @author wschenyongyin
 * @date 2017年9月21日
 * @version 1.0
 */

@Controller
@RequestMapping("/emay")
public class SocialEmayReportController {

	@Autowired
	SocialEmayReportService socialEmayReportService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create() {
//		String responseString=EmaySmsUtils.getInstance().doGetRequest("http://hprpt2.eucp.b2m.cn:8080/sdkproxy/getreport.action?cdkey=EUCP-EMY-SMS1-0FKFJ&password=D12D45F78EEB14B0");
//		return socialEmayReportService.EmayReport(GsonTools
//				.createJsonString(EmaySmsUtils.getReports(responseString)));
        return null;
	}

}
