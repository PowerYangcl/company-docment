package cn.cecook.dao.business.markting;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.CouponBatchClickStatistics;
import cn.cecook.bean.business.markting.WriteOffBean;
import cn.cecook.model.business.markting.BmWriteOff;
import cn.cecook.model.business.markting.BmWriteOffExample;

public interface BmWriteOffMapper {
    int countByExample(BmWriteOffExample example);

    int deleteByExample(BmWriteOffExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmWriteOff record);

    int insertSelective(BmWriteOff record);

    List<BmWriteOff> selectByExample(BmWriteOffExample example);

    BmWriteOff selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmWriteOff record, @Param("example") BmWriteOffExample example);

    int updateByExample(@Param("record") BmWriteOff record, @Param("example") BmWriteOffExample example);

    int updateByPrimaryKeySelective(BmWriteOff record);

    /**
     * 查询列表
     * @param map
     * @return
     */
    List<WriteOffBean> queryBmWriteOffList(Map<String, Object> map);

    /**
     * 反核销(更新)
     * @param map
     * @return
     */
    int ReverseWriteOff(Map<String, Object> map);

    /**
     * 核销编辑
     * @param map
     * @return
     */
    int editorWriteOff(Map<String, Object> map);

    /**
     * 查询第一次消费时间
     * @param map
     * @return
     */
    Date firstTime(Map<String, Object> map);

    /**
     * 消费总额
     * @param map
     * @return
     */
    int amount(Map<String, Object> map);

    /**
     * 顾客消费次数
     * @param record
     * @return
     */
    int count(long customer_id);

    /**
     * 最后一次消费时间
     * @param map
     * @return
     */
    Date lastTime(Map<String, Object> map);

    /**
     * 
    * Title: activityAmount
    * Description:统计活动的总金额
    * @param activity_id 活动id
    * @return
     */
    double activityAmount(long activity_id);
    
    double activityAmount2(long activity_id);

    int countActivity(@Param("activity_id") long activity_id);
    int countActivity2(@Param("activity_id") long activity_id);

    /**
     * 根据客户id查询第一条消费记录  
     * @param map
     * @return
     */
    WriteOffBean firstRecord(Map<String, Object> map);

    /**
     * 根据客户id查询最近一条消费记录
     * @param map
     * @return
     */
    WriteOffBean lastRecord(Map<String, Object> map);

    List<WriteOffBean> getActivityWriteOffList(Map<String, Object> map);

    /**
     * 更新核销状态id
     */
    int updateBmstatus(long coupon_id);

    /**
     * 判断是否已经反核销
     * 
     */
    int selectStat(long coupon_id);
    
    
    int deleted(long id);
    
    /**
     * 查询所有核销记录
     */
    List<WriteOffBean> queryAll(Map<String, Object> map);
    
    /**
     * 查询核销总数
     */
    int queryCount();
    
    /**
     * 按条件查询时查询的总数  
     */
    int seachCount(Map<String, Object> map);
    
    
    /**
     * 查询客户第一次消费距离现在时间
     */
    int distanceFirstConsume(long customer_id);
    
    /**
     * 查询客户第一次消费距离现在时间
     */
    int distanceLastConsume(long customer_id);
    
    /**
     * 
    * Title: queryDimensionCount
    * Description:客户维度查询核销次数
    * @return
     */
    int queryDimensionCount(Map<String, Object> map);
    //查询第一次消费时间 、距离现在多少天   查询上一次消费时间  及距离现在多少天
    Map<String,Object> queryConsumeTime(long id);
    //根据短信批次查询核销列表
    List<CouponBatchClickStatistics> getWriteOffListByCouponBatch(Map<String,Object> map);
    
    int countByCouponBatchId(int batchId);
    
    List<CouponBatchClickStatistics> getListByCouponId(Map<String,Object> map);
    
   int countTotalByCouponId(int socialCouponId);
   
   List<Map<String,Object>> countByCity(Map<String,Object> map);
   int countTotalByCity(Map<String,Object> map);
   
   List<Map<String,Object>> countByHour(@Param("time") String time,@Param("keyWord") String keyWord);
   
   List<Map<String,Object>> countByWeek();
   
   List<Map<String,Object>> countByMonth(Map<String,Object> map);
   
   List<Map<String,Object>> countByYear(Map<String,Object> map);
    
}