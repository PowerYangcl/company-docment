package cn.cecook.dao.system;

import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysPersonInfo;

/**
 * 
 * @explain 
 * @author ZHIWEN
 * @author 2017年6月5日 下午8:46:31
 */
public interface SysPersonInfoMapper {
  SysPersonInfo PersonInfoFindById(Long id)throws Exception;
  int Updata_Hobby(@Param(value = "id") Long id, @Param(value = "hobby") String hobby)throws Exception;
  int Updata_account(@Param(value = "id") Long id, @Param(value = "account") String account)throws Exception;
  int Update_PasswordByIdAndPassword(Map<String, Object> map);
  String select_UserByIdAndPassword(Map<String, Object> map);
  int Update_NameAndEmail(@Param(value = "id") Long id, @Param(value = "name") String name, @Param(value = "email") String email)throws Exception;
}
