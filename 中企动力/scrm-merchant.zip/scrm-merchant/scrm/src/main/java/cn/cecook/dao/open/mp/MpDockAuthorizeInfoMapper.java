package cn.cecook.dao.open.mp;

import org.apache.ibatis.annotations.Param;	

public interface MpDockAuthorizeInfoMapper {
    boolean isCRMer(@Param(value = "tenant_id") String tenant_id);
}