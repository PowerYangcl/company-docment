package cn.cecook.controller.business.markting;
import cn.cecook.uitls.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.*;
import java.util.Date;
import java.util.Iterator;

@Controller
@RequestMapping("/api/profile")
public class FileUpload {

	@RequestMapping(value = "/uploadBasicHead", produces = "text/plain;charset=UTF-8")  
	 @ResponseBody  
	 public String ajaxUpload(HttpServletRequest request) throws IllegalStateException,  
	   IOException {  
		System.out.println("------------>");
	  MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;  
	  String fileName = "";  
	  String uploadPath = "uploadFile/head/";  
	  String path =request.getSession().getServletContext().getRealPath("/")+uploadPath;    
	  /*File uploadPathFile = new File(path); 
	  if (!uploadPathFile.exists()) {   
	   uploadPathFile.mkdir();   
	     }*/  
	  String realPath = "";  
	  for (Iterator it = multipartRequest.getFileNames(); it.hasNext();) {  
	   String key = (String) it.next();  
	   MultipartFile mulfile = multipartRequest.getFile(key);  
	   fileName = mulfile.getOriginalFilename();  
	   fileName = handlerFileName(fileName);  
	   File file = new File(path + "---------->");  
	   mulfile.transferTo(file);  
	  }  
	   realPath = "{\"imagePath\":\""+uploadPath+fileName+"\"}";  
	  return realPath;  
	 }  
	  
	//文件名称处理  
	private String handlerFileName(String fileName) {  
	  //处理名称start  
	  fileName = (new Date()).getTime()+"_"+fileName;  
	//时间戳+文件名，防止覆盖重名文件  
	  String pre = StringUtils.substringBeforeLast(fileName, ".");  
	  String end = StringUtils.substringAfterLast(fileName, ".");  
	  fileName ="sssssss"+"."+end;//用MD5编码文件名，解析附件名称  
	  //处理名称end  
	  return fileName;  
	 }  
	  
	//预览，获取图片流  
	@RequestMapping(value = "profile/readImage", produces = "text/plain;charset=UTF-8")  
	    public void readImage(HttpServletRequest request, HttpServletResponse response){  
	     String imagePath = request.getSession().getServletContext().getRealPath("/")+request.getParameter("imagePath");  
	     try{  
	      File file = new File(imagePath);  
	         if (file.exists()) {  
	           DataOutputStream temps = new DataOutputStream(response  
	             .getOutputStream());  
	           DataInputStream in = new DataInputStream(  
	             new FileInputStream(imagePath));  
	           byte[] b = new byte[2048];  
	           while ((in.read(b)) != -1) {  
	     temps.write(b);  
	     temps.flush();  
	           }  
	           in.close();  
	           temps.close();  
	         }   
	       } catch (Exception e) {  
	        e.printStackTrace();  
	       }  
	    }  
}
