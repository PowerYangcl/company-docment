package cn.cecook.dao.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.system.AuthorityModel;
import cn.cecook.model.system.SysAuthority;
import cn.cecook.model.system.SysRoleAuthority;
import cn.cecook.model.system.SysRoleAuthorityExample;
import cn.cecook.model.system.SysUser;
import cn.cecook.model.system.SysUserRole;

/**
 * 
* @explain 角色-权限映射表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysRoleAuthorityMapper {
    int countByExample(SysRoleAuthorityExample example);

    int deleteByExample(SysRoleAuthorityExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SysRoleAuthority record);

    int insertSelective(SysRoleAuthority record);

    List<SysRoleAuthority> selectByExample(SysRoleAuthorityExample example);

    SysRoleAuthority selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SysRoleAuthority record, @Param("example") SysRoleAuthorityExample example);

    int updateByExample(@Param("record") SysRoleAuthority record, @Param("example") SysRoleAuthorityExample example);

    int updateByPrimaryKeySelective(SysRoleAuthority record);

    int updateByPrimaryKey(SysRoleAuthority record);
    
    //查询所有权限
	List<SysAuthority> selectAuthorityByUid(Map<String, Object> map);
	
	//根据parentId查询权限
	ArrayList<SysAuthority> selectAuthorityByParentCode(Map<String, Object> map);
	
	//根据roleId查询某个角色的权限
	ArrayList<SysRoleAuthority> selectAuthorityByRoleId(Map<String, Object> map);

	//根据role删除
	int deleteByRoleId(Map<String, Object> map);
	
	//根据id查询权限
	SysAuthority selectAuthorityById(Map<String, Object> map);

	//更新删除状态
	int updateDelByRoleId(Map<String, Object> map);

	//插入
	int insertAuth(SysRoleAuthority sra);
	
	//查询基本权限
	List<SysAuthority> selectBaseAuth();
	//<!-- 查询模块下的权限分组 -->
	List<AuthorityModel> ListAuthorityGroup();
	List<AuthorityModel> ListAuthorityGroupByTenantId(String tenantId);
	
	//根据刚插入的角色获取全部的该角色对应的用户
	List<SysUserRole> getAllUserByRoleId(Long roleId);
	
	//根据role_id和authority_id恢复权限 
	int restoreByAuthIdsAndRoleId(Map<String,Object> map);
}