package cn.cecook.model.business.automation;
/**
 * 会员触发行为
 * @author majie
 *
 * 2018年1月22日-下午5:16:37
 */
public enum TriggerAction {
	//创建新会员、购买商品、购买金额、生日、储值
	CREATE_CUSTOMER,BUY_GOODS,BUY_PRICE,BIRTHDAY,BALANCE
}
