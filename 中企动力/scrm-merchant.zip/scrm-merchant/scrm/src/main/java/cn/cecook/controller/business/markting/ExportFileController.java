package cn.cecook.controller.business.markting;


import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.business.markting.StatisticsBean;
import cn.cecook.dao.business.markting.BmActivityBrowseMapper;
import cn.cecook.uitls.ExportExcel;
import cn.cecook.uitls.FastJsonUtil;

@Controller
@RequestMapping("/api/export")
public class ExportFileController {
	@Resource
	private BmActivityBrowseMapper bmActivityBrowseMapper;
	
	
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		Map<String, Object> map = new HashMap<String, Object>();
		map.put("activity_id", 273);
		map.put("startIndex", 0);
		map.put("pageSize", 100);
		map.put("activity_type", 1);
		map.put("orderBy", "t1.create_time desc");
//		ExportExcel<BrowseBean> ee= new ExportExcel<BrowseBean>(); 
//		
//		List<BrowseBean> dataList=new ArrayList<BrowseBean>();
		
		
		ExportExcel<StatisticsBean> ee = new ExportExcel<StatisticsBean>();
		List<StatisticsBean> dataList = new ArrayList<StatisticsBean>();
//		System.out.println("datalist----->"+GsonTools.createJsonString(dataList));
		
		
		
//		for(int i=1;i<10;i++){
//			BrowseBean browseBean=new BrowseBean();
//			browseBean.setName(1+i+"");
//			browseBean.setPhone(1000+i+"");
//			browseBean.setBrowse_ip(10000+i+"");
//			browseBean.setEmail("短信批次"+i);
//			browseBean.setWeibo("2017-09-"+i);
//			browseBean.setWechat("wechat"+i);
//			browseBean.setGener("nan"+i);
//			browseBean.setCreate_time("2017.8.9 :"+i);
//			dataList.add(browseBean);
//		}
		
		for(int i=0;i<11;i++){
			StatisticsBean statisticsBean=new StatisticsBean();
			statisticsBean.setConverNum(1+i+"");
			statisticsBean.setOpenNum(1000+i+"");
			statisticsBean.setSendNum(10000+i+"");
			statisticsBean.setName("短信批次"+i);
			statisticsBean.setConvertTime("2017-09-"+i);
			dataList.add(statisticsBean);
			
		}
		
		System.out.println(FastJsonUtil.createJsonString(dataList));
		
//        String[] headers = { "姓名", "电话", "ip地址" ,"邮箱","微博","微信","性别","时间"};  
//        String fileName = "活动浏览表";  
		String[] headers = { "批次名称", "发送量", "点击量", "转化量", "转化日期" };
		String fileName = "短信统计" ;
        ee.exportExcel(headers,dataList,fileName,response);  
				return response;
		
	}
}
