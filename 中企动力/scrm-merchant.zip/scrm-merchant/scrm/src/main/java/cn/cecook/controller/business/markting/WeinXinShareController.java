package cn.cecook.controller.business.markting;


import org.apache.http.HttpException;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.uitls.JssdkUtils;

import java.net.URISyntaxException;

@Controller
@RequestMapping("/api/weixin")
public class WeinXinShareController {
	@RequestMapping(value = "/share")
	@ResponseBody
	public Object edit(String url) throws URISyntaxException, HttpException {
		return (JssdkUtils.getInstance().getInfo(url));
	}
}
