package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysDepartment;
import cn.cecook.model.system.SysDepartmentExample;
import cn.cecook.model.system.SysUser;
import cn.cecook.uitls.Pages;

/**
 * 
* @explain 部门表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysDepartmentMapper {
    int countByExample(SysDepartmentExample example);

    int deleteByExample(SysDepartmentExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SysDepartment record);

    int insertSelective(SysDepartment record);

    List<SysDepartment> selectByExample(SysDepartmentExample example);

    SysDepartment selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SysDepartment record, @Param("example") SysDepartmentExample example);

    int updateByExample(@Param("record") SysDepartment record, @Param("example") SysDepartmentExample example);

    int updateByPrimaryKeySelective(SysDepartment record);

    int updateByPrimaryKey(SysDepartment record);
    /**
     * sunny
     * 查询部门主管列表资料
     * @author sunny
     */
    List<Map<String, Object>> sysDepartmentDetailList(Pages<Map<String, Object>> pages);
    /**
     * sunny
     *查询部门主管列表显示账户总数
     */
    int sysDepartmentDetailListCount(Map<String, Object> where);
    /**
     * sunny
     *更新leadID
     */
    int updateleaderIdById(SysDepartment sysDepartment);
    /**
     * sunny
     *更新departmentId
     */
    int updatedepartmentIdById(SysUser sysUser);
    /**
     * 
     * @explain 根据上级部门id查询子部门数量
     * @author LeeX
     * @date 2017年6月16日 下午8:18:34
     */
	int selectCountByPid(Map<String, Object> map);
	/**
	 *
	 * @explain 查询部门id和租户id
	 * @author LeeX
	 * @date 2017年6月20日 下午9:06:47
	 */
	SysDepartment selectDepartmentById(Map<String, Object> map);
	/**
	 *
	 * @explain 更新删除
	 * @author LeeX
	 * @date 2017年6月21日 上午10:11:11
	 */
	int updateIsDeletedByDepart(SysDepartment sysDepartment);
    /**
     * sunny
     *查询部門主管即leadID
     */
    Map<String, Object> findLeadId(@Param("department_id") Long department_id, @Param("tenant_id") String tenant_id);

   /**
    * sunny
    *查询部成员
    */
    List<Map<String, Object>> findMember(@Param("department_id") Long department_id, @Param("tenant_id") String tenant_id);

  /**
	 * 
	 * @explain 删除所有部门成员
	 * @author sunny
	 * @date 2017年6月21日 上午10:11:11
	 */
    int updatedepartmentIdBydepartment_id(Long department_id);

  /**
   * 根据租户ID查询所有的部门
   * @param tenant_id
   * @param bmIdForEdit
   * @return
   */
    List<Map<String, Object>> getAllChildNode2(@Param(value="startIndex")Object startIndex,
    		                                  @Param(value="pageSize") Object pageSize,
    		                                  @Param(value="tenant_id")String tenant_id);
    List<Map<String, Object>> getAllChildNode(String tenant_id);
//Map<String, Object> findLeadId(Long department_id, String tenant_id);
//
//Map<String, Object> findMember(Long department_id, String tenant_id);



}