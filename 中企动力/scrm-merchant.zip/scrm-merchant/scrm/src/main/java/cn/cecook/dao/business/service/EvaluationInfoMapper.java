package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.EvaluationInfo;

/**
 * 
 * @作者	马杰
 * @时间	2017年5月13日-下午4:47:46
 * @介绍	dao方法接口
 */
@Repository("evaluationInfoMapper")
public interface EvaluationInfoMapper {	
	/**
	 * 查询(可分页)
	 * @param EvaluationInfo	条件模糊查询
	 * @return
	 */
	public List<EvaluationInfo> findAll(Map<String, Object> map);
	/**
	 * 获取记录总数
	 * @param EvaluationInfo	多条件获取
	 * @return
	 */
	public Integer getCount(Map<String, Object> map);
	/**
	 * 添加
	 * @param EvaluationInfo
	 * @return
	 */
	public int addEvaluationInfo(EvaluationInfo evaluationInfo);
	/**
	 * 删除信息
	 * @param id
	 * @return
	 */
	public int delete(int id);
	/**
	 * 查询单条记录
	 * @param EvaluationInfo
	 * @return
	 */
	public EvaluationInfo findOne(EvaluationInfo evaluationInfo);
	/**
	 * 修改信息
	 * @return
	 */
	public int update(EvaluationInfo evaluationInfo);
	/**
	 * 根据id获取评价信息
	 * @param id
	 * @return
	 */
	public EvaluationInfo findById(Integer id);
	/**
	 * 判断是否已经评价
	 * @param id
	 * @return
	 */
	public Integer findByOrderId(String orderId);

	public int isEvaluateByOrderId(@Param("id") int id, @Param("tenantId") String tenantId);
	
}
