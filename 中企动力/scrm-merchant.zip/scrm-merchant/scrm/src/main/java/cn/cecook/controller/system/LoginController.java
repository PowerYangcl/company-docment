package cn.cecook.controller.system;



import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import jdk.nashorn.internal.ir.annotations.Ignore;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.aspectj.weaver.ast.Var;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.AuthorityModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.dao.system.SysLoginLogMapper;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.system.SysAuthority;
import cn.cecook.model.system.SysLoginLog;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.system.IAccountService;
import cn.cecook.service.system.ILoginService;
import cn.cecook.thirdparty.weibo.model.User;
import cn.cecook.uitls.AESUtil;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.LoginUtil;
import cn.cecook.uitls.MD5Util;
import cn.cecook.uitls.StringUtils;


/**
 * @author LeeX
 * @explain
 * @date 2017年5月24日
 */
@Controller
@RequestMapping("/api/login")
public class LoginController {
    @Resource
    ILoginService loginService;
    @Autowired
    private IAccountService iAccountService;
    @Resource
    SysLoginLogMapper logMapper;

    /**
     * 租户通过用户名和密码直接登录
     *
     * @explain
     * @author LeeX
     * @date 2017年5月24日 上午11:05:53
     */
    @RequestMapping(value = "/login", method = RequestMethod.POST)
    @ResponseBody
    public Object login(HttpServletRequest request, HttpServletResponse response) {
        //对象参数
        ResultModel resultModel = new ResultModel();
        AccountModel accountModel = new AccountModel();
        SysLoginLog log = new SysLoginLog();

        //需要的请求参数
        String account = request.getParameter("account");
        String password = request.getParameter("password");
        String sCode = request.getParameter("sCode");

        //10天登录参数
        String ten_login = request.getParameter("ten_login");
        Date date = new Date();
        /**验证码暂时屏蔽
        if (StringUtils.isBlank(sCode)) {
            resultModel.setError_code(ConfigStatusCode.LOSE_PARAMETER);
            resultModel.setError_msg("安全码不能为空");
            return (resultModel);
        }

        HttpSession session = request.getSession();
        String code = (String) session.getAttribute("rand");
        if (!sCode.equalsIgnoreCase(code) && !sCode.equals("1990")) {
            resultModel.setError_code(ConfigStatusCode.LOSE_PARAMETER);
            resultModel.setError_msg("安全码有误");
            return (resultModel);
        }
        **/
        if (StringUtils.isBlank(account) || StringUtils.isBlank(password)) {
            resultModel.setError_code(ConfigStatusCode.LOSE_PARAMETER);
            resultModel.setError_msg("登录失败，用户名和密码不能为空");
            return (resultModel);
        }

        //密码二次加密
        password = MD5Util.encodeString(MD5Util.encodeString(password) + ConfigUtil.MD5_PWD_STR);

        //封装
        accountModel.setAccount(account);
        accountModel.setPassword(password);
        accountModel.setTen_login(ten_login);

        //传入service
        try {
            resultModel = loginService.login(request, response, accountModel);
            //登陆状态
            log.setLoginStatus(1);
        } catch (Exception e1) {
            //登陆状态
            log.setLoginStatus(0);
            resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
            resultModel.setError_msg("登陆异常，请联系管理员");
            e1.printStackTrace();
        }
        //ip
        String ipAddr = LoginUtil.getIpAddr(request);
        log.setLoginIp(ipAddr);
        //账户
        log.setRemarks(account);
        //时间
        log.setLoginTime(date);
        //失败原因
        log.setFailureReason(resultModel.getError_msg());
        //退出时间,默认十天以后
        if ("0".equals(resultModel.getError_code())) {
            if (ConfigUtil.TEN_LOGIN_STR.equals(ten_login)) {
                log.setLogoutTime(DateUtils.afterNDay(10));
            } else {
                log.setLogoutTime(DateUtils.afterNDay(1));
            }
        }

        //获取登陆账户
        String uid = resultModel.getUid();
        if (!StringUtils.isBlank(uid)) {
            log.setUserId(Long.parseLong(uid));
        } else {
            log.setUserId(0l);
        }
        logMapper.insertSelective(log);

        Cookie logCK = new Cookie("logid", String.valueOf(log.getId()));
        if (ConfigUtil.TEN_LOGIN_STR.equals(ten_login)) {
            logCK.setMaxAge(ConfigUtil.COOKIE_TIME_TEN);
        } else {
            logCK.setMaxAge(24 * 60 * 60 * 60);
        }
        logCK.setPath("/");
        response.addCookie(logCK);

        return resultModel;


    }


    /**
     * @explain 手机验证码登录
     * @author LeeX
     * @date 2017年5月31日 上午8:31:59
     */
    @RequestMapping(value = "/code", method = RequestMethod.POST)
    public @ResponseBody
    Object loginCode(HttpServletRequest request, HttpServletResponse response) {
        //对象参数
        ResultModel resultModel = new ResultModel();
        AccountModel accountModel = new AccountModel();
        SysLoginLog log = new SysLoginLog();

        //获取用户名和手机验证码
        String account = request.getParameter("account");
        String sms_code = request.getParameter("ver_code");
        //String ten_login = request.getParameter("ten_login");
        Date date = new Date();

        //封装accountModel
        accountModel.setAccount(account);
        accountModel.setSms_code(sms_code);
        //accountModel.setTen_login(ten_login);

        //传service查询
        try {
            resultModel = loginService.loginVercode(request, response, accountModel);
        } catch (Exception e1) {
            //系统异常
            resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
            resultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
            e1.printStackTrace();
        }

        //ip
        String ipAddr = LoginUtil.getIpAddr(request);
        log.setLoginIp(ipAddr);
        //账户
        log.setRemarks(account);
        //时间
        log.setLoginTime(date);
        //失败原因
        log.setFailureReason(resultModel.getError_msg());
        //退出时间,默认十天以后
        if ("0".equals(resultModel.getError_code())) {
            log.setLogoutTime(DateUtils.afterNDay(1));
        }

        //获取登陆账户
        log.setUserId(Long.parseLong(resultModel.getUid()));
        logMapper.insertSelective(log);

        Cookie logCK = new Cookie("logid", String.valueOf(log.getId()));
        logCK.setMaxAge(24 * 60 * 60 * 60);
        logCK.setPath("/");
        response.addCookie(logCK);

        return (resultModel);
    }


    @RequestMapping(value = "/exit", method = RequestMethod.POST)
    public @ResponseBody
    Object exit(HttpServletRequest request, HttpServletResponse response) {
        //对象参数
        ResultModel resultModel = new ResultModel();
        if (!MyCatFilter.getToken_Valid()) {
            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
            resultModel.setError_msg("请重新登录");
            return (resultModel);
        }
        Cookie[] cookies = request.getCookies();
        Map cookieSet = CookieUtil.getCookieSet(cookies);
        try {
            loginService.exit(cookieSet);
            //获取cookie中的直
            for (Cookie cookie : cookies) {
                //删除cookie
                cookie.setValue(null);
                cookie.setMaxAge(0);
                cookie.setPath("/");
                response.addCookie(cookie);
            }
            resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
            resultModel.setError_msg("已退出");
        } catch (Exception e) {
            e.printStackTrace();
            resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
            resultModel.setError_msg("退出失败");
            return (resultModel);
        }

        return (resultModel);
    }

    /**
     * @explain 第一次登陆展示信息
     * @author LeeX
     * @date 2017年6月28日 下午4:25:21
     */
    @RequiresPermissions("login")
    @RequestMapping(value = "/perInforShow", method = RequestMethod.POST)
    @ResponseBody
    public Object perInforShow(HttpServletRequest request, HttpServletResponse response,Integer startIndex, Integer pageSize) {
        //对象参数
        ResultModel resultModel = new ResultModel();
        if (!MyCatFilter.getToken_Valid()) {
            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
            resultModel.setError_msg("请重新登录");
            return (resultModel);
        }
        return loginService.perInforShow(CookieUtil.getCookieSet(request.getCookies()),startIndex,pageSize);
    }

    @RequiresPermissions("login")
    @RequestMapping(value = "/toSaveStoreId", method = RequestMethod.POST)
    @ResponseBody
    public Object toSaveStoreId(HttpServletRequest request, HttpServletResponse response) {
    	//获取session中当前用户所属店铺(单个)
        Subject subject = SecurityUtils.getSubject();
    	Session session = subject.getSession();
    	String storeId = request.getParameter("storeId");
    	session.setAttribute("curUserStoreId", storeId);
        //对象参数
        ResultModel resultModel = new ResultModel();
        if (!MyCatFilter.getToken_Valid()) {
            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
            resultModel.setError_msg("请重新登录");
            return (resultModel);
        }
        return null;
    }
    
    
    /**
     * @return Object
     * @author LeeX
     * @time 2017年7月20日 上午9:04:25
     * @params updateHobby
     */
    @RequiresPermissions("login")
    @RequestMapping(value = "/updateHobby", method = RequestMethod.POST)
    public @ResponseBody
    Object updateHobby(HttpServletRequest request, HttpServletResponse response, SysUser user) {
        //对象参数
        ResultModel resultModel = new ResultModel();
        if (!MyCatFilter.getToken_Valid()) {
            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
            resultModel.setError_msg("请重新登录");
            return (resultModel);
        }
        resultModel = loginService.updatePerInfo(CookieUtil.getCookieSet(request.getCookies()), user);
        return (resultModel);
    }
    
    
    /**
     * @explain 首次加载页面时，根据用户点击的一级菜单权限ID，从登陆用户角色对应的所有的权限中匹配其对应的二级菜单和分类
     * @author zhangHao
     * @date 2017年6月28日 下午4:25:21
     */
    @SuppressWarnings("unchecked")
	@RequiresPermissions("login")
    @RequestMapping(value = "/getAuthFromSession", method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Object getAuthFromSession(HttpServletRequest request, HttpServletResponse response) {
        //对象参数
        ResultModel resultModel = new ResultModel();
//        if (!MyCatFilter.getToken_Valid()) {
//            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
//            resultModel.setError_msg("请重新登录");
//            return (resultModel);
//        }
        //需要的请求参数
        String menuId = request.getParameter("menuId");
        String searchMenuName = request.getParameter("searchMenuName");
        
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        List<AuthorityModel> authsChildren = new ArrayList<AuthorityModel>();
        List<AuthorityModel> auths = (List<AuthorityModel>) session.getAttribute("auths");
//        if(!"".equals(menuId)){
        for(int i=0;i<auths.size();i++){
        	if(menuId.equals(String.valueOf(auths.get(i).getParentCode()))){
        		authsChildren.add(auths.get(i));
        	}
        }
//        }else{
//        	authsChildren.addAll(auths);
//        }
        //如果用户搜索的参数不为空字符串或者为null
        if(!"".equals(searchMenuName) && searchMenuName != null){
        	List<AuthorityModel> searchList = new ArrayList<AuthorityModel>();
        	for(int i=0;i<authsChildren.size();i++){
        		if(authsChildren.get(i).getName().indexOf(searchMenuName.trim()) != -1){
        			searchList.add(authsChildren.get(i));
        		}
        	}
        	authsChildren = searchList;
        }
        
        if(authsChildren != null && authsChildren.size() > 0){
        	resultModel.setList(authsChildren);
            resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
            resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
        }
        return resultModel;
    }
    
    
    /**
     * @explain 获取全部的url，用于判断是否是最后一页
     * @author zhangHao
     * @date 2017年6月28日 下午4:25:21
     */
    @SuppressWarnings("unchecked")
	@RequiresPermissions("login")
    @RequestMapping(value = "/getAllUrl", method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
    @ResponseBody
    public Object getAllUrl(HttpServletRequest request, HttpServletResponse response) {
        //对象参数
        ResultModel resultModel = new ResultModel();
        if (!MyCatFilter.getToken_Valid()) {
            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
            resultModel.setError_msg("请重新登录");
            return (resultModel);
        }
        List<Map<String,Object>> list = loginService.getAllUrl();
        if(list != null && list.size() > 0){
        	resultModel.setList(list);
            resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
            resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
        }else{
            resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
            resultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
        }
        return resultModel;
    }
    
    
	// 用于获取全部二级菜单列表
	@RequestMapping(value = "/menuTwos")
	@ResponseBody
	public Object getMenuTwos(String keyWord,HttpServletRequest request, HttpServletResponse response) {
        String tenant_id = request.getParameter("tenant_id");
        String uid = request.getParameter("uid");
		return loginService.getMenuTwos(keyWord,tenant_id,uid);

	}
    
	//判断token是否存在，是否过期接口，如果存在且未过期，根据token按规则生成ticket
	@RequestMapping(value = "/validateToken")
	@ResponseBody
	public Object validateToken(HttpServletRequest request, HttpServletResponse response){
        //对象参数
         ResultModel resultModel = new ResultModel();
		
		 SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		 String token = request.getParameter("token");
		 //根据token获取account、password、third_token_expiry_time
		 Map<String, Object> map = loginService.selectSysUserByToken(token);
		 //将当前日期与token的失效时间进行比对
		 Date date = new Date();
		 //如果token对应的用户存在且token的失效时间大于当前时间
		 if(map != null){
			 String expiryTime = String.valueOf(map.get("third_token_expiry_time"));
			 int i = sf.format(date).compareTo(expiryTime); 
			 //如果当前日期大于过期时间
			 if(i > 0){
		         resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
		         resultModel.setError_msg("token已过期");
			 }else{
				 //按ASE加密规则生成ticket
				 String ticket = AESUtil.encode(token,ConfigUtil.THIRD_TOKEN_PASSWORD);
		    	 //返回tickt
		    	 resultModel.setTicket(ticket);
		         resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		         resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			 }
		 }
		 return resultModel;
	}
	
	//根据用户名、密码、创建时间生成token，更新数据库
	@RequestMapping(value = "/createToken")
	@ResponseBody
	public Object createToken(HttpServletRequest request, HttpServletResponse response){
        //对象参数
        ResultModel resultModel = new ResultModel();
        
		//用户名
		String account =  request.getParameter("account");
		//密码
		String password = request.getParameter("password");
		//过期时间
		String expiryTime = request.getParameter("expiryTime");
        //密码二次加密
        password = MD5Util.encodeString(MD5Util.encodeString(password) + ConfigUtil.MD5_PWD_STR);
        //根据手机号查询用户
		SysUser user = loginService.selectSysUserByAccount(account);
		
		//如果查询出的用户不为空，并且密码和参数中的密码一致
        if(user != null && user.getPwd().equals(password)){
            //根据用户名查询数据库，根据加密后的密码进行匹配，如果匹配的上，根据用户名生成token
    		String token = MD5Util.encodeStringDouble(account);
    		//根据account,token,过期时间，更新数据库
    		loginService.updateUserToken(account,token,expiryTime);
    		//返回token
    		resultModel.setToken(token);
            resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
            resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
        }else{
            resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
            resultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
        }
        return resultModel;
	}
	
	/**
	 * 根据ticket全局票据，按规则解析成token，根据token从DB拿到用户名密码，
	 * 根据用户名密码进行授权操作。更新token失效时间为当前时间。转发到登陆页面
	 * @return
	 */
    @RequestMapping("/main")
	public ModelAndView validateTicket(HttpServletRequest request, HttpServletResponse response){
        //对象参数
        AccountModel accountModel = new AccountModel();
		String ticket = request.getParameter("ticket");
		ModelAndView modelAndView = new ModelAndView();
		
		SimpleDateFormat sf = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		try {
		//解密ticket为token
		String token = AESUtil.decode(ticket,ConfigUtil.THIRD_TOKEN_PASSWORD);
		//根据token获取account、password、third_token_expiry_time
		Map<String, Object> map = loginService.selectSysUserByToken(token);
		//将当前日期与token的失效时间进行比对
		Date date = new Date();
		String expiryTime = String.valueOf(map.get("third_token_expiry_time"));
		int i = sf.format(date).compareTo(expiryTime); 
		 //如果当前日期大于过期时间，直接捕获异常，给用户没有该功能权限的提示
		if(i > 0){
			throw new RuntimeException();
		}
		String account = String.valueOf(map.get("account"));
		String password = String.valueOf(map.get("pwd"));
        //封装
        accountModel.setAccount(account);
        accountModel.setPassword(password);
		loginService.login(request, response, accountModel);
		//更新该用户对应的token的失效时间为当前时间
		loginService.updateUserToken(account, token, sf.format(date));
		modelAndView = toMainPage(request);
		} catch (Exception e) {
			//e.printStackTrace();
			modelAndView = new ModelAndView("403");
			return modelAndView;
		}
		return modelAndView;
	}
    
    /**
     * 主页面需要的参数，MainView
     * @param httpServletRequest
     * @return
     */
    public ModelAndView toMainPage(HttpServletRequest httpServletRequest) {
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        String uid = String.valueOf(session.getAttribute("userId"));
        String tenantId = String.valueOf(session.getAttribute("tenantId"));

        ModelAndView modelAndView = new ModelAndView("main");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        String sign = MD5Util.encodeString(MD5Util.encodeString("api_crm_anPOSCrmGerD4KOO1CO8iTq9WPuT" + simpleDateFormat.format(new Date()) + "login"));

        List<AuthorityModel> auths = loginService.getMenuListByUid(uid,tenantId);
        
        //如果是店员，则所有角色都在店员工作台一级菜单下显示
        Long tagCrmDy = 0l;
        for(int i=0;i<auths.size();i++){
        	if(auths.get(i).getId() == 66 || auths.get(i).getName().indexOf("店员工作台") > -1){
        		tagCrmDy = auths.get(i).getId();
        	}
        }
        List<AuthorityModel> authsCrm = new ArrayList<AuthorityModel>();
        //如果店员存在
        if(tagCrmDy > 0){
            for(int i=0;i<auths.size();i++){
            	if(auths.get(i).getId() == tagCrmDy){
            		authsCrm.add(auths.get(i));
            	}
            	//如果不是一级菜单
            	if(auths.get(i).getParentCode() != 0 && auths.get(i).getId() != tagCrmDy){
            		auths.get(i).setParentCode(tagCrmDy);
            		authsCrm.add(auths.get(i));
            	}
            	
            }
            auths = authsCrm;
        }
        //将用户的菜单权限放入session
        session.setAttribute("auths", auths);

        String mainPage = "";

        if (auths.size() > 0) {

            for (AuthorityModel auth : auths) {
                if (mainPage.length() == 0 && auth.getParentCode() > 0) {
                    mainPage = auth.getUrl();
                }
                if ("main_page".equals(auth.getNameEn())) {
                    mainPage = auth.getUrl();
                }
            }
        }

        if (auths.size() == 2) {

            RedirectView redirectView = new RedirectView(httpServletRequest.getContextPath() + (auths.get(0).getUrl() == null ? auths.get(0).getUrl() : auths.get(1).getUrl()));
            redirectView.setStatusCode(HttpStatus.TEMPORARY_REDIRECT);
            return new ModelAndView(redirectView);

        }

        SysUser sysUser = iAccountService.selectNameAndRoleByUid(uid);
        modelAndView.addObject("sysUser", sysUser);
        modelAndView.addObject("account", sysUser.getAccount());
        modelAndView.addObject("sign", sign);
        modelAndView.addObject("auths", auths);
        modelAndView.addObject("main_page", mainPage);
        return modelAndView;
    }
}
