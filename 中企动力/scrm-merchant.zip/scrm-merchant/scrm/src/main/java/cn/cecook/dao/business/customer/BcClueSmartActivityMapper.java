package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcClueSmartActivity;
import cn.cecook.model.business.customer.BcClueSmartActivityExample;

/**
 * 
* @explain 智能营销活动线索表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcClueSmartActivityMapper {
    int countByExample(BcClueSmartActivityExample example);

    int deleteByExample(BcClueSmartActivityExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcClueSmartActivity record);

    int insertSelective(BcClueSmartActivity record);

    List<BcClueSmartActivity> selectByExample(BcClueSmartActivityExample example);

    BcClueSmartActivity selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcClueSmartActivity record, @Param("example") BcClueSmartActivityExample example);

    int updateByExample(@Param("record") BcClueSmartActivity record, @Param("example") BcClueSmartActivityExample example);

    int updateByPrimaryKeySelective(BcClueSmartActivity record);

    int updateByPrimaryKey(BcClueSmartActivity record);
}