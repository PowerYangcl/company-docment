package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import cn.cecook.model.system.SysAuthority;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;

@Component
public class AuthorityModel implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	private Long id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Long createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;

    //权限名称
    private String name;
    //权限英文名称
    private String nameEn;
    //权限类型    0菜单  1按钮
    private int type;
    //上级菜单   父id
    private Long parentCode;
    //链接
    private String url;
    //菜单类别
    private String menuType;
    //菜单图标
    private String menuIcon;
    //菜单描述
    private String menuDesc;

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    //父权限的子权限集合
    private List<SysAuthority> list = new ArrayList<SysAuthority>();

    private List<AuthorityModel> childrenList;

    public List<AuthorityModel> getChildrenList() {
        return childrenList;
    }

    public void setChildrenList(List<AuthorityModel> childrenList) {
        this.childrenList = childrenList;
    }

    /*
     * set get
     */
    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getBak1() {
        return bak1;
    }

    public void setBak1(String bak1) {
        this.bak1 = bak1;
    }

    public String getBak2() {
        return bak2;
    }

    public void setBak2(String bak2) {
        this.bak2 = bak2;
    }

    public String getBak3() {
        return bak3;
    }

    public void setBak3(String bak3) {
        this.bak3 = bak3;
    }

    public String getBak4() {
        return bak4;
    }

    public void setBak4(String bak4) {
        this.bak4 = bak4;
    }

    public String getBak5() {
        return bak5;
    }

    public void setBak5(String bak5) {
        this.bak5 = bak5;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getNameEn() {
        return nameEn;
    }

    public void setNameEn(String nameEn) {
        this.nameEn = nameEn;
    }

    public int getType() {
        return type;
    }

    public void setType(int type) {
        this.type = type;
    }

    public Long getParentCode() {
        return parentCode;
    }

    public void setParentCode(Long parentCode) {
        this.parentCode = parentCode;
    }

    public List getList() {
        return list;
    }

    public void setList(List list) {
        this.list = list;
    }
    
    public String getMenuType() {
		return menuType;
	}

	public void setMenuType(String menuType) {
		this.menuType = menuType;
	}

	public String getMenuIcon() {
		return menuIcon;
	}

	public void setMenuIcon(String menuIcon) {
		this.menuIcon = menuIcon;
	}
	
	public String getMenuDesc() {
		return menuDesc;
	}

	public void setMenuDesc(String menuDesc) {
		this.menuDesc = menuDesc;
	}

	@Override
    public String toString() {
        return "AuthorityModel [id=" + id + ", uuid=" + uuid + ", tenantId="
                + tenantId + ", isDeleted=" + isDeleted + ", createId="
                + createId + ", createTime=" + createTime + ", orderCode="
                + orderCode + ", deleteTime=" + deleteTime + ", remarks="
                + remarks + ", attachment=" + attachment + ", bak1=" + bak1
                + ", bak2=" + bak2 + ", bak3=" + bak3 + ", bak4=" + bak4
                + ", bak5=" + bak5 + ", name=" + name + ", nameEn=" + nameEn
                + ", type=" + type + ", parentCode=" + parentCode + ", list="
                + list + "]";
    }
    


}
