package cn.cecook.controller.business.service;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.druid.support.logging.Log;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.controller.system.AccountController;
import cn.cecook.dao.business.markting.BmUserStoreMapper;
import cn.cecook.model.business.service.Order;
import cn.cecook.model.business.service.OrderDetail;
import cn.cecook.model.business.service.PosReceipts;
import cn.cecook.service.business.service.AutomatedOperationService;
import cn.cecook.service.business.service.IorderService;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.redis.ser.RedisStringSerUtil;

/**
 * 订单控制器
 * @author majie
 *
 */
@Controller
@RequestMapping("ser/order")
public class OrderController {
	@Resource
	private IorderService orderService;
	@Resource
	private AutomatedOperationService autoService;
	@Resource
	private BmUserStoreMapper userStoreDao;
	//日志输出
	private Logger logger = Logger.getLogger(AccountController.class);
	/**
	 * 查询订单集合
	 * @param param
	 * @param order
	 * @return
	 */
	@RequestMapping(value="/orderList",produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getOrderList(@RequestBody String param,Order order){
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		JsonElement jsonElement = jsonObj.get("extra_search");
		JsonObject json = jsonElement.getAsJsonObject();
		JsonElement orderNumber = json.get("orderNumber");
		JsonElement storeId = json.get("storeId");
		JsonElement cashierId = json.get("cashierId");
		JsonElement startDate = json.get("startDate");
		JsonElement endDate = json.get("endDate");
		JsonElement sorts =jsonObj.get("order");
		String flag = json.get("flag").getAsString();
		JsonArray asJsonArray=null;
		if(orderNumber!=null){
				order.setOrderNumber(orderNumber.getAsString());		
		}
		if(storeId!=null){
				order.setStoreId(storeId.getAsLong());
		}
		if(cashierId!=null){			
				order.setCashierId(cashierId.getAsLong());
		}
		if(startDate!=null){
			order.setBak1(startDate.getAsString());
		}
		if(endDate!=null){
				order.setBak2(endDate.getAsString());
		}
		if(sorts!=null){
				asJsonArray = sorts.getAsJsonArray();
		}
		for (int i = 0; i < asJsonArray.size(); i++) {
			JsonObject sort = asJsonArray.get(i).getAsJsonObject();
			String column = sort.get("column").getAsString();
			if("1".equals(column)){
				order.setWithSort(sort.get("dir").getAsString());
			}
		}		
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();		
		order.setPageStart(startIndex);
		order.setPageSize(pageSize);
		int count=orderService.getCount(order,flag);
		List<Order> list=null;
		list=(List<Order>) orderService.findAll(order,flag);	
		Map map=new HashMap();
		map.put("data", list);
		map.put("recordsTotal", count);
		map.put("recordsFiltered", count);
		map.put("draw", draw);
		Object json2 = JSONObject.toJSON(map);
		Gson gson=new Gson();
		 return gson.toJson(json2);
	}
	/**
	 * 获取注册会员数量
	 * @param order
	 * @param storeId
	 * @param cashierId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/getUserCount" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getUserCount(Order order,Long storeId,
			Long cashierId,
			String startDate,
			String endDate){
		if("".equals(startDate)){
			startDate=null;
		}else if("".equals(endDate)){
			endDate=null;
		}
		order.setBak1(startDate);
		order.setBak2(endDate);
		order.setCashierId(cashierId);
		order.setStoreId(storeId);
		//System.out.println(order);
		Gson g=new Gson();
		return g.toJson(orderService.getUserCount(order));
	}
	/**
	 * 获取录入体质数量
	 * @param order
	 * @param storeId
	 * @param cashierId
	 * @param startDate
	 * @param endDate
	 * @return
	 */
	@RequestMapping(value="/getTagCount" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getTagCount(Order order,Long storeId,
			Long cashierId,
			String startDate,
			String endDate){
		//System.out.println(order);
		if("".equals(startDate)){
			startDate=null;
		}else if("".equals(endDate)){
			endDate=null;
		}
		order.setBak1(startDate);
		order.setBak2(endDate);
		order.setCashierId(cashierId);
		order.setStoreId(storeId);
		Gson g=new Gson();
		return g.toJson(orderService.getTagCount(order));
	}
	/**
	 * 统计订单数量
	 * @param order
	 * @return
	 */
	@RequestMapping(value="/getCount" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getCount(Order order){
		Gson gson=new Gson();
		 return gson.toJson(orderService.getCount(order,"0"));
	}
/*	*//**
	 * 统计订单数量
	 * @param order
	 * @return
	 *//*
	@RequestMapping(value="/getOrderCount" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getOrderCount(Order order){
		return GsonTools.createJsonString(orderService.getCount(order,"0"));
	}*/
	/**
	 * 更新订单信息
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param request
	 * @param order
	 * @param tag
	 * @param date
	 * @param sex
	 * @return
	 */
	@RequestMapping(value="/updateOrder" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String update(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,Order order,String tag,String date,String sex){
		JsonObject jsonObject = new JsonObject();
		order.setTenantId(tenant_id);
		order.setUuid(uid);
		Integer update = orderService.update(order, tag,date,sex);
		Object insertQuartzTaskByMedicine=null;
		if(update!=null&&update>0){
			List<OrderDetail> findGoods = orderService.findGoods(order.getId()+"");
			List<Integer> medicineIds=new ArrayList<>();
			for (int i = 0; i < findGoods.size(); i++) {
				if(findGoods.get(i).getGoodsId()!=null){
					medicineIds.add(findGoods.get(i).getGoodsId().intValue());
				}
			}
		if(medicineIds!=null&&medicineIds.size()>0){
			insertQuartzTaskByMedicine= autoService.insertQuartzTaskByMedicine(Long.valueOf(uid),medicineIds,order.getId()+"",order.getConsumerId().intValue(),tenant_id,order.getConsumerPhone(),order.getConsumerName(),null);
			}
		}			
			jsonObject.addProperty("msg_code", 0);
		 return FastJsonUtil.createJsonString(jsonObject);
	}
	/**
	 * 查询单个订单信息
	 * @param order
	 * @return
	 */
	@RequestMapping(value="/findOrder" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String findOrder(Order order){
		Object json = JSONObject.toJSON(orderService.findOne(order));
		Gson gson=new Gson();
		 return gson.toJson(json);
	}
	//1.查询小票数据集合和订单数据集合（传入一个小票id,查询比小票id大的数据（如果没有就查全部））
	//2.然后遍历两个集合进行比对
	//-1.小票id在订单集合中，跳过。如果不存在执行2
	//-2.并且拿session中的小票对象中的小票单号和这次对象的小票单号进行比对，
	//-3.如果一样就跳过，如果不一样返回一个小票对象。
	//-4.如果遍历结束，那么返回null
	//5.拿到这个小票对象进行插入逻辑，插入成功之后把小票对象放到session。  ******
	//6.根据这个小票id查询订单对象								***
	//7.把订单对象返给前台
	@RequestMapping(value="/getChange",method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public  String getChange(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request){		
		PosReceipts pos=new PosReceipts();
		Order order=new Order();
		order.setUuid(uid);
		order.setTenantId(tenant_id);
		List<Map<String,Object>>stores = new ArrayList<>();
		Object storeId=null;		
		stores=(List<Map<String, Object>>) userStoreDao.getStores(uid);
		if(stores!=null&&stores.size()>0){			
			storeId=stores.get(0).get("store_id");
		}
		String key=ConfigUtil.REDIS_KEY+":"+order.getTenantId()+":"+storeId;
		//获取上次处理的小票数据
		String value = RedisStringSerUtil.getValue(key);
		pos = (PosReceipts) FastJsonUtil.jsonToPojo(PosReceipts.class, value);
		//筛选出来需要处理的小票数据
		pos = (PosReceipts) orderService.getChange(pos);		
		if(pos!=null){	
			//转化为json存入redis
			 String obj = FastJsonUtil.createJsonString(pos);
			 RedisStringSerUtil.setData(key,obj);
			 Object addOrder =orderService.addOrder(pos,order);
			 if(addOrder!=null){
				 Gson gson=new Gson();
				 return gson.toJson(addOrder);
			 }		 			 
		}
		return null;
	}
	/**
	 * 获取订单中药品的模板信息
	 * @param orderId
	 * @return
	 */
	@RequestMapping(value="/getSms" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getSms(String orderId){
		 List<OrderDetail> findGoods = orderService.findGoods(orderId);
		for (int i = 0; i < findGoods.size(); i++) {
			OrderDetail orderDetail = findGoods.get(i);
			List modelListByMedicineId=new ArrayList<>();
			if(orderDetail.getGoodsId()!=null){
				modelListByMedicineId = (List) autoService.getModelListByMedicineId(orderDetail.getGoodsId().intValue());
			}
			if(modelListByMedicineId!=null&&modelListByMedicineId.size()>0){
				Gson gson=new Gson();
				 return gson.toJson(modelListByMedicineId);
			}
		}
		return null;
	}
}
