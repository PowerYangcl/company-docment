package cn.cecook.dao.business.service;


import java.util.List;
import java.util.Map;

import cn.cecook.model.business.service.SerTask;

public interface SerTaskMapper {


    int deleteByPrimaryKey(Long id);

    int insert(SerTask record);

    int insertSelective(SerTask record);

    SerTask selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(SerTask record);

    int updateByPrimaryKey(SerTask record);
    /**
     * 
    * Title: getMedicineRuleList
    * Description:获取当前药瓶有哪些任务需要插入到定时任务里边
    * @param id
    * @return
     */
	public List<Map<String,Object>> getMedicineRuleList(int id);
	/**
	 * 获取自动化营销列表
	* Title: getAutomatedList
	* Description:
	* @return
	 */
	public List<Integer> getAutomatedList(Map<String, Object> map);

	public int countTotal();
	/**
	 * 获取每个售后自动化运营任务的统计数据
	* Title: getAutomatedList
	* Description:
	* @param id
	* @return
	 */
	List<Map<String,Object>> getAutomatedStatistics(int id);

	/**
	 *
	* Title: getAppraiseCount
	* Description:<!-- 获取评价数据统计 -->
	* @param id automated_task_id
	* @return
	 */
	Map<String,Object> getAppraiseCount(int id);

	int deleteTask(int id);

	int updateMedicineTaskIdByBatch(Map<String, Object> map);
	
	Map<String,Object> getTaskMedicines(int taskId);
	
	List<Map<String,Object>> getTaskMedicineRuleList(int taskId);
	
}