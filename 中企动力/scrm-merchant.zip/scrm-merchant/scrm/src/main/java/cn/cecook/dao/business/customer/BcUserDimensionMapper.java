package cn.cecook.dao.business.customer;

import cn.cecook.model.business.customer.BcUserDimension;

/**
 * 
 * @Title: BcUserDimensionMapper
 * @Package
 * @Description: 用户维度mapper
 * @author : ning
 * @date : 2017年5月26日
 * @version V1.0
 */
public interface BcUserDimensionMapper {

    /**
     * 用户维度属性设置方法
     * @param userDimension
     * @return
     */
    int addUserDimension(BcUserDimension userDimension);

    /**
     * 查询维度设置
     * @return
     */
    BcUserDimension getUserDimension();
    
    /**
     * 用户维度属性设置方法
     * @param userDimension
     * @return
     */
    int updateUserDimension(BcUserDimension userDimension);
    
    
}
