package cn.cecook.bean.business.markting;


public class ReqRainingOrder {

    private int id;

    private int balance;

    private String cardno;

    private String tenant_id;

    private int cash;

    private int transLimit;//沉淀额度正表示增加的额度，为负表示减少的额度

    private int credits;

    private String remarks;

    private String storeId;

    private int coupon;

    private String coupon_code;

    private String staff_id;

    private String trade_no;
    private String phone;
    private String jobNumber;
    //订单状态:0未处理交易1已处理交易2取消交易
    private String orderStatus;
    private ReqRainingTransactionData transaction_data;
    public int getTransLimit() {
        return transLimit;
    }

    public void setTransLimit(int transLimit) {
        this.transLimit = transLimit;
    }

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }


    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getTrade_no() {
        return trade_no;
    }

    public void setTrade_no(String trade_no) {
        this.trade_no = trade_no;
    }

    public String getStaff_id() {
        return staff_id;
    }

    public void setStaff_id(String staff_id) {
        this.staff_id = staff_id;
    }

    public String getTenant_id() {
        return tenant_id;
    }

    public void setTenant_id(String tenant_id) {
        this.tenant_id = tenant_id;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getBalance() {
        return balance;
    }

    public void setBalance(int balance) {
        this.balance = balance;
    }

    public String getCardno() {
        return cardno;
    }

    public void setCardno(String cardno) {
        this.cardno = cardno;
    }

    public int getCash() {
        return cash;
    }

    public void setCash(int cash) {
        this.cash = cash;
    }

    public int getCredits() {
        return credits;
    }

    public void setCredits(int credits) {
        this.credits = credits;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getStoreId() {
        return storeId;
    }

    public void setStoreId(String storeId) {
        this.storeId = storeId;
    }

    public int getCoupon() {
        return coupon;
    }

    public void setCoupon(int coupon) {
        this.coupon = coupon;
    }

    public String getCoupon_code() {
        return coupon_code;
    }

    public void setCoupon_code(String coupon_code) {
        this.coupon_code = coupon_code;
    }

    public ReqRainingTransactionData getTransaction_data() {
        return transaction_data;
    }

    public void setTransaction_data(ReqRainingTransactionData transaction_data) {
        this.transaction_data = transaction_data;
    }

	public String getOrderStatus() {
		return orderStatus;
	}

	public void setOrderStatus(String orderStatus) {
		this.orderStatus = orderStatus;
	}

	@Override
	public String toString() {
		return "ReqRainingOrder [id=" + id + ", balance=" + balance + ", cardno=" + cardno + ", tenant_id=" + tenant_id
				+ ", cash=" + cash + ", transLimit=" + transLimit + ", credits=" + credits + ", remarks=" + remarks
				+ ", storeId=" + storeId + ", coupon=" + coupon + ", coupon_code=" + coupon_code + ", staff_id="
				+ staff_id + ", trade_no=" + trade_no + ", phone=" + phone + ", jobNumber=" + jobNumber
				+ ", orderStatus=" + orderStatus + ", transaction_data=" + transaction_data + "]";
	}

}
