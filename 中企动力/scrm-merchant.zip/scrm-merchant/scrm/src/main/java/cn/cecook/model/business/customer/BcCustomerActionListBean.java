package cn.cecook.model.business.customer;

import java.util.Date;

/**
 * 
 * @Title: BcCustomerActionListBean
 * @Package
 * @Description: 客户行为列表模型
 * @author : ning
 * @date : 2017年5月26日
 * @version V1.0
 */
public class BcCustomerActionListBean {
    private Integer id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Long createId;

    private Date createTime;

    private String remarks;

    private String attachment;

    private Long customerId;

    private String customerName;

    private Long activityId;

    private String activityName;

    private String type;

    private String content;

    private Integer enjoyStatus;

    private Integer handleStatus;

    private Long clueActivityId;

    private String channelName;

    public String getChannelName() {
        return channelName;
    }

    public void setChannelName(String channelName) {
        this.channelName = channelName;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName;
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName;
    }

    public String getType() {
        return type;
    }

    public void setType(String type) {
        this.type = type;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public Integer getEnjoyStatus() {
        return enjoyStatus;
    }

    public void setEnjoyStatus(Integer enjoyStatus) {
        this.enjoyStatus = enjoyStatus;
    }

    public Integer getHandleStatus() {
        return handleStatus;
    }

    public void setHandleStatus(Integer handleStatus) {
        this.handleStatus = handleStatus;
    }

    public Long getClueActivityId() {
        return clueActivityId;
    }

    public void setClueActivityId(Long clueActivityId) {
        this.clueActivityId = clueActivityId;
    }

}
