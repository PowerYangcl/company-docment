package cn.cecook.bean.system;

import java.io.Serializable;
import java.util.List;

/**
 * 部门
 * @explain 
 * @author sunny
 * @date 2017年6月15日
 */
public class DepartmentModel implements Serializable{  
    //部门id
    private long department_id;
    //领导id
    private long leader_id;
    //角色集合
    private List<String> sysuserIdList;
    
    public long getDepartment_id() {
        return department_id;
    }
    public void setDepartment_id(long department_id) {
        this.department_id = department_id;
    }
    public long getLeader_id() {
        return leader_id;
    }
    public void setLeader_id(long leader_id) {
        this.leader_id = leader_id;
    }
    public List<String> getSysuserIdList() {
        return sysuserIdList;
    }
    public void setSysuserIdList(List<String> sysuserIdList) {
        this.sysuserIdList = sysuserIdList;
    }
    @Override
    public String toString() {
        return "DepartmentModel [department_id=" + department_id + ", leader_id=" + leader_id + ", sysuserIdList="
                        + sysuserIdList + "]";
    }


}
