package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.cecook.uitls.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.markting.BmSmsModel;
import cn.cecook.service.impl.business.markting.BmSmsModelService;

@Controller
@RequestMapping("/social/smsModel")
public class SocialSmsModelController {
	@Autowired
	private BmSmsModelService bmSmsModelService;
	
	
	@RequestMapping(value = "/getList")
	@ResponseBody
	public Object getList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();

		String keyWord = "";
		String type = "";
		if (jsonObj.get("keyWord") != null) {
			keyWord = jsonObj.get("keyWord").getAsString();
		}
		if (jsonObj.get("type") != null) {
			type = jsonObj.get("type").getAsString();
		}
		return (bmSmsModelService.modelList(startIndex, pageSize, type, keyWord, draw));

	}
	/**
	 * 
	* Title: create
	* Description:
	* @param request
	* @param response
	* @return
	 */
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response){
		String modelType=request.getParameter("modelType");
		String modelName=request.getParameter("modelName");
		String modelContent=request.getParameter("content");
		String contentType=request.getParameter("contentType");
		int autograph_id=Integer.parseInt(request.getParameter("autograph_id"));
		String is_show=request.getParameter("saveType");
		BmSmsModel bmSmsModel=new BmSmsModel();
		bmSmsModel.setType(modelType);
		bmSmsModel.setName(modelName);
		bmSmsModel.setContent_type(contentType);
		bmSmsModel.setContent(modelContent);
		bmSmsModel.setAutograph_id(autograph_id);
		if(!StringUtils.isEmpty(is_show)){
			bmSmsModel.setIs_show(is_show);
		}
		
		return (bmSmsModelService.insert(bmSmsModel));
		
	}
	
	@RequestMapping(value = "/update")
	@ResponseBody
	public Object update(HttpServletRequest request,
			HttpServletResponse response){
		String modelType=request.getParameter("modelType");
		String modelName=request.getParameter("modelName");
		String modelContent=request.getParameter("content");
		String contentType=request.getParameter("contentType");
		int id=Integer.parseInt(request.getParameter("id"));
		int autograph_id=Integer.parseInt(request.getParameter("autograph_id"));
		BmSmsModel bmSmsModel=new BmSmsModel();
		bmSmsModel.setType(modelType);
		bmSmsModel.setName(modelName);
		bmSmsModel.setContent_type(contentType);
		bmSmsModel.setContent(modelContent);
		bmSmsModel.setId(id);
		bmSmsModel.setAutograph_id(autograph_id);
		return (bmSmsModelService.update(bmSmsModel));
		
	}
	
	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object update(int id){
		return (bmSmsModelService.modelDetail(id));
	}
	
	@RequestMapping(value = "/deleteModel")
	@ResponseBody
	public Object deleteModel(int id){
		return (bmSmsModelService.delete(id));
	}
	
}
