package cn.cecook.controller.system;


import java.io.BufferedWriter;
import java.io.OutputStream;
import java.io.OutputStreamWriter;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.Map.Entry;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;
import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.dao.system.SmsMsgLogMapper;
import cn.cecook.service.system.ICompanyService;
import cn.cecook.service.system.ISmsService;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Pages;
import cn.cecook.uitls.StringUtils;
import redis.clients.jedis.Jedis;

/**
 * 
 * @explain 短信
 * @author LeeX
 * @date 2017年5月31日
 */
@Controller
@RequestMapping("/api/sms/verification_code")
public class SmsController {
	
	@Resource
	ISmsService smsService;
	
	Jedis jedis;
	
	@Autowired
	private SmsMsgLogMapper smsMsgLogMapper;
	@Autowired
	private ICompanyService companyService;

	/**
	 * 
	 * @explain 核对验证码
	 * @author LeeX
	 * @date 2017年5月31日 上午10:04:41
	 */
	@RequestMapping(value = "/verify", method = RequestMethod.POST)
	public @ResponseBody Object verify(HttpServletRequest request, HttpServletResponse response){
		//增加js跨域支持
		response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		//对象参数
		AccountModel  accountModel = new AccountModel();
		ResultModel resultModel = new ResultModel();
		
		//获取参数
		String account = request.getParameter("account");
		String ver_code  = request.getParameter("ver_code");
		String code_type  = request.getParameter("code_type");		
		String code_id_str  = request.getParameter("code_id");
		Long code_id = null;
		
		if(!"".equals(code_id_str) && code_id_str !=  null){
			code_id = Long.parseLong(code_id_str);
			accountModel.setId(code_id);
		}
		
		//封装
		accountModel.setAccount(account);
		accountModel.setVer_code(ver_code);
		accountModel.setCode_type(code_type);
		
		try {
			resultModel = smsService.verify(accountModel);
		} catch (Exception e) {
			//resultModel = smsService.verifyDB(accountModel);
			e.printStackTrace();
		}
		
		return (resultModel);
	}
	
	
	/**
	 * 
	 * @explain 发送短信
	 * @author LeeX
	 * @date 2017年5月31日 上午9:24:43
	 */
	@RequestMapping(value="/send", method = RequestMethod.POST)
	public @ResponseBody Object send(HttpServletRequest request, HttpServletResponse response){
		//增加js跨域支持
		response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		
		//对象参数
		AccountModel  accountModel = new AccountModel();
		ResultModel resultModel = new ResultModel();
		
		//手机号码
		String mobile = request.getParameter("account");
		//验证码类型
		String code_type = request.getParameter("code_type");
		//是否是忘记密码页面
		String type = request.getParameter("type");
		//为传输model赋值
		accountModel.setAccount(mobile);
		accountModel.setCode_type(code_type);
		accountModel.setType(type);
		try {
		    //执行service层
			resultModel = smsService.send(accountModel);
		} catch (Exception e) {
			e.printStackTrace();
			return (resultModel);
		}
		
		return (resultModel);
	}
	
	@RequestMapping(value="/openSend")
	public @ResponseBody Object openSend(HttpServletRequest request, HttpServletResponse response){
		//增加js跨域支持
		response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
		//手机号码
		String mobile = request.getParameter("mobile");
	    
		return smsService.openSend(mobile);
	}
	
	   /**
     * 
     * @explain 发送启用/停用短信
     * @author sunny
     * @date 2017年6月28日
     */
    @RequestMapping(value="/sendQT", method = RequestMethod.POST)
    public @ResponseBody Object sendqt(HttpServletRequest request, HttpServletResponse response){
        System.out.println("进入  SmsController--->sendqt");
        //传参数的model
        AccountModel  accountModel = new AccountModel();
        //传输结果的model
        ResultModel resultModel = new ResultModel();
        //手机号码
        String mobile = request.getParameter("account");
        //验证码类型
        String code_type = request.getParameter("code_type");
        //为传输model赋值
        accountModel.setAccount(mobile);
        accountModel.setCode_type(code_type);        
        try {
            //执行service
            resultModel = smsService.sendqt(accountModel);
        } catch (Exception e) {
            e.printStackTrace();
            return resultModel;
        }
        System.out.println("smsController---code:"+resultModel.getError_code());
        System.out.println("smsController---msg:"+resultModel.getError_msg());
        return resultModel;
    }
    
    /**
  * 
  * @explain 发送子账号登录码
  * @author sunny
  * @date 2017年6月28日
  */
 @RequestMapping(value="/sendSe", method = RequestMethod.POST)
 public @ResponseBody Object sendSe(HttpServletRequest request, HttpServletResponse response){
     System.out.println("进入  SmsController--->sendqt");
     //传参数的model
     AccountModel  accountModel = new AccountModel();
     //传输结果的model
     ResultModel resultModel = new ResultModel();
     //手机号码
     String mobile = request.getParameter("account");
     //验证码类型
     String code_type = request.getParameter("code_type");
     //为传输model赋值
     accountModel.setAccount(mobile);
     accountModel.setCode_type(code_type);     
     try {
         //执行service
         resultModel = smsService.sendSe(accountModel);
     } catch (Exception e) {
         e.printStackTrace();
         return (resultModel);
     }
     System.out.println("smsController---code:"+resultModel.getError_code());
     System.out.println("smsController---msg:"+resultModel.getError_msg());
     return resultModel;
 }
 
 
	/**
	 * 按天、按月、按年获取短信消耗打开量和商机转化
	 * @param startIndex
	 * @param pageSize
	 * @param startTime
	 * @param endTime
	 * @param days
	 * @return
	 */
	@RequestMapping(value = "/getQdPropChartData")
	@ResponseBody
	public Object getQdPropChartData(int startIndex, int pageSize,
			String startTime, String endTime, String dates) {
		if (StringUtils.isEmpty(dates)) {
			dates = "m";
		}
		return (smsService
				.getQdPropChartData(startTime,endTime,dates));

	}
 
	@RequestMapping(value = "/smsList")
	public String smsList() {
		return "system/smsList";
	}
	
	@RequestMapping(value = "/smsPage")
	@ResponseBody
	public JSONObject smsPage(@RequestBody String json,HttpServletRequest request) {
		JsonParser parser = new JsonParser();
		JsonObject param = parser.parse(json).getAsJsonObject();
		
		JsonObject data = new JsonObject();
		int startIndex = param.get("start").getAsInt();
		int pageSize = param.get("length").getAsInt();
		String orderby = null;
		if(param.get("order").getAsJsonArray().size() > 0 )
			orderby = param.get("columns").getAsJsonArray().get(param.get("order").getAsJsonArray().get(0).getAsJsonObject().get("column").getAsInt()).getAsJsonObject().get("name").getAsString() + " " + param.get("order").getAsJsonArray().get(0).getAsJsonObject().get("dir").getAsString();
		else 
			orderby = "id desc";
		
		Map<String, Object> where = new HashMap<String, Object>();
		Cookie[] cookies = request.getCookies();
		where.put("tenantId", CookieUtil.getCookieSet(cookies).get("tenant_id"));
		for (Entry<String, JsonElement> entry : param.get("extra_search").getAsJsonObject().entrySet()) {
			String key = entry.getKey();
			String value = entry.getValue().getAsString();
			where.put(key, value);
		}
		
		Pages<Map<String, Object>> pages = new Pages<Map<String,Object>>(startIndex, pageSize, where, orderby);
		List<Map<String, Object>> list = smsMsgLogMapper.smsPage(pages);
		int count = smsMsgLogMapper.smsCount(pages.getWhere());
		int draw = param.get("draw").getAsInt();
		int recordsTotal = count;
		int recordsFiltered = recordsTotal;
		data.addProperty("draw", draw);
		data.addProperty("recordsTotal", recordsTotal);
		data.addProperty("recordsFiltered", recordsFiltered);
		Gson gson = new Gson();
		data.add("data", parser.parse(gson.toJson(list)));
		
		JSONObject jObject = JSONObject.parseObject(data.toString());
		return jObject;
	}
	
	/**
	 * 短信统计，已发短信，剩余短信
	 * @return
	 */
	@RequestMapping(value = "/smsTotal")
	@ResponseBody
	public JSONObject smsTotal(HttpServletRequest request) {
		JSONObject jObject = new JSONObject();
		Map<String, Object> map = new HashMap<String, Object>();
		Cookie[] cookies = request.getCookies();
		map.put("tenantId", CookieUtil.getCookieSet(cookies).get("tenant_id"));
		int sendCount = smsMsgLogMapper.getSendCount(map);
		Integer selectSmsNumByTenantId = companyService.selectSmsNumByTenantId(map.get("tenantId")+"");
		
		jObject.put("sendCount", sendCount);	//已发短信
		jObject.put("usableCount", selectSmsNumByTenantId);	//剩余短信
		return jObject;
	}
	
//	@RequestMapping(value = "/smsDetailDownload")
	public void smsDetailDownload(String batch_num,HttpServletResponse response) {
		try {
			// 下载文件
//			response.setCharacterEncoding("utf-8");
//        response.setContentType("application/octet-stream");
//        response.setContentType("application/vnd.ms-excel");
//			response.setHeader("Content-Disposition", "attachment;fileName=" + UUID.randomUUID()+".xlsx");
			String batchNo = batch_num.substring(0, batch_num.length()-1);
			String batchType = batch_num.substring(batch_num.length()-1);
			
			Map<String, Object> map = new HashMap<>();
			map.put("batchNo", batchNo);
			map.put("batchType", batchType);
			Map<String, Object> smsDetailCount = smsMsgLogMapper.smsDetailCount(map);
			
			String smsContent = "";
			if(batchType.equals("c")) {
				smsContent = "著券短信";
			}else if(batchType.equals("c")) {
				smsContent = "活动短信";
			}
			
			String row1[] = {"短信类型","群发短信","发送成功",smsDetailCount.get("success")+""};
			String row2[] = {"短信内容",smsContent,"发送失败",smsDetailCount.get("failure")+""};
			
			
			
			OutputStream os = response.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os));
			os.flush();
			os.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	@RequestMapping(value = "/smsLogDownload")
	public void smsLogDownload(HttpServletRequest request,HttpServletResponse response) {
		try {
			// 下载文件
//			response.setCharacterEncoding("utf-8");
//        response.setContentType("application/octet-stream");
//        response.setContentType("application/vnd.ms-excel");
			response.setHeader("Content-Disposition", "attachment;fileName=" + UUID.randomUUID()+".csv");
			Map<String, Object> map = new HashMap<String, Object>();
			Cookie[] cookies = request.getCookies();
			map.put("tenantId", CookieUtil.getCookieSet(cookies).get("tenant_id"));
			
			String title[] = {"短信类型","短信内容","时间","短信数量"};
			
			OutputStream os = response.getOutputStream();
			BufferedWriter writer = new BufferedWriter(new OutputStreamWriter(os,"gbk"));
			
			for (int i = 0; i < title.length; i++) {
				String s = title[i];
				writer.write(s);
				if(i < title.length-1) {
					writer.write(",");
				}else {
					writer.newLine();
				}
			}
			
			int count = smsMsgLogMapper.smsCount(map);
			int startIndex = 0;
			int pageSize = 4000;
			int pageCount = count / pageSize;
			if(count%pageSize > 0) {
				pageCount++;
			}
			
			for(int i=0; i<pageCount; i++) {
				startIndex = i * pageSize;
				Pages<Map<String, Object>> pages = new Pages<Map<String,Object>>(startIndex, pageSize, map,null);
				List<Map<String, Object>> list = smsMsgLogMapper.smsPage(pages);
				
				for (Map<String, Object> sms : list) {
					String msg_type = sms.get("msg_type")+"";
					String msg_tittle = sms.get("msg_tittle")+"";
					String create_time = sms.get("create_time")+"";
					String sum_msg_counts = sms.get("sum_msg_counts")+"";
					if(msg_type.equals("1")){
	                	msg_type = "系统短信";
	                }else if(msg_type.equals("2")){
	                	msg_type = "群发短信";
	                }else if(msg_type.equals("3")){
	                	msg_type = "短信充值";
	                }else if(msg_type.equals("4")){
	                	msg_type = "通知短信";
	                }
					writer.write(msg_type+","+msg_tittle+","+create_time+","+sum_msg_counts);
					writer.newLine();
				}
			}
			writer.flush();
			writer.close();
			os.flush();
			os.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
}