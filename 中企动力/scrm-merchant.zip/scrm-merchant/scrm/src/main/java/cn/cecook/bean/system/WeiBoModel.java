package cn.cecook.bean.system;

import java.io.Serializable;

/**
 * 
 *@explain
 * @author ZHIWEN
 * @data 2017年6月22日
 */

public class WeiBoModel extends SysBaseResultModel implements Serializable {
  

	/**
	 * @explain
	 * @author ZHIWEN
	 * @date 2017年6月22日
	 */
	private static final long serialVersionUID = 1L;
	private   Long  RemainingDay;
    //微博绑定的天数	
	private Long BindDays;
    
	
	public long getBindDays() {
		return BindDays;
	}

	public void setBindDays(long bindDays) {
		BindDays = bindDays;
	}

	public static long getSerialversionuid() {
		return serialVersionUID;
	}

	public Long getRemainingDay() {
		return RemainingDay;
	}

	public void setRemainingDay(Long remainingDay) {
		RemainingDay = remainingDay;
	}

	@Override
	public String toString() {
		return "WeiBoModel [RemainingDay=" + RemainingDay + "]";
	}
    
}
