package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.CouponBatchClickStatistics;
import cn.cecook.model.business.markting.SocialCouponBrowse;

public interface SocialCouponBrowseMapper {


    int deleteByPrimaryKey(Integer id);

    int insert(SocialCouponBrowse record);

    int insertSelective(SocialCouponBrowse record);

    SocialCouponBrowse selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SocialCouponBrowse record);

    int updateByPrimaryKey(SocialCouponBrowse record);
    
    int countClickNum(@Param("batchId") int couponBatch);
    
    List<CouponBatchClickStatistics> getListByCouponBatchId(Map<String,Object> map);
	
	int countByCouponBatchId(int batchId);
}