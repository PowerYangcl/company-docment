package cn.cecook.controller.system;

import java.io.IOException;
import java.io.InputStream;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import cn.cecook.uitls.QiniuUtils;

/**
 * 
 *@explain
 * @author ZHIWEN
 * @data 2017年7月6日
 */ 
@Controller
@RequestMapping("/Qiniu")
public class QiniuController {
	/**
	 * 
	 * @explain 七牛云-上传本地文件
	 * @author ZHIWEN
	 * @date 2017年7月6日
	 */
	@RequestMapping(value="/fileUploadlocalhost" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public void fileUploadlocalhost( HttpServletRequest request,HttpServletResponse response
		,@RequestParam(value = "typename",required = false)String typename	){
	    //以参数形式给路径
        String filename = "F:\\屏保\\257629.jpg";//获取文件名
        System.out.println(typename);
        System.out.println("上传文件路径："+filename);
	    QiniuUtils.getinstance().fileUploadlocalhost(2, 0, null, null, filename);
			
		
	}
	
	/**
	 * 
	 * @explain 七牛云-字节数组上传
	 * @author ZHIWEN
	 * @date 2017年7月6日
	 */
	@RequestMapping(value="/fileUploadByByte" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public void fileUploadByByte( HttpServletRequest request,HttpServletResponse response
		,@RequestParam(value = "typename",required = false)String typename	){
	    //以参数形式给路径
        String Bytes = "F:\\屏保\\257629.jpg";//获取文件名
        System.out.println(Bytes);
	    QiniuUtils.getinstance().fileUploadByByte(2, 0, null, null, Bytes);
			
	}
	
	/**
	 * 
	 * @explain 七牛云-数据流上传
	 * @author ZHIWEN
	 * @date 2017年7月6日
	 */
	@RequestMapping(value="/fileUploadByInputStream" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public void fileUploadByInputStream( HttpServletRequest request,HttpServletResponse response
		,@RequestParam(value = "typename",required = false)String typename	){
	   
	   
		InputStream inputStream = AnalysisRequest(typename, request);
	    QiniuUtils.getinstance().fileUploadByInputStream(2, 0, null, null, inputStream);
			
	}
	
	/**
	 * 
	 * @explain 七牛云-断点续传
	 * @author ZHIWEN
	 * @date 2017年7月6日
	 */
	@RequestMapping(value="/BreakPointResumeUpload" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public void BreakPointResumeUpload( HttpServletRequest request,HttpServletResponse response
		,@RequestParam(value = "typename",required = false)String typename	){
	   
	   
		InputStream inputStream = AnalysisRequest(typename, request);
	    QiniuUtils.getinstance().BreakPointResumeUpload(2, 0, null, null, inputStream);
			
	}
	
	
	/**
	 * ******************************文件上传接口，此处截止****************************************************
	 */
	
	/**
	 * 
	 * @explain 七牛云-公开资源文件下载
	 * @author ZHIWEN
	 * @date 2017年7月10日
	 */
	@RequestMapping(value="/FileDownLoadOnDownLoad" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody String FileDownLoadOnDownLoad( HttpServletRequest request,HttpServletResponse response
			){
	   
	  String filename = "";//文件上传后的文件名
	  
	  String DownloadUrl=  QiniuUtils.getinstance().PublicFileDownLoad(1, filename);
	  return DownloadUrl;
	}
	
	/**
	 * 
	 * @explain 七牛云-公开资源文件在线预览
	 * @author ZHIWEN
	 * @date 2017年7月10日
	 */
	@RequestMapping(value="/FileDownLoadOnBrowse" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody String FileDownLoadOnBrowse( HttpServletRequest request,HttpServletResponse response
			){
	  String filename = "";//文件上传后的文件名
	  String DownloadUrl=  QiniuUtils.getinstance().PublicFileDownLoad(0, filename);
	  return DownloadUrl;
	}
	
	/**
	 * ******************************文件下载接口，此处截止****************************************************
	 */
	
	
	/**
	 * 
	 * @explain 该类公用方法-处理解析出来的request请求
	 * @author ZHIWEN
	 * @date 2017年7月6日
	 */
	private InputStream AnalysisRequest(String typename,HttpServletRequest request){
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		InputStream inputStream = null;
		try {
			inputStream = multipartRequest.getFile(typename).getInputStream();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		return inputStream;
	}
}
