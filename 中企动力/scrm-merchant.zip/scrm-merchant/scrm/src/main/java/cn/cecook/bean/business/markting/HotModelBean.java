package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
public class HotModelBean implements Serializable{
	private String name;
	private String pic_url;
	private int id;
	private double max_ratio;
	private int use_num;
	private double average_ratio;
	private int max_write_off;
	private int min_write_off;
	private String type;
	private String thumbnail_pic;
	
	
	
	public String getThumbnail_pic() {
		return thumbnail_pic;
	}
	public void setThumbnail_pic(String thumbnail_pic) {
		this.thumbnail_pic = thumbnail_pic;
	}
	public String getType() {
		return type;
	}
	public void setType(String type) {
		this.type = type;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPic_url() {
		return pic_url;
	}
	public void setPic_url(String pic_url) {
		this.pic_url = pic_url;
	}
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public double getMax_ratio() {
		return max_ratio;
	}
	public void setMax_ratio(double max_ratio) {
		this.max_ratio = max_ratio;
	}
	public int getUse_num() {
		return use_num;
	}
	public void setUse_num(int use_num) {
		this.use_num = use_num;
	}
	public double getAverage_ratio() {
		return average_ratio;
	}
	public void setAverage_ratio(double average_ratio) {
		this.average_ratio = average_ratio;
	}
	public int getMax_write_off() {
		return max_write_off;
	}
	public void setMax_write_off(int max_write_off) {
		this.max_write_off = max_write_off;
	}
	public int getMin_write_off() {
		return min_write_off;
	}
	public void setMin_write_off(int min_write_off) {
		this.min_write_off = min_write_off;
	}
	
	
	
	
}
