package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.SocialSmsAutograph;

public interface SocialSmsAutographMapper {


    int deleteByPrimaryKey(Integer id);


    int insertSelective(SocialSmsAutograph record);


    SocialSmsAutograph selectByPrimaryKey(Integer id);


    int updateByPrimaryKeySelective(SocialSmsAutograph record);
    
    
    List<SocialSmsAutograph> getList();
    
    
    String getDefaultAutograph(@Param("tenantId") String tenantId);
    
    String getAutographByModelId(@Param("id") int id, @Param("tenantId") String tenantId);

}