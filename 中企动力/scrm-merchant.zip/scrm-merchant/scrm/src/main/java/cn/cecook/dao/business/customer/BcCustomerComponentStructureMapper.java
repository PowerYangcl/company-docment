package cn.cecook.dao.business.customer;

import java.util.ArrayList;
import java.util.Map;

import cn.cecook.model.business.customer.BcCustomerComponentStructure;

/**
 * 
 *@explain 控件结构mapper接口
 * @author ZHIWEN
 * @data 2017年7月27日
 */
public interface BcCustomerComponentStructureMapper {
     	int Inster_CustomerComponentStructure(Map<String, Object> map);
     	int Delete_CustomerComponentStructure(Long id);
     	ArrayList<BcCustomerComponentStructure> Select_CustomerComponentStructure(Long id);
}
