package cn.cecook.controller.api;


import cn.cecook.service.business.markting.APIemayService;
import cn.cecook.thirdparty.emay.v8.util.AES;
import cn.cecook.thirdparty.emay.v8.util.GZIPUtils;
import cn.cecook.thirdparty.emay.v8.util.ResponseUtils;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import java.io.IOException;

/*
 * 
 * 短信状态推送
*/
@Controller
@RequestMapping(value = "/api/emay/")
public class APIemayController {
    @Value("#{configProperties['smart_key']}")
    private String smart_key;
    @Value("#{configProperties['key']}")
    private String key;
    @Value("#{configProperties['smart_password']}")
    private String smart_password;
    @Value("#{configProperties['V8_ALGORITHM']}")
    private String V8_ALGORITHM;

    @Autowired
    private APIemayService aPIemayService;
    private static Logger logger = Logger.getLogger(APIemayController.class);

	@RequestMapping(value = "/emayPush")
    @ResponseBody
    public void getEmayPush(HttpServletRequest request, HttpServletResponse response) {
		logger.info("亿美推送进入了------------》");
		String appid=request.getHeader("appId");
		logger.info("appId------------》"+appid);
		String reports = request.getParameter("reports");
		logger.info("result------------》"+reports);
		if(!StringUtils.isEmpty(appid)&&(appid.equals(smart_key)||appid.equals(key))) {
			if(!StringUtils.isEmpty(reports)){
				String result= aPIemayService.getEmayPush(reports);
		        ResponseUtils.outputWithString(response, result);
			}
		}
    }

//    @RequestMapping(value = "/emayPush")
//    @ResponseBody
//    public void getEmayPush(HttpServletRequest request) {
//        logger.info("亿美推送进入了------------》");
//        String appid = request.getHeader("appId");
//        logger.info("appid------------》" + appid);
//        String result = null;
//        if (appid.equals(smart_key)) {
//            logger.info("bytes-start------------》");
//            byte[] bytes = null;
//            try {
//                bytes = getRequestPostBytes(request);
//                logger.info("bytes------------》" + bytes);
//            } catch (Exception e) {
//                e.printStackTrace();
//            }
//            ;
//            logger.info("bytes------------》" + bytes);
//            try {
//                logger.info("开始解码------------》");
//                bytes = AES.encrypt(bytes, smart_password.getBytes(), V8_ALGORITHM);
//                logger.info("开始解压------------》");
//                bytes = GZIPUtils.decompress(bytes);
//                result = new String(bytes, "UTF-8");
//                logger.info("返回结果------------》");
//                aPIemayService.getEmayPush(result);
//            } catch (IOException e) {
//                logger.info("失败了------------》");
//                e.printStackTrace();
//            }
//
//        }
//
//
//    }

    public static byte[] getRequestPostBytes(HttpServletRequest request)
            throws IOException {
        int contentLength = request.getContentLength();
        /*当无请求参数时，request.getContentLength()返回-1 */
        if(contentLength<0){
            return null;
        }
        byte buffer[] = new byte[contentLength];
        for (int i = 0; i < contentLength;) {

            int readlen = request.getInputStream().read(buffer, i,
                    contentLength - i);
            if (readlen == -1) {
                break;
            }
            i += readlen;
        }
        return buffer;
    }


}
