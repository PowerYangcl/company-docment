package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;
@Repository("goodsStandardMapper")
public interface GoodsStandardMapper {
    /**
     * 根据条形码查询药品基本信息
     * @param drugScan
     * @return
     */
	Map<String, Object> getDataByDrugScan(String drugScan);
	/**
	 * 进行纠错操作
	 * @param id
	 * @return
	 */
	int updateErrorCorrect(Integer id);
    /**
     * 根据id查询药品基本信息
     * @param drugScan
     * @return
     */
	Map<String, Object> getDataByDrugScanById(String id);
	/**
	 * 根据药品名称查询药品信息
	 * @param name
	 * @return
	 */
	List<Map<String,Object>> getGoodsByName(String name);
	/**
	 * 根据药品编码查询药品信息
	 * @param goodsNumber
	 * @return
	 */
	Map<String, Object> getDataByDrugScanByGoodsNumber(String goodsNumber);
	/**
	 * 根据药品条形码查询药品信息
	 * @param barCode
	 * @return
	 */
	Map<String,Object> getDataByBarCode(String barCode);
}