package cn.cecook.dao.open.mp;

import java.util.List;

import cn.cecook.model.business.markting.BmCoupon;

public interface BmCouponMapper {

	int findCouponCountByPhone(String phone);
	List<BmCoupon> findCouponByPhone(String phone);
	
}
