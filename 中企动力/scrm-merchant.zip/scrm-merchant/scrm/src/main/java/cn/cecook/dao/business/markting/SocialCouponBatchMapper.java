package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.bean.business.markting.ExportCouponBatchStatistics;
import cn.cecook.model.business.markting.SocialCouponBatch;

@Repository("socialCouponBatchMapper")
public interface SocialCouponBatchMapper {

	int deleteByPrimaryKey(Integer id);

	int insert(SocialCouponBatch record);

	int insertSelective(SocialCouponBatch record);

	SocialCouponBatch selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(SocialCouponBatch record);

	int updateByPrimaryKey(SocialCouponBatch record);

	int insertBatch(@Param("batch") String batch, @Param("id") int id);

	List<SocialCouponBatch> getCouponBatchList(Map<String, Object> map);

	int countCouponBatch(Map<String, Object> map);

	int getSendStatus(@Param("id") int id, @Param("tenant_id") String tenant_id);

	int deleteBatch(List<Long> ids);

	List<ExportCouponBatchStatistics> couponStatistics(Map<String, Object> map);

	int countStatisticsTotal(Map<String, Object> map);

	int updateStatus(@Param("id") int id, @Param("status") int status,
			@Param("tenant_id") String tenant_id);

	
	// 发送发完成
	int sendComplete(Map<String,Object> map);
	

	// 根据ids查询
	List<Map<String, String>> queryContentByIds(List<Integer> ids);

	// 批量更新审核状态
	 int updateStstuaByIds(Map<String,Object> map);
	/**
	 * 
	* Title: countUnAuditeByTemplateId
	* Description:根据自动化营销id统计未审核的数量
	* @param templateId
	* @return
	 */
	 Integer countUnAuditeByTemplateId(@Param("templateId") int templateId);
	 
	 /**
	  * 
	 * Title: unAuditIdsByTemplateId
	 * Description:根据自动化营销id获取未审核的id集合
	 * @param templateId
	 * @return
	  */
	 List<Integer> unAuditIdsByTemplateId(@Param("templateId") int templateId);
	 /**
	  * 
	 * Title: getTemplateIdById
	 * Description:根据id查询自动化营销id
	 * @param id
	 * @return
	  */
	 Integer getTemplateIdById(@Param("id") int id);
	 /**
	  * 
	 * Title: deleteByTemplateId
	 * Description:根据自动化营销templateId删除
	 * @param templateId
	 * @return
	  */
	 int deleteByTemplateId(@Param("templateId") int templateId);
	 /**
	  * 
	 * Title: getTemplateStatusBySocialSmsId
	 * Description:根据批次id查询自动化营销状态
	 * @param id
	 * @return
	  */
	 Integer getTemplateStatusBySocialSmsId(@Param("id") int id);
	 
	 List<String> batchNameListByThirdCouponModelId(@Param("modelId") String thirdPartyCouponModelId);

}