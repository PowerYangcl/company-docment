package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.markting.SocailCoupon;
@Repository("socailCouponMapper")
public interface SocailCouponMapper {


    int deleteByPrimaryKey(Integer id);

    int insert(SocailCoupon record);

    int insertSelective(SocailCoupon record);
    SocailCoupon selectByPrimaryKey(Integer id);
    int updateByPrimaryKeySelective(SocailCoupon record);
    int updateByPrimaryKey(SocailCoupon record);
    int isExist(@Param("name") String name, @Param("id") String id);
    List<Map<String,Object>> getList(Map<String, Object> map);
    int countTotal(Map<String, Object> map);
    int OffTheShelves(int id);
    int OnTheShelves(int id);
    int delete(int id);
	int deleteBatch(List<Long> ids);
	int offSgelvesBatch(List<Long> ids);
	//判断优惠券模板是否被使用
	int isUsedById(int id);
	
	int isUsedByIds(List<Long> ids);
	
	int updateStatus();
	
	List<SocailCoupon> getListByIds(Map<String,Object> map);
}