package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.CouponBatchClickStatistics;
import cn.cecook.model.business.markting.BmActivityBrowse;
import cn.cecook.model.business.markting.BmActivityBrowseExample;

public interface BmActivityBrowseMapper {
	int countByExample(BmActivityBrowseExample example);

	int deleteByExample(BmActivityBrowseExample example);

	int deleteByPrimaryKey(long id);

	int insert(BmActivityBrowse record);

	int insertSelective(BmActivityBrowse record);

	List<BmActivityBrowse> selectByExample(BmActivityBrowseExample example);

	BmActivityBrowse selectByPrimaryKey(long id);

	int updateByExampleSelective(@Param("record") BmActivityBrowse record,
                                 @Param("example") BmActivityBrowseExample example);

	int updateByExample(@Param("record") BmActivityBrowse record,
                        @Param("example") BmActivityBrowseExample example);

	int updateByPrimaryKeySelective(BmActivityBrowse record);

	int updateByPrimaryKey(BmActivityBrowse record);

	List<Map<String,Object>> browseList(Map<String, Object> map);

	int totalCount(Map<String, Object> map);
	
	
	Map<String,Integer> countOpen(long activity_id);
	Map<String,Integer> countOpen2(long activity_id);
	
	int countTransmit(long customer_id);
	
	List<CouponBatchClickStatistics> getListByCouponBatchId(Map<String,Object> map);
	
	int countByCouponBatchId(int batchId);

}