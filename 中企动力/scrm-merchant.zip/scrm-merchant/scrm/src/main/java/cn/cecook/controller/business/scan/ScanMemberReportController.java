package cn.cecook.controller.business.scan;

import java.io.OutputStream;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.scan.ScanMemberReport;
import cn.cecook.service.business.scan.ScanMemberReportService;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.Pages;

@Controller
@RequestMapping("/scan/memberReport")
public class ScanMemberReportController {
	@Autowired
	private ScanMemberReportService memberReportService;
	
	@RequestMapping(value = "/getPages", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getPages(@RequestBody String param) {
		JsonObject result = new JsonObject();
		Gson gson = new Gson();
		JsonParser parser = new JsonParser();
		JsonObject jsonObject = parser.parse(param).getAsJsonObject();
		Pages<ScanMemberReport> pages = memberReportService.getPages(jsonObject);
		int draw = jsonObject.get("draw").getAsInt();
		int recordsTotal = pages.getTotalCount();
		int recordsFiltered = recordsTotal;
		result.addProperty("draw", draw);
		result.addProperty("recordsTotal", recordsTotal);
		result.addProperty("recordsFiltered", recordsFiltered);
		result.add("data", parser.parse(gson.toJson(pages.getItems())));
        return result.toString();
    }
	
	@RequestMapping(value = "/sumAll", produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String sumAll(@RequestParam Map<String,Object> where) {
		JsonObject result = new JsonObject();
		try {
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			Map<String,Object> sumAll = memberReportService.sumAll(where);
			result.addProperty("code", 1);
			result.add("data",parser.parse(gson.toJson(sumAll)));
		} catch (Exception e) {
			result.addProperty("code", 0);
		}
		
		return result.toString();
	}
	
	@RequestMapping(value = "/memberLine", produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String memberLine(@RequestParam Map<String,Object> where) {
		JsonObject result = new JsonObject();
		try {
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			List<ScanMemberReport> list = memberReportService.memberLine(where);
			result.addProperty("code", 1);
			result.add("data",parser.parse(gson.toJson(list)));
		} catch (Exception e) {
			e.printStackTrace();
			result.addProperty("code", 0);
		}
		
		return result.toString();
	}
	@RequestMapping(value = "/memberBarAll", produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String memberBarAll(@RequestParam Map<String,Object> where) {
		JsonObject result = new JsonObject();
		try {
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			List<ScanMemberReport> list = memberReportService.memberBarAll(where);
			result.addProperty("code", 1);
			result.add("data",parser.parse(gson.toJson(list)));
		} catch (Exception e) {
			e.printStackTrace();
			result.addProperty("code", 0);
		}
		
		return result.toString();
	}
	@RequestMapping(value = "/memberLineAll", produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String memberLineAll(@RequestParam Map<String,Object> where) {
		JsonObject result = new JsonObject();
		try {
			Gson gson = new Gson();
			JsonParser parser = new JsonParser();
			List<ScanMemberReport> list = memberReportService.memberLineAll(where);
			result.addProperty("code", 1);
			result.add("data",parser.parse(gson.toJson(list)));
		} catch (Exception e) {
			e.printStackTrace();
			result.addProperty("code", 0);
		}
		
		return result.toString();
	}
	
	@RequestMapping(value = "/exportMemberReport")
    public void exportMemberReport(String startTime,String endTime,String storeId,String storeIds,
    		HttpServletRequest request,HttpServletResponse response) throws Exception {
		Cookie[] cookies = request.getCookies();
		String tenantId = CookieUtil.getCookieSet(cookies).get("tenant_id");
		List<ScanMemberReport> listMemberReport = memberReportService.listMemberReport(tenantId, startTime, endTime,storeId,storeIds);
		response.setContentType("application/ms-txt.numberformat:@");
		response.setCharacterEncoding("utf-8");
		response.setHeader("Pragma", "public");
		response.setHeader("Cache-Control", "max-age=30");
		response.setHeader("Content-Disposition", "attachment; filename="+UUID.randomUUID()+".csv");
		OutputStream os = response.getOutputStream();
		StringBuffer buf = new StringBuffer();
		buf.append("日期,门店,新增会员,消费会员,参与活动会员,储值会员,复购会员\r\n");
		for (int i = 0; i < listMemberReport.size(); i++) {
			ScanMemberReport r = listMemberReport.get(i);
			buf.append(r.getDate()+","+r.getStoreName()+","+r.getCreateCustomerNumber()+","+r.getConsumeCustomerNumber()+","
					+r.getJoinCustomerNumber()+","+r.getBalanceCustomerNumber()+","+r.getRePurchaseCustomerNumber()+"\r\n");
		}
		os.write(buf.toString().getBytes("GBK"));
		os.flush();
    }
}