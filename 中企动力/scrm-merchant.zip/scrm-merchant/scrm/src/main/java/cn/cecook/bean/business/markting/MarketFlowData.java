package cn.cecook.bean.business.markting;


import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

import cn.cecook.uitls.DateUtils;

public class MarketFlowData implements Serializable{
	
	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;
	private long id;
	private String uuid;
	private String tenant_id;
	private String activity_name;
	private String activity_description;
	private String activity_url;
	private String coupong_send_type;
	private int coupon_number;
	private int transmit_rule;
	private Timestamp start_time;
	private Timestamp end_time;
	private Timestamp expire_time;
	private String expire_remind_time;
	private String send_type;
	private int behavior_rule;
	private String send_time;
	private String activity_send_time;
	private String source;
	private String tag;
	private String bak1;
	private Long create_id;
	private String userEmail;
	private String userEmailPwd;
	
	public String getUserEmail() {
		return userEmail;
	}
	public void setUserEmail(String userEmail) {
		this.userEmail = userEmail;
	}
	public String getUserEmailPwd() {
		return userEmailPwd;
	}
	public void setUserEmailPwd(String userEmailPwd) {
		this.userEmailPwd = userEmailPwd;
	}
	public Long getCreate_id() {
		return create_id;
	}
	public void setCreate_id(Long create_id) {
		this.create_id = create_id;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getBak1() {
		return bak1;
	}
	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public static long getSerialversionuid() {
		return serialVersionUID;
	}
	public int getBehavior_rule() {
		return behavior_rule;
	}
	public void setBehavior_rule(int behavior_rule) {
		this.behavior_rule = behavior_rule;
	}
	
	public String getSend_time() {
		return send_time;
	}
	public void setSend_time(String send_time) {
		this.send_time = send_time;
	}
	public String getActivity_send_time() {
		return activity_send_time;
	}
	public void setActivity_send_time(String activity_send_time)  {
		Date date=DateUtils.string2Date(activity_send_time,"yyyy-MM-dd");
		this.activity_send_time =DateUtils.getISO8601Timestamp(date);
	}
	public void setActivity_send_time(Date activity_send_time)  {
		
		this.activity_send_time =DateUtils.getISO8601Timestamp(activity_send_time);
	}
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}
	public String getActivity_name() {
		return activity_name;
	}
	public void setActivity_name(String activity_name) {
		this.activity_name = activity_name;
	}
	public String getActivity_description() {
		return activity_description;
	}
	public void setActivity_description(String activity_description) {
		this.activity_description = activity_description;
	}

	
	public String getActivity_url() {
		return activity_url;
	}
	public void setActivity_url(String activity_url) {
		this.activity_url = activity_url;
	}
	public String getCoupong_send_type() {
		return coupong_send_type;
	}
	public void setCoupong_send_type(String coupong_send_type) {
		this.coupong_send_type = coupong_send_type;
	}
	public int getCoupon_number() {
		return coupon_number;
	}
	public void setCoupon_number(int coupon_number) {
		this.coupon_number = coupon_number;
	}
	public int getTransmit_rule() {
		return transmit_rule;
	}
	public void setTransmit_rule(int transmit_rule) {
		this.transmit_rule = transmit_rule;
	}
	public Timestamp getStart_time() {
		return start_time;
	}
	public void setStart_time(Timestamp start_time) {
		this.start_time = start_time;
	}
	public Timestamp getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Timestamp end_time) {
		this.end_time = end_time;
	}
	public Timestamp getExpire_time() {
		return expire_time;
	}
	public void setExpire_time(Timestamp expire_time) {
		Date date=DateUtils.transTimestamp(expire_time);
		expire_remind_time=DateUtils.getISO8601Timestamp(date);
		System.out.println("优惠券到齐提醒----》"+expire_remind_time);
		this.expire_time = expire_time;
	}
	public String getExpire_remind_time() {
		return expire_remind_time;
	}
	public void setExpire_remind_time(String expire_remind_time) {
		this.expire_remind_time = expire_remind_time;
	}
	public String getSend_type() {
		return send_type;
	}
	public void setSend_type(String send_type) {
		this.send_type = send_type;
	}
	

	
	
	

}
