package cn.cecook.dao.business.markting;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmTransmit;

public interface BmTransmitMapper {

    int deleteByPrimaryKey(Long id);

    int insert(BmTransmit record);

    int insertSelective(BmTransmit record);


    BmTransmit selectByPrimaryKey(Long id);


    int updateByPrimaryKeySelective(BmTransmit record);

    int updateByPrimaryKey(BmTransmit record);
    
    int transmitNum(@Param("id") long id,
                    @Param("transmitTag") String transmitTag,
                    @Param("activity_type") int activity_type);
    
    int countUserTransmit(String customer_id);
    
}