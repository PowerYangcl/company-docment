package cn.cecook.controller.api;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.bean.business.markting.ReqRainingOrder;
import cn.cecook.model.business.customer.BcCustomer;
import cn.cecook.service.business.markting.SynWithCRMService;
import org.apache.ibatis.annotations.Param;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

/**
 * Created by scar on 2017/10/13.
 */
@Controller
@RequestMapping(value = "/API/synWithCRM")
public class APISynWithCRM {

    @Autowired
    private SynWithCRMService synWithCRMService;

    @RequestMapping(value = "/upsertMember")
    @ResponseBody
    public BaseResultModel upsertMember(BcCustomer bcCustomer) {
        return synWithCRMService.upsertMember(bcCustomer);
    }


    @RequestMapping(value = "/addTransaction")
    @ResponseBody
    public BaseResultModel addTransaction(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.addTransaction(reqRainingOrder);
    }

    @RequestMapping(value = "/cancelTransaction")
    @ResponseBody
    public BaseResultModel cancelTransaction(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.cancelTransaction(reqRainingOrder);
    }


    @RequestMapping(value = "/openCRMService")
    @ResponseBody
    public BaseResultModel openCRMService(@Param("tenant_id") String tenant_id, @Param("count") int count) {
        return synWithCRMService.openCRMService(tenant_id, count);
    }

    @RequestMapping(value = "/findCouponsByPhone")
    @ResponseBody
    public BaseResultModel findCouponsByPhone(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.findCouponsByPhone(reqRainingOrder.getTenant_id(), reqRainingOrder.getPhone());
    }


    @RequestMapping(value = "/findProductsByPhone")
    @ResponseBody
    public BaseResultModel findProductsByPhone(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.findProductsByPhone(reqRainingOrder.getTenant_id(), reqRainingOrder.getPhone());
    }


    @RequestMapping(value = "/findStaffByJobNumber")
    @ResponseBody
    public BaseResultModel findStaffByJobNumber(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.findStaffByJobNumber(reqRainingOrder.getTenant_id(), reqRainingOrder.getJobNumber());
    }

    @RequestMapping(value = "/findMemberByPhone")
    @ResponseBody
    public BaseResultModel findMemberByPhone(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.findMemberByPhone(reqRainingOrder);
    }
    /**
     * 获取crm端同步的交易信息
     * @param reqRainingOrder
     * @return
     * majie
     */
    @RequestMapping(value = "/receiveTransaction")
    @ResponseBody
    public BaseResultModel receiveTransaction(@RequestBody ReqRainingOrder reqRainingOrder) {
        return synWithCRMService.receiveTransaction(reqRainingOrder);
    }
}
