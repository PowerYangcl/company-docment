package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.scan.ScanRule;
import cn.cecook.model.business.scan.ScanRuleExample;

public interface ScanRuleMapper {
    long countByExample(ScanRuleExample example);

    int deleteByExample(ScanRuleExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ScanRule record);

    int insertSelective(ScanRule record);

    List<ScanRule> selectByExample(ScanRuleExample example);

    ScanRule selectByPrimaryKey(Integer id);
    ScanRule selectByPrimaryKey2(Map<String, Object> map);

    int updateByExampleSelective(@Param("record") ScanRule record, @Param("example") ScanRuleExample example);

    int updateByExample(@Param("record") ScanRule record, @Param("example") ScanRuleExample example);

    int updateByPrimaryKeySelective(ScanRule record);

    int updateByPrimaryKey(ScanRule record);

    List<Map<String, Object>> getAddress(String parent_code);

    List<ScanRule> getRuleList(int type);

    void deleteRule(int ruleId);

    List<String> getTenantId();
    List<ScanRule> getRule(@Param("tenantId") String tenantId);
    
    long countByName(@Param("name") String name, @Param("type") int type, @Param("ruleId") Integer ruleId);
}