package cn.cecook.intercept.shiro.shiroRedis;

import java.util.concurrent.ConcurrentHashMap;
import java.util.concurrent.ConcurrentMap;

import org.apache.shiro.cache.Cache;
import org.apache.shiro.cache.CacheException;
import org.apache.shiro.cache.CacheManager;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.cecook.uitls.RedisUtil;

/**
 * 是自己redis的RedisCacheManager存储实现类
 * 
 * 基于cache DB缓存的session共享
 * 即使用cacheDB存取session信息，应用服务器接受新请求将session信息保存在cache DB中，当应用服务器发生故障时，
 * web服务器（apache/nginx）会遍历寻找可用节点，分发请求，当应用服务器发现session不在本机内存 时，
 * 则去cache DB中查找，如果找到则复制到本机，这样实现session共享和高可用。
 * @author zhanghao
 *
 */
public class RedisCacheManager implements CacheManager {

	private static final Logger logger = LoggerFactory
			.getLogger(RedisCacheManager.class);

	// fast lookup by name map
	private final ConcurrentMap<String, Cache> caches = new ConcurrentHashMap<String, Cache>();

	private RedisUtil redisManager;

	/**
	 * The Redis key prefix for caches 
	 */
	private String keyPrefix = "redis_session_shiro:";
	
	/**
	 * Returns the Redis session keys
	 * prefix.
	 * @return The prefix
	 */
	public String getKeyPrefix() {
		return keyPrefix;
	}

	/**
	 * Sets the Redis sessions key 
	 * prefix.
	 * @param keyPrefix The prefix
	 */
	public void setKeyPrefix(String keyPrefix) {
		this.keyPrefix = keyPrefix;
	}
	
	@Override
	public <K, V> Cache<K, V> getCache(String name) throws CacheException {
		logger.debug("获取名称为: " + name + " 的RedisCache实例");
		
		Cache c = caches.get(name);
		
		if (c == null) {

			// initialize the Redis manager instance
			//redisManager.init();
			
			// create a new cache instance
			c = new RedisCache<K, V>(redisManager, keyPrefix);
			
			// add it to the cache collection
			caches.put(name, c);
		}
		return c;
	}

	public RedisUtil getRedisManager() {
		return redisManager;
	}

	public void setRedisManager(RedisUtil redisManager) {
		this.redisManager = redisManager;
	}

}
