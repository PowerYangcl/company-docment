package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcCustomerSource;
import cn.cecook.model.business.customer.BcCustomerSourceExample;

/**
 * 
* @explain 客户来源表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcCustomerSourceMapper {
    int countByExample(BcCustomerSourceExample example);

    int deleteByExample(BcCustomerSourceExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcCustomerSource record);

    int insertSelective(BcCustomerSource record);

    List<BcCustomerSource> selectByExample(BcCustomerSourceExample example);

    BcCustomerSource selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcCustomerSource record,
                                 @Param("example") BcCustomerSourceExample example);

    int updateByExample(@Param("record") BcCustomerSource record, @Param("example") BcCustomerSourceExample example);

    int updateByPrimaryKeySelective(BcCustomerSource record);

    int updateByPrimaryKey(BcCustomerSource record);

    /**
     * 获取客户来源列表数据
     * @return
     */
    List<BcCustomerSource> getList();
}