package cn.cecook.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.system.SysSmsCode;
import cn.cecook.model.system.SysSmsCodeExample;

/**
 * 
* @explain 短信验证码表
* @author wschenyongyin
* @date 2017年5月22日
 */
@Repository("sysSmsCodeMapper")
public interface SysSmsCodeMapper {
    int countByExample(SysSmsCodeExample example);

    int deleteByExample(SysSmsCodeExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysSmsCode record);

    int insertSelective(SysSmsCode record);

    List<SysSmsCode> selectByExample(SysSmsCodeExample example);

    SysSmsCode selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysSmsCode record, @Param("example") SysSmsCodeExample example);

    int updateByExample(@Param("record") SysSmsCode record, @Param("example") SysSmsCodeExample example);

    int updateByPrimaryKeySelective(SysSmsCode record);

    int updateByPrimaryKey(SysSmsCode record);
    /**
     * 
    * Title: insertCode
    * @author wschenyongyin
    * Description:
    * @param map
    * @return
     */
    int insertCode(SysSmsCode record);
    
    int insertCodeByTime(SysSmsCode record);
    /**
     * 
     * @explain 查单个对象
     * @author LeeX
     * @date 2017年6月30日 下午1:34:55
     */
	SysSmsCode selectCodeById(long id);
}