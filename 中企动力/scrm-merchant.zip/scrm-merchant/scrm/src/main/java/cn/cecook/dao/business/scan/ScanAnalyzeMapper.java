package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

public interface ScanAnalyzeMapper {
	/**
	 * 发起活动量
	 * @return
	 */
	List<Map<String,Object>> activityCountTop10();
	/**
	 * 参与活动人数
	 * @return
	 */
	List<Map<String,Object>> peopleCountTop10();
	/**
	 * 会员增长量
	 * @return
	 */
	List<Map<String,Object>> growCountTop10();
	/**
	 * 交易额
	 * @return
	 */
	List<Map<String,Object>> costTotalTop10();
}