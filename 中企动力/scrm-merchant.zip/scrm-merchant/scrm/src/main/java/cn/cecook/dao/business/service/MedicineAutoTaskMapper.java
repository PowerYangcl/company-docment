package cn.cecook.dao.business.service;

import java.util.List;

import cn.cecook.model.business.service.MedicineAutoTask;

public interface MedicineAutoTaskMapper {


    int deleteByPrimaryKey(Integer id);

    int insert(MedicineAutoTask record);

    int insertSelective(MedicineAutoTask record);

    MedicineAutoTask selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(MedicineAutoTask record);

    int updateByPrimaryKey(MedicineAutoTask record);
    
    int insertIgonreByBatch(List<MedicineAutoTask> list);
    
    int medicineIsExist(int id);
   
    int updateAutoTaskId(MedicineAutoTask record);
   
    List<Integer> queryMediciineIdByTaskId(int taskId);
    
    int deletedByTaskId(int taskId);
    
    int getTaskIdByMedicineId(int taskId);
}