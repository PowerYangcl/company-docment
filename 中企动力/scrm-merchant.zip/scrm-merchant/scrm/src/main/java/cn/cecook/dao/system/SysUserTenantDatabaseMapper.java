package cn.cecook.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysUserTenantDatabase;
import cn.cecook.model.system.SysUserTenantDatabaseExample;

/**
 * 
* @explain 租户数据库表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysUserTenantDatabaseMapper {
    int countByExample(SysUserTenantDatabaseExample example);

    int deleteByExample(SysUserTenantDatabaseExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysUserTenantDatabase record);

    int insertSelective(SysUserTenantDatabase record);

    List<SysUserTenantDatabase> selectByExample(SysUserTenantDatabaseExample example);

    SysUserTenantDatabase selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysUserTenantDatabase record, @Param("example") SysUserTenantDatabaseExample example);

    int updateByExample(@Param("record") SysUserTenantDatabase record, @Param("example") SysUserTenantDatabaseExample example);

    int updateByPrimaryKeySelective(SysUserTenantDatabase record);

    int updateByPrimaryKey(SysUserTenantDatabase record);
}