package cn.cecook.intercept;

import cn.cecook.dao.business.markting.SysTenantDatabaseMapper;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.SpringApplicationContextHolderUtil;
import cn.cecook.uitls.StringUtils;
import cn.cecook.uitls.redis.RedisConfig;
import cn.cecook.uitls.redis.RedisStringUtil;
import com.alibaba.fastjson.JSONObject;
import org.springframework.http.MediaType;
import org.springframework.stereotype.Component;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.multipart.commons.CommonsMultipartResolver;

import javax.servlet.*;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.util.Map;
import java.util.Objects;

@Component
public class MyCatFilter implements Filter {


    private SysTenantDatabaseMapper tenantDao;

    private static final ThreadLocal<String> SCHEMA_LOCAL = new ThreadLocal<>();
    private static final ThreadLocal<String> TENANT_ID_LOCAL = new ThreadLocal<>();
    private static final ThreadLocal<Boolean> TOKEN_VALID = new ThreadLocal<>();
    public static MyCatFilter myCatFilter;

    public static String getSchema() {
        String schema = SCHEMA_LOCAL.get();
        if (!StringUtils.isEmpty(schema)) {
            return schema;
        } else {
            return ConfigUtil.SCHEMA_NAME;
        }
    }

    public static String getTenant_Id() {
        String tenant_id = TENANT_ID_LOCAL.get();
        if (!StringUtils.isEmpty(tenant_id)) {
            return tenant_id;
        } else {
            return "";
        }
    }

    public static boolean getToken_Valid() {
        return TOKEN_VALID.get();

    }


    @Override
    public void init(FilterConfig filterConfig) throws ServletException {
        // TODO Auto-generated method stub

    }

    @Override
    public void doFilter(ServletRequest request, ServletResponse response,
                         FilterChain chain) throws IOException, ServletException {
        // TODO Auto-generated method stub
        try {
            HttpServletRequest req = (HttpServletRequest) request;
            String tenant_id = "";
            String servletPath = req.getServletPath();

            String contentType = request.getContentType();

            if (contentType != null && contentType.contains(MediaType.APPLICATION_FORM_URLENCODED_VALUE)) {
                tenant_id = req.getParameter("tenant_id");
            } else if (contentType != null && contentType.contains(MediaType.APPLICATION_JSON_VALUE)) {

                ServletRequest requestWrapper = new BodyReaderHttpServletRequestWrapper(req);
                BufferedReader reader = new BufferedReader(new InputStreamReader(requestWrapper.getInputStream()));
                StringBuilder text = new StringBuilder();
                String aux;

                while ((aux = reader.readLine()) != null) {
                    text.append(aux);
                }

                if (StringUtils.isNotBlank(text)) {
                    System.out.println(text);
                }
                JSONObject jsonObject = JSONObject.parseObject(text.toString());
                tenant_id = jsonObject.getString("tenant_id");
                //重置request   ！！！
                request = requestWrapper;
                req = (HttpServletRequest) request;

            } else if (contentType != null && contentType.contains(MediaType.MULTIPART_FORM_DATA_VALUE)) {
                MultipartHttpServletRequest multipartHttpServletRequest = new CommonsMultipartResolver().resolveMultipart(req);
                tenant_id = multipartHttpServletRequest.getParameter("tenant_id");
                if (tenant_id == null) {
                    tenant_id = multipartHttpServletRequest.getParameter("brand_id");
                }
                //重置request   ！！！
                request = multipartHttpServletRequest;
                req = (HttpServletRequest) request;
            }
            /**
             * 单独处理亚博松接口的租户id
             */
            if (Objects.equals(servletPath, "/API/YBSTicket/receiveTicket")) {
                MultipartHttpServletRequest multipartHttpServletRequest = new CommonsMultipartResolver().resolveMultipart(req);
                tenant_id = multipartHttpServletRequest.getParameter("brand_id");
                request = multipartHttpServletRequest;
                System.out.println("____ybs-success_______mycatfilter____________" + tenant_id);

            }

            String account = req.getParameter("uid");
            String token = req.getParameter("access_token");

            if (StringUtils.isEmpty(tenant_id)) {
                tenant_id = req.getParameter("tenant_id");
                if (StringUtils.isEmpty(tenant_id)) {
                    Cookie[] cookies = req.getCookies();
                    Map map = CookieUtil.getCookieSet(cookies);
                    if (map != null) {
                        tenant_id = (String) map.get("tenant_id");
                        account = (String) map.get("uid");
                        token = (String) map.get("access_token");
                    }
                }
            }

            System.out.println("___________mycatfilter____________" + tenant_id);

//			// 判断用户token是否有效
//			if (!StringUtils.isEmpty(token) && !StringUtils.isEmpty(account)
//					&& !StringUtils.isEmpty(tenant_id)) {
//				TOKEN_VALID.set(TokenUtil.checkToken(account, token));
//			} else {
//				TOKEN_VALID.set(false);
//			}
            TOKEN_VALID.set(true);

            String schema = "";
            // 根据租户id查询租户对应的数据库
            if (!StringUtils.isEmpty(tenant_id)) {
                // 静态的本地线程变量来存储租户信息
                TENANT_ID_LOCAL.set(tenant_id);
                schema = RedisStringUtil.getValue(RedisConfig.TENANT_SCHEMA + tenant_id);
                if (StringUtils.isEmpty(schema)) {
                    tenantDao = (SysTenantDatabaseMapper) SpringApplicationContextHolderUtil.getSpringBean("sysTenantDatabaseMapper");
                    // 根据租户id查询schema逻辑数据库
                    schema = tenantDao.getTenantSchema(tenant_id);//
                    if (!StringUtils.isEmpty(schema)) {
                        RedisStringUtil.setData(RedisConfig.TENANT_SCHEMA + tenant_id, schema);
                    }
                }
                // 静态的本地线程变量来存储数据库信息
                SCHEMA_LOCAL.set(schema);
                // chain
                chain.doFilter(request, response);
            } else {
                chain.doFilter(request, response);
            }
        } finally {
            SCHEMA_LOCAL.remove();
        }

    }

    @Override
    public void destroy() {
        // TODO Auto-generated method stub
    }

}
