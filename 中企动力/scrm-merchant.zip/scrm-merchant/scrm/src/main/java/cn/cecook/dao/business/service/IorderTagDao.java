package cn.cecook.dao.business.service;

import java.util.List;

import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.OrderTag;

/**
 * 
 * @作者	马杰
 * @时间	2017年5月13日-下午4:47:46
 * @介绍	dao方法接口
 */
@Repository
public interface IorderTagDao {	
	/**
	 * 查询(可分页)
	 * @param orderTag	条件模糊查询
	 * @return
	 */
	public List<OrderTag> findAll(OrderTag orderTag);
	/**
	 * 获取记录总数
	 * @param orderTag	多条件获取
	 * @return
	 */
	public int getCount(OrderTag orderTag);
	/**
	 * 添加
	 * @param orderTag
	 * @return
	 */
	public int addOrderTag(OrderTag orderTag);
	/**
	 * 删除信息
	 * @param id
	 * @return
	 */
	public int delete(int id);
	/**
	 * 查询单条记录
	 * @param orderTag
	 * @return
	 */
	public OrderTag findOne(OrderTag orderTag);
	/**
	 * 修改信息
	 * @return
	 */
	public int update(OrderTag orderTag);
	
}
