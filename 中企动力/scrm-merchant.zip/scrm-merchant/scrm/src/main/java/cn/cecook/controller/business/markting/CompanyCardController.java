package cn.cecook.controller.business.markting;

import java.io.IOException;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import com.amazonaws.services.s3.model.ObjectMetadata;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.dao.system.SysUserMapper;
import cn.cecook.model.business.markting.BmCompanyCard;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.business.markting.CompanyCardService;
import cn.cecook.service.business.markting.CouponService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.amazonaws.FileUtil;

@Controller
@RequestMapping("/api/company_card")
public class CompanyCardController {

	@Autowired
	private CompanyCardService companyCardService;

	@Autowired
	private CouponService couponService;
	
	@Resource
    private SysUserMapper sysUserMapper;
	
	 @Value("#{configProperties['PROJECT_URL']}")
	 private String FILE_URL;
	/**
	 * 添加企业名片
	 * 
	 * @param bmCompanyCard
	 * @return
	 */
	@RequestMapping(value = "/insertcard")
	@ResponseBody
	public Object insertCard(BmCompanyCard bmCompanyCard) {
		return (companyCardService.insertCard(bmCompanyCard));
	}

	/**
	 * 二次点击暂存时进行的修改操作
	 * 
	 * @param bmCompanyCard
	 * @return
	 */
	@RequestMapping(value = "/updatecard")
	@ResponseBody
	public Object updateCompanyCard(BmCompanyCard bmCompanyCard) {
		return (companyCardService.updateCompanyCard(bmCompanyCard));
	}

	/**
	 * 根据企业名片id查询
	 * 
	 * @param bmCompanyCard
	 * @return
	 */
	@RequestMapping(value = "/querycard")
	@ResponseBody
	public Object queryCompanyCard(BmCompanyCard bmCompanyCard) {

		return (companyCardService.queryCompanyCard(bmCompanyCard));
	}

	/**
	 * 根据用户id查询
	 * 
	 * @param bmCompanyCard
	 * @return
	 */
	@RequestMapping(value = "/querycardByUid")
	@ResponseBody
	public Object queryCompanyCardByUid(BmCompanyCard bmCompanyCard) {
		return (companyCardService.queryCompanyCard(bmCompanyCard));
	}
	
	/**
	 * 浏览企业名片
	 * 
	 * @param bmCompanyCard
	 * @return
	 */
	@RequestMapping(value = "/browsecard")
	@ResponseBody
	public Object browseCompanyCard(String id, String browse_ip,
			String open_way, String open_id) {

		return (companyCardService.browseCompanyCard(id, browse_ip, open_way,
				open_id));
	}
	
	
	@RequestMapping(value = "/createBrowse")
	@ResponseBody
	public Object createBrowse(String id, String browse_ip,
			String open_way, String open_id) {

		return (companyCardService.createBrowse(id, browse_ip, open_way,
				open_id));
	}

	/**
	 * 
	 * Title: queryActivityList Description:根据名片id查询活动列表
	 * 
	 * @param card_id
	 * @return
	 */
	@RequestMapping(value = "/queryActivityList")
	@ResponseBody
	public Object queryActivityList(String card_id) {

		return (companyCardService.queryActivityList(card_id));
	}

	/**
	 * 
	 * Title: insertCardActivity Description:创建
	 * 
	 * @param card_id
	 * @param ids
	 * @param type
	 *            1.表示用系统模板创建的活动 2.表示用自定义模板穿件的活动
	 * @return
	 */
	@RequestMapping(value = "/insertCardActivity")
	@ResponseBody
	public Object insertCardActivity(String card_id, String ids, String type) {

		if (type.equals("1")) {
			// return (companyCardService.insertCardModel(card_id, ids));
			return (companyCardService.insertCardActivity(card_id, ids, type));
		} else {
			System.out.println("------------------------>nishiashdi");
			return (companyCardService.insertCardActivity(card_id, ids, type));
		}

	}

	/**
	 * 
	 * Title: updateCardActivity Description:更新
	 * 
	 * @param card_idv
	 * @param ids
	 * @param type
	 *            1.表示用系统模板创建的活动 2.表示用自定义模板穿件的活动
	 * @return
	 */
	@RequestMapping(value = "/updateCardActivity")
	@ResponseBody
	public Object updateCardActivity(String card_id, String ids, String type ,String business_tag) {
		return (companyCardService.updateCardActivity(card_id, ids, type, business_tag));

	}

	/**
	 * 
	 * Title: deleteCard Description:删除名片
	 * 
	 * @param card_id
	 * @return
	 */
	@RequestMapping(value = "/deleteCard")
	@ResponseBody
	public Object deleteCard(String card_id) {

		return (companyCardService.deleteCard(card_id));
	}

	/**
	 * 
	 * Title: queryCardList Description:查询名片列表
	 * 
	 * @param startIndex
	 *            开始下表
	 * @param pageSize
	 *            获取数据大小
	 * @param keyWord
	 *            关键字
	 * @param status
	 *            状态
	 * @return
	 */
	@RequestMapping(value = "/queryCardList")
	@ResponseBody
	public Object queryCardList(String startIndex, String pageSize,
			String keyWord, String status) {
		return (companyCardService.queryCardList(startIndex, pageSize, keyWord,
				status));
	}

	@RequestMapping(value = "/sharecard")
	@ResponseBody
	public Object setShareCard(String card_id) {
		return (companyCardService.setShareCard(card_id));
	}

	/**
	 * 
	 * Title: setShareCard Description:
	 * 
	 * @return
	 */
	@RequestMapping(value = "/getsharecard")
	@ResponseBody
	public Object getShareCard() {
		return (companyCardService.getShareCardId());
	}

	/**
	 * 
	 * Title: cardTransmit Description:名片转发统计接口 统计名片转发
	 * 
	 * @return
	 */
	@RequestMapping(value = "/transmit")
	@ResponseBody
	public Object cardTransmit() {
		return (companyCardService.getShareCardId());
	}

	//查询用户是否已经有卡
	@RequestMapping(value = "/getUserCardCount")
	@ResponseBody
	public Object getUserCardCount(String id) {
		return (companyCardService.getUserCardCount(id));
	}


	@RequestMapping(value = "/statistics")
	@ResponseBody
	public Object Statistics(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		String type = jsonObj.get("type").getAsString();

		String keyWord = "";
		String orderBy = "";
		if (jsonObj.get("keyWord") != null) {
			keyWord = jsonObj.get("keyWord").getAsString();
		}
		if (jsonObj.get("orderBy") != null) {
			orderBy = jsonObj.get("orderBy").getAsString();
		}
		if (type.equals("wechat")) {
			return (companyCardService.cardStatisticsByWeChat(startIndex,
					pageSize, keyWord, orderBy, draw));
		} else {
			return (companyCardService.cardStatisticsByOther(startIndex,
					pageSize, keyWord, orderBy, draw));
		}

	}

	/**
	 * 修改名片信息
	 * 
	 * @param bmCompanyCard
	 * @return
	 */
	@RequestMapping(value="/updatecardForH5" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object updateCompanyCardForH5(BmCompanyCard bmCompanyCard) {
		JsonObject j = new JsonObject();
		BaseResultModel baseResultModel = companyCardService.updateCompanyCard(bmCompanyCard);
		j.addProperty("error_code", baseResultModel.getError_code());
		j.addProperty("error_message", baseResultModel.getError_msg());
		return j.toString();
	}
	
	/**
	 * 名片登录
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping("/toLogin")
	public ModelAndView toLogin() {
		return new ModelAndView("social/companycard/s01");
	}
	
	/**
	 * 名片主页
	 * @param request
	 * @param response
	 * @return
	 */
    @RequestMapping("/main")
	public ModelAndView toMainPage(HttpServletRequest httpServletRequest) {
		ModelAndView modelAndView = new ModelAndView("social/companycard/s04");
		Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String uid = String.valueOf(session.getAttribute("userId"));
		if(!"".equals(uid) && uid != null && !"null".equals(uid)){
			//通过用户获取这个用户的名片信息
			BaseResultModel result = companyCardService.queryCompanyCardByUid(Long.parseLong(uid));
			if(ConfigStatusCode.AFRESH_LOGIN.equals(result.getError_code())){
				return new ModelAndView("social/companycard/s01");
			}else if("1".equals(result.getError_code())){
				ModelAndView m = new ModelAndView("social/companycard/s01");
				m.addObject("nocard","1");
				return m;
			}
			//将名片信息放入session
	        session.setAttribute("usercompanycard", ((BmCompanyCard)result.getData()).getId());
	        //获取card_id
	        Long card_id = ((BmCompanyCard)result.getData()).getId();
	        //根据card_id查询当日统计数据
	        Map<String, Object> dataOfdate = companyCardService.cardStatisticsForDate(card_id.toString());
	        //根据card_id查询当月统计数据
	        Map<String, Object> dataOfmonth = companyCardService.cardStatisticsForMonth(card_id.toString());
	        //根据card_id查询当年统计数据
	        Map<String, Object> dataOfyear = companyCardService.cardStatisticsForYear(card_id.toString());
	        //我的打开排行排名
	        Map<String, Object> openOfmine = companyCardService.openOfmine(card_id.toString());
	        //我的转化排行排名
	        Map<String, Object> convertOfmine = companyCardService.convertOfmine(card_id.toString());
	        
	        SysUser sysuser = sysUserMapper.selectByPrimaryKey(Long.valueOf(uid));
	        modelAndView.addObject("sysuser", sysuser);
	        modelAndView.addObject("companycard", result.getData());
	        modelAndView.addObject("dataOfdate",dataOfdate.get("data"));
	        modelAndView.addObject("dataOfmonth",dataOfmonth.get("data"));
	        modelAndView.addObject("dataOfyear",dataOfyear.get("data"));
	        modelAndView.addObject("openOfmine",openOfmine.get("data"));
	        modelAndView.addObject("convertOfmine",convertOfmine.get("data"));
	        modelAndView.addObject("fileUrl",FILE_URL);
			return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
	}
	
	
	/**
     * @explain 跳转到找回密码页
     * @author zb
     * @date 2017年12月18日 下午16:53:15
     */
    @RequestMapping("/recoverPwd")
    public String recoverPwd() {
        return "social/companycard/s02";
    }
    
    /**
     * 跳转到修改密码页面(无需输入原密码)
     * @return
     */
    @RequestMapping("/toupdatepwd")
    public ModelAndView toupdatepwd(HttpServletRequest request){
    	 ModelAndView modelAndView = new ModelAndView("social/companycard/s03");
    	 String cz = request.getParameter("cz");
         if ("t".equalsIgnoreCase(cz)) {
        	 String account = request.getParameter("account");
        	 modelAndView.addObject("account",account);
             return modelAndView;
         } else {
        	 return new ModelAndView("social/companycard/s02");
         }
    }
    
    /**
     * 跳转到修改密码页面(需输入原密码)
     * @return
     */
    @RequestMapping("/tomodifypwd")
    public ModelAndView tomodifypwd(){
    	ModelAndView modelAndView = new ModelAndView("social/companycard/s3");
    	Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String uid = String.valueOf(session.getAttribute("userId"));
		if(!"".equals(uid) && uid != null && !"null".equals(uid)){
			SysUser sysuser = sysUserMapper.selectSysUserById(Long.parseLong(uid));
			modelAndView.addObject("sysuser",sysuser);
			return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
    }
    
    /**
     * 跳转到修改名片信息列表页面
     * @return
     */
    @RequestMapping("toModify")
    public ModelAndView toModify(){
    	ModelAndView modelAndView = new ModelAndView("social/companycard/s08");
    	Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String uid = String.valueOf(session.getAttribute("userId"));
		if(!"".equals(uid) && uid != null && !"null".equals(uid)){
			//通过用户获取这个用户的名片信息
			BaseResultModel result = companyCardService.queryCompanyCardByUid(Long.parseLong(uid));
	        if(ConfigStatusCode.AFRESH_LOGIN.equals(result.getError_code())){
	        	return new ModelAndView("social/companycard/s01");
	        }else if("1".equals(result.getError_code())){
				ModelAndView m = new ModelAndView("social/companycard/s01");
				m.addObject("nocard","1");
				return m;
			}
			modelAndView.addObject("bmcompanyCard",((BmCompanyCard)result.getData()));
	        return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
    }
    
    /**
     * 修改详细信息
     * @param request
     * @return
     */
    @RequestMapping("toUpdateCardInfo")
    public ModelAndView toUpdateCardInfo(HttpServletRequest request){
    	ModelAndView modelAndView = new ModelAndView("social/companycard/s09");
    	Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String uid = String.valueOf(session.getAttribute("userId"));
		if(!"".equals(uid) && uid != null && !"null".equals(uid)){
			//通过用户获取这个用户的名片信息
			BaseResultModel result = companyCardService.queryCompanyCardByUid(Long.parseLong(uid));
			if(ConfigStatusCode.AFRESH_LOGIN.equals(result.getError_code())){
				return new ModelAndView("social/companycard/s01");
			}else if("1".equals(result.getError_code())){
				ModelAndView m = new ModelAndView("social/companycard/s01");
				m.addObject("nocard","1");
				return m;
			}
			String point = request.getParameter("point");
			if("1".equals(point)){	//跳转到修改头像页面
				ModelAndView headpicView = new ModelAndView("social/companycard/s9");
				headpicView.addObject("bmcompanyCard",((BmCompanyCard)result.getData()));
				return headpicView;
			}
	    	modelAndView.addObject("point",point);
			modelAndView.addObject("bmcompanyCard",((BmCompanyCard)result.getData()));
	        return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
    }
    
    /**
     * 跳转到统计列表页面
     * @return
     */
    @RequestMapping("/totj")
    public ModelAndView totj(HttpServletRequest httpServletRequest){
    	ModelAndView modelAndView = new ModelAndView("social/companycard/s05");
    	Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		Object obj = session.getAttribute("usercompanycard");
		if(obj != null){
			String cardId = String.valueOf(obj);
			String point = httpServletRequest.getParameter("point");
	    	if("1".equals(point)){	//当日统计
	    		Map<String, Object> result = companyCardService.cardStatisticsForDate(cardId);
	    		modelAndView.addObject("result",result.get("data"));
	    	}else if("2".equals(point)){   //当月统计
	    		Map<String, Object> result = companyCardService.cardStatisticsForMonth(cardId);
	    		modelAndView.addObject("result",result.get("data"));
	    	}else if("3".equals(point)){		//当年统计
	    		Map<String, Object> result = companyCardService.cardStatisticsForYear(cardId);
	    		modelAndView.addObject("result",result.get("data"));
	    	}
	    	modelAndView.addObject("point",point);
	    	return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
    }
    
    /**
     * 跳转到活动转化列表页面
     * @return
     */
    @RequestMapping("/toactivityConvert")
    public ModelAndView toactivityConvert(HttpServletRequest httpServletRequest){
    	ModelAndView modelAndView = new ModelAndView("social/companycard/s06");
    	Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		Object obj = session.getAttribute("usercompanycard");
		if(obj != null){
			String cardId = String.valueOf(obj);
			String point = httpServletRequest.getParameter("point");
	    	if("1".equals(point)){	//当日统计
	    		Map<String, Object> result = couponService.selectActivityRevertListForDate(cardId);
	    		modelAndView.addObject("result",result.get("data"));
	    	}else if("2".equals(point)){   //当月统计
	    		Map<String, Object> result = couponService.selectActivityRevertListForMonth(cardId);
	    		modelAndView.addObject("result",result.get("data"));
	    	}else if("3".equals(point)){		//当年统计
	    		Map<String, Object> result = couponService.selectActivityRevertListForYear(cardId);
	    		modelAndView.addObject("result",result.get("data"));
	    	}
	    	return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
    }
    
    /**
     * 跳转到前十列表页面
     * @return
     */
    @RequestMapping("/topTen")
    public ModelAndView topTen(HttpServletRequest httpServletRequest){
    	Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		Object obj = session.getAttribute("usercompanycard");
		if(obj != null){
	    	ModelAndView modelAndView = new ModelAndView("social/companycard/s07");
			String point = httpServletRequest.getParameter("point");
	    	if("1".equals(point)){	//打开排行
	    		Map<String, Object> result = companyCardService.openTopTen();
	    		modelAndView.addObject("result",result.get("data"));
	    	}else if("2".equals(point)){   //转化排行
	    		Map<String, Object> result = companyCardService.convertTopTen();
	    		modelAndView.addObject("result",result.get("data"));
	    	}
	    	modelAndView.addObject("point",point);
	    	return modelAndView;
		}else{
			return new ModelAndView("social/companycard/s01");
		}
    }
    
    
    @RequestMapping("/uploadHead")
    @ResponseBody
    public Object uploadHead(HttpServletRequest request) throws IOException{		
    	BaseResultModel baseResultModel = new BaseResultModel();
    	MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		Map<String, MultipartFile> map = multipartRequest.getFileMap();
		MultipartFile multipartFile = null;
		for (String fname : map.keySet()) {
            // 获得文件：
            multipartFile = multipartRequest.getFile(fname);
		}
		if(multipartFile == null){
			baseResultModel.setError_msg("上传失败！");
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			return baseResultModel;
		}
		String filename = multipartFile.getOriginalFilename();//获取文件名
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentType("image/jpeg");
		String path="";
		try {
			path = FileUtil.uploadFile(multipartFile.getInputStream(), metadata,filename);
		} catch (IOException e) {
			e.printStackTrace();
			baseResultModel.setError_msg("上传失败！");
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
		}		
		baseResultModel.setData(path);
		baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		baseResultModel.setError_msg("上传成功！");
    	return baseResultModel;
    }
    
    @RequestMapping(value = "/cradList")
	@ResponseBody
	public Object cradList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		String keyWord=jsonObj.get("keyWord").getAsString();

		return (companyCardService.cardList(startIndex, pageSize, draw, keyWord));
	}
    
}
