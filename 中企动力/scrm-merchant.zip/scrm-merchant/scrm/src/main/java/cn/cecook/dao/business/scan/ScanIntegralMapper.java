package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.uitls.Pages;

/**
 * 	积分
 * @author zhaoxin
 * @date 2017年10月23日 下午7:48:06
 */
public interface ScanIntegralMapper {
	/**
	 * 	获取最后一条订单id
	 * @return
	 */
	Integer getLastOrderId(Map<String, Object> where);

	/**
	 * 	获取积分规则
	 * @return
	 */
	Map<String,Object> getIntegralRule(Map<String, Object> where);

	/**
	 * 获取订单
	 * @return
	 */
	List<Map<String,Object>> listOrder(Map<String, Object> where);

	void saveIntegral(Map<String, Object> param);	//定时任务用
	void saveIntegral2(Map<String, Object> param);

	/**
	 * 	积分过期
	 */
	void updateIntegralExpired(Map<String, Object> param);

	void saveIntegralRule(Map<String, Object> param);
	void updateIntegralRule(Map<String, Object> param);

	/**
	 * 	冻结与解冻，和加减积分用
	 * @param param
	 */
	void updateIntegral(Map<String, Object> param);

	/**
     * 分页
     * @param page
     * @return
     */
    List<Map<String, Object>> getPage(Pages<Map<String, Object>> page);
    int count(Map<String, Object> where);

    /**
     * 	获取所有会员id
     * @param param
     * @return
     */
    List<Integer> listMemberId(Map<String, Object> param);

    /**
     * 	获取某个会员的可用积分（不包含过期）
     * @param param
     * @return
     */
    int getIntegral(Map<String, Object> param);

    /**
     * 	获取某个会员已使用的积分（包含过期）
     * @param param
     * @return
     */
    int getUseIntegral(Map<String, Object> param);

    /**
     * 	获取会员获得的积分，正整数的总和（包含过期）
     * @param param
     * @return
     */
    int getGainIntegral(Map<String, Object> param);

    /**
     * 	获取使用获得积分
     * @param param
     * @return
     */
    Map<String,Object> getUseGainIntegral(Map<String, Object> param);

    /**
     * 	获取会员的过期积分
     * @param param
     * @return
     */
    int getExpiredIntegral(Map<String, Object> param);

    /**
     * 	获取会员消费情况
     * @param param
     * @return
     */
    Map<String,Object> getCost(Map<String, Object> param);

    /**
     * 	根据时间，获取某个会员消费
     * @param param
     * @return
     */
    int getCostByDate(Map<String, Object> param);

    /**
     * 	更改会员FRM属性
     * @param param
     */
    void updateMemberRFMAttr(Map<String, Object> param);

    /**
     * 获取一天内创建订单的会员id
	 * @param param
     */
	List<Long> getOrderMemberId(Map<String, Object> param);

	/**
	 *获取之前会员的数据
	 * @param param
	 */
    Map<String,Object> getCustomer(Map<String, Object> param);

    /**
	 *获取昨天消费的金额
	 * @param param
	 */
	Map<String,Object> getYesterDayCost(Map<String, Object> param);
}