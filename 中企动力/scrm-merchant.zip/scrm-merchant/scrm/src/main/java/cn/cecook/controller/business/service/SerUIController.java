package cn.cecook.controller.business.service;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/ser/ui")
public class SerUIController {
	/**
	 * 
	* Title: AutomatedOperation
	* Description:运营自动化
	* @return
	 */
	@RequiresPermissions("scrm_customer_service_auto")
	@RequestMapping("/automatedOperation")
	public String AutomatedOperation() {
		System.out.println("---------->");
		return "service/automatedOperation";
	} 
	
	@RequiresPermissions("login")
	@RequestMapping("/automatedRuleEdit")
	public String automatedRuleEdit() {
		System.out.println("----111111------>");
		return "service/automateRuleEdit";
	}
	@RequiresPermissions("login")
	@RequestMapping("/medicineModal")
	public String MedicineList() {
		System.out.println("----3333------>");
		return "service/modalMedicine";
	}
	
	@RequiresPermissions("login")
	@RequestMapping("/modalSmsModelEdit")
	public String modalSmsModelEdit() {
		System.out.println("----3333------>");
		return "service/modalSmsModelEdit";
	}
}
