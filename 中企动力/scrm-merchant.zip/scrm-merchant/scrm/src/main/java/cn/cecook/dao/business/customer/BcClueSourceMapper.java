package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcClueSource;
import cn.cecook.model.business.customer.BcClueSourceExample;

/**
 * 
* @explain 线索来源
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcClueSourceMapper {
    int countByExample(BcClueSourceExample example);

    int deleteByExample(BcClueSourceExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcClueSource record);

    int insertSelective(BcClueSource record);

    List<BcClueSource> selectByExample(BcClueSourceExample example);

    BcClueSource selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcClueSource record, @Param("example") BcClueSourceExample example);

    int updateByExample(@Param("record") BcClueSource record, @Param("example") BcClueSourceExample example);

    int updateByPrimaryKeySelective(BcClueSource record);

    int updateByPrimaryKey(BcClueSource record);
}