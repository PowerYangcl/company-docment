package cn.cecook.dao.system;

import cn.cecook.bean.system.DockProductService;

public interface DockProductServiceMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DockProductService record);

    int insertSelective(DockProductService record);

    DockProductService selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DockProductService record);

    int updateByPrimaryKey(DockProductService record);
}