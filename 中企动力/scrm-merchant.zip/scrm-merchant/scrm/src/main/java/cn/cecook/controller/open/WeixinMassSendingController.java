package cn.cecook.controller.open;

import java.net.URLDecoder;
import java.text.SimpleDateFormat;
import java.util.Arrays;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpEmoji;
import cn.cecook.model.open.mp.MpMass;
import cn.cecook.model.open.mp.MpMaterialNews;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpMassService;
import cn.cecook.service.open.IMpMaterialNewsDetailService;
import cn.cecook.service.open.IMpMaterialNewsService;
import cn.cecook.service.open.IMpMaterialService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.thirdparty.open.MassMsgStatusType;
import cn.cecook.thirdparty.open.MassUtil;
import cn.cecook.thirdparty.open.MenuUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.EmojiUtil;
import cn.cecook.uitls.SqlUtil;
import cn.cecook.uitls.redis.RedisConfig;
import cn.cecook.uitls.redis.RedisStringUtil;

import com.google.common.collect.Lists;
import com.google.gson.JsonObject;

@Controller
@RequestMapping("/weixin")
public class WeixinMassSendingController {

	@Autowired
	private IMpAccountService mpAccountService;

	@Autowired
	private IMpUserService mpuserService;

	@Autowired
	private IMpMassService mpMassService;
	
	@Autowired
	private IMpMaterialService mpMaterialService;
	
	@Autowired
	private IMpMaterialNewsService mpMaterialNewsService;
	
	@Autowired
	private IMpMaterialNewsDetailService mpMaterialNewsDetailService;

	@RequestMapping(value = "/massSending", method = RequestMethod.GET)
	public ModelAndView massSendingList(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView("open/wxMassSending");
		int pageNo = ServletRequestUtils.getIntParameter(request, "page", 1);
		int pageSize = ServletRequestUtils.getIntParameter(request, "pageSize", 10);
		String dateStartStr = ServletRequestUtils.getStringParameter(request, "dateStart", "");
		String dateEndStr = ServletRequestUtils.getStringParameter(request, "dateEnd", "");
		String keyword = ServletRequestUtils.getStringParameter(request, "keyword", "");
		keyword = SqlUtil.isValid(keyword) == true ? keyword : null;
		Date dateStart = DateUtils.toDate(SqlUtil.isValid(dateStartStr) == true ? dateStartStr : null);
		Date dateEnd = DateUtils.toDate(SqlUtil.isValid(dateEndStr) == true ? dateEndStr : null);
		if (dateEnd != null) {
			dateEnd.setHours(23);
			dateEnd.setMinutes(59);
			dateEnd.setSeconds(59);
		}
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		// 删除
		int delid = ServletRequestUtils.getIntParameter(request, "delid", 0);
		if (delid > 0) {
			mpMassService.del(delid);
		}

		int count = mpMassService.getCountByCondition(dateStart, dateEnd, keyword);
		List<MpMass> mpMassList = mpMassService.selectByPageAndCondition(tenant_id, (pageNo - 1) * pageSize, pageSize, dateStart, dateEnd, keyword);
		for (int i = 0; i < mpMassList.size(); i++) {
			MpMass mpMass = mpMassList.get(i);
			mpMass.setMsgStatus(MassMsgStatusType.parse(mpMass.getMsgStatus()).getNote());
			String titles = "";
			if("news".equals(mpMass.getMsgType())){				
				MpMaterialNews materialNews = mpMaterialNewsService.selectNewsByMediaId(tenant_id, mpMass.getMsgDetail());
				if(materialNews != null){
					titles = materialNews.getTitles();
					titles = titles.replace("|", "<br>");
				}
				mpMass.setMsgTitle(titles);
			}
		}
		modelAndView.addObject("mpMassList", mpMassList);

		modelAndView.addObject("count", count);
		modelAndView.addObject("dateStart", dateStartStr);
		modelAndView.addObject("dateEnd", dateEndStr);
		modelAndView.addObject("keyword", keyword);
		modelAndView.addObject("currentPage", pageNo);
		modelAndView.addObject("totalPage", (count + pageSize) / pageSize);

		return modelAndView;
	}

	@RequestMapping(value = "/createMassSending", method = RequestMethod.GET)
	public String createMassSending(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		JsonObject menuData = MenuUtil.get(authorizer_access_token);
		request.setAttribute("menuData", menuData);
		int sendNumMonth = mpMassService.getCount();
		int massId = ServletRequestUtils.getIntParameter(request, "massId", 0);
		String newsMediaId = ServletRequestUtils.getStringParameter(request, "newsMediaId", "");
		if (massId > 0) {
			MpMass mass = mpMassService.get(massId);
			if ("text".equals(mass.getMsgType())) {
				String massText = EmojiUtil.formatEmoji(mass.getMsgDetail());
				request.setAttribute("massText", massText);
			}
			request.setAttribute("mass", mass);
		}else if(StringUtils.hasText(newsMediaId)){
			//图文保存后并群发功能
			MpMass mass = new MpMass();
			mass.setMsgDetail(newsMediaId);
			mass.setMsgType("news");
			request.setAttribute("mass", mass);
		}
		request.setAttribute("sendNumMonth", sendNumMonth);

		List<MpEmoji> emojiList = EmojiUtil.getEmojiList();
		List<Map<String, String>> emojiMapList = Lists.newArrayList();
		for (MpEmoji mpEmoji : emojiList) {
			Map<String, String> emoji = new HashMap<String, String>();
			emoji.put("src", mpEmoji.getImage());
			emoji.put("alt", mpEmoji.getEmoji());
			emojiMapList.add(emoji);
		}
		request.setAttribute("emojiList", JSONArray.fromObject(emojiMapList));
		return "open/wxMassSendingForm";
	}

	private Map<String, Object> prapreParam(HttpServletRequest request) {
		String sendCondition = ServletRequestUtils.getStringParameter(request, "sendCondition", "0");
		Map<String, Object> condition = new HashMap<String, Object>();
		if ("1".equals(sendCondition)) {
			String sex = ServletRequestUtils.getStringParameter(request, "sex", "");
			String focusTimeQuery = ServletRequestUtils.getStringParameter(request, "focusTimeQuery", "");
			String tagids = ServletRequestUtils.getStringParameter(request, "tagids", "");
			String systagids = ServletRequestUtils.getStringParameter(request, "systagids", "");
			// String tagNames = ServletRequestUtils.getStringParameter(request, "tagNames", "");
			String province = ServletRequestUtils.getStringParameter(request, "province", "");
			String city = ServletRequestUtils.getStringParameter(request, "city", "");
			condition.put("province", province);
			condition.put("city", city);
			if (!StringUtils.isEmpty(focusTimeQuery) && !"0".equals(focusTimeQuery)) {
				Date startTime = MassUtil.focusTime(focusTimeQuery);
				String startQueryTime = DateUtils.toDateString(startTime);
				Calendar endCalendar = Calendar.getInstance();
				endCalendar.setTime(new Date());
				String endQueryTime = DateUtils.toDateString(endCalendar.getTime());
				condition.put("startQueryTime", startQueryTime + " 00:00:00");
				condition.put("endQueryTime", endQueryTime + " 23:59:59");
			}
			String[] sexArray = sex.split(",");
			condition.put("sexArray", sexArray);

			if (!StringUtils.isEmpty(tagids)) {
				List<String> tagidList = Arrays.asList(tagids.split(","));
				condition.put("tagidList", tagidList);
			}

			if (!StringUtils.isEmpty(systagids)) {
				List<String> systagidList = Arrays.asList(systagids.split(","));
				condition.put("systagidList", systagidList);
			}
		}
		return condition;
	}

	@ResponseBody
	@RequestMapping("/queryTargetUserCount")
	public Object queryTargetUserCount(HttpServletRequest request, HttpServletResponse response) {
		Map<String, Object> condition = prapreParam(request);
		int totalCount = mpuserService.getTargetUserCount(condition);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		result.put("totalCount", totalCount);
		return result;
	}
	
	@ResponseBody
	@RequestMapping(value = "/sendMass")
	public Object sendMass(HttpServletRequest request, HttpServletResponse response){
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		String massType = ServletRequestUtils.getStringParameter(request, "massType", "");
		int massId = ServletRequestUtils.getIntParameter(request, "massId", 0);
		String mediaId = ServletRequestUtils.getStringParameter(request, "mediaId", "");
		String msgTitle = ServletRequestUtils.getStringParameter(request, "title", "");
		String msgDigest = ServletRequestUtils.getStringParameter(request, "digest", "");
		String thumbMediaId = ServletRequestUtils.getStringParameter(request, "thumbMediaId", "");
		String content = ServletRequestUtils.getStringParameter(request, "content", "");
		String sex = ServletRequestUtils.getStringParameter(request, "sex", "");
		int sendTime = ServletRequestUtils.getIntParameter(request, "sendTime", 0);
		String publishTime = ServletRequestUtils.getStringParameter(request, "publishTime", "");

		MpMass mpMass = new MpMass();
		if("news".equals(massType)){
			mpMass.setMsgType("news");			
			mpMass.setMsgDetail(mediaId);
			mpMass.setMsgThumb(thumbMediaId);
			String titles = "";
			MpMaterialNews materialNews = mpMaterialNewsService.selectNewsByMediaId(tenant_id, mediaId);
			if(materialNews != null){
				titles = materialNews.getTitles();
			}
			mpMass.setMsgTitle(titles);
			mpMass.setMsgDigest(msgDigest);
		}else if("image".equals(massType)){
			mpMass.setMsgType("image");
			mpMass.setMsgTitle("");
			mpMass.setMsgThumb(mediaId);
			mpMass.setMsgDetail(mediaId);
		}else if("text".equals(massType)){
			mpMass.setMsgType("text");
			mpMass.setMsgTitle(content);
			mpMass.setMsgDetail(content);
		}else{
			//错误
		}
		mpMass.setSex(sex);
		mpMass.setProvince(ServletRequestUtils.getStringParameter(request, "province", ""));
		mpMass.setCity(ServletRequestUtils.getStringParameter(request, "city", ""));
		mpMass.setCountry(ServletRequestUtils.getStringParameter(request, "country", ""));
		
		String sendCondition = ServletRequestUtils.getStringParameter(request, "sendCondition", "");
		try {
			mpMass.setSendCondition(Integer.valueOf(sendCondition));
		} catch (Exception e) {
		}
		String focusTimeQuery = ServletRequestUtils.getStringParameter(request, "focusTimeQuery", "0");

		mpMass.setSubscribeType(Integer.parseInt(focusTimeQuery));
		mpMass.setSubscribeTime(MassUtil.focusTime(focusTimeQuery));

		String tagids = ServletRequestUtils.getStringParameter(request, "tagids", "");
		mpMass.setTagids(tagids);
		String systagids = ServletRequestUtils.getStringParameter(request, "systagids", "");
		mpMass.setSystagids(systagids);
		mpMass.setSendTime(sendTime);
		if (sendTime == 0) {
			mpMass.setPublishTime(new Date());
		} else {
			Date date = new Date();
			try {
				SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd HH:mm");
				date = sdf.parse(publishTime);
			} catch (Exception e) {
				e.printStackTrace();
			}
			mpMass.setPublishTime(date);
		}
		mpMass.setMsgStatus(MassMsgStatusType.NOTSTART.getType());
		mpMass.setCreateTime(new Date());
		if (massId > 0) {
			mpMass.setId(massId);
			mpMassService.update(tenant_id, mpMass);
		} else {
			mpMassService.insert(mpMass);
		}

		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);

		return result;
	}

	@RequestMapping(value = "/exportMassExcel_{starttime}_{endtime}_{keyword}", method = RequestMethod.GET)
	@ResponseBody
	public String exportMassExcel(HttpServletRequest request, @PathVariable String starttime,
			@PathVariable String endtime, @PathVariable String keyword, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String user_name = "--";
		try {
			user_name = URLDecoder.decode(CookieUtil.getCookieSet(cookies).get("user_name"), "UTF-8");
		} catch (Exception e) {
			e.printStackTrace();
		}
		keyword = SqlUtil.isValid(keyword) == true ? keyword : null;
		Date dateStart = DateUtils.toDate(SqlUtil.isValid(starttime) == true ? starttime : null);
		Date dateEnd = DateUtils.toDate(SqlUtil.isValid(endtime) == true ? endtime : null);
		if (dateEnd != null) {
			dateEnd.setHours(23);
			dateEnd.setMinutes(59);
			dateEnd.setSeconds(59);
		}
		if (org.apache.commons.lang.StringUtils.isNotEmpty(tenant_id)) {
			List<MpMass> dataList = mpMassService.selectByPageAndCondition(tenant_id, 0, Integer.MAX_VALUE, dateStart,
					dateEnd, keyword);
			String fileName = "群发记录" + DateUtils.DateToString(new Date(), "yyyy-MM-dd");
			new MassUtil().exportExcel(dataList, fileName, dateStart, dateEnd, response, user_name, tenant_id, mpAccount.getAuthorizerAppid(), mpMaterialService, mpMaterialNewsService);
		}
		return "";
	}
}
