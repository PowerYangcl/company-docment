package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.bean.business.markting.exportManageStoreBean;
import cn.cecook.model.business.markting.BmStore;
@Repository("bmStoreMapper")
public interface BmStoreMapper {

    // 删除门店
    int deleteByPrimaryKey(Long id);

    int insert(BmStore record);

    int insertSelective(BmStore record);

    // 根据id查询门店
    BmStore selectByPrimaryKey(Long id);

    // 编辑操作
    int updateByPrimaryKeySelective(BmStore record);

    int updateByPrimaryKey(BmStore record);

    // 查询所有
    List<BmStore> getAll(Map<String, Object> map);

    // 查询门店总量
    int countStore(Map<String, Object> map);
    
    //添加门店时查询是否有相同店名
    BmStore queryMing(Map<String, Object> map);

   //添加门店时查询是否有相同门店地址
    int queryDian(Map<String, Object> map);
    
    //查询门店是否被选用
    int queryshan(Long store_id);
    /**
     * 根据名称查询门店信息
     * @param name
     * @return
     * majie
     */
    List<BmStore> findByName(String name);
    /**
     * 根据瑞恩的store_id查询门店信息
     * @return
     * majie
     */
    public BmStore findByStroreId(String storeId);
    
    /**
     * 查询品牌下的全部门店
     * @return
     */
	List<exportManageStoreBean> getAllStoreByTenantId(@Param("tenantId") String tenant_id);
	
	/**
	 * 
	* @Description: 根据门店id和租户id查询
	* @param storeId
	* @param tenantId
	* @return
	*
	* @author: wschenyongyin
	* @date: 2018年3月23日 下午6:00:11
	 */
	public BmStore findByIdAndTenantId(@Param("storeId") Long storeId,@Param("tenantId") String tenantId);
}