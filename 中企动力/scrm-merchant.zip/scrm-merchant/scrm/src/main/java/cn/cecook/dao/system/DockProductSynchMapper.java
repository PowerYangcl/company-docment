package cn.cecook.dao.system;

import cn.cecook.bean.system.DockProductSynch;

public interface DockProductSynchMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DockProductSynch record);

    int insertSelective(DockProductSynch record);

    DockProductSynch selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DockProductSynch record);

    int updateByPrimaryKey(DockProductSynch record);
    /**
     * 根据userId查询门店id
     * @param record
     * @return
     * majie
     */
    DockProductSynch findByUserId(Long userId);
    
    /**
     * 删除CRM同步表
     * @param id
     */
	void deleteByUserId(Long id);
}