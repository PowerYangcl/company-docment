package cn.cecook.controller.open;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStream;
import java.io.InputStreamReader;
import java.util.Date;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpMass;
import cn.cecook.model.open.mp.MpMaterialNews;
import cn.cecook.model.open.mp.MpMaterialNewsDetail;
import cn.cecook.model.open.mp.MpTicket;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpMassService;
import cn.cecook.service.open.IMpMaterialNewsDetailService;
import cn.cecook.service.open.IMpMaterialNewsService;
import cn.cecook.service.open.IMpMaterialService;
import cn.cecook.service.open.IMpTicketService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.thirdparty.open.ConfigUtil;
import cn.cecook.thirdparty.open.CryptoUtil;
import cn.cecook.thirdparty.open.MassMsgStatusType;
import cn.cecook.thirdparty.open.TokenUtil;
import cn.cecook.uitls.redis.RedisStringUtil;

@Controller
@RequestMapping("/open")
public class RecvController {
	private Logger logger = Logger.getLogger(RecvController.class);
	
	@Resource
	private IMpUserService iMpUserService;
	
	@Autowired
	private IMpAccountService iMpAccountService;
	
	@Autowired
	private IMpTicketService iMpTicketService;
	
	@Autowired
	private IMpMaterialService iMpMaterialService;
	
	@Autowired
	private IMpMaterialNewsService iMpMaterialNewsService;
	
	@Autowired
	private IMpMaterialNewsDetailService iMpMaterialNewsDetailService;
	
	@Autowired
	private IMpMassService iMpMassService;
	
	@RequestMapping(value = "/recvinfo", method = RequestMethod.POST)
    @ResponseBody
    public String recvinfo(HttpServletRequest request, HttpServletResponse response) {
        StringBuffer debugInfo = new StringBuffer();
		String nonce = request.getParameter("nonce");
		String encrypt_type = request.getParameter("encrypt_type");
		String timestamp = request.getParameter("timestamp");
		String signature = request.getParameter("signature");
		String msg_signature = request.getParameter("msg_signature");
		String notifyMessage = "";
		debugInfo.append("nonce:"+nonce+"\n");
		debugInfo.append("encrypt_type:"+encrypt_type+"\n");
		debugInfo.append("timestamp:"+timestamp+"\n");
		debugInfo.append("signature:"+signature+"\n");
		debugInfo.append("msg_signature:"+msg_signature+"\n");
		
		InputStream is = null;
		try {
			is = request.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			String buffer = null;
			StringBuffer sb = new StringBuffer();
			while ((buffer = br.readLine()) != null) {
				sb.append(buffer);
			}
			notifyMessage = sb.toString();
			debugInfo.append("notifyMessage:"+notifyMessage+"\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		String verifyTicket = CryptoUtil.getVerifyTicket(nonce, timestamp, msg_signature, notifyMessage);
		logger.debug("revcInfo:"+debugInfo.toString());
		logger.debug("verifyTicket:"+verifyTicket);
		
		String componentAccessToken = TokenUtil.getInstance().getComponentAccessToken(verifyTicket);
		if(StringUtils.isNotEmpty(componentAccessToken)) {
			TokenUtil.getInstance().refreshPreAuthCode(componentAccessToken);
		}
		MpTicket mpTicketDB = iMpTicketService.selectOne();
		if(mpTicketDB == null) {
			MpTicket mpTicket = new MpTicket();
			mpTicket.setVerifyTicket(verifyTicket);
			mpTicket.setComponentAccessToken(componentAccessToken);
			iMpTicketService.insert(mpTicket);
		}else {
			mpTicketDB.setVerifyTicket(verifyTicket);
			mpTicketDB.setComponentAccessToken(componentAccessToken);			
			iMpTicketService.update(mpTicketDB);
		}
		//取token更新时间大于1小时的mpaccount，取用refreshToken刷新
		List<MpAccount> mpAccounts = iMpAccountService.selectTokenTimeMoreHour();
		for (int i = 0; mpAccounts != null && i < mpAccounts.size(); i++) {
			MpAccount mpAccount = mpAccounts.get(i);
			TokenUtil.getInstance().refreshAuthorizerToken(mpAccount, componentAccessToken);
			mpAccount.setTokenStatus(1);
			mpAccount.setTokenTime(new Date());
			iMpAccountService.updateMpAccountByUid(mpAccount.getUid(), mpAccount);
		}
		return "system/registerOne";
    }
	
	@RequestMapping(value = "/callback/{appid}", method = RequestMethod.POST)
	@ResponseBody
	public String callback(HttpServletRequest request, HttpServletResponse response,
			@PathVariable String appid) {
		StringBuffer debugInfo = new StringBuffer("callback\n");
		debugInfo.append("appid:"+appid);
		String nonce = request.getParameter("nonce");
		String encrypt_type = request.getParameter("encrypt_type");
		String timestamp = request.getParameter("timestamp");
		String signature = request.getParameter("signature");
		String msg_signature = request.getParameter("msg_signature");
		String notifyMessage = "";
		debugInfo.append("nonce:"+nonce+"\n");
		debugInfo.append("encrypt_type:"+encrypt_type+"\n");
		debugInfo.append("timestamp:"+timestamp+"\n");
		debugInfo.append("signature:"+signature+"\n");
		debugInfo.append("msg_signature:"+msg_signature+"\n");
		InputStream is = null;
		try {
			is = request.getInputStream();
			BufferedReader br = new BufferedReader(new InputStreamReader(is, "UTF-8"));
			String buffer = null;
			StringBuffer sb = new StringBuffer();
			while ((buffer = br.readLine()) != null) {
				sb.append(buffer);
			}
			notifyMessage = sb.toString();
			debugInfo.append("notifyMessage:"+notifyMessage+"\n");
		} catch (IOException e) {
			e.printStackTrace();
		}
		String xml = CryptoUtil.parse2Xml(nonce, timestamp, msg_signature, notifyMessage);
		debugInfo.append("xml:::"+xml+"\n");
		org.dom4j.Document resultDocument = null;
		String FromUserName = null;
		String ToUserName = null;
		String EventKey = null;
		String MsgType = null;
		String Content = null;
		try {
			resultDocument = DocumentHelper.parseText(xml);
			FromUserName = resultDocument.getRootElement().elementText("FromUserName");
			ToUserName = resultDocument.getRootElement().elementText("ToUserName");
			EventKey = resultDocument.getRootElement().elementText("EventKey");
			MsgType = resultDocument.getRootElement().elementText("MsgType");
			Content = resultDocument.getRootElement().elementText("Content");
		} catch (DocumentException e) {
			e.printStackTrace();
		}
		String sendtype = RedisStringUtil.getValue(EventKey+"_type");
		String sendContent = RedisStringUtil.getValue(EventKey+"_content");
		debugInfo.append("ready to : " + sendtype + " and " + sendContent+"\n");
		String result = "<xml>";
		result+="<ToUserName><![CDATA["+FromUserName+"]]></ToUserName>";
		result+="<FromUserName><![CDATA["+ToUserName+"]]></FromUserName>";
		result+="<CreateTime>"+System.currentTimeMillis()/1000+"</CreateTime>";
		if(StringUtils.isEmpty(sendtype) && "text".equals(MsgType) && StringUtils.isNotEmpty(Content)){//未知消息类型
			result+="<MsgType><![CDATA[text]]></MsgType>";
			result+="<Content><![CDATA[对不起，您的意思我没太理解，请联系我们的客服吧~]]></Content>";
		}else if("text".equals(sendtype)){//文字
			result+="<MsgType><![CDATA["+sendtype+"]]></MsgType>";
			result+="<Content><![CDATA["+sendContent+"]]></Content>";
		}else if("image".equals(sendtype)){//图片
			result+="<MsgType><![CDATA["+sendtype+"]]></MsgType>";
			result+="<PicUrl>< ![CDATA["+ConfigUtil.getInstance().domain+"/test/material?media_id="+sendContent+"] ]></PicUrl>";
			result+="<MediaId>< ![CDATA["+sendContent+"] ]></MediaId>";
		}else if("news".equals(sendtype)){//图文
			result+="<MsgType><![CDATA["+sendtype+"]]></MsgType>";
			MpAccount mpAccount = iMpAccountService.selectMpAccountByUserName(ToUserName);
			MpMaterialNews mpMaterialNews = iMpMaterialNewsService.selectNewsByMediaId(mpAccount.getTenantId(), sendContent);
			System.out.println(mpMaterialNews);
			if(mpMaterialNews != null) {
				mpMaterialNews.setDetails(iMpMaterialNewsDetailService.selectNewsDetailByNewsId(mpAccount.getTenantId(), mpMaterialNews.getId()));
			}
			if(mpMaterialNews != null && mpMaterialNews.getDetails() != null && mpMaterialNews.getDetails().size() > 0) {
				result+="<ArticleCount>"+mpMaterialNews.getDetails().size()+"</ArticleCount>";
				result+= "<Articles>";
				for (int i = 0; i < mpMaterialNews.getDetails().size(); i++) {
					MpMaterialNewsDetail mpMaterialNewsDetail = mpMaterialNews.getDetails().get(i);
					result += "<item>";
					result += "<Title><![CDATA["+mpMaterialNewsDetail.getTitle()+" ]]></Title>";
					result += "<Description><![CDATA["+mpMaterialNewsDetail.getDigest()+"]]></Description>";
					result += "<PicUrl><![CDATA["+mpMaterialNewsDetail.getThumbUrl()+"]]></PicUrl>";
					result += "<Url><![CDATA["+mpMaterialNewsDetail.getUrl()+"]]></Url>";
					result += "</item>";
				}
				result+= "</Articles>";
				result+= "<FuncFlag>0</FuncFlag>";
			}
		}else if("link".equals(sendtype)){//链接
			result+="<MsgType><![CDATA[text]]></MsgType>";
			result+="<Title>< ![CDATA[标题需要吗] ]></Title>";
			result+="<Description>< ![CDATA[描述需要吗] ]></Description>";
			result+="<Url>< ![CDATA["+sendContent+"] ]></Url>";
		}else if("event".equals(MsgType)){//处理响应事件
			String Event = resultDocument.getRootElement().elementText("Event");
			if("MASSSENDJOBFINISH".equals(Event)){//群发消息的回调
				MpAccount mpAccount = iMpAccountService.selectMpAccountByUserName(ToUserName);
				String msgId = resultDocument.getRootElement().elementText("MsgID");
				String TotalCount = resultDocument.getRootElement().elementText("TotalCount");
				String FilterCount = resultDocument.getRootElement().elementText("FilterCount");
				String SentCountStr = resultDocument.getRootElement().elementText("SentCount");
				String ErrorCount = resultDocument.getRootElement().elementText("ErrorCount");
				String Status = resultDocument.getRootElement().elementText("Status");
				int SentCount = 0;
				try {
					SentCount = Integer.valueOf(SentCountStr);
				} catch (Exception e) {
					e.printStackTrace();
				}
				int planMsgPushNum = 0;
				try {
					planMsgPushNum = Integer.valueOf(TotalCount);
				} catch (Exception e) {
					e.printStackTrace();
				}
				List<MpMass> mpMasses = iMpMassService.selectByMsgId(mpAccount.getTenantId(), msgId);
				for (int i = 0; mpMasses != null && i < mpMasses.size(); i++) {
					MpMass mpMass = mpMasses.get(i);
					mpMass.setMsgPushNum(SentCount);
					mpMass.setPlanMsgPushNum(planMsgPushNum);
					if(StringUtils.isNotEmpty(Status) && Status.contains("success")) {						
						mpMass.setMsgStatus(MassMsgStatusType.SEND_SUCCESS.getType());
					}else {
						mpMass.setMsgStatus(MassMsgStatusType.UNKNOWN.getType());
					}
					iMpMassService.update(mpAccount.getTenantId(), mpMass);
				}
			}
		}
		result+="<MsgId></MsgId>";
		result+="</xml>";
		debugInfo.append(result);
		logger.debug(debugInfo.toString());
		return result;
	}
	
}
