package cn.cecook.model.business.customer;

import java.util.Date;


public class BcCustomer {
    private Integer id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Long createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String name;

    private String phone;

    private String email;

    private String company;

    private String job;

    private String score;

    private String gender;

    private String birthday;

    private String weibo;

    private String wechat;

    private String city;

    private String address;

    private String fax;

    private String tag;

    private String source;

    private String groupCustomer;

    private String avatar;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;

    private String weiboUid;

    private String qq;

    private Integer point;

    private String level;

    private Integer storeId;

    private String storeName;

    private Integer marketId;

    private String marketName;

    private Double costTotal;

    private Integer costCount;

    private Integer firstCost;

    private Integer lastCost;

    private Double crmbalance;

    private Integer crmscore;

    private Double crmdiscount;

    private String crmmemberlevel;

    private Integer goodsTotal;

    private Integer averageCost;

    private Integer averageGoodsQuantity;

    private Integer maxCost;

    private Integer gainIntegral;

    private Integer useIntegral;

    private Integer expiredIntegral;

    private Integer couponCodeTotal;

    private Integer crmBalance;

    private Integer crmScore;

    private Double crmDiscount;

    private String officeAddress;

    private String idCard;

    private String incomeRange;

    private Integer familySize;

    private String education;

    private String ageBracket;

    private String childrenName;

    private Integer childrenAge;

    private String parentName;

    private Integer parentAge;

    private Date exportTime;

    private Double coolCoin;

    private Integer crmHisScore;

    private String belongSaleper;

    private String referee;

    private Double valueScore;

    private Date firstCostTime;

    private Date lastCostTime;

    private Integer integralType;

    private Integer cash;

    private String erpStoreId;

    private String crmMemberLevel;

    private String province;

    private Integer status;

    private Integer type;

    private String openId;

    private Long staffId;

    private Integer custLimit;

    private Integer signRaining;

    private String jobNumber;

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode;
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks;
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getPhone() {
        return phone;
    }

    public void setPhone(String phone) {
        this.phone = phone;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getCompany() {
        return company;
    }

    public void setCompany(String company) {
        this.company = company;
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job;
    }

    public String getScore() {
        return score;
    }

    public void setScore(String score) {
        this.score = score;
    }

    public String getGender() {
        return gender;
    }

    public void setGender(String gender) {
        this.gender = gender;
    }

    public String getBirthday() {
        return birthday;
    }

    public void setBirthday(String birthday) {
        this.birthday = birthday;
    }

    public String getWeibo() {
        return weibo;
    }

    public void setWeibo(String weibo) {
        this.weibo = weibo;
    }

    public String getWechat() {
        return wechat;
    }

    public void setWechat(String wechat) {
        this.wechat = wechat;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getAddress() {
        return address;
    }

    public void setAddress(String address) {
        this.address = address;
    }

    public String getFax() {
        return fax;
    }

    public void setFax(String fax) {
        this.fax = fax;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getSource() {
        return source;
    }

    public void setSource(String source) {
        this.source = source;
    }

    public String getGroupCustomer() {
        return groupCustomer;
    }

    public void setGroupCustomer(String groupCustomer) {
        this.groupCustomer = groupCustomer;
    }

    public String getAvatar() {
        return avatar;
    }

    public void setAvatar(String avatar) {
        this.avatar = avatar;
    }

    public String getBak1() {
        return bak1;
    }

    public void setBak1(String bak1) {
        this.bak1 = bak1;
    }

    public String getBak2() {
        return bak2;
    }

    public void setBak2(String bak2) {
        this.bak2 = bak2;
    }

    public String getBak3() {
        return bak3;
    }

    public void setBak3(String bak3) {
        this.bak3 = bak3;
    }

    public String getBak4() {
        return bak4;
    }

    public void setBak4(String bak4) {
        this.bak4 = bak4;
    }

    public String getBak5() {
        return bak5;
    }

    public void setBak5(String bak5) {
        this.bak5 = bak5;
    }

    public String getWeiboUid() {
        return weiboUid;
    }

    public void setWeiboUid(String weiboUid) {
        this.weiboUid = weiboUid;
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq;
    }

    public Integer getPoint() {
        return point;
    }

    public void setPoint(Integer point) {
        this.point = point;
    }

    public String getLevel() {
        return level;
    }

    public void setLevel(String level) {
        this.level = level;
    }

    public Integer getStoreId() {
        return storeId;
    }

    public void setStoreId(Integer storeId) {
        this.storeId = storeId;
    }

    public String getStoreName() {
        return storeName;
    }

    public void setStoreName(String storeName) {
        this.storeName = storeName;
    }

    public Integer getMarketId() {
        return marketId;
    }

    public void setMarketId(Integer marketId) {
        this.marketId = marketId;
    }

    public String getMarketName() {
        return marketName;
    }

    public void setMarketName(String marketName) {
        this.marketName = marketName;
    }

    public Double getCostTotal() {
        return costTotal;
    }

    public void setCostTotal(Double costTotal) {
        this.costTotal = costTotal;
    }

    public Integer getCostCount() {
        return costCount;
    }

    public void setCostCount(Integer costCount) {
        this.costCount = costCount;
    }

    public Integer getFirstCost() {
        return firstCost;
    }

    public void setFirstCost(Integer firstCost) {
        this.firstCost = firstCost;
    }

    public Integer getLastCost() {
        return lastCost;
    }

    public void setLastCost(Integer lastCost) {
        this.lastCost = lastCost;
    }

    public Double getCrmbalance() {
        return crmbalance;
    }

    public void setCrmbalance(Double crmbalance) {
        this.crmbalance = crmbalance;
    }

    public Integer getCrmscore() {
        return crmscore;
    }

    public void setCrmscore(Integer crmscore) {
        this.crmscore = crmscore;
    }

    public Double getCrmdiscount() {
        return crmdiscount;
    }

    public void setCrmdiscount(Double crmdiscount) {
        this.crmdiscount = crmdiscount;
    }

    public String getCrmmemberlevel() {
        return crmmemberlevel;
    }

    public void setCrmmemberlevel(String crmmemberlevel) {
        this.crmmemberlevel = crmmemberlevel;
    }

    public Integer getGoodsTotal() {
        return goodsTotal;
    }

    public void setGoodsTotal(Integer goodsTotal) {
        this.goodsTotal = goodsTotal;
    }

    public Integer getAverageCost() {
        return averageCost;
    }

    public void setAverageCost(Integer averageCost) {
        this.averageCost = averageCost;
    }

    public Integer getAverageGoodsQuantity() {
        return averageGoodsQuantity;
    }

    public void setAverageGoodsQuantity(Integer averageGoodsQuantity) {
        this.averageGoodsQuantity = averageGoodsQuantity;
    }

    public Integer getMaxCost() {
        return maxCost;
    }

    public void setMaxCost(Integer maxCost) {
        this.maxCost = maxCost;
    }

    public Integer getGainIntegral() {
        return gainIntegral;
    }

    public void setGainIntegral(Integer gainIntegral) {
        this.gainIntegral = gainIntegral;
    }

    public Integer getUseIntegral() {
        return useIntegral;
    }

    public void setUseIntegral(Integer useIntegral) {
        this.useIntegral = useIntegral;
    }

    public Integer getExpiredIntegral() {
        return expiredIntegral;
    }

    public void setExpiredIntegral(Integer expiredIntegral) {
        this.expiredIntegral = expiredIntegral;
    }

    public Integer getCouponCodeTotal() {
        return couponCodeTotal;
    }

    public void setCouponCodeTotal(Integer couponCodeTotal) {
        this.couponCodeTotal = couponCodeTotal;
    }

    public Integer getCrmBalance() {
        return crmBalance;
    }

    public void setCrmBalance(Integer crmBalance) {
        this.crmBalance = crmBalance;
    }

    public Integer getCrmScore() {
        return crmScore;
    }

    public void setCrmScore(Integer crmScore) {
        this.crmScore = crmScore;
    }

    public Double getCrmDiscount() {
        return crmDiscount;
    }

    public void setCrmDiscount(Double crmDiscount) {
        this.crmDiscount = crmDiscount;
    }

    public String getOfficeAddress() {
        return officeAddress;
    }

    public void setOfficeAddress(String officeAddress) {
        this.officeAddress = officeAddress;
    }

    public String getIdCard() {
        return idCard;
    }

    public void setIdCard(String idCard) {
        this.idCard = idCard;
    }

    public String getIncomeRange() {
        return incomeRange;
    }

    public void setIncomeRange(String incomeRange) {
        this.incomeRange = incomeRange;
    }

    public Integer getFamilySize() {
        return familySize;
    }

    public void setFamilySize(Integer familySize) {
        this.familySize = familySize;
    }

    public String getEducation() {
        return education;
    }

    public void setEducation(String education) {
        this.education = education;
    }

    public String getAgeBracket() {
        return ageBracket;
    }

    public void setAgeBracket(String ageBracket) {
        this.ageBracket = ageBracket;
    }

    public String getChildrenName() {
        return childrenName;
    }

    public void setChildrenName(String childrenName) {
        this.childrenName = childrenName;
    }

    public Integer getChildrenAge() {
        return childrenAge;
    }

    public void setChildrenAge(Integer childrenAge) {
        this.childrenAge = childrenAge;
    }

    public String getParentName() {
        return parentName;
    }

    public void setParentName(String parentName) {
        this.parentName = parentName;
    }

    public Integer getParentAge() {
        return parentAge;
    }

    public void setParentAge(Integer parentAge) {
        this.parentAge = parentAge;
    }

    public Date getExportTime() {
        return exportTime;
    }

    public void setExportTime(Date exportTime) {
        this.exportTime = exportTime;
    }

    public Double getCoolCoin() {
        return coolCoin;
    }

    public void setCoolCoin(Double coolCoin) {
        this.coolCoin = coolCoin;
    }

    public Integer getCrmHisScore() {
        return crmHisScore;
    }

    public void setCrmHisScore(Integer crmHisScore) {
        this.crmHisScore = crmHisScore;
    }

    public String getBelongSaleper() {
        return belongSaleper;
    }

    public void setBelongSaleper(String belongSaleper) {
        this.belongSaleper = belongSaleper;
    }

    public String getReferee() {
        return referee;
    }

    public void setReferee(String referee) {
        this.referee = referee;
    }

    public Double getValueScore() {
        return valueScore;
    }

    public void setValueScore(Double valueScore) {
        this.valueScore = valueScore;
    }

    public Date getFirstCostTime() {
        return firstCostTime;
    }

    public void setFirstCostTime(Date firstCostTime) {
        this.firstCostTime = firstCostTime;
    }

    public Date getLastCostTime() {
        return lastCostTime;
    }

    public void setLastCostTime(Date lastCostTime) {
        this.lastCostTime = lastCostTime;
    }

    public Integer getIntegralType() {
        return integralType;
    }

    public void setIntegralType(Integer integralType) {
        this.integralType = integralType;
    }

    public Integer getCash() {
        return cash;
    }

    public void setCash(Integer cash) {
        this.cash = cash;
    }

    public String getErpStoreId() {
        return erpStoreId;
    }

    public void setErpStoreId(String erpStoreId) {
        this.erpStoreId = erpStoreId;
    }

    public String getCrmMemberLevel() {
        return crmMemberLevel;
    }

    public void setCrmMemberLevel(String crmMemberLevel) {
        this.crmMemberLevel = crmMemberLevel;
    }

    public String getProvince() {
        return province;
    }

    public void setProvince(String province) {
        this.province = province;
    }

    public Integer getStatus() {
        return status;
    }

    public void setStatus(Integer status) {
        this.status = status;
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public String getOpenId() {
        return openId;
    }

    public void setOpenId(String openId) {
        this.openId = openId;
    }

    public Long getStaffId() {
        return staffId;
    }

    public void setStaffId(Long staffId) {
        this.staffId = staffId;
    }

    public Integer getCustLimit() {
        return custLimit;
    }

    public void setCustLimit(Integer custLimit) {
        this.custLimit = custLimit;
    }

    public Integer getSignRaining() {
        return signRaining;
    }

    public void setSignRaining(Integer signRaining) {
        this.signRaining = signRaining;
    }

    public String getJobNumber() {
        return jobNumber;
    }

    public void setJobNumber(String jobNumber) {
        this.jobNumber = jobNumber;
    }

	@Override
	public String toString() {
		return "BcCustomer [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createId=" + createId + ", createTime=" + createTime + ", orderCode=" + orderCode + ", deleteTime="
				+ deleteTime + ", remarks=" + remarks + ", attachment=" + attachment + ", name=" + name + ", phone="
				+ phone + ", email=" + email + ", company=" + company + ", job=" + job + ", score=" + score
				+ ", gender=" + gender + ", birthday=" + birthday + ", weibo=" + weibo + ", wechat=" + wechat
				+ ", city=" + city + ", address=" + address + ", fax=" + fax + ", tag=" + tag + ", source=" + source
				+ ", groupCustomer=" + groupCustomer + ", avatar=" + avatar + ", bak1=" + bak1 + ", bak2=" + bak2
				+ ", bak3=" + bak3 + ", bak4=" + bak4 + ", bak5=" + bak5 + ", weiboUid=" + weiboUid + ", qq=" + qq
				+ ", point=" + point + ", level=" + level + ", storeId=" + storeId + ", storeName=" + storeName
				+ ", marketId=" + marketId + ", marketName=" + marketName + ", costTotal=" + costTotal + ", costCount="
				+ costCount + ", firstCost=" + firstCost + ", lastCost=" + lastCost + ", crmbalance=" + crmbalance
				+ ", crmscore=" + crmscore + ", crmdiscount=" + crmdiscount + ", crmmemberlevel=" + crmmemberlevel
				+ ", goodsTotal=" + goodsTotal + ", averageCost=" + averageCost + ", averageGoodsQuantity="
				+ averageGoodsQuantity + ", maxCost=" + maxCost + ", gainIntegral=" + gainIntegral + ", useIntegral="
				+ useIntegral + ", expiredIntegral=" + expiredIntegral + ", couponCodeTotal=" + couponCodeTotal
				+ ", crmBalance=" + crmBalance + ", crmScore=" + crmScore + ", crmDiscount=" + crmDiscount
				+ ", officeAddress=" + officeAddress + ", idCard=" + idCard + ", incomeRange=" + incomeRange
				+ ", familySize=" + familySize + ", education=" + education + ", ageBracket=" + ageBracket
				+ ", childrenName=" + childrenName + ", childrenAge=" + childrenAge + ", parentName=" + parentName
				+ ", parentAge=" + parentAge + ", exportTime=" + exportTime + ", coolCoin=" + coolCoin
				+ ", crmHisScore=" + crmHisScore + ", belongSaleper=" + belongSaleper + ", referee=" + referee
				+ ", valueScore=" + valueScore + ", firstCostTime=" + firstCostTime + ", lastCostTime=" + lastCostTime
				+ ", integralType=" + integralType + ", cash=" + cash + ", erpStoreId=" + erpStoreId
				+ ", crmMemberLevel=" + crmMemberLevel + ", province=" + province + ", status=" + status + ", type="
				+ type + ", openId=" + openId + ", staffId=" + staffId + ", custLimit=" + custLimit + ", signRaining="
				+ signRaining + ", jobNumber=" + jobNumber + "]";
	}
}

/*
@Component
public class BcCustomer {
	private Integer id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Long createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String name;

    private String phone;

    private String email;

    private String company;

    private String job;

    private String score;

    private String gender;

    private String birthday;

    private String weibo;

    private String wechat;

    private String city;

    private String address;

    private String fax;

    private String tag;

    private String source;

    private String groupCustomer;

    private String avatar;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;

    private String weiboUid;

    private String QQ;

    private Integer point;

    private String level;

    private Integer marketId;

    private String marketName;

    private Double costTotal;

    private Integer costCount;

    private Date firstCost;

    private Date lastCost;

    private Double crmbalance;

    private Integer crmscore;

    private Double crmdiscount;

    private String crmmemberlevel;

    private Integer goodsTotal;

    private Integer averageCost;

    private Integer averageGoodsQuantity;

    private Integer maxCost;

    private Integer gainIntegral;

    private Integer useIntegral;

    private Integer expiredIntegral;

    private Integer couponCodeTotal;

    private String officeAddress;

    private String idCard;

    private String incomeRange;

    private Integer familySize;

    private String education;

    private String ageBracket;

    private String childrenName;

    private Integer childrenAge;

    private String parentName;

    private Integer parentAge;

    private Date exportTime;

    private Double coolCoin;

    private Integer crmHisScore;

    private String belongSaleper;

    private String referee;

    private Double valueScore;

    private Date firstCostTime;

    private Date lastCostTime;

    private Integer integralType;

    private Integer cash;

    private String erpStoreId;

    private String province;

    private Integer status;

    private Integer type;

    private Integer signRaining;


    //额外字段
    private String customer_source;


    //CRM字段

    private Integer custLimit;

    private Integer crmBalance;

    private Integer crmScore;

    private Double crmDiscount;

    private String crmMemberLevel;

    private String openId; //微信openId

    private Integer staffId; //对应客服人员

    private String jobNumber; //对应客服人员工号
    private Integer storeId;//所属门店id
    private String storeName;//所属门店名称
    
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Long getCreateId() {
		return createId;
	}
	public void setCreateId(Long createId) {
		this.createId = createId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public Date getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getCompany() {
		return company;
	}
	public void setCompany(String company) {
		this.company = company;
	}
	public String getJob() {
		return job;
	}
	public void setJob(String job) {
		this.job = job;
	}
	public String getScore() {
		return score;
	}
	public void setScore(String score) {
		this.score = score;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getBirthday() {
		return birthday;
	}
	public void setBirthday(String birthday) {
		this.birthday = birthday;
	}
	public String getWeibo() {
		return weibo;
	}
	public void setWeibo(String weibo) {
		this.weibo = weibo;
	}
	public String getWechat() {
		return wechat;
	}
	public void setWechat(String wechat) {
		this.wechat = wechat;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getFax() {
		return fax;
	}
	public void setFax(String fax) {
		this.fax = fax;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getGroupCustomer() {
		return groupCustomer;
	}
	public void setGroupCustomer(String groupCustomer) {
		this.groupCustomer = groupCustomer;
	}
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getBak1() {
		return bak1;
	}
	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}
	public String getBak2() {
		return bak2;
	}
	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}
	public String getBak3() {
		return bak3;
	}
	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}
	public String getBak4() {
		return bak4;
	}
	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}
	public String getBak5() {
		return bak5;
	}
	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}
	public String getQQ() {
		return QQ;
	}
	public void setQQ(String qQ) {
		QQ = qQ;
	}
	public String getProvince() {
		return province;
	}
	public void setProvince(String province) {
		this.province = province;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public Integer getType() {
		return type;
	}
	public void setType(Integer type) {
		this.type = type;
	}
	public String getMarketName() {
		return marketName;
	}
	public void setMarketName(String marketName) {
		this.marketName = marketName;
	}
	public Date getLastCostTime() {
		return lastCostTime;
	}
	public void setLastCostTime(Date lastCostTime) {
		this.lastCostTime = lastCostTime;
	}
	public Integer getCash() {
		return cash;
	}
	public void setCash(Integer cash) {
		this.cash = cash;
	}
	public Integer getPoint() {
		return point;
	}
	public void setPoint(Integer point) {
		this.point = point;
	}
	public Integer getStatus() {
		return status;
	}
	public void setStatus(Integer status) {
		this.status = status;
	}
	public String getCustomer_source() {
		return customer_source;
	}
	public void setCustomer_source(String customer_source) {
		this.customer_source = customer_source;
	}
	public Integer getCustLimit() {
		return custLimit;
	}
	public void setCustLimit(Integer custLimit) {
		this.custLimit = custLimit;
	}
	public Integer getCrmBalance() {
		return crmBalance;
	}
	public void setCrmBalance(Integer crmBalance) {
		this.crmBalance = crmBalance;
	}
	public Integer getCrmScore() {
		return crmScore;
	}
	public void setCrmScore(Integer crmScore) {
		this.crmScore = crmScore;
	}
	public Double getCrmDiscount() {
		return crmDiscount;
	}
	public void setCrmDiscount(Double crmDiscount) {
		this.crmDiscount = crmDiscount;
	}
	public String getCrmMemberLevel() {
		return crmMemberLevel;
	}
	public void setCrmMemberLevel(String crmMemberLevel) {
		this.crmMemberLevel = crmMemberLevel;
	}
	public String getOpenId() {
		return openId;
	}
	public void setOpenId(String openId) {
		this.openId = openId;
	}
	public Integer getStaffId() {
		return staffId;
	}
	public void setStaffId(Integer staffId) {
		this.staffId = staffId;
	}
	public String getJobNumber() {
		return jobNumber;
	}
	public void setJobNumber(String jobNumber) {
		this.jobNumber = jobNumber;
	}
	public Integer getStoreId() {
		return storeId;
	}
	public void setStoreId(Integer storeId) {
		this.storeId = storeId;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	public String getWeiboUid() {
		return weiboUid;
	}
	public void setWeiboUid(String weiboUid) {
		this.weiboUid = weiboUid;
	}
	public Integer getMarketId() {
		return marketId;
	}
	public void setMarketId(Integer marketId) {
		this.marketId = marketId;
	}
	public Double getCostTotal() {
		return costTotal;
	}
	public void setCostTotal(Double costTotal) {
		this.costTotal = costTotal;
	}
	public Integer getCostCount() {
		return costCount;
	}
	public void setCostCount(Integer costCount) {
		this.costCount = costCount;
	}
	public Date getFirstCost() {
		return firstCost;
	}
	public void setFirstCost(Date firstCost) {
		this.firstCost = firstCost;
	}
	public Date getLastCost() {
		return lastCost;
	}
	public void setLastCost(Date lastCost) {
		this.lastCost = lastCost;
	}
	public Double getCrmbalance() {
		return crmbalance;
	}
	public void setCrmbalance(Double crmbalance) {
		this.crmbalance = crmbalance;
	}
	public Integer getCrmscore() {
		return crmscore;
	}
	public void setCrmscore(Integer crmscore) {
		this.crmscore = crmscore;
	}
	public Double getCrmdiscount() {
		return crmdiscount;
	}
	public void setCrmdiscount(Double crmdiscount) {
		this.crmdiscount = crmdiscount;
	}
	public String getCrmmemberlevel() {
		return crmmemberlevel;
	}
	public void setCrmmemberlevel(String crmmemberlevel) {
		this.crmmemberlevel = crmmemberlevel;
	}
	public Integer getGoodsTotal() {
		return goodsTotal;
	}
	public void setGoodsTotal(Integer goodsTotal) {
		this.goodsTotal = goodsTotal;
	}
	public Integer getAverageCost() {
		return averageCost;
	}
	public void setAverageCost(Integer averageCost) {
		this.averageCost = averageCost;
	}
	public Integer getAverageGoodsQuantity() {
		return averageGoodsQuantity;
	}
	public void setAverageGoodsQuantity(Integer averageGoodsQuantity) {
		this.averageGoodsQuantity = averageGoodsQuantity;
	}
	public Integer getMaxCost() {
		return maxCost;
	}
	public void setMaxCost(Integer maxCost) {
		this.maxCost = maxCost;
	}
	public Integer getGainIntegral() {
		return gainIntegral;
	}
	public void setGainIntegral(Integer gainIntegral) {
		this.gainIntegral = gainIntegral;
	}
	public Integer getUseIntegral() {
		return useIntegral;
	}
	public void setUseIntegral(Integer useIntegral) {
		this.useIntegral = useIntegral;
	}
	public Integer getExpiredIntegral() {
		return expiredIntegral;
	}
	public void setExpiredIntegral(Integer expiredIntegral) {
		this.expiredIntegral = expiredIntegral;
	}
	public Integer getCouponCodeTotal() {
		return couponCodeTotal;
	}
	public void setCouponCodeTotal(Integer couponCodeTotal) {
		this.couponCodeTotal = couponCodeTotal;
	}
	public String getOfficeAddress() {
		return officeAddress;
	}
	public void setOfficeAddress(String officeAddress) {
		this.officeAddress = officeAddress;
	}
	public String getIdCard() {
		return idCard;
	}
	public void setIdCard(String idCard) {
		this.idCard = idCard;
	}
	public String getIncomeRange() {
		return incomeRange;
	}
	public void setIncomeRange(String incomeRange) {
		this.incomeRange = incomeRange;
	}
	public Integer getFamilySize() {
		return familySize;
	}
	public void setFamilySize(Integer familySize) {
		this.familySize = familySize;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getAgeBracket() {
		return ageBracket;
	}
	public void setAgeBracket(String ageBracket) {
		this.ageBracket = ageBracket;
	}
	public String getChildrenName() {
		return childrenName;
	}
	public void setChildrenName(String childrenName) {
		this.childrenName = childrenName;
	}
	public Integer getChildrenAge() {
		return childrenAge;
	}
	public void setChildrenAge(Integer childrenAge) {
		this.childrenAge = childrenAge;
	}
	public String getParentName() {
		return parentName;
	}
	public void setParentName(String parentName) {
		this.parentName = parentName;
	}
	public Integer getParentAge() {
		return parentAge;
	}
	public void setParentAge(Integer parentAge) {
		this.parentAge = parentAge;
	}
	public Date getExportTime() {
		return exportTime;
	}
	public void setExportTime(Date exportTime) {
		this.exportTime = exportTime;
	}
	public Double getCoolCoin() {
		return coolCoin;
	}
	public void setCoolCoin(Double coolCoin) {
		this.coolCoin = coolCoin;
	}
	public Integer getCrmHisScore() {
		return crmHisScore;
	}
	public void setCrmHisScore(Integer crmHisScore) {
		this.crmHisScore = crmHisScore;
	}
	public String getBelongSaleper() {
		return belongSaleper;
	}
	public void setBelongSaleper(String belongSaleper) {
		this.belongSaleper = belongSaleper;
	}
	public String getReferee() {
		return referee;
	}
	public void setReferee(String referee) {
		this.referee = referee;
	}
	public Double getValueScore() {
		return valueScore;
	}
	public void setValueScore(Double valueScore) {
		this.valueScore = valueScore;
	}
	public Date getFirstCostTime() {
		return firstCostTime;
	}
	public void setFirstCostTime(Date firstCostTime) {
		this.firstCostTime = firstCostTime;
	}
	public Integer getIntegralType() {
		return integralType;
	}
	public void setIntegralType(Integer integralType) {
		this.integralType = integralType;
	}
	public String getErpStoreId() {
		return erpStoreId;
	}
	public void setErpStoreId(String erpStoreId) {
		this.erpStoreId = erpStoreId;
	}
	public Integer getSignRaining() {
		return signRaining;
	}
	public void setSignRaining(Integer signRaining) {
		this.signRaining = signRaining;
	}
	@Override
	public String toString() {
		return "BcCustomer [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createId=" + createId + ", createTime=" + createTime + ", orderCode=" + orderCode + ", deleteTime="
				+ deleteTime + ", remarks=" + remarks + ", attachment=" + attachment + ", name=" + name + ", phone="
				+ phone + ", email=" + email + ", company=" + company + ", job=" + job + ", score=" + score
				+ ", gender=" + gender + ", birthday=" + birthday + ", weibo=" + weibo + ", wechat=" + wechat
				+ ", city=" + city + ", address=" + address + ", fax=" + fax + ", tag=" + tag + ", source=" + source
				+ ", groupCustomer=" + groupCustomer + ", avatar=" + avatar + ", bak1=" + bak1 + ", bak2=" + bak2
				+ ", bak3=" + bak3 + ", bak4=" + bak4 + ", bak5=" + bak5 + ", weiboUid=" + weiboUid + ", QQ=" + QQ
				+ ", point=" + point + ", level=" + level + ", marketId=" + marketId + ", marketName=" + marketName
				+ ", costTotal=" + costTotal + ", costCount=" + costCount + ", firstCost=" + firstCost + ", lastCost="
				+ lastCost + ", crmbalance=" + crmbalance + ", crmscore=" + crmscore + ", crmdiscount=" + crmdiscount
				+ ", crmmemberlevel=" + crmmemberlevel + ", goodsTotal=" + goodsTotal + ", averageCost=" + averageCost
				+ ", averageGoodsQuantity=" + averageGoodsQuantity + ", maxCost=" + maxCost + ", gainIntegral="
				+ gainIntegral + ", useIntegral=" + useIntegral + ", expiredIntegral=" + expiredIntegral
				+ ", couponCodeTotal=" + couponCodeTotal + ", officeAddress=" + officeAddress + ", idCard=" + idCard
				+ ", incomeRange=" + incomeRange + ", familySize=" + familySize + ", education=" + education
				+ ", ageBracket=" + ageBracket + ", childrenName=" + childrenName + ", childrenAge=" + childrenAge
				+ ", parentName=" + parentName + ", parentAge=" + parentAge + ", exportTime=" + exportTime
				+ ", coolCoin=" + coolCoin + ", crmHisScore=" + crmHisScore + ", belongSaleper=" + belongSaleper
				+ ", referee=" + referee + ", valueScore=" + valueScore + ", firstCostTime=" + firstCostTime
				+ ", lastCostTime=" + lastCostTime + ", integralType=" + integralType + ", cash=" + cash
				+ ", erpStoreId=" + erpStoreId + ", province=" + province + ", status=" + status + ", type=" + type
				+ ", signRaining=" + signRaining + ", customer_source=" + customer_source + ", custLimit=" + custLimit
				+ ", crmBalance=" + crmBalance + ", crmScore=" + crmScore + ", crmDiscount=" + crmDiscount
				+ ", crmMemberLevel=" + crmMemberLevel + ", openId=" + openId + ", staffId=" + staffId + ", jobNumber="
				+ jobNumber + ", storeId=" + storeId + ", storeName=" + storeName + "]";
	}
}
*/