package cn.cecook.controller.business.markting;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.SmartMarketService;
import cn.cecook.uitls.StringUtils;

@Controller
@RequestMapping("/api/smart_market")
public class SmartMarketController {

	SmartMarketService smartMarketService;

	/**
	 * 
	 * Title: createMarket Description:创建智能营销实例
	 * 
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param name
	 *            名称
	 * @param model_id
	 *            智能营销模板id
	 * @param model_key
	 *            智能营销模板key
	 * @param activitys
	 *            智能营销活动集合
	 * @return
	 */
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object createMarket(String tenant_id, String uid, String name,
			String model_id, String model_key, String activitys) {
		System.out.println("--------->");
		return (smartMarketService.create(tenant_id,
				uid, name, model_id, model_key, activitys));
	}
	
	@RequestMapping(value = "/createbyactivityOne")
	@ResponseBody
	public Object createMarketByActivityOne(String tenant_id, String uid, String name,
			String model_id, String model_key, String activity_id) {
		System.out.println("--------->");
		return (smartMarketService.createByOne(tenant_id,
				uid, name, model_id, model_key, activity_id));
	}
	

	@RequestMapping(value = "/copy")
	@ResponseBody
	public Object copyMarket(String tenant_id, String uid, String name,
			String model_id, String model_key, String activitys) {
		System.out.println("--------->");
		return (smartMarketService.copy(tenant_id,
				uid, name, model_id, model_key, activitys));
	}
	
	@RequestMapping(value = "/cancel")
	@ResponseBody
	public Object cancel(String market_rules, String activitys) {
		System.out.println("--------->");
		return (smartMarketService.cancel(
				market_rules, activitys));
	}

	/**
	 * 
	 * Title: activateMarket Description:激活智能营销
	 * 
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param market_id
	 *            智能营销实例id
	 * @param processDefintionId
	 *            流程定义id
	 * @return
	 */
	@RequestMapping(value = "/activate")
	@ResponseBody
	public Object activateMarket(String tenant_id, String uid,
			String market_id, String processDefintionId, String rule_id,
			String activity_id) {
//		return (smartMarketService.start(tenant_id,
//				uid, market_id, processDefintionId, rule_id, activity_id));
		return (smartMarketService.startByTime(tenant_id,
				uid, market_id, processDefintionId, rule_id, activity_id));

	}

	/**
	 * 
	 * Title: suspendMarket Description:中止智能营销
	 * 
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param market_id
	 *            智能营销id
	 * @param model_key
	 * @param processDefintionId
	 * @return
	 */
	@RequestMapping(value = "/suspend")
	@ResponseBody
	public Object suspendMarket(String tenant_id, String uid, String market_id,
			String processDefintionId) {
		return (smartMarketService.stop(tenant_id,
				uid, market_id, processDefintionId));

	}

	/**
	 * 
	 * Title: editMarket Description:
	 * 
	 * @param tenant_id
	 * @param uid
	 * @param market_id
	 * @param activitys
	 * @param name
	 * @return
	 */
	@RequestMapping(value = "/edit")
	@ResponseBody
	public Object editMarket(String tenant_id, String uid, String market_id,
			String activitys, String name) {
		return (smartMarketService.edit(tenant_id,
				uid, market_id, activitys, name));

	}

	/**
	 * 
	 * Title: deleteMarket Description:
	 * 
	 * @param tenant_id
	 * @param uid
	 * @param market_id
	 * @param processDefintionId
	 * @return
	 */
	@RequestMapping(value = "/delete")
	@ResponseBody
	public Object deleteMarket(String tenant_id, String uid, String market_id,
			String processDefintionId) {
		return (smartMarketService.delete(tenant_id,
				uid, market_id, processDefintionId));

	}

	/**
	 * 
	 * Title: startMarket Description:
	 * 
	 * @param tenant_id
	 * @param market_id
	 * @param name
	 * @param phoneNum
	 * @return
	 */
//	@RequestMapping(value = "/start")
//	@ResponseBody
//	public Object startMarket(String tenant_id, String market_id, String name,
//			String phoneNum) {
///*		return (smartMarketService.startIntance(
//				tenant_id, market_id, name, phoneNum));*/
//		return (smartMarketService.startIntance(
//				tenant_id, market_id, name, phoneNum));
//	}
	
	@RequestMapping(value = "/start")
	@ResponseBody
	public Object startMarket(String tenant_id, String uid,
			String market_id, String processDefintionId, String rule_id,
			String activity_id,String birthdayFlag) {
/*		return (smartMarketService.startIntance(
				tenant_id, market_id, name, phoneNum));*/
		if(!StringUtils.isEmpty(birthdayFlag)&&birthdayFlag.equals("1")){
			System.out.println("11111111");
			return (smartMarketService.startByBirthday(tenant_id, uid, market_id, processDefintionId, rule_id, activity_id));

		}else{
			System.out.println("2222222");
			return (smartMarketService.start(tenant_id, uid, market_id, processDefintionId, rule_id, activity_id));

		}
		
			}

	/**
	 * 
	 * Title: getMarketList Description: 获取营销列表
	 * 
	 * @param status
	 * @param key_word
	 * @param startIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/getMarketList")
	@ResponseBody
	public Object getMarketList(String status, String key_word,
			String startIndex, String pageSize) {

		return (smartMarketService.getMarketList(
				status, key_word, startIndex, pageSize));
	}

	/**
	 * 
	 * Title: getMarketDetail Description:获取智能营销详情
	 * 
	 * @param market_id
	 * @return
	 */
	@RequestMapping(value = "/getMarketDetail")
	@ResponseBody
	public Object getMarketDetail(String market_id) {
		System.out.println(market_id);
		return (smartMarketService
				.getMarketDetail(market_id));
	}

	@RequestMapping(value = "/customerDimensionCount")
	@ResponseBody
	public Object customerDimensionCount(String send_object,String uid) {
		return (smartMarketService
				.customerDimensionCount(send_object, uid));
	}

	// 设置首页显示
	@RequestMapping(value = "/setMarketShowHome")
	@ResponseBody
	public Object setMarketShowHome(String market_id) {
		return (smartMarketService
				.setHomeShow(market_id));
	}

	// 获取首先显示的智能营销
	@RequestMapping(value = "/queryHomeMarket")
	@ResponseBody
	public Object queryHomeMarket() {
		return (smartMarketService.queryHomeMarket());
	}

}
