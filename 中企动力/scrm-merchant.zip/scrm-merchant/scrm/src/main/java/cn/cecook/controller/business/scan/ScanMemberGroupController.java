package cn.cecook.controller.business.scan;

import java.math.BigDecimal;
import java.sql.Timestamp;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.dao.business.scan.ScanIntegralMapper;
import cn.cecook.service.business.scan.ScanMemberGroupService;
import cn.cecook.uitls.ConfigStatusCode;

@Controller
@RequestMapping("/scan/memberGroup")
public class ScanMemberGroupController {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	private JsonParser jsonParser = new JsonParser();
	@Autowired
	private ScanMemberGroupService memberGroupService;
	@Autowired
	private ScanIntegralMapper integralMapper;
	
	@RequestMapping(value="/saveGroup",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String saveGroup(@RequestBody String param) {
		JsonObject jsonObject = jsonParser.parse(param).getAsJsonObject();
		Map<String, Object> map = new HashMap<>();
		if(jsonObject.get("id") != null) {
			map.put("id", jsonObject.get("id").getAsInt());
		}
		map.put("type", jsonObject.get("type").getAsInt());
		if(jsonObject.get("parent_id") != null) {
			map.put("parent_id", jsonObject.get("parent_id").getAsInt());
		}
		map.put("name", jsonObject.get("name").getAsString());
		if(jsonObject.get("status") != null) {
			map.put("status", jsonObject.get("status").getAsInt());
		}
		if(jsonObject.get("base_attr") != null) {
			map.put("base_attr", jsonObject.get("base_attr").toString());
		}
		if(jsonObject.get("trade_attr") != null) {
			map.put("trade_attr", jsonObject.get("trade_attr").toString());
		}
		if(jsonObject.get("RFM_attr") != null) {
			map.put("RFM_attr", jsonObject.get("RFM_attr").toString());
		}
		if(jsonObject.get("tag_attr") != null) {
			map.put("tag_attr", jsonObject.get("tag_attr").toString());
		}
		return memberGroupService.saveMemberGroup(map);
	}
	
	@RequestMapping(value="/getMemberGroupTree",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getMemberGroupTree(@RequestBody String param) {
		return memberGroupService.getMemberGroupTree();
	}
	
	@RequestMapping(value="/countPeople",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String countPeople(long groupId) {
		return memberGroupService.countPeople(groupId);
	}
	
	@RequestMapping(value="/getGroup",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getGroup(long groupId) {
		return memberGroupService.getGroup(groupId);
	}
	
	@RequestMapping(value = "/getPageGroup", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getPageGroup(@RequestBody String param) {
        String page = memberGroupService.getPageGroup(jsonParser.parse(param).getAsJsonObject());
        return jsonParser.parse(page).getAsJsonObject().get("data").toString();
    }
	
	@RequestMapping(value = "/delGroup", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String delGroup(long groupId) {
        return memberGroupService.delGroup(groupId);
    }
	
	@RequestMapping(value = "/delGroupAll", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String delGroupAll(String groupId) {
        return memberGroupService.delGroupAll(groupId);
    }
	
	@RequestMapping(value = "/selectGroup", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String selectGroup(long groupId, long parentId) {
        return memberGroupService.selectGroup(groupId, parentId);
    }
	
	//导出分组下面的会员
    @RequestMapping(value = "/exportMember")
    public void exportMember(long groupId,HttpServletResponse response) {
        memberGroupService.exportMember(groupId,response);
    }
    
    //短信营销模块  获取分组列表
    @RequestMapping(value = "/getCustomerGroup")
	@ResponseBody
	public Object getCustomerGroup(int startIndex, int pageSize,
			String groupName,long uid,String groupIds) {
		return (memberGroupService.getCustomerGroup(
				startIndex, pageSize, groupName,uid,groupIds));
	}
    //导入会员进行分组
    @RequestMapping(value = "/importMember", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String importMember(MultipartFile file, int type,String name,int parentId) {
        return memberGroupService.importMember(file, type,name,parentId);
    }
    
    @RequestMapping(value = "/rename", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String rename(int groupId, String name) {
        return memberGroupService.rename(groupId, name);
    }
    
    //商品名称模糊查找
    @RequestMapping(value = "/listMedicineNameLikeName", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String listMedicineNameLikeName(String name) {
    	JsonObject result = new JsonObject();
		try {
			JsonArray listMedicineNameLikeName = memberGroupService.listMedicineNameLikeName(name);
			result.add("data", listMedicineNameLikeName);
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error(this.getClass().getName()+".listMedicineNameLikeName()", e);
		}
		logger.debug(this.getClass().getName()+".listMedicineNameLikeName()", result.toString());
		return result.toString();
    }
    /**
     * 查询分组(按名称查询)
     */
    @RequestMapping("/findByName")
    @ResponseBody
    public Object findByName(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String name){
    	return memberGroupService.findByName(name);
    }
    /**
     * 动态数据每小时更新1次
     */
    @RequestMapping("/getRefreshMember")
    @ResponseBody
    public Integer getRefreshMember(Integer groupId){
    	int result = 0;
    	try {
    		result = memberGroupService.getRefreshMember(groupId);
		} catch (Exception e) {
			// TODO: handle exception
			result = 0;
		}
    	return result;
    }
    
    /**
     * 初始化每个租户库下面的会员RFM属性
     * @param tenantId
     * @return
     */
    @RequestMapping("/initRFM")
    @ResponseBody
    public void initRFM(@RequestParam(required=true) final String tenantId) {
    	try {
    		Thread thread = new Thread(new Runnable() {
				@Override
				public void run() {
					Map<String, Object> where1 = new HashMap<>();
					where1.put("tenantId", tenantId);
					List<Integer> listMemberId = integralMapper.listMemberId(where1);
					System.out.println(tenantId);
					System.out.println(listMemberId.size());
					for (Integer memberId : listMemberId) {
						where1.put("memberId", memberId);
						int integral = integralMapper.getIntegral(where1);	//可用积分
						int expiredIntegral = integralMapper.getExpiredIntegral(where1);	//过期积分
						Map<String, Object> useGainIntegral = integralMapper.getUseGainIntegral(where1);
						int useIntegral = ((BigDecimal)useGainIntegral.get("useIntegral")).intValue();	//已使用积分
						int gainIntegral = ((BigDecimal)useGainIntegral.get("gainIntegral")).intValue();	//获得积分
						
						Map<String, Object> cost = integralMapper.getCost(where1);
						int cost_total = ((BigDecimal)cost.get("cost_total")).intValue();	//消费金额统计
						long cost_count = (Long)cost.get("cost_count");	//消费次数统计
						int goods_total = ((BigDecimal)cost.get("goods_total")).intValue();	//购买商品总件数
						long average_cost = 0;	//平均消费金额
						long average_goods_quantity = 0;	//平均购买件数
						if(cost_count != 0) {
							average_cost = cost_total / cost_count;
							average_goods_quantity = goods_total / cost_count;
						}
						Long coupon_code_total = (Long)cost.get("coupon_code_total");	//优惠券使用次数
						Timestamp first_cost_time = (Timestamp)cost.get("first_cost_time");	//第一次消费时间
						Timestamp last_cost_time = (Timestamp)cost.get("last_cost_time");	//最后一次消费时间
						long max_cost = (Long)cost.get("max_cost");	//单笔最大消费金额
						int first_cost = 0;	//第一次消费金额
						int last_cost = 0;	//最后一次消费金额
						
						if(first_cost_time != null) {
							where1.put("trade_time", first_cost_time);
							first_cost = integralMapper.getCostByDate(where1);
						}
						if(last_cost_time != null) {
							where1.put("trade_time", last_cost_time);
							last_cost = integralMapper.getCostByDate(where1);
						}
						Map<String, Object> param = new HashMap<>();
						param.put("tenantId", tenantId);
						param.put("memberId", memberId);
						param.put("integral", integral);
						param.put("expiredIntegral", expiredIntegral);
						param.put("useIntegral", useIntegral);
						param.put("gainIntegral", gainIntegral);
						param.put("cost_total", cost_total);
						param.put("cost_count", cost_count);
						param.put("goods_total", goods_total);
						param.put("average_cost", average_cost);
						param.put("average_goods_quantity", average_goods_quantity);
						param.put("coupon_code_total", coupon_code_total);
						param.put("first_cost_time", first_cost_time);
						param.put("last_cost_time", last_cost_time);
						param.put("max_cost", max_cost);
						param.put("first_cost", first_cost);
						param.put("last_cost", last_cost);
						integralMapper.updateMemberRFMAttr(param);
					}
				}
			});
    		thread.setDaemon(true);
    		thread.start();
    	}catch (Exception e) {
    		logger.error(this.getClass().getName()+"initRFM()",e);
		}
    }
}