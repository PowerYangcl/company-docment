package cn.cecook.controller.business.markting;


import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.SmartActivityService;

@Controller
@RequestMapping("/api/smart_activity")
public class SmartActivityController {

    SmartActivityService smartActivityService;

    /**
     * 
     * Title: createSmartActivity Description:选择活动作为智能营销活动
     * 
     * @param uid 用户id
     * @param tenant_id 租户id
     * @param activity_id 活动id
     * @return
     */
    @RequestMapping(value = "/createActivity")
    @ResponseBody
    public Object createSmartActivity(String uid, String tenant_id, String activity_id) {

        return (smartActivityService.createSmartActivity(uid, tenant_id, activity_id));

    }

    /**
     * 
    * Title: activityDetail
    * Description:获取智能营销活动详情
    * @param uid 租户id
    * @param tenant_id 用户id
    * @param activity_id 活动id
    * @return
     */
    @RequestMapping(value = "/detail")
    @ResponseBody
    public Object activityDetail(String uid, String tenant_id, String activity_id) {

        return (smartActivityService.getDetail(uid, tenant_id, activity_id));

    }

    /**
     * 
    * Title: deleteSmartActivity
    * Description:删除智能营销活动
    * @param uid  用户id
    * @param tenant_id 租户id
    * @param activity_id 活动id
    * @return
     */
    @RequestMapping(value = "/deleteActivity")
    @ResponseBody
    public Object deleteSmartActivity(String uid, String tenant_id, String activity_id) {
        return (smartActivityService.deleteSmartActivity(uid, tenant_id, activity_id));
    }

    /**
     * 
    * Title: createRule
    * Description：创建智能营销活动规则
    * @param tenant_id 租户id
    * @param uid 用户id 
    * @param activity_id 活动id
    * @param send_time 发送时间
    * @param send_type 发送方式
    * @param behavior_rule 行为规则
    * @param receive_rule 领取规则
    * @param send_object 发送对象
    * @return
     */
    @RequestMapping(value = "/createRule")
    @ResponseBody
    public Object createRule(String tenant_id, String uid, String activity_id, 
                    String send_time, String send_type,
                    String behavior_rule, String receive_rule, String send_object,String sms_content) {
        return (smartActivityService.createRule(tenant_id, uid, activity_id, send_time,
                        send_type, behavior_rule, receive_rule, send_object,sms_content));
    }

    /**
     * 
    * Title: deleteRule
    * Description:删除活动规则
    * @param tenant_id 租户id
    * @param uid 用户id
    * @param activity_id 活动id
    * @param rule_id 规则id
    * @return
     */
    @RequestMapping(value = "/deleteRule")
    @ResponseBody
    public Object deleteRule(String tenant_id, String uid, String activity_id, String rule_id) {
        return (smartActivityService.deleteRule(tenant_id, uid, activity_id, rule_id));

    }

    /**
     * 
    * Title: editRule
    * Description:编辑活动规则
    * @param tenant_id租户id
    * @param uid 用户id
    * @param rule_id 活动规则
    * @param send_time 发送时间
    * @param send_type 发送方式
    * @param behavior_rule 行为规则
    * @param receive_rule 领取规则
    * @param send_object 发送方式
    * @return
     */
    @RequestMapping(value = "/editRule")
    @ResponseBody
    public Object editRule(String tenant_id, String uid, String rule_id, String send_time, String send_type,
                    String behavior_rule, String receive_rule, String send_object,String sms_content) {

        return (smartActivityService.editRule(tenant_id, uid, rule_id, send_time, send_type,
                        behavior_rule, receive_rule, send_object,sms_content));

    }

    /**
     * 
    * Title: ruleDetail
    * Description:获取规则详情
    * @param tenant_id 租户id
    * @param uid 用户id
    * @param rule_id 规则id
    * @return
     */
    @RequestMapping(value = "/ruleDetail")
    @ResponseBody
    public Object ruleDetail(String tenant_id, String uid, String rule_id) {
        return (smartActivityService.ruleDetail(tenant_id, uid, rule_id));
    }
    
    @RequestMapping(value = "/getStatisticalDetail")
    @ResponseBody
    public Object getStatisticalDetail(String activity_id) {
        return (smartActivityService.getStatisticalDetail(activity_id));
    }
    
}
