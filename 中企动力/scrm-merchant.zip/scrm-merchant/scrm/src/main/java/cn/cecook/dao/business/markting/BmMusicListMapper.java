package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.bean.business.markting.MusicBean;
import cn.cecook.model.business.markting.BmMusicList;

public interface BmMusicListMapper {
   

    int deleteByPrimaryKey(Long id);

    int insertSelective(BmMusicList record);

    MusicBean selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BmMusicList record);
    
    List<MusicBean> getMusicList(Map<String, Object> map);

    int count(String keyWord);
}