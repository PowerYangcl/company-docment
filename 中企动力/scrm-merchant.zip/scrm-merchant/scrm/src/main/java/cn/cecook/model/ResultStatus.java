package cn.cecook.model;

public enum ResultStatus {

    //系统成功200
    SUCCESS("200", "成功"),
    //成功，但是结果等为符合条件2XX
    NO_RECORD("201", "无记录"),
    //系统异常5XX
    HTTP_REQUEST_ERROR("501", "远程请求出错"),

    REQUEST_PARAM_ERROR("502", "请求参数出错"),

    NEED_UPDATE_ERROR("504", "必要更新出错"),

    NEED_DATA_ERROR("503", "必要数据查询出错");

    private String status_code;
    private String status_message;

    ResultStatus(String status_code, String status_message) {
        this.status_code = status_code;
        this.status_message = status_message;
    }

    public String getStatus_message() {
        return this.status_message;
    }

    public String getStatus_code() {
        return this.status_code;
    }
}
