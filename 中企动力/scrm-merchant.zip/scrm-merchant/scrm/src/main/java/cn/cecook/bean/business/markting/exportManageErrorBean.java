package cn.cecook.bean.business.markting;

public class exportManageErrorBean {
	private String phone;
	private String name;
    private String address;
    private String office_address;
    private String gender;
    private String id_card;
    private String income_range;
    private String family_size;
    private String education;
    private String age_bracket;
    private String children_name;
    private String children_age;
    private String parent_name;
    private String parent_age;
    private String email;
    private String wechat;
    private String weibo;
    private String QQ;
    private String cool_coin;
    private String crmScore;
    private String crm_his_score;
    private String level;
    private String source;    
    private String belong_saleper;    
    private String referee;      
    private String store_name;      
    private String value_score;
    private String group_customer;   
    private String type_customer;
    private String create_time;
    private String cost_count;   
    private String cost_total;
    private String goods_total;
    private String tag;
    private String last_cost_time;
    private String last_cost;
    private String first_cost_time; 
    private String first_cost; 
    private String export_time;
    
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getAddress() {
		return address;
	}
	public void setAddress(String address) {
		this.address = address;
	}
	public String getOffice_address() {
		return office_address;
	}
	public void setOffice_address(String office_address) {
		this.office_address = office_address;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		this.gender = gender;
	}
	public String getId_card() {
		return id_card;
	}
	public void setId_card(String id_card) {
		this.id_card = id_card;
	}
	public String getIncome_range() {
		return income_range;
	}
	public void setIncome_range(String income_range) {
		this.income_range = income_range;
	}
	public String getFamily_size() {
		return family_size;
	}
	public void setFamily_size(String family_size) {
		this.family_size = family_size;
	}
	public String getEducation() {
		return education;
	}
	public void setEducation(String education) {
		this.education = education;
	}
	public String getAge_bracket() {
		return age_bracket;
	}
	public void setAge_bracket(String age_bracket) {
		this.age_bracket = age_bracket;
	}
	public String getChildren_name() {
		return children_name;
	}
	public void setChildren_name(String children_name) {
		this.children_name = children_name;
	}
	public String getChildren_age() {
		return children_age;
	}
	public void setChildren_age(String children_age) {
		this.children_age = children_age;
	}
	public String getParent_name() {
		return parent_name;
	}
	public void setParent_name(String parent_name) {
		this.parent_name = parent_name;
	}
	public String getParent_age() {
		return parent_age;
	}
	public void setParent_age(String parent_age) {
		this.parent_age = parent_age;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWechat() {
		return wechat;
	}
	public void setWechat(String wechat) {
		this.wechat = wechat;
	}
	public String getWeibo() {
		return weibo;
	}
	public void setWeibo(String weibo) {
		this.weibo = weibo;
	}
	public String getQQ() {
		return QQ;
	}
	public void setQQ(String qQ) {
		QQ = qQ;
	}
	public String getCool_coin() {
		return cool_coin;
	}
	public void setCool_coin(String cool_coin) {
		this.cool_coin = cool_coin;
	}
	public String getExport_time() {
		return export_time;
	}
	public void setExport_time(String export_time) {
		this.export_time = export_time;
	}
	public String getCrmScore() {
		return crmScore;
	}
	public void setCrmScore(String crmScore) {
		this.crmScore = crmScore;
	}
	public String getCrm_his_score() {
		return crm_his_score;
	}
	public void setCrm_his_score(String crm_his_score) {
		this.crm_his_score = crm_his_score;
	}
	public String getLevel() {
		return level;
	}
	public void setLevel(String level) {
		this.level = level;
	}
	public String getSource() {
		return source;
	}
	public void setSource(String source) {
		this.source = source;
	}
	public String getBelong_saleper() {
		return belong_saleper;
	}
	public void setBelong_saleper(String belong_saleper) {
		this.belong_saleper = belong_saleper;
	}
	public String getReferee() {
		return referee;
	}
	public void setReferee(String referee) {
		this.referee = referee;
	}
	public String getStore_name() {
		return store_name;
	}
	public void setStore_name(String store_name) {
		this.store_name = store_name;
	}
	public String getValue_score() {
		return value_score;
	}
	public void setValue_score(String value_score) {
		this.value_score = value_score;
	}
	public String getGroup_customer() {
		return group_customer;
	}
	public void setGroup_customer(String group_customer) {
		this.group_customer = group_customer;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public String getCost_count() {
		return cost_count;
	}
	public void setCost_count(String cost_count) {
		this.cost_count = cost_count;
	}
	public String getCost_total() {
		return cost_total;
	}
	public void setCost_total(String cost_total) {
		this.cost_total = cost_total;
	}
	public String getGoods_total() {
		return goods_total;
	}
	public void setGoods_total(String goods_total) {
		this.goods_total = goods_total;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getLast_cost_time() {
		return last_cost_time;
	}
	public void setLast_cost_time(String last_cost_time) {
		this.last_cost_time = last_cost_time;
	}
	public String getLast_cost() {
		return last_cost;
	}
	public void setLast_cost(String last_cost) {
		this.last_cost = last_cost;
	}
	public String getFirst_cost_time() {
		return first_cost_time;
	}
	public void setFirst_cost_time(String first_cost_time) {
		this.first_cost_time = first_cost_time;
	}
	public String getFirst_cost() {
		return first_cost;
	}
	public void setFirst_cost(String first_cost) {
		this.first_cost = first_cost;
	}
	public String getType_customer() {
		return type_customer;
	}
	public void setType_customer(String type_customer) {
		this.type_customer = type_customer;
	}
}
