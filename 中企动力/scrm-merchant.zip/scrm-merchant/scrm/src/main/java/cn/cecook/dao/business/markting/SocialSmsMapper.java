package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.bean.business.markting.ClickFormBean;
import cn.cecook.bean.business.markting.StatisticsBean;
import cn.cecook.model.business.markting.SocialSms;

@Repository("socialSmsDao")
public interface SocialSmsMapper {

	int deleteByPrimaryKey(Integer id);

	int insertSelective(SocialSms record);

	SocialSms selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(SocialSms record);

	int deleteBatch(List<Long> ids);

	int activate(int id);

	int suspend(int id);
	
	Map<String,Object> getDetail(@Param("id") int id,@Param("tenant_id") String tenant_id);
	
	List<Map<String,Object>> getList(Map<String, Object> map);

	int countTotal(Map<String, Object> map);

	int insertBatch(@Param("batch") String batch,
                    @Param("id") int id);

	List<Map<String,Object>> smsStatistics(Map<String, Object> map);

	int countStatisticsTotal(Map<String, Object> map);

	List<StatisticsBean> exportStatistics(Map<String, Object> map);
	//更新短信发送状态0未发送  1发送成功   2发送失败  3发送中
	int updateState(@Param("state") int state,
                    @Param("id") int id, @Param("tenantId") String tenantId, @Param("send_time") String send_time);

	List<Map<String,Object>> clickList(Map<String, Object> map);

	int clickListTotal(int id);

	List<Map<String,Object>> converList(Map<String, Object> map);

	int converListTotal(int id);


	List<ClickFormBean> exportConverList(int id);

	List<ClickFormBean> exportClickList(int id);

	int NonApproval(Map<String, Object> map);

	//获取短信批次状态
	int getState(@Param("id") int id, @Param("tenant_id") String tenant_id);
	//更新短信发送对象
	int updateSendObject(Map<String,Object> map);
	//发送完成
	int sendComplete(Map<String,Object> map);
	//根据ids查询
	List<Map<String,String>> queryContentByIds(List<Integer> ids);
	//批量更新审核状态
	public int updateStstuaByIds(Map<String,Object> map);
	
	/**
	 * 
	* Title: countUnAuditeByTemplateId
	* Description:根据自动化营销id统计未审核的数量
	* @param templateId
	* @return
	 */
	 Integer countUnAuditeByTemplateId(@Param("templateId") int templateId);
	 
	 /**
	  * 
	 * Title: unAuditIdsByTemplateId
	 * Description:根据自动化营销id获取未审核的id集合
	 * @param templateId
	 * @return
	  */
	 List<Integer> unAuditIdsByTemplateId(@Param("templateId") int templateId);
	 
	 /**
	  * 
	 * Title: getTemplateIdById
	 * Description:根据id查询自动化营销id
	 * @param id
	 * @return
	  */
	 Integer getTemplateIdById(@Param("id") int id);
	 
	 int deleteByTemplateId(@Param("templateId") int templateId);
	 /**
	  * 
	 * Title: getTemplateStatusBySocialSmsId
	 * Description:根据批次id查询自动化营销状态
	 * @param id
	 * @return
	  */
	 Integer getTemplateStatusBySocialSmsId(@Param("id") int id);
}