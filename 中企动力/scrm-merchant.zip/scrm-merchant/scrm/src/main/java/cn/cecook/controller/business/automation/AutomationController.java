package cn.cecook.controller.business.automation;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import cn.cecook.model.business.automation.AutomationTemplate;
import cn.cecook.service.business.automation.AutomationService;
import net.iwanglu.HttpPostRequest;

/**
 * 自动化营销控制器
 * @author majie
 *
 * 2018年1月22日-下午2:12:42
 */
@Controller
@RequestMapping("/api/automation/")
public class AutomationController {
    @Value("#{configProperties['CREATE_TASKCHAIN']}")
    private String CREATE_TASKCHAIN;
    @Value("#{configProperties['STOP_TASKCHAIN']}")
    private String STOP_TASKCHAIN;
	@Resource 
	private AutomationService automationService;
	/**
	 * 跳转到自动化营销主页面
	 * @return
	 * majie
	 */
	@RequestMapping("ui/main")
	public Object redictMain(){
		return "social/automation/main";
	}
	/**
	 * 跳转到自动化营销系统预制
	 * @return
	 * majie
	 */
	@RequestMapping("ui/systemList")
	public Object redictSystemList(){
		return "social/automation/systemList";
	}
	/**
	 * 跳转到自动化营销自定义创建
	 * @return
	 * majie
	 */
	@RequestMapping("ui/curtain")
	public Object redictCurtain(){
		return "social/automation/curtain";
	}
	/**
	 * 跳转到自动化营销自定义列表
	 * @return
	 * majie
	 */
	@RequestMapping("ui/customList")
	public Object redictCustomList(){
		return "social/automation/customList";
	}
	/**
	 * 跳转到编辑页面
	 * @return
	 * majie
	 */
	@RequestMapping("ui/editTemplate")
	public Object redicteditTemplate(){
		return "social/automation/editTemplate";
	}
	/**
	 * 查询所有模板信息
	 * majie
	 */
	@RequestMapping("findAll")
	@ResponseBody
	public Object findAll(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id){
		return  automationService.findAll();
	}
	/**
	 * 更新模板信息
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param automationTemplate
	 * @return
	 * majie
	 */
	@RequestMapping("updateAutomationTask")
	@ResponseBody
	public Object updateAutomationTask(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		return  automationService.updateAutomationTask(automationTemplate);
	}
	/**
	 * 添加自动化营销任务模板
	 */
	@RequestMapping("addAutomationTemplate")
	@ResponseBody
	public Object addAutomationTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		automationTemplate.setCreateTime(new Date());
		automationTemplate.setIsDeleted(1);
		automationTemplate.setIsRun(0);
		automationTemplate.setAuditing(0);
		return automationService.addAutomationTemplate(automationTemplate);
	}
	/**
	 * 添加自动化营销任务条件
	 */
	/**@RequestMapping("selectByTaskId")
	@ResponseBody
	public Object selectByTaskId(){
		JSONObject json=new JSONObject();
		//json.put("4", automationService.selectByTaskId("297e8f0360443e1e01604454a27a0001",4));		
		//json.put("5", automationService.selectByTaskId("297e8f0360443e1e01604454a27a0001",5));
		//json.put("6", automationService.selectByTaskId("297e8f0360443e1e01604454a27a0001",6));
		json.put("9", automationService.selectByTaskId("297e8f0360443e1e01604454a27a0001",9));
		json.put("10", automationService.selectByTaskId("297e8f0360443e1e01604454a27a0001",10));
		return json;
	}*/
	
	/**
	 * 
	* Title: Audit
	* Description:提供给运营审核
	* @return
	 */
	@RequestMapping("auditResult")
	@ResponseBody
	public Object auditResult(int id,int status){
		return automationService.auditResult(id, status);
	}
	
	
	/**
	 * 保存自动化营销模板
	 */
	@RequestMapping("saveAutomationTemplate")
	@ResponseBody
	public Object saveAutomationTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		//1.修改模板信息
		automationTemplate.setIsDeleted(0);
		automationTemplate.setAuditing(0);
		automationTemplate.setRunTime(null);
		automationService.updateAutomationTask(automationTemplate);
		//2.添加Task以及rule信息	
		automationService.saveAutomationTask(automationTemplate);
		//3.提交短信模板给运营审核
		return 	automationService.submitAudit(automationTemplate.getId());
	}
	/**
	 * 更新模板信息
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param automationTemplate
	 * @return
	 * majie
	 */
	@RequestMapping("updateAutomationTemplate")
	@ResponseBody
	public Object updateAutomationTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		//1.修改模板信息
		automationTemplate.setAuditing(0);
		automationService.updateAutomationTask(automationTemplate);
		
		//2.删除之前的模板
		automationService.deleteAutomationTemplate(automationTemplate);
		//3.添加Task以及rule信息	
		automationService.saveAutomationTask(automationTemplate);
		//4.提交短信模板给运营审核				
		return 	automationService.submitAudit(automationTemplate.getId());
	}
	/**
	 * 启动任务
	 */
	@RequestMapping("runAutomation")
	@ResponseBody
	public Object runAutomation(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		automationTemplate.setRunTime(new Date());
		automationTemplate.setIsRun(1);
		//启动任务
        HttpPostRequest httpPostRequest = new HttpPostRequest();
        JSONObject jsonObject=new JSONObject();
        jsonObject.put("tenantId", tenant_id);
        jsonObject.put("templateId", automationTemplate.getId());
        String response = httpPostRequest.postResponseJson(CREATE_TASKCHAIN, jsonObject);
		return automationService.updateAutomationTask(automationTemplate);
	}
	/**
	 * 关闭任务
	 */
	@RequestMapping("offAutomation")
	@ResponseBody
	public Object offAutomation(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		automationTemplate.setStopTime(new Date());
		//关闭任务
		HttpPostRequest httpPostRequest = new HttpPostRequest();
        JSONObject jsonObject=new JSONObject();
        jsonObject.put("tenantId", tenant_id);
        jsonObject.put("templateId", automationTemplate.getId());        
        String response = httpPostRequest.postResponseJson(STOP_TASKCHAIN, jsonObject);
		return automationService.updateAutomationTask(automationTemplate);
	}
	/**
	 * 根据模板id查询模板信息
	 */
	@RequestMapping("findByTemplateId")
	@ResponseBody
	public Object isRunAutomation(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		//判断是否可以启动
		return 	automationService.findByTemplateId(automationTemplate);
	}
	/**
	 * 复制模板
	 */
	@RequestMapping("copyAutomationTemplate")
	@ResponseBody
	public Object copyAutomationTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		//复制模板信息
		return 	automationService.copyAutomationTemplate(automationTemplate);
	}
	/**
	 * 查询模板信息
	 */
	@RequestMapping("findAutomationTemplate")
	@ResponseBody
	public Object findAutomationTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		//复制模板信息
		return 	automationService.findAutomationTemplate(automationTemplate);
	}
	/**
	 * 校验模板名称是否重复
	 */
	@RequestMapping("checkAutomationTemplateByName")
	@ResponseBody
	public Object checkAutomationTemplateByName(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
		//复制模板信息
		return 	automationService.checkAutomationTemplateByName(automationTemplate);
	}
	/***预置模板**/
	/**
	 * copy公共模板
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param automationTemplate
	 * @return
	 * majie
	 */
	@RequestMapping("copyPublicTemplate")
	@ResponseBody
	public Object copyPublicTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate){
	
		return  automationService.copyAutomationTemplateByPublic(automationTemplate);
	}
	/**
	 * 查询所有公共模板
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param automationTemplate
	 * @return
	 * majie
	 */
	@RequestMapping("findAllByPublic")
	@ResponseBody
	public Object findAllByPublic(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationTemplate automationTemplate)
	{
		return automationService.findAllByPublic();
	}
}
