package cn.cecook.controller.open;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpStatistic;
import cn.cecook.model.open.mp.MpUserMemberStat;
import cn.cecook.model.open.mp.MpUserProvinceStat;
import cn.cecook.model.open.mp.MpUserSexStat;
import cn.cecook.model.open.mp.MpUserSourceStat;
import cn.cecook.model.open.mp.MpUserSystemStat;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpStatisticService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.uitls.StringUtils;

@Controller
@RequestMapping("/weixin")
public class WeixinStatisticController {

	@Autowired
	private IMpUserService iMpUserService;
	@Autowired
	private IMpAccountService iMpAccountService;
	@Autowired
	private IMpStatisticService iMpStatisticService;
	
	@Autowired
	private IMpAccountService mpAccountService;
	
	@RequestMapping(value = "/stat")
    public ModelAndView focusUser(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView("open/stat");
		Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
        String tenantId = String.valueOf(session.getAttribute("tenantId"));
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenantId);
		//新增关注用户
		int newUser = 0;
		//取消关注用户
		int canelUser = 0;
		//净增关注用户
		int addUser = 0;
		//关注用户总数
		int cumulateUser = 0;
		if(mpAccount != null){					
			Calendar startCalendar = Calendar.getInstance();
			startCalendar.setTime(new Date());
			startCalendar.add(Calendar.DAY_OF_MONTH, -2);
			startCalendar.set(Calendar.HOUR_OF_DAY, 23);
			startCalendar.set(Calendar.MINUTE, 59);
			startCalendar.set(Calendar.SECOND, 59);
			List<MpStatistic> mpStatistics = iMpStatisticService.selectByTime(tenantId, startCalendar.getTime(), new Date());
			if(mpStatistics!= null && mpStatistics.size() > 0) {
				newUser = mpStatistics.get(mpStatistics.size()-1).getNewUser();
				canelUser = mpStatistics.get(mpStatistics.size()-1).getCancelUser();
				addUser = newUser - canelUser;
				cumulateUser = mpStatistics.get(mpStatistics.size()-1).getCumulateUser();
			}
		}
		modelAndView.addObject("newUser", newUser);
		modelAndView.addObject("canelUser", canelUser);
		modelAndView.addObject("addUser", addUser);
		modelAndView.addObject("cumulateUser", cumulateUser);
		
		//来源分布
		MpUserSourceStat sourceStat = iMpStatisticService.getSourceStat();
		modelAndView.addObject("wx_sourceStatnames", sourceStat.nameToJson());
		modelAndView.addObject("wx_sourceStatvals", sourceStat.toJson());
		
		//性别的数量
		int man = 0;
		int woman = 0;
		int unkown = 0;
		List<MpUserSexStat> sexStatList = iMpUserService.getSexStat();
		for (int i = 0; i < sexStatList.size(); i++) {
			MpUserSexStat mpUserSexStat = sexStatList.get(i);
			if("1".equals(mpUserSexStat.getSex())) {
				man = mpUserSexStat.getSexcount();
			}else if("2".equals(mpUserSexStat.getSex())) {
				woman = mpUserSexStat.getSexcount();
			}else if("0".equals(mpUserSexStat.getSex())) {
				unkown = mpUserSexStat.getSexcount();
			}
		}
		modelAndView.addObject("sex_man", man);
		modelAndView.addObject("sex_woman", woman);
		modelAndView.addObject("sex_unkown", unkown);
		
		//会员和非会员的数量
		int member_yes = 0;
		int member_no = 0;
		List<MpUserMemberStat> memberStat = iMpUserService.getMemberStat();
		for (int i = 0; i < memberStat.size(); i++) {
			if("1".equals(memberStat.get(i).getMember())){
				member_yes = memberStat.get(i).getCount();
			}else{
				member_no = memberStat.get(i).getCount();
			}
		}
		modelAndView.addObject("member_yes", member_yes);
		modelAndView.addObject("member_no", member_no);
		
		//用户设备分布
		int user_system_android = 0;
		int user_system_ios = 0;
		int user_system_unkown = 0;
		List<MpUserSystemStat> systemStat = iMpUserService.getSystemStat();
		for (int i = 0; i < systemStat.size(); i++) {
			if("android".equals(systemStat.get(i).getSystem())){
				user_system_android = systemStat.get(i).getCount();
			}else if("ios".equals(systemStat.get(i).getSystem())){
				user_system_ios = systemStat.get(i).getCount();
			}else{
				user_system_unkown = systemStat.get(i).getCount();
			}
		}
		modelAndView.addObject("user_system_android", user_system_android);
		modelAndView.addObject("user_system_ios", user_system_ios);
		modelAndView.addObject("user_system_unkown", user_system_unkown);
		
		//城市分布
		JSONArray cityInfo = new JSONArray();
		List<MpUserProvinceStat> provinceInfoList = iMpUserService.getProvinceInfo();
		for (int i = 0; i < provinceInfoList.size(); i++) {	
			MpUserProvinceStat mpProvinceInfo = provinceInfoList.get(i);
			if(StringUtils.isNotEmpty(mpProvinceInfo.getProvince())) {				
				JSONObject cityObj = new JSONObject();
				cityObj.put("name", mpProvinceInfo.getProvince());
				cityObj.put("value", mpProvinceInfo.getProvincecount());
				cityInfo.add(cityObj);
			}
		}
		modelAndView.addObject("cityInfo", cityInfo);
		
        return modelAndView;
	}
}
