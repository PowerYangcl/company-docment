package cn.cecook.dao.business.markting;

import cn.cecook.model.business.markting.GoodsSearchLog;

public interface GoodsSearchLogMapper {
    int deleteByPrimaryKey(Long id);

    int insert(GoodsSearchLog record);

    int insertSelective(GoodsSearchLog record);

    GoodsSearchLog selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GoodsSearchLog record);

    int updateByPrimaryKey(GoodsSearchLog record);
}