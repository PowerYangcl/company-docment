package cn.cecook.controller.business.customer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.customer.BcCustomer;
import cn.cecook.model.business.customer.BcCustomerExtend;
import cn.cecook.service.business.customer.ICustomerService;
import cn.cecook.uitls.AjaxJson;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Pages;
import cn.cecook.uitls.StringUtils;

/**
 * 客户资料
 * @author zhaoxin
 *
 */
@Controller
@RequestMapping("/api/custome")
public class CustomeController {

    @Autowired
    private ICustomerService customerService;

    @RequestMapping("/customerInfo")
    public String customerInfo(HttpServletRequest request) {
        String customerID = request.getParameter("customerID");
        request.setAttribute("customerID", customerID);
        return "bc/customerInfo";
    }

    /**
     * 客户资料详情接口
     * @return
     */
    @RequestMapping(value = "/customerDetail")
    @ResponseBody
    public AjaxJson customerDetail(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        Gson g = new Gson();
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
            BcCustomer customer = customerService.customerDetail(Integer.valueOf(id));
            j.setObj(g.toJson(customer));
        } else {
            // 如果ID为空 返回错误信息
        }
        return j;
    }

    /**
     * 客户资料列表接口
     * @return
     */
    @RequestMapping(value = "/customerDetailList")
    @ResponseBody
    public String customerDetailList(HttpServletRequest request) {
    	
        //增加创建人id
        Cookie[] cookies= request.getCookies();
        String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid =null;
        if (id!=null) {
         uid = Long.parseLong(id);
        
		}
    	
    	
        JsonObject j = new JsonObject();
        int startIndex = 0;
        int pageCount = 0;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 15;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        String orderby = request.getParameter("orderby");
        if(StringUtils.isEmpty(orderby)){
        	orderby="t1.create_time desc";
        }else{
        	orderby="t1."+orderby;
        }
        	
        
        String nameOrphone = request.getParameter("nameOrphone");
        String activity = request.getParameter("activity");
        String source = request.getParameter("source");
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("nameOrphone", nameOrphone);
        where.put("activity", activity);
        where.put("source", source);
        where.put("uid", uid);
        Pages<Map<String, Object>> page = customerService.customerDetailList(uid,
                        new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby));
        if (page.getTotalCount() > 0) {
            pageCount = page.getTotalCount() % pageSize == 0 ? page.getTotalCount() / pageSize
                            : page.getTotalCount() / pageSize + 1;
        }
        Gson g = new Gson();
        JsonParser jsonParser = new JsonParser();
        j.add("customerList", jsonParser.parse(g.toJson(page.getItems())));
        j.addProperty("totalCount", page.getTotalCount());
        j.addProperty("startIndex", startIndex);
        j.addProperty("pageCount", pageCount);
        j.addProperty("pageSize", pageSize);
        return j.toString();
    }

    /**
     * 添加客户接口
     * @return
     */
    @RequestMapping("/addCustomer")
    @ResponseBody
    public AjaxJson addCustomer(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        BcCustomer bcCustomer = new BcCustomer();
        //增加创建人id
        Cookie[] cookies= request.getCookies();
        String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
        if (id!=null) {
         Long	uid = Long.parseLong(id);
         bcCustomer.setCreateId(uid);
		}
        if ((request.getParameter("remarks"))!=null&&(request.getParameter("remarks"))!="") {
        	String remarks= request.getParameter("remarks");// remarks
        	bcCustomer.setRemarks(remarks);
   		}
        
        
        if ((request.getParameter("name"))!=null&&(request.getParameter("name"))!="") {
        	 String name = request.getParameter("name");// 姓名
             bcCustomer.setName(name);
		}
        if ((request.getParameter("group"))!=null&&(request.getParameter("group"))!="") {
        	 String group = request.getParameter("group");// 姓名
             bcCustomer.setGroupCustomer(group);
		}
       
        	 String phone = request.getParameter("phone");// 手机号
             bcCustomer.setPhone(phone);
		
        if ((request.getParameter("email"))!=null&&(request.getParameter("email"))!="") {
        	 String email = request.getParameter("email");// 邮箱
             bcCustomer.setEmail(email);
		}
        if ((request.getParameter("company"))!=null&&(request.getParameter("company"))!="") {
        	 String company = request.getParameter("company");// 公司
             bcCustomer.setCompany(company);
		}
        if ((request.getParameter("job"))!=null&&(request.getParameter("job"))!="") {
        	 String job = request.getParameter("job");// 职位
             bcCustomer.setJob(job);
		}
        if ((request.getParameter("gender"))!=null&&(request.getParameter("gender"))!="") {
        	 String gender = request.getParameter("gender");// 性别
             bcCustomer.setGender(gender);
		}
        if ((request.getParameter("birthday"))!=null&&(request.getParameter("birthday"))!="") {
        	String birthday = request.getParameter("birthday");// 生日
            bcCustomer.setBirthday(birthday);
		}
        if ((request.getParameter("weibo"))!=null&&(request.getParameter("weibo"))!="") {
        	 String weibo = request.getParameter("weibo");// 微博
             bcCustomer.setWeibo(weibo);
		}
        if ((request.getParameter("qq"))!=null&&(request.getParameter("qq"))!="") {
        	 String qq = request.getParameter("qq");// 分组
             bcCustomer.setBak1(qq);
		}
        if ((request.getParameter("wechat"))!=null&&(request.getParameter("wechat"))!="") {
        	String wechat = request.getParameter("wechat");// 微信
            bcCustomer.setWechat(wechat);
		}
        if ((request.getParameter("city"))!=null&&(request.getParameter("city"))!="") {
        	String city = request.getParameter("city");// 城市
            bcCustomer.setCity(city);
		}
        if ((request.getParameter("fax"))!=null&&(request.getParameter("fax"))!="") {
        	String fax = request.getParameter("fax");// 传真
            bcCustomer.setFax(fax);
		}
        if ((request.getParameter("tag"))!=null&&(request.getParameter("tag"))!="") {
        	 String tag = request.getParameter("tag");// 分组
             bcCustomer.setTag(tag);
		}
        if ((request.getParameter("address"))!=null&&(request.getParameter("address"))!="") {
        	 String address = request.getParameter("address");// 地址
             bcCustomer.setAddress(address);
		}
        
        //获取扩展参数
        String extenddata="";
        if ((request.getParameter("extenddata"))!=null&&(request.getParameter("extenddata"))!="") {
        	extenddata= request.getParameter("extenddata");// 
           
		}
        bcCustomer.setSource("1");
        if (StringUtils.isNotEmpty(phone)) {
            Map<String, Object> map = customerService.addCustomer(bcCustomer,extenddata);
            if ("0".equals(map.get("state").toString())) {
                j.setError_msg("添加成功");
            } else if ("1".equals(map.get("state").toString())) {
                j.setError_msg("手机号已存在");
            } else {
                j.setError_msg("添加失败");
            }
        } else {
            j.setError_msg("手机号已存在");
        }
        return j;
    }
    
    /**
     * @author ZHIWEN
     * @description 查寻客户扩展信息
     */
    @RequestMapping(value="/showCustomerectend" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody Object addCustomerectend(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "id",required = false)Integer id
			){
    	ArrayList<BcCustomerExtend>   data_BcCustomerExtend=customerService.selectCustomerectendinfo(id);
    	if ((data_BcCustomerExtend.size()>0)&&data_BcCustomerExtend!=null) {
    		System.out.println(data_BcCustomerExtend.toString());
			return data_BcCustomerExtend;
		}
    	return null;

	}

    /**
     * @author ZHIWEN
     * @description 移除客户扩展信息
     */
    @RequestMapping(value="/removeCustomerectend" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody Object removeCustomerectend(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "type",required = false)String type,
			@RequestParam(value = "key",required = false)String key,
			@RequestParam(value = "id",required = false)Integer id
			){
    	
    	int status=customerService.RemoveCustomerectendinfo(type,key,id);
    	
    	return status;
		
	}

    /**
     * 编辑客户接口
     * @return
     */
//    @RequestMapping("/editCustomer")
    @ResponseBody
    public AjaxJson editCustomer(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        BcCustomer bcCustomer = new BcCustomer();
        
        //增加创建人id
        Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        if (createid!=null) {
         Long	uid = Long.parseLong(createid);
         bcCustomer.setCreateId(uid);
		}
        if ((request.getParameter("remarks"))!=null&&(request.getParameter("remarks"))!="") {
        	String remarks= request.getParameter("remarks");// ID
        	bcCustomer.setRemarks(remarks);
   		}
        
        
        if ((request.getParameter("customerID"))!=null&&(request.getParameter("customerID"))!="") {
        	String id = request.getParameter("customerID");// ID
        	bcCustomer.setId(Integer.parseInt(id));
   		}
        if ((request.getParameter("name"))!=null&&(request.getParameter("name"))!="") {
       	 String name = request.getParameter("name");// 姓名
            bcCustomer.setName(name);
		}
       if ((request.getParameter("group"))!=null&&(request.getParameter("group"))!="") {
       	 String group = request.getParameter("group");// 姓名
            bcCustomer.setGroupCustomer(group);
		}
      
       	 String phone = request.getParameter("phone");// 手机号
            bcCustomer.setPhone(phone);
		
       if ((request.getParameter("email"))!=null&&(request.getParameter("email"))!="") {
       	 String email = request.getParameter("email");// 邮箱
            bcCustomer.setEmail(email);
		}
       if ((request.getParameter("company"))!=null&&(request.getParameter("company"))!="") {
       	 String company = request.getParameter("company");// 公司
            bcCustomer.setCompany(company);
		}
       if ((request.getParameter("job"))!=null&&(request.getParameter("job"))!="") {
       	 String job = request.getParameter("job");// 职位
            bcCustomer.setJob(job);
		}
       if ((request.getParameter("gender"))!=null&&(request.getParameter("gender"))!="") {
       	 String gender = request.getParameter("gender");// 性别
            bcCustomer.setGender(gender);
		}
       if ((request.getParameter("birthday"))!=null&&(request.getParameter("birthday"))!="") {
       	String birthday = request.getParameter("birthday");// 生日
           bcCustomer.setBirthday(birthday);
		}
       if ((request.getParameter("weibo"))!=null&&(request.getParameter("weibo"))!="") {
       	 String weibo = request.getParameter("weibo");// 微博
            bcCustomer.setWeibo(weibo);
		}
       if ((request.getParameter("qq"))!=null&&(request.getParameter("qq"))!="") {
       	 String qq = request.getParameter("qq");// 分组
            bcCustomer.setBak1(qq);
		}
       if ((request.getParameter("wechat"))!=null&&(request.getParameter("wechat"))!="") {
       	String wechat = request.getParameter("wechat");// 微信
           bcCustomer.setWechat(wechat);
		}
       if ((request.getParameter("city"))!=null&&(request.getParameter("city"))!="") {
       	String city = request.getParameter("city");// 城市
           bcCustomer.setCity(city);
		}
       if ((request.getParameter("fax"))!=null&&(request.getParameter("fax"))!="") {
       	String fax = request.getParameter("fax");// 传真
           bcCustomer.setFax(fax);
		}
       if ((request.getParameter("tag"))!=null&&(request.getParameter("tag"))!="") {
       	 String tag = request.getParameter("tag");// 分组
            bcCustomer.setTag(tag);
		}
       if ((request.getParameter("address"))!=null&&(request.getParameter("address"))!="") {
       	 String address = request.getParameter("address");// 地址
            bcCustomer.setAddress(address);
		}
       
       //获取扩展参数
       String extenddata="";
       if ((request.getParameter("extenddata"))!=null&&(request.getParameter("extenddata"))!="") {
       	extenddata= request.getParameter("extenddata");// 
          
		}
       
        int count = customerService.editCustomer(bcCustomer,extenddata);
        if (count == 1) {
            j.setError_msg("修改成功");
        } else {
            j.setError_code(1);
            j.setError_msg("修改失败");
        }
        return j;
    }

    /**
     * 删除客户接口
     * @return
     */
    @RequestMapping("/delCustomer")
    @ResponseBody
    public AjaxJson delCustomer(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
            int count = customerService.delCustomer(Integer.valueOf(id));
            if (count == 0) {
                j.setError_code(1);// 删除失败
            } else {
                j.setError_code(0);// 删除成功
            }
        } else {
            j.setError_code(2);// Id 不能为空
        }
        return j;
    }

    /**
     * 导入客户接口
     * @return
     */
    @RequestMapping("/importCustomer")
    @ResponseBody
    public Object importCustomer(HttpServletRequest request) {
        return "bc/";
    }

    @RequestMapping("/toCustomerList")
    public String toCustomerList() {
        return "bc/customerList";
    }

    /**
     * 获取客户分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerClassification")
    @ResponseBody
    public String getCustomerClassification(HttpServletRequest request) {
    	
    	 //增加创建人id
        Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        	uid = Long.parseLong(createid);
        
		}
    	
        JsonObject jsonObject = customerService.getCustomerClassification(uid);
        return jsonObject.toString();
    }
    /**
     * 获取客户分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/rightNewOrOld")
    @ResponseBody
    public String rightNewOrOld(HttpServletRequest request) {
    	
    	 //增加创建人id
        Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        	uid = Long.parseLong(createid);
        
		}
    	
        JsonObject jsonObject = customerService.rightNewOrOld(uid);
        return jsonObject.toString();
    }
    
    /**
     * 获取客户分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/rightTotalConsumption")
    @ResponseBody
    public String rightTotalConsumption(HttpServletRequest request) {
    	
    	//增加创建人id
        Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        	uid = Long.parseLong(createid);
        
		}
    	
        JsonObject jsonObject = customerService.rightTotalConsumption(uid);
        return jsonObject.toString();
    }
    
    /**
     * 获取流失客户列表
     * @param request
     * @return
     */
    @RequestMapping(value = "/getLossCustromer")
    @ResponseBody
    public String getLossCustromer(HttpServletRequest request) {
    	
    	  Cookie[] cookies= request.getCookies();
          String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
          Long	uid = null;
          if (id!=null) {
           	uid = Long.parseLong(id);
          
  		}
    	
        int startIndex = 1;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 15;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        String orderby = request.getParameter("orderby");
        String nameOrphone = request.getParameter("nameOrphone");
        String activity = request.getParameter("activity");
        String source = request.getParameter("source");
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("nameOrphone", nameOrphone);
        where.put("activity", activity);
        where.put("source", source);
        JsonObject j = customerService.getLossCustromer(
                        new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby),uid);
        j.addProperty("startIndex", startIndex);
        return j.toString();
    }

    /**
     * 获取时间属性列表
     * @param request
     * @return
     */
    @RequestMapping(value = "/getTotalDay")
    @ResponseBody
    public String getTotalDay(HttpServletRequest request) {
    	
    	  Cookie[] cookies= request.getCookies();
          String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
          Long	uid = null;
          if (id!=null) {
           	uid = Long.parseLong(id);
          
  		}
    	
        int startIndex = 1;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 15;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        String orderby = request.getParameter("orderby");
        String nameOrphone = request.getParameter("nameOrphone");
        String activity = request.getParameter("activity");
        String source = request.getParameter("source");
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("nameOrphone", nameOrphone);
        where.put("activity", activity);
        where.put("source", source);
        JsonObject j = customerService.getTotalDay(
                        new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby),uid);
        j.addProperty("startIndex", startIndex);
        return j.toString();
    }

    /**
     * 获取交易频率客户列表
     * @param request
     * @return
     */
    @RequestMapping(value = "/getTotalConsumption")
    @ResponseBody
    public String getTotalConsumption(HttpServletRequest request) {
    	
    	 Cookie[] cookies= request.getCookies();
         String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
         Long	uid = null;
         if (id!=null) {
          	uid = Long.parseLong(id);
         
 		}
    	
        int startIndex = 1;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 15;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        String orderby = request.getParameter("orderby");
        String nameOrphone = request.getParameter("nameOrphone");
        String activity = request.getParameter("activity");
        String source = request.getParameter("source");
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("nameOrphone", nameOrphone);
        where.put("activity", activity);
        where.put("source", source);
        JsonObject j = customerService.getTotalConsumption(
                        new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby),uid);
        j.addProperty("startIndex", startIndex);
        return j.toString();
    }

    /**
     * 获取客户交易量列表
     * @param request
     * @return
     */
    @RequestMapping(value = "/getTradingVolume")
    @ResponseBody
    public String getTradingVolume(HttpServletRequest request) {
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
    	
        int startIndex = 0;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 15;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        String orderby = request.getParameter("orderby");
        String nameOrphone = request.getParameter("nameOrphone");
        String activity = request.getParameter("activity");
        String source = request.getParameter("source");
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("nameOrphone", nameOrphone);
        where.put("activity", activity);
        where.put("source", source);
        JsonObject j = customerService.getTradingVolume(
                        new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby),uid);
        j.addProperty("startIndex", startIndex);
        return j.toString();
    }

    /**
     * 获取用户来源分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerSourceChar")
    @ResponseBody
    public String getCustomerSourceChar(HttpServletRequest request) {
    	
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
        JsonObject j = new JsonObject();
        j = customerService.getCustomerSourceChar(uid);
        return j.toString();
    }

    /**
     * 获取用户新客户分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerNewChar")
    @ResponseBody
    public String getCustomerNewChar(HttpServletRequest request) {
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
    	
        JsonObject j = new JsonObject();
        j = customerService.getCustomerNewChar(uid);
        return j.toString();
    }

    /**
     * 获取用户频率分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerTotalConsumptionChar")
    @ResponseBody
    public String getCustomertotalConsumptionChar(HttpServletRequest request) {
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
    	
        JsonObject j = new JsonObject();
        j = customerService.getCustomerTotalConsumptionChar(uid);
        return j.toString();
    }

    /**
     * 获取用户交易量分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerTradingVolumeChar")
    @ResponseBody
    public String getCustomerTradingVolumeChar(HttpServletRequest request) {
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
    	
        JsonObject j = new JsonObject();
        j = customerService.getCustomerTradingVolumeChar(uid);
        System.out.println("获取用户交易量分类数据---->"+FastJsonUtil.createJsonString(j));
        return j.toString();
    }

    /**
     * 获取用户流失分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerLossCustromerChar")
    @ResponseBody
    public String getCustomerLossCustromerChar(HttpServletRequest request) {
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
    	
        JsonObject j = new JsonObject();
        j = customerService.getCustomerLossCustromerChar(uid);
        return j.toString();
    }

    /**
     * 导入
     * @return
     */
//    @RequestMapping("importInfo")
    @ResponseBody
    public String importInfo(HttpServletRequest request,
                    @RequestParam(required = false, value = "file") MultipartFile file) {
        String ecxelstr = request.getParameter("ecxelstr");
        
        Cookie[]   cookies = request.getCookies();
        String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid =null;
        if (id!=null) {
        uid = Long.parseLong(id);
         
		}
        return customerService.importInfo(file, ecxelstr,uid).toString();
    }

    /**
     * 删除方法
     * @param request
     * @return
     */
    @RequestMapping(value = "/delectCustomer")
    @ResponseBody
    public String delectCustomer(HttpServletRequest request) {
        JsonObject j = new JsonObject();
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
            j = customerService.delectCustomer(Integer.parseInt(id));
        } else {
            j.addProperty("success", 2);
        }
        return j.toString();
    }

    @RequestMapping(value = "/getCustomerInfo")
    @ResponseBody
    public String getCustomerInfo(HttpServletRequest request) {
        JsonObject j = new JsonObject();
        String id = request.getParameter("customerID");
        if (StringUtils.isNotEmpty(id)) {
            j = customerService.getCustomerInfo(Integer.parseInt(id));
        } else {
            j.addProperty("bcCustomer", 0);
        }
        return j.toString();
    }

    @RequestMapping(value = "/findByCustomerId")
    @ResponseBody
    public String findByCustomerId(HttpServletRequest request) {
        JsonObject j = new JsonObject();
        String id = request.getParameter("customerID");
        if (StringUtils.isNotEmpty(id)) {
            j = customerService.findByCustomerId(Integer.parseInt(id));
        } else {
            j.addProperty("bcCustomer", 0);
        }
        return j.toString();
    }
    
    /**
     * 获取客户分类数据
     * @param request
     * @return
     */
    @RequestMapping(value = "/getRigehtLossCustromer")
    @ResponseBody
    public String getRigehtLossCustromer(HttpServletRequest request) {
    	
    	Cookie[] cookies= request.getCookies();
        String createid= CookieUtil.getCookieSet(cookies).get("uid").toString();
        Long	uid = null;
        if (createid!=null) {
        uid = Long.parseLong(createid);
         
		}
    	
        JsonObject jsonObject = customerService.getRigehtLossCustromer(uid);
        return jsonObject.toString();
    }
    
    
}