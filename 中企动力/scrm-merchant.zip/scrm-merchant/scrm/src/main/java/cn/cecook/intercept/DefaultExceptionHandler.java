package cn.cecook.intercept;

import cn.cecook.uitls.ConfigUtil;
import com.alibaba.fastjson.support.spring.FastJsonJsonView;
import org.apache.shiro.authz.UnauthorizedException;
import org.springframework.web.servlet.HandlerExceptionResolver;
import org.springframework.web.servlet.ModelAndView;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;

public class DefaultExceptionHandler implements HandlerExceptionResolver {

	@Override
	public ModelAndView resolveException(HttpServletRequest arg0,
			HttpServletResponse arg1, Object arg2, Exception arg3) {
		// TODO Auto-generated method stub
		
		 System.out.println("异常拦截");
		 arg3.printStackTrace();
		 if(arg3 instanceof UnauthorizedException){  
			 System.out.println("-----------.");
	            ModelAndView mv = new ModelAndView("index");  
	            return mv;  
	     } 
		/* //拦截登陆
		 if(arg3!=null&&!StringUtils.isEmpty(arg3.getMessage())&&arg3.getMessage().equals(errorMsg)){
			 ModelAndView mv = new ModelAndView("index");  
	            return mv;  
		 }*/
		
		
		ModelAndView mv = new ModelAndView();
		String errorCode="10010";
		String errorMessage="系统异常";
	    /*	使用FastJson提供的FastJsonJsonView视图返回，不需要捕获异常	*/
	    FastJsonJsonView view = new FastJsonJsonView();
	    Map<String, Object> attributes = new HashMap<String, Object>();
	    attributes.put(ConfigUtil.PARAMETER_ERROR_CODE, errorCode);
	    attributes.put(ConfigUtil.PARAMETER_ERROR_MSG, errorMessage);
	    view.setAttributesMap(attributes);
	    mv.setView(view); 
		return mv;
	}

}
