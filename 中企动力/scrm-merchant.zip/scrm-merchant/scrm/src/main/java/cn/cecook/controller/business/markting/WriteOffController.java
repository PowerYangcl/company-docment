package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.service.business.markting.WriteOffService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.ErrorCodeConfigUtil;
import cn.cecook.uitls.StringUtils;

@Controller
@RequestMapping("/verification")
public class WriteOffController {

	@Autowired
	private WriteOffService writeOffService;

	@RequestMapping(value = "/activitylist")
	@ResponseBody
	public Object activityList(String tenant_id, String uid,
			String activity_id, String startIndex, String page_size,
			String activity_type) {
		return (writeOffService.getActivityWriteOffList(tenant_id, uid,
				activity_id, null, startIndex, page_size, activity_type));
	}

	/**
	 * 核销列表
	 */
	@RequestMapping(value = "/list")
	@ResponseBody
	public Object queryList(String tenant_id, String key, String uid,
			String mobile, String coupon_code, String page_size,
			String startIndex) {

		return (writeOffService.getWriteOffList(tenant_id, key, uid, mobile,
				coupon_code, page_size, startIndex));
	}

	/**
	 * 反核销
	 */

	@RequestMapping(value = "/reverse")
	@ResponseBody
	public Object Reverse(String tenant_id, String uid, String reverse_reason,
			String coupon_id, String reverse_name, String activity_id,
			String customer_id) {

		if (MyCatFilter.getToken_Valid()) {
			return (writeOffService.ReverseWriteOff(tenant_id, uid,
					reverse_reason, coupon_id, reverse_name, customer_id,
					activity_id));
		} else {
			BaseResultModel baseResultModel = new BaseResultModel();
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return baseResultModel;
		}

	}

	/**
	 * 核销编辑
	 */

	@RequestMapping(value = "/edit")
	@ResponseBody
	public Object Editor(String tenant_id, String uid, String verification_id,
			String consumption_preference, String consumption_amount) {

		return (writeOffService.editorWriteOff(tenant_id, uid, verification_id,
				consumption_preference, consumption_amount));
	}

	/**
	 * 核销验证
	 */
	@RequestMapping
	@ResponseBody
	public Object validate(String tenant_id, String uid, String coupon_code,
			String coupon_id, String coupon_name, String mobile,
			String activity_id, String customer_id) {

		if (MyCatFilter.getToken_Valid()) {
			return (writeOffService.validateWriteOff(tenant_id, uid,
					coupon_code, coupon_id, coupon_name, mobile, activity_id,
					customer_id, 0));
		} else {
			BaseResultModel baseResultModel = new BaseResultModel();
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return baseResultModel;
		}

	}

	/**
	 * Title: queryCouponDetail Description:获取优惠券详情
	 *
	 * @param tenant_id
	 *            租户id
	 * @param coupon_code
	 *            优惠券码
	 * @return
	 */
	@RequestMapping(value = "/query_coupon")
	@ResponseBody
	public Object queryCouponDetail(String uid, String tenant_id,
			String coupon_code) {
		// 判断token是否有效
		if (MyCatFilter.getToken_Valid()) {
			return (writeOffService.queryCouponDetail(tenant_id, uid,
					coupon_code));
		} else {
			BaseResultModel baseResultModel = new BaseResultModel();
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return baseResultModel;
		}
	}

	@RequestMapping(value = "/query_coupon_v2")
	@ResponseBody
	public Object queryCouponDetailV2(String uid, String tenant_id,
			String coupon_code) {
		// 判断token是否有效
		if (MyCatFilter.getToken_Valid()) {
			return (writeOffService.queryCouponDetailV2(tenant_id, uid,
					coupon_code));
		} else {
			BaseResultModel baseResultModel = new BaseResultModel();
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return baseResultModel;
		}
	}

	/**
	 * 根据客户id查询第一条消费记录 根据客户id查询最近一条消费记录 第一次消费距离现在有多少天 最后一次消费距今有多少天
	 * 根据顾客id获取最近一条参加的活动信息 根据顾客id获取该客户一共多少天 消费总额 消费次数
	 *
	 * @param tenant_id
	 * @param uid
	 * @param customer_id
	 * @return
	 */
	@RequestMapping(value = "/statistics")
	@ResponseBody
	public Object queryCount(String tenant_id, String uid, String customer_id) {
		return (writeOffService
				.queryCustomerDetail(tenant_id, uid, customer_id));
	}

	@RequestMapping(value = "/insertId")
	@ResponseBody
	public Object firstTime(String tenant_id, String uid, String customer_id) {

		return (writeOffService.firstTime(tenant_id, uid, customer_id));
	}

	@RequestMapping(value = "/deleted")
	@ResponseBody
	public Object deleted(String id) {

		return (writeOffService.deleted(id));
	}

	@RequestMapping(value = "/queryAll")
	@ResponseBody
	public Object queryAll(String startIndex, String page_size) {

		return (writeOffService.queryAll(startIndex, page_size));
	}

	@RequestMapping(value = "/getListByCouponId")
	@ResponseBody
	public Object getListByCouponId(@RequestBody String param) {
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		return (writeOffService.getWriteOffListByCouponId(jsonObj));

	}

	// 导出注券统计报表
	@RequestMapping(value = "/exportWriteOffForm")
	@ResponseBody
	public Object exportWriteOffForm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		int batchId = 0;

		if (!StringUtils.isEmpty(request.getParameter("id")))
			batchId = Integer.parseInt(request.getParameter("id"));
		return writeOffService.exportWriteOffForm(batchId, response);

	}

	
	@RequestMapping(value = "/countBySearch")
	@ResponseBody
	public BaseResultModel countBySearch(String keyWord,String startTime,String endTime) {
		return writeOffService.countBySearch(keyWord, startTime, endTime);
	}
	/**
	 * 
	 * Title: countByCity Description:根据城市排名
	 * 
	 * @param startIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/countByCity")
	@ResponseBody
	public BaseResultModel countByCity(String keyWord,int startIndex, int pageSize,String timeType,String startTime,String endTime) {
		return writeOffService.countByCity(keyWord,startIndex, pageSize,timeType,startTime,endTime);
	}

	/**
	 * 
	 * Title: countByHour Description:根据当前天 按照小时统计
	 * 
	 * @return
	 */
	@RequestMapping(value = "/countByHour")
	@ResponseBody
	public BaseResultModel countByHour() {
		return writeOffService.countByHour("","");
	}

	/**
	 * 
	 * Title: countByWeek Description:根据最近7天 按照星期统计
	 * 
	 * @return
	 */
	@RequestMapping(value = "/countByWeek")
	@ResponseBody
	public BaseResultModel countByWeek() {
		return writeOffService.countByWeek();
	}

	/**
	 * 
	 * Title: countByMonth Description:根据最近30天 按天统计
	 * 
	 * @return
	 */
	@RequestMapping(value = "/countByMonth")
	@ResponseBody
	public BaseResultModel countByMonth() {
		return writeOffService.countByMonth("","","");
	}

	/**
	 * 
	 * Title: countByYear Description:根据最近12个月 按月统计
	 * 
	 * @return
	 */
	@RequestMapping(value = "/countByYear")
	@ResponseBody
	public BaseResultModel countByYear() {
		return writeOffService.countByYear("","","");
	}

}
