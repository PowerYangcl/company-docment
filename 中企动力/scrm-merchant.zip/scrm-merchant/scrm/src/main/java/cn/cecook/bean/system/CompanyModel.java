package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * 企业实体类
 * @explain 
 * @author sunny
 * @date 2017年5月26日
 */
@Component
public class CompanyModel implements Serializable{
    //    //uuid
//    private long uuid;   
//    //
//    private String access_token;
//    //
//    private long uid;
//    //
//    private long tenant_id;
    //企业id主键
    private long id;
    //企业id
    private long company_id;
    //城市地域
    private String city;
    //企业标签
    private String tag;
    //企业执照
    private String b_license;
    //业务（标签）
    private String business;
    //介绍
    private String intro;
    //关键字
    private String keyword;
    //企业名字
    private String company;
    //租户ID
    private String tenant_id;
    //行业
    private String industry;
    //电话
    private String phone;
    //logo
    private String logo;
    private String uuid;

    
    public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getTenant_id() {
        return tenant_id;
    }
    public void setTenant_id(String tenant_id) {
        this.tenant_id = tenant_id;
    }
    public String getCompany() {
        return company;
    }
    public void setCompany(String company) {
        this.company = company;
    }
    public long getId() {
        return id;
    }
    public void setId(long id) {
        this.id = id;
    }
    public long getCompany_id() {
        return company_id;
    }
    public void setCompany_id(long company_id) {
        this.company_id = company_id;
    }
    public String getCity() {
        return city;
    }
    public void setCity(String city) {
        this.city = city;
    }
    public String getTag() {
        return tag;
    }
    public void setTag(String tag) {
        this.tag = tag;
    }
    public String getB_license() {
        return b_license;
    }
    public void setB_license(String b_license) {
        this.b_license = b_license;
    }
    public String getBusiness() {
        return business;
    }
    public void setBusiness(String business) {
        this.business = business;
    }
    public String getIntro() {
        return intro;
    }
    public void setIntro(String intro) {
        this.intro = intro;
    }
    public String getKeyword() {
        return keyword;
    }
    public void setKeyword(String keyword) {
        this.keyword = keyword;
    }
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	@Override
	public String toString() {
		return "CompanyModel [id=" + id + ", company_id=" + company_id + ", city=" + city + ", tag=" + tag
				+ ", b_license=" + b_license + ", business=" + business + ", intro=" + intro + ", keyword=" + keyword
				+ ", company=" + company + ", tenant_id=" + tenant_id + ", industry=" + industry + ", phone=" + phone
				+ ", logo=" + logo + ", uuid=" + uuid + "]";
	}
	public CompanyModel() {
		super();
		// TODO Auto-generated constructor stub
	}
   
}

   
    
    

