package cn.cecook.controller.business.scan;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/scan/view")
public class ScanViewController {
	
	/************************************************** 微博找人 *********************************************************/
    @RequiresPermissions("login")
	@RequestMapping("/findPeople/rule")
	public String findPeopleRule() {
		return "scan/findPeopleRule";
	}
    
    @RequiresPermissions("login")
	@RequestMapping("/findPeople/baseSet")
	public String findPeopleBaseSet() {
		return "scan/findPeopleBaseSet";
	}
    
    @RequiresPermissions("login")
	@RequestMapping("/findPeople/option")
	public String findPeopleOption() {
		return "scan/findPeopleOption";
	}
	
	/**
	 * 	微博找人列表展示页面
	 * @return
	 */
    @RequiresPermissions("login")
	@RequestMapping("/findPeople/list")
	public String findPeopleList() {
		return "scan/findPeopleList";
	}
	
    @RequiresPermissions("login")
	@RequestMapping("/findPeople/chat")
	public String chat() {
		return "scan/chat";
	}
	
	/************************************************** 微博找事 *********************************************************/
    @RequiresPermissions("login")
	@RequestMapping("/findThing/rule")
	public String findThingRule() {
		return "scan/findThingRule";
	}
	
    @RequiresPermissions("login")
	@RequestMapping("/findThing/option")
	public String findThingOption() {
		return "scan/findThingOption";
	}
	
    @RequiresPermissions("login")
	@RequestMapping("/findThing/list")
	public String findThingList() {
		return "scan/findThingList";
	}
	
	/****************************************** 会员管理 ********************************************************/
	/**
	 * 	会员列表
	 * @return
	 */
    @RequiresPermissions("scrm_member_list")
	@RequestMapping("/member/list")
	public String memberList() {
		return "scan/memberList";
	}
	/**
	 * 	潜客列表
	 * @return
	 */
    @RequiresPermissions("login")
	@RequestMapping("/member/potentialCustomerList")
	public String potentialCustomerList() {
		return "scan/potentialCustomerList";
	}
	/**
	 * 	评价会员管理
	 * @return
	 */
    @RequiresPermissions("login")
	@RequestMapping("/member/userInfo")
	public String getUserInfo() {
		return "service/memberDetail";
	}
	/**
	 * 会员数据管理
	 * @return
	 */
    @RequiresPermissions("scrm_setting_data")
	@RequestMapping("/member/memberManageList")
	public String memberManageList() {
		return "scan/memberManage";
	}
	
    @RequiresPermissions("scrm_member_list_group")
	@RequestMapping("/member/group")		
	public String memberGroup() {
		return "scan/memberGroup";
	}
	
	//导入会员
    @RequiresPermissions("login")
	@RequestMapping("/member/importMember")
	public String importMember() {
		return "scan/importMember";
	}
	
	//会员详情
    @RequiresPermissions("login")
	@RequestMapping("/member/memberDetail")
	public String memberDetail() {
		return "scan/memberDetail";
	}
	
	//分组详情
    @RequiresPermissions("login")
	@RequestMapping("/member/groupList")
	public String groupList() {
		return "scan/groupList";
	}
	
	//选择分组
    @RequiresPermissions("login")
	@RequestMapping("/member/selectGroup")
	public String selectGroup() {
		return "scan/selectGroup";
	}
	
	/******************************************* 会员等级管理 *****************************************************/
	//积分规则
    @RequiresPermissions("login")
	@RequestMapping("/level/integralRule")
	public String integralRule() {
		return "scan/integralRule";
	}
	
	//会员积分列表
    @RequiresPermissions("login")
	@RequestMapping("/level/integralList")
	public String integralList() {
		return "scan/integralList";
	}
	
	//积分详情
    @RequiresPermissions("login")
	@RequestMapping("/level/integralDetail")
	public String integralDetail() {
		return "scan/integralDetail";
	}
	
	//积分详情
    @RequiresPermissions("login")
	@RequestMapping("/level/integralDetailList")
	public String integralDetailList() {
		return "scan/integralDetailList";
	}
	
	/************************************************ 店铺榜单 ***************************************************************/
	//店铺榜单
    @RequiresPermissions("login")
	@RequestMapping("/analyze/storeTop10")
	public String storeTop10() {
		return "scan/storeTop10";
	}
    
    /********************************************* 报告大厅 ***********************************************************/
    @RequiresPermissions("login")
	@RequestMapping("/report/memberReport")
	public String memberReport() {
		return "scan/memberReport";
	}
}