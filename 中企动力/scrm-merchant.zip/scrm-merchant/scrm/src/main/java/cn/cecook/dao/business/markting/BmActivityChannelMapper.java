package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmActivityChannel;
import cn.cecook.model.business.markting.BmActivityChannelExample;

/**
 * 
* @explain 活动分享渠道表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BmActivityChannelMapper {
    int countByExample(BmActivityChannelExample example);

    int deleteByExample(BmActivityChannelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmActivityChannel record);

    int insertSelective(BmActivityChannel record);

    List<BmActivityChannel> selectByExample(BmActivityChannelExample example);

    BmActivityChannel selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmActivityChannel record, @Param("example") BmActivityChannelExample example);

    int updateByExample(@Param("record") BmActivityChannel record, @Param("example") BmActivityChannelExample example);

    int updateByPrimaryKeySelective(BmActivityChannel record);

    int updateByPrimaryKey(BmActivityChannel record);
}