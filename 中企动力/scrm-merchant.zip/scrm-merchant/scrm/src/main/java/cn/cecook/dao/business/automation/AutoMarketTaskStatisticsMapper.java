package cn.cecook.dao.business.automation;

import java.util.Map;

import cn.cecook.bean.business.markting.AutoMarketTaskStatistics;

public interface AutoMarketTaskStatisticsMapper {
    int deleteByPrimaryKey(Long id);

    int insert(AutoMarketTaskStatistics record);

    int insertSelective(AutoMarketTaskStatistics record);

    AutoMarketTaskStatistics selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(AutoMarketTaskStatistics record);

    int updateByPrimaryKey(AutoMarketTaskStatistics record);
    //根据taskId获取发送量
	Map<String, Object> getSummaryData(Integer taskId);
	
	//统计短信到达量 
	int selectArriveCount(Integer taskId);
	
	//统计点击量 
	int selectClickCount(Integer taskId);
	
	//统计提交表单量
	int selectSubmitCount(Integer taskId);
	
	//统计核销量
	int selectWriteOffNum(Integer taskId);
	
	//统计核销总额
	double selectWriteOffCount(Integer taskId);

	//统计短信发送量
	long selectSendNum(Integer ex_action_id);

	//统计优惠券发送量
	long selectSendNum2(Integer ex_action_id);
	
	
}