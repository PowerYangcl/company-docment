package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcSmsSend;
import cn.cecook.model.business.customer.BcSmsSendExample;

/**
 * 
* @explain 短信发送记录表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcSmsSendMapper {
    int countByExample(BcSmsSendExample example);

    int deleteByExample(BcSmsSendExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcSmsSend record);

    int insertSelective(BcSmsSend record);

    List<BcSmsSend> selectByExample(BcSmsSendExample example);

    BcSmsSend selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcSmsSend record, @Param("example") BcSmsSendExample example);

    int updateByExample(@Param("record") BcSmsSend record, @Param("example") BcSmsSendExample example);

    int updateByPrimaryKeySelective(BcSmsSend record);

    int updateByPrimaryKey(BcSmsSend record);
}