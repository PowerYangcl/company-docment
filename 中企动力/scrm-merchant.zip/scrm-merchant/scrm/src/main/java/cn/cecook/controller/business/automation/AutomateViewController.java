package cn.cecook.controller.business.automation;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
@RequestMapping("/automate/view")
public class AutomateViewController {
	@RequiresPermissions("login")
	@RequestMapping("/createSms")
	public String createSms() {
		return "social/automation/createSms";
	}
	
	@RequiresPermissions("login")
	@RequestMapping("/createCouponBatch")
	public String createCouponBatch() {
		return "social/automation/createCouponBatch";
	}
	@RequiresPermissions("login")
	@RequestMapping("/modalSmsModelEdit")
	public String automateRuleEdit() {
		return "social/automation/modalSmsModelEdit";
	}
}
