package cn.cecook.dao.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysDepartment;
import cn.cecook.model.system.SysDepartmentManagement;

/**
 * 
 *@explain
 * @author ZHIWEN
 * @data 2017年6月14日
 */
public interface SysDepartmentManagementMapper {
  ArrayList<SysDepartmentManagement>	Select_departmentANDuser_Bytenant_id(String tenant_id);
  List<SysDepartment> Select_departmentBybak1andtenant_id(@Param(value = "tenantId") String tenantId, @Param(value = "bak1") String bak1);
  ArrayList<SysDepartmentManagement> Select_departmentBytenant_id(String tenant_id);
  SysDepartment Select_departmentByidandtenant_id(@Param(value = "tenantId") String tenantId, @Param(value = "id") Long id);
  List<SysDepartment> Select_departmentforlikename(@Param(value = "tenantId") String tenantId, @Param(value = "id") Long id);
  ArrayList<SysDepartmentManagement>  Select_departmentBytenant_idandbak1(@Param(value = "tenantId") String tenantId, @Param(value = "bak1") String bak1);
  //分页查询部门
  public  List<SysDepartment> select_department_limit(Map<String,Object> map);
  //查询下属部门信息
  public List<SysDepartment> select_departmentByParentId(Map<String,Object> map);
  //不分页查询部门
  List<SysDepartment> select_department_nolimit(Map<String, Object> map);
}
