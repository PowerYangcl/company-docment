package cn.cecook.controller.system;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.system.PageBean;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.bean.system.RoleModel;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.system.SysRole;
import cn.cecook.service.system.IRoleService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.StringUtils;

/**
 * 
 * @explain 角色设置接口
 * @author LeeX
 * @date 2017年6月8日
 */
@Controller
@RequestMapping("/api/role")
public class RoleController {
	/*
	 *	service 
	 */
	@Resource
	IRoleService roleService;
/*	@Resource
	SysRoleMapper mapper;
	@Resource
	SysRoleAuthorityMapper sysRoleAuthorityMapper;*/
	
	/**
	 * 
	 * @explain 查询权限接口
	 * @author LeeX
	 * @date 2017年6月8日 上午10:30:44
	 */
	@RequestMapping(value = "/selectAuthority", method = RequestMethod.POST)
	@RequiresPermissions("login")
	public @ResponseBody Object selectAuthority(HttpServletRequest request, HttpServletResponse response){
		//对象参数
		ResultModel resultModel = new ResultModel();
		
		//token
		if (!MyCatFilter.getToken_Valid()){
			resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
		
		//查询权限分为查询所有和根据角色id查询
		List list = null;
		
		//获取id
		String role_id = request.getParameter("roleId");
		
		//获取cookie
		Map cookieSet = CookieUtil.getCookieSet(request.getCookies());
		
		//判断id
		try{ 
			if(StringUtils.isBlank(role_id)){
				//没有id，执行查询所有
				list = roleService.selectAllAuthority(cookieSet); 
			}else{
				//有id，执行id查询
				Long roleId = Long.parseLong(role_id);
				list = roleService.selectAuthorityByRoleId(roleId,cookieSet);
				SysRole role = roleService.selectRoleById(roleId,cookieSet);
				resultModel.setName(role.getName());
			}
		}catch(Exception e){
			e.printStackTrace();
		}
		
		resultModel.setList(list);
		resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
		
		return (resultModel);
	}
	
	
	/**
	 * 
	 * @explain 添加角色接口
	 * @author LeeX
	 * @date 2017年6月8日 上午10:29:02
	 */
	@RequestMapping(value = "/create", method = RequestMethod.POST)
	@RequiresPermissions("login")
	public @ResponseBody Object create(HttpServletRequest request, HttpServletResponse response){
		//对象参数
		ResultModel resultModel = new ResultModel();
		RoleModel roleModel = new RoleModel();
		
		//token
		if (!MyCatFilter.getToken_Valid()){
			resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
		
		//获取请求参数
		Cookie[] cookies = request.getCookies();
		Map cookieMap = CookieUtil.getCookieSet(cookies);
		String uid = (String) cookieMap.get("uid");
		String tenant_id  = (String) cookieMap.get("tenant_id");
		
		//页面传的参数类型为:String    "id,id,id....."
		String rname = request.getParameter("newName");
		String strs = request.getParameter("auths");
		String description=request.getParameter("description");
		String operation=request.getParameter("operation");
		String[] authArr = strs.split(",");
		List<String> authList = new ArrayList<String>();
		for (String s : authArr) {
			authList.add(s);
		}
		if(authList.contains("1") || authList.contains("4") || authList.contains("6")){
			authList.add("63");
		}
		if(authList.contains("35") || authList.contains("42") || authList.contains("48") || authList.contains("57")){
			authList.add("62");
		}
		//封装到 roleModel中
		roleModel.setTenant_id(tenant_id);
		roleModel.setRname(rname);
		roleModel.setUid(uid);
		roleModel.setDescription(description);
		roleModel.setOperation(Integer.parseInt(operation));
		
		//传入service
		try {
			resultModel = roleService.create(roleModel,authList);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return (resultModel);
	}

	
	/**
	 * 
	 * @explain 更新接口
	 * @author LeeX
	 * @date 2017年6月8日 上午10:19:59
	 */
	@RequestMapping(value = "/update", method = RequestMethod.POST)
	@RequiresPermissions("login")
	public @ResponseBody Object update(HttpServletRequest request, HttpServletResponse response){
		//对象参数
		ResultModel resultModel = new ResultModel();
		RoleModel roleModel = new RoleModel();
		
		//token
		if (!MyCatFilter.getToken_Valid()){
			resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
		
		//cookie
		Cookie[] cookies = request.getCookies();
		Map cookieMap = CookieUtil.getCookieSet(cookies);
		String uid = (String) cookieMap.get("uid");
		String tenant_id  = (String) cookieMap.get("tenant_id");
		String access_token = (String) cookieMap.get("access_token");
		String rname = request.getParameter("newName");
		String strs = request.getParameter("auths");
		String description=request.getParameter("description");
		String operation=request.getParameter("operation");
		String[] authArr = strs.split(",");
		List<String> authList = new ArrayList<String>();
		for (String s : authArr) {
			authList.add(s);
		}
		if(authList.contains("1") || authList.contains("4") || authList.contains("6")){
			authList.add("63");
		}
		if(authList.contains("35") || authList.contains("42") || authList.contains("48") || authList.contains("57")){
			authList.add("62");
		}
		String roleId = request.getParameter("roleId");
		
		//封装到 roleModel中
		roleModel.setTenant_id(tenant_id);
		roleModel.setRname(rname);
		roleModel.setUid(uid);
		roleModel.setRole_id(roleId);
		roleModel.setDescription(description);
		roleModel.setOperation(Integer.parseInt(operation));
		
		//传入service
		try {
			resultModel = roleService.update(roleModel,authList);
		} catch (Exception e) {
			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			e.printStackTrace();
			return (resultModel);
		}
		
		return (resultModel);
	}
	
	
	/**
	 * 
	 * @explain 删除角色接口
	 * @author LeeX
	 * @date 2017年6月8日 上午10:29:32
	 */
	@RequestMapping(value = "/delete", method = RequestMethod.POST)
	@RequiresPermissions("login")
	public @ResponseBody Object delete(HttpServletRequest request, HttpServletResponse response){
		//对象参数
		ResultModel resultModel = new ResultModel();
		
		//token
		if (!MyCatFilter.getToken_Valid()){
			resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
		
		//cookie
		Cookie[] cookies = request.getCookies();
		Map map = CookieUtil.getCookieSet(cookies);
		
		//有账号的角色不允许删除，系统管理员不可删除
		String roleId = request.getParameter("roleId");
		if(StringUtils.isBlank(roleId)){
			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg("请刷新页面后尝试");
			return (resultModel);
		}
		
		Long role_id = Long.parseLong(roleId);
		map.put("role_id", role_id);
		
		try {
			resultModel = roleService.delete(map);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		return (resultModel);
	}
	
	
	/**
	 * 
	 * @explain 查询角色列表接口
	 * @author LeeX
	 * @date 2017年6月8日 上午10:29:53
	 */
	@RequestMapping(value = "/search_list", method = RequestMethod.POST)
	@RequiresPermissions("login")
	public @ResponseBody Object searchList(HttpServletRequest request, HttpServletResponse response){
		//对象参数
		ResultModel resultModel = new ResultModel();
		PageBean pageBean = new PageBean();
		
		//token
		if (!MyCatFilter.getToken_Valid()){
			resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
		
		//查询参数
		String pageNum = request.getParameter("pageNum");
		String currentPage = request.getParameter("currentPage");
		String keyword = request.getParameter("keyword");
		
		//cookie
		Map cookieSet = CookieUtil.getCookieSet(request.getCookies());
		
		String tenantId = (String)cookieSet.get("tenant_id");
		if(StringUtils.isBlank(pageNum)){
			pageNum = "10";
		}
		if(StringUtils.isBlank(currentPage)){
			currentPage = "1";
		}
		
		//封装对象
		pageBean.setPageNum(Long.parseLong(pageNum));
		pageBean.setCurrentPage(Long.parseLong(currentPage));
		pageBean.setKeyword(keyword);
		pageBean.setTenantId(tenantId);
		
		//传参到service
		try {
			pageBean = roleService.searchList(pageBean);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//处理结果
		resultModel.setObj(pageBean);
		resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
		
		return (resultModel);
	}
	
	/**
	 * 
	 * @explain 校验角色名称是否重复
	 * @author LeeX
	 * @date 2017年6月9日 上午10:31:27
	 */
	@RequestMapping(value = "/check", method = RequestMethod.POST)
	@RequiresPermissions("login")
	@ResponseBody
	public  Object check(HttpServletRequest request, HttpServletResponse response){
		//对象参数
		ResultModel resultModel = new ResultModel();
		
		//token
		if (!MyCatFilter.getToken_Valid()){
			resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return resultModel;
    	}
		
		//名字判断
		String newName = request.getParameter("newName");
		String id=request.getParameter("id");
		if(StringUtils.isBlank(newName)){
			resultModel.setError_code(ConfigStatusCode.NAME_OCCUPATION);
			resultModel.setError_msg("角色名不能为空");
			return resultModel;
		}
		
		//验证
		Pattern chinaP = Pattern.compile("[\\p{P}&&]+");  
	    Matcher chinaM = chinaP.matcher(newName);  
		boolean chinaKey = chinaM.matches();
		if(chinaKey){
				resultModel.setError_code(ConfigStatusCode.NAME_OCCUPATION);
				resultModel.setError_msg("角色名不能全是符号");
				return resultModel;
		}
		
		String[] fhArr = new String[]{"!","@","~","#","$","%","^","&","*","(",")","_","+","-","/","","{","}",":","<",">","?",".","！","￥","……"
										,"（","）","——","=","【","】","[","]","：","；",";","‘","’","“","”","《","》","，",",","。","？","|","\\","、"};
		for (String str : fhArr) {
			newName = newName.replace(str, "");
		}
		
		if(newName.trim().length() == 0){
			resultModel.setError_code(ConfigStatusCode.NAME_OCCUPATION);
			resultModel.setError_msg("角色名不能全是符号");
			return resultModel;
		}
		
		//cookie
		Map cookieSet = CookieUtil.getCookieSet(request.getCookies());
		int i = 1;
		
		try {
			i = roleService.checkNewName(id,newName,cookieSet);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		if(i == 0){
			resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			return resultModel;
		}else{
			resultModel.setError_code(ConfigStatusCode.NAME_OCCUPATION);
			resultModel.setError_msg("已有此角色名称："+newName);
			return resultModel;
		}
	}
	
	/**
	 * 用来手动添加权限
	 * @author LeeX
	 * @time 2017年8月5日 下午4:24:05
	 * @params  addAuth
	 * @return  void
	 */
/*	@RequestMapping(value = "/addAuth")
	@RequiresPermissions("login")
	public void addAuth(HttpServletRequest request, HttpServletResponse response){
		//所有没有被删除的角色
		List<SysRole> roles = mapper.selectAllUsedRole();
		//每个角色所对应的权限id
		for (SysRole role : roles) {
			Map<String,Object> map = new HashMap<String, Object>();
			map.put("rid", role.getId());
			map.put("tid", role.getTenantId());
			//根据tid和rid查询该角色所有权限,只返回authid
			List<Long> roleAuthids = mapper.selectOneRoleAuths(map);
			boolean flag = false;
			
			for (Long authid : roleAuthids) {
				String aid = String.valueOf(authid);
				if("1".equals(aid)){
					flag = true;
				}
				if("4".equals(aid)){
					flag = true;				
				}
				if("6".equals(aid)){
					flag = true;
				}
				
				if(flag){
					break;
				}
			}
			if(flag){
				SysRoleAuthority sra = new SysRoleAuthority();
				sra.setAuthorityId(63l);
				sra.setAuthorityName("客户总按钮");
				sra.setAuthorityNameEn("bc_button");
				sra.setTenantId(role.getTenantId());
				sra.setRemarks(" ");
				sra.setCreateId(role.getCreateId());
				sra.setRoleId(role.getId());
				sysRoleAuthorityMapper.insertSelective(sra);
			}
			
			
			for (Long authid : roleAuthids) {
				String aid = String.valueOf(authid);
				if("35".equals(aid)){
					flag = true;
				}
				if("42".equals(aid)){
					flag = true;				
				}
				if("48".equals(aid)){
					flag = true;
				}
				if("57".equals(aid)){
					flag = true;
				}
				if(flag){
					break;
				}
			}
			
			if(flag){
				SysRoleAuthority sra = new SysRoleAuthority();
				sra.setAuthorityId(62l);
				sra.setAuthorityName("营销总按钮");
				sra.setAuthorityNameEn("bm_button");
				sra.setTenantId(role.getTenantId());
				sra.setRemarks(" ");
				sra.setCreateId(role.getCreateId());
				sra.setRoleId(role.getId());
				sysRoleAuthorityMapper.insertSelective(sra);
			}
			
		}
	}*/
	
	/**
	 * 
	* Title: AuthorityGroupList
	* Description:获取权限分组列表
	* @return
	 */
	@RequestMapping(value = "/authorityGroupList")
	@ResponseBody
	public Object AuthorityGroupList(){
		
		return (roleService.AuthorityGroupList());
		
	}
	
	@RequestMapping(value = "/roleDetail")
	@ResponseBody
	public Object RoleDetail(String id,String tenant_id){
		
		return (roleService.RoleDetail(id,tenant_id));
	}
	
	
	@RequestMapping(value = "/roleList")
	@RequiresPermissions("login")
	@ResponseBody
	public Object RoleList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		String tenant_id= jsonObj.get("tenant_id").getAsString();

		return (roleService.RoleList(
				startIndex, pageSize, draw, tenant_id));
	}
	
	@RequestMapping(value = "/roleListCreate")
	@ResponseBody
	public Object RoleListCreate(int startIndex,int pageSize,String tenant_id) {

		return (roleService.RoleListCreate(
				startIndex, pageSize,  tenant_id));
	}
	
}
