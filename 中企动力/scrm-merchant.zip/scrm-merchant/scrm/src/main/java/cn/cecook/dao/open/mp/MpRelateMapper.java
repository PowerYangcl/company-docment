package cn.cecook.dao.open.mp;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpRelate;

public interface MpRelateMapper {

	public MpRelate selectMpRelateByOpenid(@Param(value = "tenant_id") String tenantId, @Param(value = "openid") String openid);
	public MpRelate selectMpRelateByPhone(@Param(value = "tenant_id") String tenantId, @Param(value = "phone") String phone);
	public int getCountByOpenid(@Param(value = "tenant_id") String tenantId, @Param(value = "openid") String openid);
	public void update(@Param(value = "tenant_id") String tenantId, @Param(value = "mpRelate") MpRelate mpRelate);
	public void insert(@Param(value = "tenant_id") String tenantId, @Param(value = "mpRelate") MpRelate mpRelate);
	public void deleteByPhone(@Param(value = "tenant_id") String tenantId, @Param(value = "phone") String phone);
	public void deleteByOpenid(@Param(value = "tenant_id") String tenantId, @Param(value = "openid") String openid);
}
