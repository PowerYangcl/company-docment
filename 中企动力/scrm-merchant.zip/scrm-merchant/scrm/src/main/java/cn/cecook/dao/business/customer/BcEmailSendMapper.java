package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcEmailSend;
import cn.cecook.model.business.customer.BcEmailSendExample;

/**
 * 
* @explain 邮件发送记录表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcEmailSendMapper {
    int countByExample(BcEmailSendExample example);

    int deleteByExample(BcEmailSendExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcEmailSend record);

    int insertSelective(BcEmailSend record);

    List<BcEmailSend> selectByExample(BcEmailSendExample example);

    BcEmailSend selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcEmailSend record, @Param("example") BcEmailSendExample example);

    int updateByExample(@Param("record") BcEmailSend record, @Param("example") BcEmailSendExample example);

    int updateByPrimaryKeySelective(BcEmailSend record);

    int updateByPrimaryKey(BcEmailSend record);
}