package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import cn.cecook.model.system.SmsMsgLog;
import cn.cecook.uitls.Pages;

public interface SmsMsgLogMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(SmsMsgLog record);

    int insertSelective(SmsMsgLog record);

    SmsMsgLog selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SmsMsgLog record);

    int updateByPrimaryKey(SmsMsgLog record);
    
    /**
     * 短信详情分页显示
     * @param pages
     * @return
     */
    List<Map<String,Object>> smsPage(Pages<Map<String,Object>> pages);
    int smsCount(Map<String,Object> map);
    
    /**
     * 发送短信，所有负值的总和
     * @param map
     * @return	绝对值
     */
    int getSendCount(Map<String,Object> map);
    
    /**
     * 短信详情表的发送的成功与失败数
     * @param map
     * @return
     */
    Map<String,Object> smsDetailCount(Map<String,Object> map);
    List<Map<String,Object>> smsDetail(Map<String,Object> map);
}