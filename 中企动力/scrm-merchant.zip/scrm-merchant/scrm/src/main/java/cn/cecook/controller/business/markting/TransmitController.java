package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import cn.cecook.uitls.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.markting.BmCardTransmit;
import cn.cecook.model.business.markting.BmTransmit;
import cn.cecook.service.business.markting.TransmitService;

@Controller
@RequestMapping("/api/transmit")
public class TransmitController {

	@Autowired
	private TransmitService transmitService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		BmTransmit bmTransmit = new BmTransmit();
		String transmit_way = request.getParameter("transmit_way");
		String activity_id = request.getParameter("activity_id");
		String activity_type = request.getParameter("activity_type");
		String transmit_tag = request.getParameter("transmit_tag");
		String customer_id = request.getParameter("customer_id");
		String ip = request.getParameter("ip");
		String card_id=request.getParameter("card_id");
		String open_id=request.getParameter("open_id");
		
		String province = request.getParameter("province");
		String city=request.getParameter("city");
		String district=request.getParameter("district");
		
		if (!StringUtils.isEmpty(card_id))
			bmTransmit.setCard_id(Integer.parseInt(card_id));
		if (!StringUtils.isEmpty(open_id) && !open_id.equals("undefined"))
			bmTransmit.setOpen_id(open_id);
		if (!StringUtils.isEmpty(activity_id))
			bmTransmit.setActivityId(Long.parseLong(activity_id));
		if (!StringUtils.isEmpty(activity_type))
			bmTransmit.setActivityType(Integer.parseInt(activity_type));
		bmTransmit.setTransmit_tag(transmit_tag);
		bmTransmit.setTransmitWay(transmit_way);
		bmTransmit.setBak1(customer_id);
		bmTransmit.setBak2(ip);
		bmTransmit.setProvince(province);
		bmTransmit.setCity(city);
		bmTransmit.setDistrict(district);
		return (transmitService.create(bmTransmit));
	}

	@RequestMapping(value = "/card")
	@ResponseBody
	public Object cardTransmit(HttpServletRequest request,
			HttpServletResponse response) {
		BmCardTransmit bmCardTransmit = new BmCardTransmit();
		String transmit_way = request.getParameter("transmit_way");
		String card_id = request.getParameter("card_id");
		String transmit_tag = request.getParameter("transmit_tag");
		String ip = request.getParameter("ip");
		String open_id = request.getParameter("open_id");
		String province = request.getParameter("province");
		String city=request.getParameter("city");
		String district=request.getParameter("district");
		if (!StringUtils.isEmpty(card_id))
			bmCardTransmit.setCardId(Long.parseLong(card_id));
		if (!StringUtils.isEmpty(transmit_tag))
			bmCardTransmit.setTransmitTag(Integer.parseInt(transmit_tag));
		bmCardTransmit.setTransmitWay(transmit_way);
		bmCardTransmit.setIp(ip);
		bmCardTransmit.setProvince(province);
		bmCardTransmit.setCity(city);
		bmCardTransmit.setDistrict(district);
		if (!StringUtils.isEmpty(open_id) && !open_id.equals("undefined"))
			bmCardTransmit.setOpen_id(open_id);
		return (transmitService.cardTransmit(bmCardTransmit));
	}

}
