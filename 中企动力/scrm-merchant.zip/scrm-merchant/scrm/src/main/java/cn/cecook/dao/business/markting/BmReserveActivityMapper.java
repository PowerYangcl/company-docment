package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmReserveActivity;

public interface BmReserveActivityMapper {

    int deleteByPrimaryKey(Long id);


    int insertSelective(BmReserveActivity record);

    BmReserveActivity selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BmReserveActivity record);
    
    int isJoin(Map<String, Object> map);

    List<Map<String,Object>> getReserveMemberInfo(Map<String, Object> map);

    Map<String,Object> getReserveInfo(Map<String, Object> map);

}