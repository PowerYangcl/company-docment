package cn.cecook.dao.business.markting;

import java.util.List;

import cn.cecook.bean.business.markting.HotModelBean;
import cn.cecook.model.business.markting.BmHotActivity;

public interface BmHotActivityMapper {

	int insertSelective(BmHotActivity record);

	int updateByPrimaryKeySelective(BmHotActivity record);

	List<HotModelBean> queryList();
	
	int deleteHotActivity(long id);

}