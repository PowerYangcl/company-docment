package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.service.business.markting.CouponService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.ErrorCodeConfigUtil;

@Controller
@RequestMapping("/api/coupon")
public class CouponController {

	@Autowired
	private CouponService couponService;

	@RequestMapping(value = "/listByCid")
	@ResponseBody
	public Object getCouponListByCustomerId(String id) {
		return couponService.getCouponListByCustomerId(id);
	}

	@RequestMapping(value = "/queryDetailByCode")
	@ResponseBody
	public Object queryCouponDetailV2(String coupon_code) {
		return couponService.getCouponDetailByCode(coupon_code);
	}

	/**
	 * 
	 * Title: getValidCouponListByCustomerId Description:获取有效的优惠券
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/validListByCid")
	@ResponseBody
	public Object getValidCouponListByCustomerId(String cid) {
		return couponService.getValidCouponListByCustomerId(cid);
	}

	/**
	 * 
	 * Title: getUnValidCouponListByCustomerId Description:获取过期的优惠券
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/unValidListByCid")
	@ResponseBody
	public Object getUnValidCouponListByCustomerId(String cid) {
		return couponService.getUnValidCouponListByCustomerId(cid);
	}

	/**
	 * 
	 * Title: getUsedCouponListByCustomerId Description:获取已使用的优惠券
	 * 
	 * @param cid
	 * @param startIndex
	 * @param pageSize
	 * @return
	 */
	@RequestMapping(value = "/usedListByCid")
	@ResponseBody
	public Object getUsedCouponListByCustomerId(String cid) {
		return couponService.getUsedCouponListByCustomerId(cid);
	}
	
	
	@RequestMapping(value = "/generateCodeInsertDatabase")
	@ResponseBody
	public Object generateCodeInsertDatabase() {
		return couponService.generateCodeInsertDatabase();
	}
	
	@RequestMapping(value = "/getCouponCodeInsertRedis")
	@ResponseBody
	public Object getCouponCodeInsertRedis() {
		return couponService.getCouponCodeInsertRedis();
	}

}
