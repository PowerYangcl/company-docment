package cn.cecook.controller.business.customer;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.customer.BcClueWeibo;
import cn.cecook.model.business.customer.BcCustomerAction;
import cn.cecook.service.business.customer.IClueActivityService;
import cn.cecook.service.business.customer.IClueWeiboService;
import cn.cecook.service.business.markting.WriteOffService;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.Pages;

/**
 *  客户线索
 * @author zhaoxin
 *
 */
@Controller
@RequestMapping("/api/clue_customer")
public class ClueController {
    
    @Autowired
    private IClueWeiboService clueWeiboService;
    @Autowired
    private IClueActivityService clueActivityService;
    @Autowired
    private WriteOffService writeOffService;
    
    @RequiresPermissions("login")
    @RequestMapping("/customerHome")
    public String customerHome(){
        return "bc/customer";
    }
    
    /**
     * clue.jsp--页面
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/clueView")
    public String clueView(){
        return "bc/clue";
    }
    
    /**
     * 全部线索--页面
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/allClueView")
    public String allClueView(){
        return "bc/allClue";
    }
    
    /**
     * 全部线索
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/allClue")
    public String allClue(){
        return "bc/allClue";
    }
    
    
    /**
     * 微博线索统计分类接口--页面
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/clue_weiboView")
    public String weiboClueView(HttpServletRequest request, Map<String,Object> map){
        return "bc/clueWeibo";
    }
    /**
     * 微博线索统计分类接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping(value="/clue_weibo",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String weiboClue(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        
        String tenantId = request.getParameter("tenantid");
        String uid = request.getParameter("uid");
        if(tenantId == null){
            Cookie[] cookies = request.getCookies();
            Map cookie = CookieUtil.getCookieSet(cookies);
            tenantId = (String)cookie.get("tenantid");
            uid = (String)cookie.get("uid");
        }
        
        int startIndex = 0;
        if(request.getParameter("startIndex") != null)
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        int pageSize = 10;
        if(request.getParameter("pageSize") != null)
            pageSize = Integer.valueOf(request.getParameter("pageSize"));
        String keyWord = request.getParameter("keyWord");
        String orderby = null;
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("keyWord", keyWord);
        where.put("orderby", "create_time desc");
        
        List<String> keywords = clueWeiboService.getKeyWordByUserId();
        List<Map<String, Integer>> keyWordCount = clueWeiboService.getKeyWordCount();
        Pages<BcClueWeibo> page = clueWeiboService.getPage(new Pages<BcClueWeibo>(startIndex, pageSize, where, orderby));
        
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        jsonObject.add("key_word_list", jsonParser.parse(gson.toJson(keywords)));
        jsonObject.add("weibo_keyword_count", jsonParser.parse(gson.toJson(keyWordCount)));
        jsonObject.add("weibo_clue_list", jsonParser.parse(gson.toJson(page.getItems())));
        jsonObject.addProperty("totalCount", page.getTotalCount());
        
        return jsonObject.toString();
    }
    
    
    /**
     * 活动线索统计分类接口--页面
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/clue_activityView")
    public String clueActivityView(){
        return "bc/clueActivity";
    }
    
    /**
     * 活动线索统计分类接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping(value="/clue_activity",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String clueActivity(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        
        int startIndex = 0;
        if(request.getParameter("startIndex") != null)
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        int pageSize = 10;
        if(request.getParameter("pageSize") != null)
            pageSize = Integer.valueOf(request.getParameter("pageSize"));
        String keyWord = request.getParameter("keyWord");
        String orderby = null;
        Map<String, Object> where = new HashMap<String, Object>();
        //where.put("type", 1);   //活动是否分为 普通活动和 智能营销活动
        List<Map<String, Object>> activityList = clueActivityService.getActivity(where);
        String activityIds = "";
        if(activityList != null && !activityList.isEmpty()) {
        	for (Map<String, Object> map : activityList) {
        		activityIds += ","+map.get("id");
			}
        }
        if(!activityIds.equals("")) {
        	activityIds = activityIds.substring(1);
        }
        
        where.clear();
        where.put("keyWord", keyWord);
        where.put("activityIds", activityIds);
        //where.put("type", 1);   //1：活动线索；2：智能营销线索；
        where.put("orderby", "create_time desc");
        Pages<BcCustomerAction> page = clueActivityService.getPage(new Pages<BcCustomerAction>(startIndex, pageSize, where, orderby));
        
        where.clear();
        //where.put("type", 1);   //活动是否分为 普通活动和 智能营销活动
        List<Map<String, Object>> activityCount = clueActivityService.getActivityCount(where);
        
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        jsonObject.add("activity_name_list", jsonParser.parse(gson.toJson(activityList)));
        jsonObject.add("weibo_activity_count", jsonParser.parse(gson.toJson(activityCount)));
        jsonObject.add("activity_clue_list", jsonParser.parse(gson.toJson(page.getItems())));
        jsonObject.addProperty("totalCount", page.getTotalCount());
        
        return jsonObject.toString();
    }
    
    /**
     * 智能营销线索统计分类接口--页面
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/clue_smart_activityView")
    public String clueSmartActivityView(){
        return "bc/clueSmartActivity";
    }
    
    
    /**
     * 智能营销线索统计分类接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping(value="/clue_smart_activity",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String clueSmartActivity(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        
        int startIndex = 0;
        if(request.getParameter("startIndex") != null)
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        int pageSize = 10;
        if(request.getParameter("pageSize") != null)
            pageSize = Integer.valueOf(request.getParameter("pageSize"));
        String keyWord = request.getParameter("keyWord");
        String handleStatus = request.getParameter("handleStatus");
        String listIndex = request.getParameter("listIndex");
        String orderby = null;
        String activityId = request.getParameter("activityId");
        String activityIds = request.getParameter("activityIds");
        Map<String, Object> where = new HashMap<String, Object>();
        
        if(listIndex != null && (listIndex.equals("0")||listIndex.equals("1"))){
            //where.put("keyWord", keyWord);
        	where.put("activityId", activityId);
        	where.put("activityIds", activityIds);
            where.put("type", 2);   //1：活动线索；2：智能营销线索；
            where.put("orderby", "create_time desc");
            if(handleStatus != null && !handleStatus.equals("")){
                where.put("handleStatus", handleStatus);
            }
            
            Pages<BcCustomerAction> page = clueActivityService.getPage(new Pages<BcCustomerAction>(startIndex, pageSize, where, orderby));
            jsonObject.add("activity_clue_list", jsonParser.parse(gson.toJson(page.getItems())));
            jsonObject.addProperty("totalCount", page.getTotalCount());
        }else if(listIndex != null && listIndex.equals("2")){
        	where.put("activityId", activityId);
        	where.put("activityIds", activityIds);
        	where.put("type", 2);   //1：活动线索；2：智能营销线索；
        	where.put("orderby", "create_time desc");
        	Pages<Map<String, Object>> page = clueActivityService.getPage2(new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby));
            jsonObject.add("activity_clue_list", jsonParser.parse(gson.toJson(page.getItems())));
            jsonObject.addProperty("totalCount", page.getTotalCount());
        }else if(listIndex != null && listIndex.equals("3")){
            Cookie[] cookies = request.getCookies();
            Map map = CookieUtil.getCookieSet(cookies);
            String tenantId = (String)map.get("tenant_id");
            String uid = (String)map.get("uid");
            
            BaseResultModel activityWriteOffList = writeOffService.getActivityWriteOffList(tenantId, uid, activityId,activityIds,startIndex+"", pageSize+"","1");
            
            jsonObject.add("activity_clue_list", jsonParser.parse(gson.toJson(activityWriteOffList.getData())));
            jsonObject.addProperty("totalCount", activityWriteOffList.getTotalCount());
        }
        
        where.clear();
        //where.put("type", 1);   //活动是否分为 普通活动和 智能营销活动
        List<Map<String, Object>> activityList = clueActivityService.getActivity(where);
        
        jsonObject.add("activity_name_list", jsonParser.parse(gson.toJson(activityList)));
        
        return jsonObject.toString();
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/delClueWeibo",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String delClueWeibo(int clueWeiboId){
        JsonObject jsonObject = new JsonObject();
        try{
            clueWeiboService.delClueWeibo(clueWeiboId);
            
            jsonObject.addProperty("msg", "删除成功");
        }catch (Exception e) {
            jsonObject.addProperty("msg", "删除失败");
        }
        return jsonObject.toString();
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/delClueActivity",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String delClueActivity(int clueActivityId){
        JsonObject jsonObject = new JsonObject();
        try{
            clueActivityService.delClueActivity(clueActivityId);
            
            jsonObject.addProperty("msg", "删除成功");
        }catch (Exception e) {
            jsonObject.addProperty("msg", "删除失败");
        }
        
        return jsonObject.toString();
    }
}