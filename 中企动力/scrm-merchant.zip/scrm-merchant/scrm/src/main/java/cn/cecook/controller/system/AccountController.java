package cn.cecook.controller.system;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.model.business.markting.BmCompanyCard;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.system.IAccountService;
import cn.cecook.service.system.IRegisterService;
import cn.cecook.uitls.AjaxJson;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Pages;
import cn.cecook.uitls.PhoneUtil;
import cn.cecook.uitls.StringUtils;

/**
 * 账号管理
 * @explain 
 * @author sunny
 * @date 2017年6月8日
 */
@Controller
@RequestMapping("/api/account") 
public class AccountController {
	
	 //日志输出
	 private Logger logger = Logger.getLogger(AccountController.class);
    /**
     * 添加账号
     * @explain 
     * @author sunny
     * @date 2017年6月8日
     */
    @Resource
    IAccountService accountService;
    @Resource
    IRegisterService registerService;
    
    

    @ResponseBody
    @RequestMapping(value = "/add", method = RequestMethod.POST)
    public Object add(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //System.out.println("---------->");
        //返回的 ResultModel
        ResultModel resultModel = new ResultModel();
        //获取当前登录用户的id
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ 
                //获取键 
                tenant_id=cook.getValue().toString(); 
            }
         } 
        //判断是否注册的model对象
        AccountModel accountModel1=new AccountModel();
        //传输对象的model
        AccountModel accountModel=new AccountModel();
        //System.out.println(name);
        //用户账号，即从前台获取的手机号码
        String account=request.getParameter("account");
        if (PhoneUtil.isMobile(account)) {
            accountModel1.setAccount(account);
            //判断手机号码是否已经注册过
            if(registerService.isReg(accountModel1).getError_code().equals("1")){
                accountModel.setAccount(account);
            }else{            
                // 号码已被注册
                logger.debug("手机号已存在");
                resultModel.setError_code("0");
                resultModel.setError_msg("手机号已存在");
                return resultModel;                
            }
        } else {
            // 格式不正确
            resultModel.setError_code("0");
            resultModel.setError_msg("手机号格式不正确");
            //System.out.println("手机号格式不正确");
            return resultModel; 
        } 
        //姓名不是必填项 
        String name=request.getParameter("name"); 
//        if (!"".equals(name) && name != null) { 
            accountModel.setName(name);
//        }else{
//            resultModel.setError_code("0");
//            resultModel.setError_msg("姓名不能为空");
//            //System.out.println("手机号格式不正确");
//            return (resultModel);
//        }
        //邮件
        String email=request.getParameter("email");
        //员工编号
        String userNo=request.getParameter("userNo");
        //职位
        String job=request.getParameter("job");
        //部门
        String departmentId=request.getParameter("department");
        //角色ID
        String roleId=request.getParameter("roleId");
        //数据权限
        String dataAuthTag=request.getParameter("dataAuthTag");
        
        if (!"".equals(roleId) &&roleId != null) { 
            roleId=roleId.substring(0, roleId.length()-1); 
            String [] roleIdArr = roleId.split(",");
            List<String> roleIdList = new ArrayList<String>(Arrays.asList(roleIdArr));
            accountModel.setRoleIdList(roleIdList);
        }else{
            resultModel.setError_code("0");
            resultModel.setError_msg("角色不能为空");
            return resultModel;           
        }
        
        //门店Id
        String storeId=request.getParameter("storeId");
        if (!"".equals(storeId) &&storeId != null) { 
        	storeId=storeId.substring(0, storeId.length()-1); 
            String [] storeIdArr = storeId.split(",");
            List<String> storeList = new ArrayList<String>(Arrays.asList(storeIdArr));
            accountModel.setStoreIdList(storeList);
        }
//        else{
//            resultModel.setError_code("0");
//            resultModel.setError_msg("部门不能为空");
//            return (resultModel);
//        }
        
        //System.out.println(roleId);
        //System.out.println(roleName);      
        //判断邮箱格式是否正确
        //正则表达式
/*        String regex = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
        boolean flag = false;
        try{
        Pattern r = Pattern.compile(regex);
        Matcher matcher = r.matcher(email);
        flag = matcher.matches();
        }catch(Exception e){
            flag = false;
        }
        if(flag == false){
          resultModel.setError_code("0");
          resultModel.setError_msg("邮箱号格式不正确");
          return (resultModel);
        }*/
        if (!"".equals(tenant_id) && tenant_id != null) { 
            accountModel.setTenant_id(tenant_id);
        }

        if (!"".equals(email) && email != null) { 
            accountModel.setEmail(email);
            }
        if (!"".equals(userNo) && userNo != null) { 
            accountModel.setJobNumber(userNo);;
            }
        if (!"".equals(job) && job!= null) { 
            accountModel.setJob(job);
        }else{            
            resultModel.setError_code("0");
            resultModel.setError_msg("职位不能为空");
            return resultModel;                   
        } 
        if (!"".equals(departmentId) && departmentId!= null) { 
            accountModel.setDepartment_id( Long.parseLong(departmentId));
        }else{
            resultModel.setError_code("0");
            resultModel.setError_msg("部门不能为空");
            return resultModel;              
        } 
        //新增加账户的租户id与现登录者相同
        accountModel.setTenant_id(tenant_id);
        accountModel.setDataAuthTag(Integer.valueOf(dataAuthTag));
        //当前登录的用户的id
        //accountModel.setUid(u_id);       
        resultModel = accountService.add(accountModel);
        //System.out.println(GsonTools.createJsonString(resultModel));
        return resultModel;        
    }
    /**
     * 编辑账号
     * @explain 
     * @author sunny
     * @date 2017年6月8日
     */
    @RequestMapping(value = "/edit", method = RequestMethod.POST)
    @ResponseBody
    public Object edit(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //返回的数据模型ResultModel
        ResultModel resultModel=new  ResultModel(); 
        //传输对象的sysuser
        SysUser sysuser=new SysUser();
        //获取当前用户的id
        long id=Long.parseLong(request.getParameter("userid"));
        //姓名 
        String name=request.getParameter("name"); //System.out.println(name);  
        // 邮件
        String email=request.getParameter("email");
        // 职位
        String job=request.getParameter("job");
        // 部门ID
        String departmentId=request.getParameter("department");
        //员工编号
        String userNo= request.getParameter("userNo");
        //用户的数据权限
        String dataAuthTag2 = request.getParameter("dataAuthTag2");
        //角色ID
        String roleId;
        if (!"".equals(request.getParameter("roleId")) && request.getParameter("roleId") != null) {
            roleId = request.getParameter("roleId");
            //System.out.println(roleId);
            roleId=roleId.substring(0, roleId.length()-1); 
            String [] roleIdArr = roleId.split(",");
            List<String> roleIdList = new ArrayList<String>(Arrays.asList(roleIdArr));
            sysuser.setRoleID(roleIdList);
        }else{
            resultModel.setError_code("0");
            resultModel.setError_msg("角色不能为空");
            return resultModel;           
        }  
        
        //门店ID
        String storeId;
        if (!"".equals(request.getParameter("storeId")) && request.getParameter("storeId") != null) {
        	storeId = request.getParameter("storeId");
            //System.out.println(roleId);
        	storeId=storeId.substring(0, storeId.length()-1); 
            String [] storeArr = storeId.split(",");
            List<String> storeList = new ArrayList<String>(Arrays.asList(storeArr));
            sysuser.setStoreID(storeList);
        }
//        else{
//            resultModel.setError_code("0");
//            resultModel.setError_msg("门店不能为空");
//            return (resultModel);
//        }  
        //System.out.println(roleName);
        //System.out.println(satatus);
        //判断邮箱格式是否正确
        //正则表达式
/*        String regex = "^([a-z0-9A-Z]+[-|\\.]?)+[a-z0-9A-Z]@([a-z0-9A-Z]+(-[a-z0-9A-Z]+)?\\.)+[a-zA-Z]{2,}$";
        boolean flag = false;
        try{
        Pattern r = Pattern.compile(regex);
        Matcher matcher = r.matcher(email);
        flag = matcher.matches();
        }catch(Exception e){
            flag = false;
        }
        if(flag == false){
          resultModel.setError_code("0");
          resultModel.setError_msg("邮箱号格式不正确");
          return (resultModel);
        }*/
        if (id >0) { 
            sysuser.setId(id);
            }
        if (!"".equals(name) && name != null) { 
            sysuser.setName(name);
            }
        if (!"".equals(email) && email != null) { 
            sysuser.setEmail(email);
            }
        if (!"".equals(userNo) && userNo != null) { 
            sysuser.setJobNumber(userNo);;
            }
        
        if (!"".equals(job) && job!= null) { 
            sysuser.setJob(job);
        }else{            
            resultModel.setError_code("0");
            resultModel.setError_msg("职位不能为空");
            return resultModel;                   
        } 
        if (!"".equals(departmentId) && departmentId!= null) { 
            sysuser.setDepartmentId(Long.parseLong(departmentId)); 
        }else{
            resultModel.setError_code("0");
            resultModel.setError_msg("部门不能为空");
            return resultModel;              
        } 
        sysuser.setDataAuthority(Integer.valueOf(dataAuthTag2));
        //执行service      
        resultModel = accountService.edit(sysuser);
        return resultModel;  
        
    }
    /**
     * 删除账号
     * @explain 
     * @author sunny
     * @date 2017年6月8日
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public Object delete(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //账号启用后不能删除，如果需要删除账号需要先停用账号后，再直接删除。账号停用后，单击删除，列表中不在显示数据
        //0：未删除；1：删除
        //删除就是把is_deleted更改为1 
        //获取当前用户，用户id
        long id=Long.parseLong(request.getParameter("id"));
        //先判断用户状态
        SysUser sysuser=new SysUser();
        ResultModel resultModel=new ResultModel();
        sysuser.setId(id);        
        //System.out.println(sysuser.getId());
        //获取当前用户状态
        String status=request.getParameter("status");
        //System.out.println("删除----》"+status);
        if(status.equals("1")){
            sysuser.setIsDeleted(1);
            logger.debug("isde"+sysuser.getIsDeleted());
            //System.out.println("isde"+sysuser.getIsDeleted());
            resultModel = accountService.delete(sysuser);
            //组织架构-删除了员工后，名片列表页会报错，需删除员工时一并删除此员工名片
            accountService.deleteCompanyCard(id);
            return resultModel;  
        }else if(status.equals("0")){
            resultModel.setError_code("0");
            resultModel.setError_msg("请先停用账号再行删除");
            return resultModel;  
        }
        return resultModel;  
    }
    /**
     * 启用/停用账号
     * @explain 
     * @author sunny
     * @date 2017年6月8日
     */
    @RequestMapping(value = "/operate", method = RequestMethod.POST)
    @ResponseBody
    public Object operate(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //如果用户7天内未曾登录则账号进入停用状态
        //状态0：正常；1：失效
        //启动，就是把状态从1变为0,；失效就是从0变成1 
        //根据id查询出sysuser
        //从当前页面获取选中行的id
        SysUser sysuser=new SysUser();
        long id=Long.parseLong(request.getParameter("id"));
        sysuser.setId(id);
        //根据当前显示获取状态值
        String state=request.getParameter("state");
        //System.out.println(state);
        int status=0;        
        if(state.equals("启用")){
            status=0;
            logger.debug("启用");
        }else if(state.equals("停用")){
            status=1;
            logger.debug("停用");
        }
        sysuser.setStopTime(new Date()); //停用时间
        sysuser.setStatus(status);
        logger.debug("sysuser:"+sysuser);
        //System.out.println("sysuser:"+sysuser);
        ResultModel resultModel = accountService.operate(sysuser);
        return resultModel; 
    }
    /**
     * 账户列表（含查询）
     * @explain 
     * @author sunny
     * @date 2017年6月8日
     */
    @RequestMapping(value = "/list", method = RequestMethod.POST)
    @ResponseBody
    public String list(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //从缓存中获取当前用户的tenant_id，用作查询
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {	
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
         } 
        //long bak3=Long.parseLong(request.getParameter("startIndex"));
        JsonObject js = new JsonObject();
        int startIndex = 0;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 10;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        Map<String, Object> where = new HashMap<String, Object>();
        //orderby
        String orderby = "sid";
        where.put("tenant_id", tenant_id);
        //status 0：正常；1：失效
        String statusN=request.getParameter("status");
        if(statusN.equals("正常")){
            int status=0;
            where.put("astatus", status);
        }else if(statusN.equals("失效")){
            int status=1;
            where.put("astatus", status);
        }    
        if (!"全部".equals(request.getParameter("keyWord")) && request.getParameter("keyWord") != null) {
            where.put("keyWord", request.getParameter("keyWord"));
        }
        if (!"全部".equals(request.getParameter("role")) && request.getParameter("role") != null) {
            where.put("roles", request.getParameter("role"));
        }
        //where.put("isDeleted", isDeleted);
        if (!"全部".equals(request.getParameter("department")) && request.getParameter("department") != null) {
            where.put("departmentName", request.getParameter("department"));
        }        
        logger.debug("where--->"+where);
        //System.out.println("where--->"+where);
        Pages<Map<String, Object>> page = accountService
                        .list(new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby));
        //System.out.println(page);
        Gson gs = new Gson();
        JsonParser jsonParser = new JsonParser();
        js.add("sysuserList", jsonParser.parse(gs.toJson(page.getItems())));
        js.addProperty("totalCount", page.getTotalCount());
        js.addProperty("startIndex", startIndex);
        //System.out.println(js.toString());
        return js.toString();
    }
    /**
     * 用户资料详情接口
     * @explain 
     * @author sunny
     * @date 2017年6月12日
     */
    @RequestMapping(value="/sysuserDetail",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public String customerDetail(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ 
                tenant_id=cook.getValue().toString();    
            }
         } 
        JsonObject j = new JsonObject();
        Gson g = new Gson();
        String id = request.getParameter("id");
        if (StringUtils.isNotEmpty(id)) {
            Map<String, Object> map = accountService.sysuserDetail( Long.parseLong(id));
            JsonParser jsonParser = new JsonParser();
            logger.debug(map);
            //System.out.println(map);
            j.add("userInfo", jsonParser.parse(g.toJson(map)));
            j.add("roleInfo", jsonParser.parse(g.toJson(accountService.getRoles(tenant_id))));
        } else {
            // 如果ID为空 返回错误信息
        }
        logger.debug(j);
        return j.toString();
    }
    /**
     * 用户角色获取
     * @explain 
     * @author sunny
     * @date 2017年6月13日
     */
    @RequestMapping(value="/getRoles",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public AjaxJson getRoles(HttpServletRequest request, HttpServletResponse response) throws Exception {        
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ 
                tenant_id=cook.getValue().toString();    
            }
         } 
        AjaxJson j = new AjaxJson();
        Gson g = new Gson();
        j.setObj(g.toJson(accountService.getRoles(tenant_id)));
        return j;
    }
    /**
     * 用户部门获取
     * @explain 
     * @author sunny
     * @date 2017年6月13日
     */
    @RequestMapping(value="/getDepartments",produces = "application/json;charset=UTF-8")
    @ResponseBody
    public AjaxJson getDepartments(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
         } 
        AjaxJson j = new AjaxJson();
        Gson g = new Gson();
        j.setObj(g.toJson(accountService.getDepartments(tenant_id)));
        return j;
    }
    
    
	/**
	 * 根据用户id获取该用户对应的所有门店 
	 * @return
	 */
	@RequestMapping(value = "/getStores",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object getStores(String id) {
		return accountService.getStores(id);

	}

	/**
	 * 根据用户id获取该用户是否有开通的对接服务
	 * @return
	 */
	@RequestMapping(value = "/getProductService",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object getProductService(String uid,String tenant_id) {
		return accountService.getProductService(uid,tenant_id);

	}
	
	/**
	 * 同步CRM接口，并将同步信息维护到本地库
	 * @return
	 */
	@RequestMapping(value = "/synWithCrm",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object synWithCrm(String account,String storeId,String crmState,String crmRole,String uid,String access_token,String tenant_id,String productId,Integer sqNum) {
		return accountService.synWithCrm(account,storeId,crmState,crmRole,uid,access_token,tenant_id,productId,sqNum);

	}
	/**
	 * 根据门店id获取门店下所有用户id 
	 * @return
	 */
	@RequestMapping(value="/getUsers" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getUsers(String id) {
		return FastJsonUtil.createJsonString(accountService.getUsers(id));

	}
	/**
	 * 根据门店id获取门店下所有用户的信息
	 * @param uid
	 * @param tenant_id
	 * @param storeId
	 * @return
	 * majie
	 */
	@RequestMapping(value="/getUsersByStoreId",method = RequestMethod.POST)
	@ResponseBody
	public Object getUsersByStoreId(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String storeId){
		return accountService.getUsersByStoreId(tenant_id,storeId);		
	}
	/**
	 * 根据用户id获取用户信息
	 * @return
	 */
	@RequestMapping(value="/getUserInfo" ,method = RequestMethod.POST,produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getUserInfo(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String id) {
		return FastJsonUtil.createJsonString(accountService.getUserInfo(id));

	}
	/**
	 * 根据用户id获取部门信息
	 * @param id
	 * @return
	 * majie
	 */
	@RequestMapping(value="/getUserDepartment" ,method = RequestMethod.POST)
	@ResponseBody
 	public Object getUserDepartment(@RequestParam(value = "uid",required = false)String uid,
		@RequestParam(value = "tenant_id",required = false)String tenant_id) {	
		return accountService.getUserDepartment(uid, tenant_id);
	}
	
	/**
	 * 数据入库
	 */
	@RequestMapping(value="/setUser" ,method = RequestMethod.GET,produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object setUser(HttpServletRequest request, HttpServletResponse response) {
        //获取当前登录用户的id

        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID

        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ 
                //获取键 

                tenant_id=cook.getValue().toString(); 
            }
         } 
        String storeId = request.getParameter("storeId"); //部门ID

        String districtName = "北京市东城区";
        String productId = request.getParameter("productId"); //产品ID

        String djRoleId = request.getParameter("djRoleId"); //对接系统角色ID
        
        String userDate = request.getParameter("userDate");//用户入库的日期

        String imporTtag =  request.getParameter("userDate"); //用户入库的标识0员工表、员工门店表、CRM同步表 ， 1员工角色中间表
        
		return accountService.setUser(tenant_id,storeId,districtName,productId,djRoleId,userDate,imporTtag);
	}
	
	/**
	* 根据姓名电话查询用户列表
	* @param:
	* @return:
	*/
    @RequestMapping(value = "/getUserAllByNameOrPhone")
    @ResponseBody
	public Object getUserAllByNameOrPhone(String key_word, String startIndex, String page_size,String tenant_id){
	    return accountService.getUserAllByNameOrPhone(key_word, startIndex, page_size, tenant_id);
    }

    /**
    * 根据用户userId查询用户姓名
    * @param:
    * @return:
    */
    @RequestMapping(value = "/getUserNameByUserId")
    @ResponseBody
    public Object getUserNameByUserId(String userId){
        return accountService.getUserNameByUserId(Long.parseLong(userId));
    }
    @RequestMapping(value = "/loadUserAll")
    @ResponseBody
    public Object loadUserAll(String startIndex, String page_size, String tenant_id){
        return accountService.loadUserAll(startIndex,page_size,tenant_id);
    }
}
