package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

/**
 * 
* @Title JoinActivityCustomerBean.java 
* @Description 参与活动的用户bean
* @author wschenyongyin
* @date 2017年6月8日
* @version 1.0
 */

@Component
public class JoinActivityCustomerBean {
	
	private String avatar;
	private String customer_id;
	private String customer_name;
	private String phone;
	private String email;
	private String weibo;
	private String wechat;
	private String receive_way;
	
	public String getAvatar() {
		return avatar;
	}
	public void setAvatar(String avatar) {
		this.avatar = avatar;
	}
	public String getCustomer_id() {
		return customer_id;
	}
	public void setCustomer_id(String customer_id) {
		this.customer_id = customer_id;
	}
	public String getCustomer_name() {
		return customer_name;
	}
	public void setCustomer_name(String customer_name) {
		this.customer_name = customer_name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWeibo() {
		return weibo;
	}
	public void setWeibo(String weibo) {
		this.weibo = weibo;
	}
	public String getWechat() {
		return wechat;
	}
	public void setWechat(String wechat) {
		this.wechat = wechat;
	}
	public String getReceive_way() {
		return receive_way;
	}
	public void setReceive_way(String receive_way) {
		this.receive_way = receive_way;
	}
	
	
	

}
