package cn.cecook.model.business.automation;

import java.util.Date;

/**
 * 自动化营销任务条件
 * @author majie
 *
 * 2018年1月22日-下午5:09:38
 */
public class AutomationTaskRule {
	//自增id
    private Integer id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Integer createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;
    //会员分组条件 json串
    private String exRuleGroupInfo;
    //会员基本信息 json串
    private String exRuleCustomerInfo;
    //行为选人 (核销、未核销、转化)
    private String exRuleActionInfo;
    //rfm选人
    private String exRuleRfmInfo;
    //触发条件选人
    private String exRuleTrigger;
    //触发条件信息
    private String exRuleTriggerInfo;
    //医药行业条件
    private String exRuleMedicineInfo;
    //节点Id
    private Integer pointId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Integer getCreateId() {
		return createId;
	}
	public void setCreateId(Integer createId) {
		this.createId = createId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public Date getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getBak1() {
		return bak1;
	}
	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}
	public String getBak2() {
		return bak2;
	}
	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}
	public String getBak3() {
		return bak3;
	}
	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}
	public String getBak4() {
		return bak4;
	}
	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}
	public String getBak5() {
		return bak5;
	}
	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}
	public String getExRuleGroupInfo() {
		return exRuleGroupInfo;
	}
	public void setExRuleGroupInfo(String exRuleGroupInfo) {
		this.exRuleGroupInfo = exRuleGroupInfo;
	}
	public String getExRuleCustomerInfo() {
		return exRuleCustomerInfo;
	}
	public void setExRuleCustomerInfo(String exRuleCustomerInfo) {
		this.exRuleCustomerInfo = exRuleCustomerInfo;
	}
	public String getExRuleActionInfo() {
		return exRuleActionInfo;
	}
	public void setExRuleActionInfo(String exRuleActionInfo) {
		this.exRuleActionInfo = exRuleActionInfo;
	}
	public String getExRuleRfmInfo() {
		return exRuleRfmInfo;
	}
	public void setExRuleRfmInfo(String exRuleRfmInfo) {
		this.exRuleRfmInfo = exRuleRfmInfo;
	}
	public String getExRuleTrigger() {
		return exRuleTrigger;
	}
	public void setExRuleTrigger(String exRuleTrigger) {
		this.exRuleTrigger = exRuleTrigger;
	}
	public String getExRuleTriggerInfo() {
		return exRuleTriggerInfo;
	}
	public void setExRuleTriggerInfo(String exRuleTriggerInfo) {
		this.exRuleTriggerInfo = exRuleTriggerInfo;
	}
	public Integer getPointId() {
		return pointId;
	}
	public void setPointId(Integer pointId) {
		this.pointId = pointId;
	}
	public String getExRuleMedicineInfo() {
		return exRuleMedicineInfo;
	}
	public void setExRuleMedicineInfo(String exRuleMedicineInfo) {
		this.exRuleMedicineInfo = exRuleMedicineInfo;
	}
	@Override
	public String toString() {
		return "AutomationTaskRule [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createId=" + createId + ", createTime=" + createTime + ", orderCode=" + orderCode + ", deleteTime="
				+ deleteTime + ", remarks=" + remarks + ", attachment=" + attachment + ", bak1=" + bak1 + ", bak2="
				+ bak2 + ", bak3=" + bak3 + ", bak4=" + bak4 + ", bak5=" + bak5 + ", exRuleGroupInfo=" + exRuleGroupInfo
				+ ", exRuleCustomerInfo=" + exRuleCustomerInfo + ", exRuleActionInfo=" + exRuleActionInfo
				+ ", exRuleRfmInfo=" + exRuleRfmInfo + ", exRuleTrigger=" + exRuleTrigger + ", exRuleTriggerInfo="
				+ exRuleTriggerInfo + ", exRuleMedicineInfo=" + exRuleMedicineInfo + ", pointId=" + pointId + "]";
	}	
}
