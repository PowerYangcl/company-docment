package cn.cecook.dao.open.mp;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpUserInfo;

public interface MpUserInfoMapper {

	public void insert(MpUserInfo mpUserInfo);
	
	public void update(MpUserInfo mpUserInfo);

	public MpUserInfo getByTenantId(@Param(value = "tenant_id") String tenant_id);

}
