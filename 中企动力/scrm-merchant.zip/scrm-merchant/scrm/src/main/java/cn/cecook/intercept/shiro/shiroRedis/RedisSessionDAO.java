package cn.cecook.intercept.shiro.shiroRedis;

import java.io.Serializable;
import java.text.SimpleDateFormat;
import java.util.Collection;
import java.util.Date;
import java.util.HashSet;
import java.util.Set;

import org.apache.shiro.session.Session;
import org.apache.shiro.session.UnknownSessionException;
import org.apache.shiro.session.mgt.eis.AbstractSessionDAO;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

import cn.cecook.uitls.RedisUtil;
import cn.cecook.uitls.SerializeUtils;

/**
 * 我们自定义RedisSessionDAO继承AbstractSessionDAO，重写对session操作的方法，在应用中只要操作session，实际在方法中已经用redis处理了，
 * 可以用redis、mongoDB等进行实现。
 * 
 * 由Redis来管理session，包括session创建、读取、删除等，
 * 还可以统计在线用户，下面是核心代码RedisSessionDao的实现
 * 
 * 所谓会话，即用户访问应用时保持的连接关系，在多次交互中应用能够识别出当前访问的用户是谁，
 * 且可以在多次交互中保存一些数据。如访问一些网站时登录成功后，网站可以记住用户，且在退出之前都可以识别当前用户是谁。
 * @author zhanghao
 *
 */
public class RedisSessionDAO extends AbstractSessionDAO {

	private static Logger logger = LoggerFactory.getLogger(RedisSessionDAO.class);
	/**
	 * shiro-redis的session对象前缀
	 */
	private RedisUtil redisManager;
	
	/**
	 * The Redis key prefix for the sessions 
	 */
	private String keyPrefix = "redis_session_shiro:";
	
	@Override
	public void update(Session session) throws UnknownSessionException {
		this.saveSession(session);
	}
	
	/**
	 * 将session序列化保存进redis
	 * save session
	 * @param session
	 * @throws UnknownSessionException
	 */
	private void saveSession(Session session) throws UnknownSessionException{
		if(session == null || session.getId() == null){
			logger.error("session or session id is null");
			return;
		}
		
		byte[] key = getByteKey(this.keyPrefix + session.getId());
//		byte[] key = getByteKey(session.getId());
		byte[] value = SerializeUtils.serialize(session);
		session.setTimeout(redisManager.getExpire()*1000);		
		this.redisManager.set(key, value, redisManager.getExpire());
	}

	@Override
	/**
	 * 根据sessionId从redis中删除session
	 */
	public void delete(Session session) {
		if(session == null || session.getId() == null){
			logger.error("session or session id is null");
			return;
		}
		redisManager.del(this.getByteKey(this.keyPrefix + session.getId()));

	}

	@Override
	/**
	 * 从redis中获取全部的在线用户，并放入session
	 */
	public Collection<Session> getActiveSessions() {
		Set<Session> sessions = new HashSet<Session>();
		//模糊查询
		Set<byte[]> keys = redisManager.keys(this.keyPrefix + "*");
		if(keys != null && keys.size()>0){
			for(byte[] key:keys){
				Session s = (Session)SerializeUtils.deserialize(redisManager.get(key));
				sessions.add(s);
			}
		}
		
		return sessions;
	}

	/**
	 * 在redis中创建session
	 */
	@Override
	protected Serializable doCreate(Session session) {
		Serializable sessionId = this.generateSessionId(session);  
        this.assignSessionId(session, sessionId);
        this.saveSession(session);
		return sessionId;
	}
	/**
	 * 根据序列化session从redis中获取系统中的Session
	 */
	@Override
	protected Session doReadSession(Serializable sessionId) {
		if(sessionId == null){
			logger.error("session id is null");
			return null;
		}
		Session s = (Session)SerializeUtils.deserialize(redisManager.get(this.getByteKey(this.keyPrefix + sessionId)));
		if(s != null && s.getTimeout() != 0){
		//根据从redis中读取的session进行判断，如果最后操作时间与当前系统时间的差额大于60分钟，那么直接将session设置为失效，更新redis
		Long lastAccTime = s.getLastAccessTime().getTime();
		Long nowTime = new Date().getTime();
		SimpleDateFormat formatter = new SimpleDateFormat("yyyy-MM-dd HH:mm:ss");
		//System.out.println(formatter.format(s.getLastAccessTime()) + "------" + formatter.format(new Date()) + "-----"+	s.getAttribute("userId") + "-----"+(nowTime - lastAccTime));
		if((nowTime - lastAccTime) / 1000 / 60 > 60){
			String userId = String.valueOf(s.getAttribute("userId"));
			stopUserShiro(Long.valueOf(userId));
			s.setTimeout(0);
		}
		}

//		Session s = (Session)SerializeUtils.deserialize(redisManager.get(this.getByteKey(sessionId)));
		return s;
	}
	
	
	
    /**
     * 从redis中获取全部session，根据id设置其失效时间
     */
    public void stopUserShiro(Long id){
		Collection<Session> sessions =  getActiveSessions();
		for(Session session:sessions){
			if(session.getAttribute("userAccount") != null && !"".equals(session.getAttribute("userAccount"))){
			if(String.valueOf(id).equals(String.valueOf(session.getAttribute("userId")))){
				session.setTimeout(0);
				update(session);
			}
			}
		}

    }
	
	/**
	 * 获得byte[]型的key
	 * @param key
	 * @return
	 */
	private byte[] getByteKey(Serializable sessionId){
		String preKey = this.keyPrefix + sessionId;
		return preKey.getBytes();
	}

	public RedisUtil getRedisManager() {
		return redisManager;
	}

	public void setRedisManager(RedisUtil redisManager) {
		this.redisManager = redisManager;
		
		/**
		 * 初始化redisManager
		 */
//		this.redisManager.init();
	}

	/**
	 * Returns the Redis session keys
	 * prefix.
	 * @return The prefix
	 */
	public String getKeyPrefix() {
		return keyPrefix;
	}

	/**
	 * Sets the Redis sessions key 
	 * prefix.
	 * @param keyPrefix The prefix
	 */
	public void setKeyPrefix(String keyPrefix) {
		this.keyPrefix = keyPrefix;
	}
	
	
}
