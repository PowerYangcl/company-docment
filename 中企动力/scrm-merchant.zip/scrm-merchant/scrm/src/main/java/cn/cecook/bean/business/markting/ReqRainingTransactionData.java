package cn.cecook.bean.business.markting;

import java.util.Date;
import java.util.List;

public class ReqRainingTransactionData {

    private int id;

    private String transaction_id;

    private int  total_price;

    private Date checkout_time;

    private String pos_id;

    private String cashier_id;

    private String cashier_name;

    private List<ReqRainingProduct> product_list;

    public List<ReqRainingProduct> getProduct_list() {
        return product_list;
    }

    public void setProduct_list(List<ReqRainingProduct> product_list) {
        this.product_list = product_list;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getTransaction_id() {
        return transaction_id;
    }

    public void setTransaction_id(String transaction_id) {
        this.transaction_id = transaction_id;
    }

    public int getTotal_price() {
        return total_price;
    }

    public void setTotal_price(int total_price) {
        this.total_price = total_price;
    }

    public Date getCheckout_time() {
        return checkout_time;
    }

    public void setCheckout_time(Date checkout_time) {
        this.checkout_time = checkout_time;
    }

    public String getPos_id() {
        return pos_id;
    }

    public void setPos_id(String pos_id) {
        this.pos_id = pos_id;
    }

    public String getCashier_id() {
        return cashier_id;
    }

    public void setCashier_id(String cashier_id) {
        this.cashier_id = cashier_id;
    }

    public String getCashier_name() {
        return cashier_name;
    }

    public void setCashier_name(String cashier_name) {
        this.cashier_name = cashier_name;
    }
}
