package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcCustomerGroup;
import cn.cecook.model.business.customer.BcCustomerGroupExample;

/**
 * 
* @explain 客户分组表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcCustomerGroupMapper {
    int countByExample(BcCustomerGroupExample example);

    int deleteByExample(BcCustomerGroupExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcCustomerGroup record);

    int insertSelective(BcCustomerGroup record);

    List<BcCustomerGroup> selectByExample(BcCustomerGroupExample example);

    BcCustomerGroup selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcCustomerGroup record, @Param("example") BcCustomerGroupExample example);

    int updateByExample(@Param("record") BcCustomerGroup record, @Param("example") BcCustomerGroupExample example);

    int updateByPrimaryKeySelective(BcCustomerGroup record);

    int updateByPrimaryKey(BcCustomerGroup record);
}