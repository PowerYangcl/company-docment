package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.system.CompanyModel;
import cn.cecook.model.system.SysCompany;
import cn.cecook.model.system.SysCompanyExample;

/**
 * 
* @explain 企业表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysCompanyMapper {
    int countByExample(SysCompanyExample example);

    int deleteByExample(SysCompanyExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SysCompany record);

    int insertSelective(SysCompany record);

    List<SysCompany> selectByExample(SysCompanyExample example);

    SysCompany selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SysCompany record, @Param("example") SysCompanyExample example);

    int updateByExample(@Param("record") SysCompany record, @Param("example") SysCompanyExample example);

    int updateByPrimaryKeySelective(SysCompany record);

    int updateByPrimaryKey(SysCompany record);
    /**
     * 
     * @explain 根据租户id查询企业对象
     * @author LeeX
     * @date 2017年6月3日 上午11:44:36
     */
	SysCompany selectCompanyByTenantId(String tenant_id);
    
    SysCompany findByName(String name);
    
    /*
     *	根据uuid更新公司信息 
     */
    int updateSysCompanyByIDAndTid(SysCompany company);
    //sunny根据TenantId更新
    SysCompany findByTenantId(String tenant_id);
    //上传营业执照
	int uploadBLicenseByTenantId(CompanyModel companyModel);
	
	//上传/更新logo
    int uploadLogoByTenantId(CompanyModel companyModel);
	//删除营业执照
	int delBLicenseByTenantId(Map cookieSet);
	//更新关键字
	int updateupdateKeyWordsByTid(Map cookieSet);
	//根据租户id查询该租户的短信充值数量
	Integer selectSmsNumByTenantId(String tenantId);
	//根据租户id增加该租户的短信充值数量
	Integer updateSmsNumByTenantId_add(@Param("tenantId") String tenantId,@Param("smsNum") Integer smsNum);
	//根据租户id减少该用户的短信充值数量
	Integer updateSmsNumByTenantId_min(@Param("tenantId") String tenantId,@Param("smsNum") Integer sendNum);
	/**
	 * 根据租户id获取行业信息
	 * @param tenantId
	 * @return
	 */
	String getIndustryByTenantId(@Param("tenantId") String tenantId);
}
