package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.TenantDataBaseService;

@Controller
@RequestMapping("/api/tenant")
public class TenantDataBaseController {

	@Autowired
	private TenantDataBaseService tenantDataBaseService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(String tenant_id,String uid) {

		return (tenantDataBaseService
				.createTenantDatabase(tenant_id,uid));
	}
}
