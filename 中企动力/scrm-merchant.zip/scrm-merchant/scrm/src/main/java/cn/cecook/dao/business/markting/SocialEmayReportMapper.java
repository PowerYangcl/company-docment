package cn.cecook.dao.business.markting;

import cn.cecook.model.business.markting.SocialEmayReport;

public interface SocialEmayReportMapper {


    int deleteByPrimaryKey(Integer id);


    int insertSelective(SocialEmayReport record);


    SocialEmayReport selectByPrimaryKey(Integer id);



    int updateByPrimaryKeySelective(SocialEmayReport record);
    
    
    
    //批量修改短信状态
    //int updatePrice(SocialEmayReport record );

}