package cn.cecook.dao.open.mp;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpScanMemberGroup;


public interface MpScanMemberGroupMapper {
	
	public List<MpScanMemberGroup> selectGroupids(@Param(value = "tenant_id") String tenant_id, @Param(value = "member_id") String member_id);
}
