package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmUserStore;

public interface BmUserStoreMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(BmUserStore record);

    int insertSelective(BmUserStore record);

    BmUserStore selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(BmUserStore record);

    int updateByPrimaryKey(BmUserStore record);
	/**
	* 获取用户的门店
	* @param:
	* @return:
	*/
    List<Map<String,Object>> getStores(String id);
    
    /**
	* 获取用户的门店
	* @param:
	* @return:
	*/
    List<Map<String,Object>> getStoreByLogin(@Param("id")  String id,@Param("tenantId")  String tenantId);

	List<Map<String,Object>> getStoreByData(@Param("id")  String id,@Param("tenantId")  String tenantId,@Param("startIndex") Integer startIndex,@Param("pageSize") Integer pageSize);


	List<BmUserStore> selectByUserId(Long id);

	void deleteByUserId(Long id);

	Map<String, Object> getProductService(@Param("tenant_id") String tenant_id);
	/**
	 * 通过店铺id获取门店下所有的用户信息
	 * @param id
	 * @return
	 */
	List<Map<String,Object>> getUsers(String id);

	List<Map<String,Object>> getTheStores(String id);

	int getStoreTotlCount(@Param("id") String id,@Param("tenantId") String tenant_id);
}
