package cn.cecook.controller.open;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;
import com.google.gson.JsonSyntaxException;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpTag;
import cn.cecook.model.open.mp.MpUser;
import cn.cecook.service.business.scan.ScanMemberGroupService;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.thirdparty.open.MpTagUtil;
import cn.cecook.thirdparty.open.UserUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.redis.RedisConfig;
import cn.cecook.uitls.redis.RedisStringUtil;

@Controller
@RequestMapping("/weixin")
public class WeixinFocusUserController {
	private static JsonParser parser = new JsonParser();
	
	@Autowired
	private IMpUserService mpuserService;
	
	@Autowired
	private IMpAccountService mpAccountService;
	
	@Autowired
	private ScanMemberGroupService scanMemberGroupService;
	

	@RequestMapping("/listSysGroup")
	public ModelAndView listSysGroup(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String memberGroupTree = "{'data':[],'msg_code':0}";
		if(mpAccount != null) {
			memberGroupTree = scanMemberGroupService.getMemberGroupTree();
			//解析存redis
			try {
				JsonArray dataArr = parser.parse(memberGroupTree).getAsJsonObject().get("data").getAsJsonArray();
				for (int i = 0; i < dataArr.size(); i++) {
					JsonArray childrenArr = dataArr.get(i).getAsJsonObject().get("children").getAsJsonArray();
					for (int j = 0; j < childrenArr.size(); j++) {
						try {
							JsonObject childrenObj = childrenArr.get(j).getAsJsonObject();
							int sysTagId = childrenObj.get("id").getAsInt();
							String sysTagVal = childrenObj.get("text").getAsString();
							//更新redis
							if(sysTagId > 0 && StringUtils.isNotEmpty(sysTagVal)){					
								String key = RedisConfig.REDIS_KEY + ":mp:systag:" + mpAccount.getAuthorizerAppid() + ":" + sysTagId;
								RedisStringUtil.setData(key, sysTagVal);
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		model.put("jsonResult", memberGroupTree);
		modelAndView.setViewName("open/jsonResult");
		return modelAndView;
	}
	
	@RequestMapping(value = "/focusUser")
    public String focusUser(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		Map<String, Object> condition = new HashMap<String, Object>();
		request.setAttribute("condition", condition);
		String memberGroupTree = "{'data':[],'msg_code':0}";
		if(mpAccount != null) {
			memberGroupTree = scanMemberGroupService.getMemberGroupTree();
		}
		request.setAttribute("memberGroupTree", memberGroupTree);
		request.setAttribute("totalPage", 0);
		request.setAttribute("currentPage", 1);
		int totalCount = mpuserService.getAllCount(condition);
		request.setAttribute("totalCount", totalCount);
		
		return "open/wxFocusUser";
	}

	@RequestMapping(value = "/focusUserQuery")
    public String focusUserQuery(HttpServletRequest request, HttpServletResponse response) {
		int page = ServletRequestUtils.getIntParameter(request, "page", 1);
		String startQueryTime = ServletRequestUtils.getStringParameter(request, "startQueryTime", "");
		String endQueryTime = ServletRequestUtils.getStringParameter(request, "endQueryTime", "");
		String nicknameOrPhone = ServletRequestUtils.getStringParameter(request, "nicknameOrPhone","");
		String sex = ServletRequestUtils.getStringParameter(request, "sex","");
		String city = ServletRequestUtils.getStringParameter(request, "city","");
		String membered = ServletRequestUtils.getStringParameter(request, "membered","");
		String groupId = ServletRequestUtils.getStringParameter(request, "groupId", "");
		int pageSize = 10;
		Map<String, Object> condition = new HashMap<String, Object>();
		int start = (page - 1) * pageSize;
		condition.put("start", start);
		condition.put("pageSize", pageSize);
		condition.put("startQueryTime", startQueryTime);
		condition.put("endQueryTime", endQueryTime);
		condition.put("nicknameOrPhone", nicknameOrPhone);
		condition.put("sex", sex);
		condition.put("city", city);
		condition.put("membered", membered);
		condition.put("tagids", groupId);
		String uid = "";
		condition.put("uid", uid);
		List<MpUser> dataList = mpuserService.listByPage(condition);
		int totalCount = mpuserService.getAllCount(condition);
		int toalPage = totalCount % pageSize == 0 ? totalCount/pageSize: totalCount/pageSize + 1;
		request.setAttribute("dataList", dataList);
		request.setAttribute("condition", condition);
		request.setAttribute("totalPage", toalPage);
		request.setAttribute("currentPage", page);
		request.setAttribute("totalCount", totalCount);
		return "open/wxFocusUserDataList";
	}
	  
	@ResponseBody
	@RequestMapping("/createGroup")
	public Object createGroup(HttpServletRequest request, HttpServletResponse response)  {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		String groupName = ServletRequestUtils.getStringParameter(request, "groupName","");
		MpTag createTag = MpTagUtil.createTag(groupName, authorizer_access_token);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		result.put("group",createTag);

		return result;
	}
	
	@ResponseBody
	@RequestMapping("/updateGroup")
	public Object updateGroup(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		int groupId = ServletRequestUtils.getIntParameter(request, "groupId",0);
		String groupName = ServletRequestUtils.getStringParameter(request, "groupName","");
		boolean success = MpTagUtil.updateTag(groupId, groupName, authorizer_access_token);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", success);
		return result;
	}
	
	@RequestMapping("/listGroup")
	public String listGroup(HttpServletRequest request, HttpServletResponse response) {
		Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String tenantId = String.valueOf(session.getAttribute("tenantId"));
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenantId);
		List<MpTag> dataList = null;
		if(mpAccount != null) {
			String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
			dataList = MpTagUtil.allTag(mpAccount.getAuthorizerAppid(), authorizer_access_token);
		}
		request.setAttribute("dataList", dataList);
		
		//1 关注用户列表页右侧分组列表（默认）2单个用户分组弹窗 3批量分组弹窗
		int type = ServletRequestUtils.getIntParameter(request, "type",1);
		if (type == 2) {
			return "open/groupListForModal";
		}else if (type == 3) {
			return "open/groupListForBatchModal";
		}
		return "open/groupList";
	}
	
	@ResponseBody
	@RequestMapping("/listGroupJson")
	public Object listGroupJson(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		List<MpTag> dataList = MpTagUtil.allTag(mpAccount.getAuthorizerAppid(), authorizer_access_token);
		return dataList;
	}
	
	@ResponseBody
	@RequestMapping("changeUserMemo")
	public Object changeUserMemo(HttpServletRequest request, HttpServletResponse response)  {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		String memo = ServletRequestUtils.getStringParameter(request, "memo","");
		String openid = ServletRequestUtils.getStringParameter(request, "openid", "");
		int userId = ServletRequestUtils.getIntParameter(request, "userId", 0);
		Map<String, Object> mpUser = new HashMap<String, Object>();
		mpUser.put("userId", userId);
		mpUser.put("memo", memo);
		boolean success = false;
		int update = mpuserService.updateUser(mpUser );
		if(update > 0){
			success = UserUtil.updateremark(authorizer_access_token, openid, memo);	
		}
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", success);
		return result;
	}
	
	@ResponseBody
	@RequestMapping("changeUserGroup")
	public Object changeUserGroup(HttpServletRequest request, HttpServletResponse response)  {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		String openid = ServletRequestUtils.getStringParameter(request, "openid", "");
		String tagIds = ServletRequestUtils.getStringParameter(request, "groupId","");
		int userId = ServletRequestUtils.getIntParameter(request, "userId", 0);
		String[] openids = new String[]{openid};
		Map<String, Object> mpUser = new HashMap<String, Object>();
		mpUser.put("userId", userId);
		mpUser.put("tagids", tagIds);
		mpuserService.updateUser(mpUser);
		//清除旧tag
		List<MpTag> mpTags = MpTagUtil.listTagByOpenid(mpAccount.getAuthorizerAppid(), openid, authorizer_access_token);
		for (int i = 0; i < mpTags.size(); i++) {
			MpTagUtil.unmarkTag2Openid(openids, mpTags.get(i).getId(), authorizer_access_token);
		}
		//设置新tag
		String[] tags = tagIds.split(",");
		for (int j = 0; j < tags.length; j++) {
			try {
				if(StringUtils.isNotEmpty(tags[j])){				
					MpTagUtil.markTag2Openid(openids, Integer.valueOf(tags[j]), authorizer_access_token);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		return result;
	}
	
	@ResponseBody
	@RequestMapping("deleteGroup")
	public Object deleteGroup(HttpServletRequest request, HttpServletResponse response)  {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		int groupId = ServletRequestUtils.getIntParameter(request, "groupId",0);
		//将相关tag关联清除
		mpuserService.deleteTag(groupId);
		boolean deleted = MpTagUtil.delTag(groupId, authorizer_access_token);
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", deleted);
		return result;
	}
	
	@ResponseBody
	@RequestMapping("batchChangeUserGroup")
	public Object batchChangeUserGroup(HttpServletRequest request, HttpServletResponse response)  {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		String tagIds = ServletRequestUtils.getStringParameter(request, "groupId","");
		String userIds = ServletRequestUtils.getStringParameter(request, "userIds", "");
		String openids = ServletRequestUtils.getStringParameter(request, "openids", "");
		String[] userIdArray = userIds.split(",");
		for (String uid : userIdArray) {
			Map<String, Object> mpUser = new HashMap<String, Object>();
			mpUser.put("userId", uid);
			mpUser.put("tagids", tagIds);
			mpuserService.updateUser(mpUser);
		}
		
		//设置新tag
		String[] openidArray = openids.split(",");
		String[] tags = tagIds.split(",");
		for (int j = 0; j < tags.length; j++) {
			try {
				if (StringUtils.isNotEmpty(tags[j])) {
					MpTagUtil.markTag2Openid(openidArray, Integer.valueOf(tags[j]), authorizer_access_token);
				}
			} catch (Exception e) {
				e.printStackTrace();
			}
		}
		
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		return result;
	}
}
