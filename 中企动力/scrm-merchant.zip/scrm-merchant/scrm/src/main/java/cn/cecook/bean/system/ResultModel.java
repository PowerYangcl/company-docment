package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Component
public class ResultModel implements Serializable{
	//公用
	// 错误代码
	private String error_code;
	// 错误描述
	private String error_msg;
	//口令
	private String access_token ;
	//用户ID
	private	String uid;
	//租户ID
	private	String tenant_id ;
	//验证码
	private    String ver_code_d ;
	//企业
	//企业名称
	private String name;
	//企业地区
	private String city;
	//企业介绍
	private String intro;
	//企业标签
	private String tag;
	//营业执照
	private String b_license;
	//业务
	private String business ;
	//关键字
	private String keyword;
	//电话
	private String phone;
	//行业
	private String industry;
	//  企业logo
	private String logo;
	//第三方token
	private String token;
	//第三方请求ticket
	private String ticket;
	
	//list集合
	private List list = new ArrayList<>();
	//map集合
	private Map map = new HashMap<>();
	//Object 
	private Object obj= new Object(); 
	
	
	/*
	 * set  get
	 */
	public String getLogo() {
		return logo;
	}
	public void setLogo(String logo) {
		this.logo = logo;
	}
	
	public Map getMap() {
		return map;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getIndustry() {
		return industry;
	}
	public void setIndustry(String industry) {
		this.industry = industry;
	}
	public void setMap(Map map) {
		this.map = map;
	}
	public String getVer_code_d() {
        return ver_code_d;
    }
    public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public void setVer_code_d(String ver_code_d) {
        this.ver_code_d = ver_code_d;
    }
    public String getError_code() {
		return error_code;
	}
	public void setError_code(String error_code) {
		this.error_code = error_code;
	}
	public String getError_msg() {
		return error_msg;
	}
	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}
	
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getIntro() {
		return intro;
	}
	public void setIntro(String intro) {
		this.intro = intro;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getB_license() {
		return b_license;
	}
	public void setB_license(String b_license) {
		this.b_license = b_license;
	}
	public String getBusiness() {
		return business;
	}
	public void setBusiness(String business) {
		this.business = business;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	@Override
    public String toString() {
        return "ResultModel [error_code=" + error_code + ", error_msg=" + error_msg + ", access_token=" + access_token
                        + ", uid=" + uid + ", tenant_id=" + tenant_id + ", ver_code_d=" + ver_code_d + ",logo=" + logo + "]";
    }
	public List getList() {
		return list;
	}
	public void setList(List list) {
		this.list = list;
	}
	public Object getObj() {
		return obj;
	}
	public void setObj(Object obj) {
		this.obj = obj;
	}
	public String getToken() {
		return token;
	}
	public void setToken(String token) {
		this.token = token;
	}
	public String getTicket() {
		return ticket;
	}
	public void setTicket(String ticket) {
		this.ticket = ticket;
	}
	
}
