package cn.cecook.controller.system;



import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.amazonaws.services.s3.model.ObjectMetadata;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.bean.system.CompanyModel;
import cn.cecook.bean.system.LoginUser;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.system.SysCompany;
import cn.cecook.service.impl.system.SynWithCRMServiceImpl;
import cn.cecook.service.system.ICompanyService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.FileUploadUtils;
import cn.cecook.uitls.StringUtils;
import cn.cecook.uitls.amazonaws.FileUtil;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/api/company")
public class CompanyController {
//SelfInfo Sms
    @Resource
    private ICompanyService companyService;
    @Value("#{configProperties['PROJECT_URL']}")
    private String FILE_URL;
    
    private Logger logger = Logger.getLogger(CompanyController.class);
    /**
     * 企业信息操作
     * @explain 
     * @author sunny
     * @date 2017年5月26日
     */
    @RequestMapping(value = "/infoUpdate", method = RequestMethod.POST)
    @ResponseBody
    public Object infoUpdate(HttpServletRequest request, HttpServletResponse response,CompanyModel companyModel) throws Exception {
        /**
         * @author sunny
         * 注册企业资料
         * 注册时的，注册企业方法
         */        
        //企业介绍
        String intro = request.getParameter("intro");
        //企业业务
        String business = request.getParameter("business");
/*        //营业执照
        String b_license = request.getParameter("b_license");*/
//        String fpath=request.getParameter("fpath");
//        String fname=request.getParameter("fname");
        //File b_licenseF=new File(fpath, fname); 
        //String b_license = FileUtils.filetoString(b_licenseF);
        
        //String company=(String) request.getSession().getAttribute("company");  
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
        }
        //返回的 ResultModel
        //System.out.println("intro>>>>>"+intro.length()+"business"+business.length());
        ResultModel resultModel = new ResultModel();
        if(intro.length()<1&&business.length()<1){
            //System.out.println("空空空空空空");
            resultModel.setError_code("0");
            resultModel.setError_msg("请输入内容");
            return (resultModel);
        }else{
            //System.out.println(company);
            if (!"".equals(tenant_id) && tenant_id != null) { 
                companyModel.setTenant_id(tenant_id);
                }
            if (!"".equals(intro) && intro != null) { 
                companyModel.setIntro(intro);
                }
            if (!"".equals(business) && business != null) { 
                companyModel.setBusiness(business);
                }
    /*        if (!"".equals(b_license) && b_license != null) {
                companyModel.setB_license(b_license);
                }*/
            resultModel = companyService.infoUpdate(companyModel);
            System.out.println(resultModel);
            return (resultModel);
        }                       
    }

    @RequestMapping(value = "/infoKeyUpdate", method = RequestMethod.POST)
    @ResponseBody
    public Object infoKeyUpdate(HttpServletRequest request, HttpServletResponse response,CompanyModel companyModel) throws Exception {
        /**
         *@author sunny
         * 注册页面，输入关键字后更新
         */
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
        }
        //获取关键字
        String keyWord=request.getParameter("keyWord");
        //返回的 ResultModel
        ResultModel resultModel = new ResultModel();
        if (StringUtils.isEmpty(keyWord)) {
            resultModel.setError_code("0");
            resultModel.setError_msg("无更新内容");
            return (resultModel);
        }else{
            keyWord= keyWord.substring(0,keyWord.length()-1);
            companyModel.setKeyword(keyWord);
        } 
        //System.out.println(keyWord);
        if (!"".equals(tenant_id) && tenant_id != null) {
            companyModel.setTenant_id(tenant_id);
            }
        resultModel = companyService.infoKeyUpdate(companyModel);
        //注册完成后，清空cookie
        for(Cookie cookie1:cookie){
        cookie1.setMaxAge(0);
        cookie1.setPath("/");
        response.addCookie(cookie1);
        }
        return (resultModel);
    }
    /**
     * 显示企业基本资料
     */
    @RequiresPermissions("login")
    @RequestMapping(value = "/show", method = RequestMethod.POST)
    @ResponseBody
    public Object show(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	//对象参数
    	ResultModel resultModel = new ResultModel();
    	
    	//验证token是否有效
    	if (!MyCatFilter.getToken_Valid()){
    		resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
    	
    	//获取cookie
    	Cookie[] cookies = request.getCookies();
    	Map cookieSet = CookieUtil.getCookieSet(cookies);
    	
    	//将当前用户传到service
    	resultModel = companyService.show(cookieSet);
    	
        return (resultModel);
    }


    @RequestMapping(value = "/showCompanyInfo", method = RequestMethod.POST)
    @ResponseBody
    public Object showCompanyInfo(String tenant_id) throws Exception {
        //对象参数
       ResultModel resultModel = new ResultModel();
//
//        //验证token是否有效
//        if (!MyCatFilter.getToken_Valid()){
//            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
//            resultModel.setError_msg("请重新登录");
//            return (resultModel);
//        }
//
//        //获取cookie
//        Cookie[] cookies = request.getCookies();
//        Map cookieSet = CookieUtil.getCookieSet(cookies);

        //将当前用户传到service
        Map<String,String> map=new HashMap<>();
        map.put("tenant_id",tenant_id);
        resultModel = companyService.show(map);

        return (resultModel);
    }
    /**
     * 企业信息修改
     */
    @RequiresPermissions("login")
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public Object update(HttpServletRequest request, HttpServletResponse response,CompanyModel companyModel) throws Exception {
    	//对象参数
    	LoginUser loginUser = new LoginUser();
    	ResultModel resultModel = new ResultModel();
    	
    	//验证token是否有效
    	if (!MyCatFilter.getToken_Valid()){
    		resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
    	
    	//获取当前用户对象的租户id，封装到loginuser中
    	Cookie[] cookies = request.getCookies();
    	for (Cookie cookie : cookies) {
			if("tenant_id".equals(cookie.getName())){
				loginUser.setTenant_id(cookie.getValue());
			}
		}
    	
    	//把当前用户和参数传到service
    	resultModel = companyService.update(companyModel,loginUser);
    	
    	return (resultModel);

    }
    @RequestMapping(value = "/b_uploadFile", method = RequestMethod.POST)
    @ResponseBody
    public Object b_uploadFile(HttpServletRequest request,
                    @RequestParam(required = false, value = "file") MultipartFile file,String typename) throws Exception {        
        /**
         *@author sunny
         * 注册页面，营业执照上传
         */        
        //营业执照上传
        Cookie[] cookie=request.getCookies();
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
        }
        //把当前用户和参数传到service
        CompanyModel companyModel=new CompanyModel();
        if (!"".equals(tenant_id) && tenant_id != null) {
            companyModel.setTenant_id(tenant_id);
         }         
         ResultModel resultModel = new ResultModel();
         //文件上传
         JSONObject js=FileUploadUtils.getinstance().UploadFile(request,typename);
         String message=(String) js.get("message");
         System.out.println("message>>>>"+message);
         String b_license=js.getString("realSavePath");
         System.out.println("b_license>>>"+b_license);
         if (!"".equals(b_license) && b_license != null) {
             companyModel.setB_license(b_license);
             resultModel = companyService.uploadFileUpdate(companyModel);
             System.out.println("文件上传成功"+resultModel);
             return (resultModel);
         }else{
             resultModel.setError_code("0");
             resultModel.setError_msg(message); 
             System.out.println("文件上传失败"+resultModel);
             return (resultModel);
         }           
    }
    /**
     * LeeX
     * @param request
     * @param response
     * @return
     * @throws Exception
     */
    @RequiresPermissions("login")
    @RequestMapping(value = "/uploadBLicense", method = RequestMethod.POST)
    @ResponseBody
    public Object uploadBLicense(HttpServletRequest request, HttpServletResponse response,@RequestParam(required = false, value = "file") MultipartFile file) throws Exception {
    	//对象参数
    	CompanyModel companyModel=new CompanyModel();
    	ResultModel resultModel = new ResultModel();
    	
    	//验证token
    	if (!MyCatFilter.getToken_Valid()){
    		resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
    	
    	//营业执照上传
    	try{
    		Cookie[] cookies=request.getCookies();
    		Map cookieSet = CookieUtil.getCookieSet(cookies);
    		String tenant_id=String.valueOf(cookieSet.get("tenant_id"));
    		
    		//把当前用户和参数传到service
    		if ("".equals(tenant_id) || tenant_id == null) {
    			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
    			resultModel.setError_msg("上传失败，请刷新页面重新上传");
    			return (resultModel);
    		}         
    		
    		//文件上传
    		JSONObject jObject = FileUploadUtils.getinstance().UploadFile(request, file.getName());
    		String message = jObject.getString("message");
    		String saveFilename = jObject.getString("saveFilename");
    		String realSavePath = jObject.getString("realSavePath");
    		
    		if(!"success".equals(message)){
    			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
    			resultModel.setError_msg("上传失败，请刷新页面重新上传");
    			return (resultModel);
    		}
    		if("".equals(saveFilename)){
    			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
    			resultModel.setError_msg("上传失败，请刷新页面重新上传");
    			return (resultModel);
    		}
    		if("".equals(realSavePath)) {
    			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
    			resultModel.setError_msg("上传失败，请刷新页面重新上传");
    			return (resultModel);
    			
    		}       
    		
    		companyModel.setTenant_id(tenant_id);
    		companyModel.setB_license(realSavePath);
    		
    		resultModel = companyService.uploadFileUpdate(companyModel);
    		resultModel.setB_license(FILE_URL+realSavePath);
    		
    		return (resultModel);
    		
    	} catch (Exception e){
    		
    		e.printStackTrace();
    		resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg("不支持的图片类型，仅支持JPG、GIF、PNG");
			
			return (resultModel);
    	}
    }  
    
    /**
     * 
     * @author LeeX
     * @time 2017年7月19日 下午4:32:19
     * @params  delBLicense
     * @return  Object 
     */
    @RequiresPermissions("login")
    @RequestMapping(value = "/delBLicense", method = RequestMethod.POST)
    @ResponseBody
    public Object delBLicense(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	//对象参数
    	ResultModel resultModel = new ResultModel();
    	
    	//验证token是否有效
    	if (!MyCatFilter.getToken_Valid()){
    		resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
    	
    	//cookie
    	Map cookieSet = CookieUtil.getCookieSet(request.getCookies());
    	
    	return (companyService.delBLicense(cookieSet));
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value = "/updateKeyWords", method = RequestMethod.POST)
    @ResponseBody
    public Object updateKeyWords(HttpServletRequest request, HttpServletResponse response) throws Exception {
    	//对象参数
    	ResultModel resultModel = new ResultModel();
    	
    	//验证token是否有效
    	if (!MyCatFilter.getToken_Valid()){
    		resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
    	
    	//获取当前用户对象的租户id，封装到loginuser中
    	Map cookieSet = CookieUtil.getCookieSet(request.getCookies());
    	cookieSet.put("keyword", request.getParameter("keyword"));
    	//把当前用户和参数传到service
    	resultModel = companyService.updateupdateKeyWords(cookieSet);
    	
    	return (resultModel);
    }
      
    
  
   /*
    * 注册企业信息
    * */
    
    @RequiresPermissions("login")
    @RequestMapping(value = "/regist", method = RequestMethod.POST)
    @ResponseBody
    public Object regist(HttpServletRequest request, HttpServletResponse response,CompanyModel companyModel) throws Exception {
    	//对象参数
    	LoginUser loginUser = new LoginUser();
    	ResultModel resultModel = new ResultModel();
    	SysCompany sysCompany=new SysCompany();
    	sysCompany.setIsDeleted(0);
    	sysCompany.setCreateId(0L);
    	sysCompany.setCreateTime(new Date());
    	sysCompany.setName(companyModel.getCompany());
    	sysCompany.setBusiness(companyModel.getBusiness());
    	sysCompany.setIntro(companyModel.getIntro());
    	sysCompany.setAddress(companyModel.getCity());
    	sysCompany.setLogo(companyModel.getLogo());
    	sysCompany.setPhone(companyModel.getPhone());
    	
    	
    	
    	//验证token是否有效
    	if (!MyCatFilter.getToken_Valid()){
    		resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
    		resultModel.setError_msg("请重新登录");
    		return (resultModel);
    	}
    	
    	//获取当前用户对象的租户id，封装到loginuser中
    	Cookie[] cookies = request.getCookies();
    	for (Cookie cookie : cookies) {
			if("tenant_id".equals(cookie.getName())){
				loginUser.setTenant_id(cookie.getValue());
			}
		}
    	
    	//把当前用户和参数传到service
    	resultModel = companyService.infoRegist(sysCompany, loginUser);
    	
    	/*if("1".equals(resultModel.getError_code())) {
    		
    		
    		
    	}
    	*/
    	
    	
    	
    	return (resultModel);

    }
    /**
     * 上传logo
     * @param request
     * @param response
     * @param typename
     * @param isFile
     * @return
     * majie
     */
    @RequestMapping(value = "/uploadLogo", method = RequestMethod.POST)
    @ResponseBody
    public Object uploadLogo(HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value = "typename", required = false) String typename,
			@RequestParam(value = "isFile", required = false) Boolean isFile) {		
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		MultipartFile multipartFile = multipartRequest.getFile(typename);// 获取表单
	    String filename = multipartFile.getOriginalFilename();//获取文件名
		ObjectMetadata metadata = new ObjectMetadata();
		metadata.setContentType("image/jpeg");
		BaseResultModel baseResultModel = new BaseResultModel();
		String path="";
		try {
			path = FileUtil.uploadFile(multipartFile.getInputStream(), metadata,filename);
			logger.debug("返回图片地址"+path);
		} catch (IOException e) {
			e.printStackTrace();
			baseResultModel.setError_msg("上传失败！");
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
		}		
		baseResultModel.setData(path);
		baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		baseResultModel.setError_msg("上传成功！");
    	return baseResultModel;
    }
    /**
     * 根据租户id获取企业信息
     * @param request
     * @param response
     * @param tenantId
     * @return
     */
    @RequestMapping(value = "/getCompanyByTenantId", method = RequestMethod.POST)
    @ResponseBody
    public Object getCompanyByTenantId(HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value = "tenantId", required = false) String tenantId){
    	BaseResultModel baseResultModel=new BaseResultModel();
    	String result = companyService.getCompanyByTenantId(tenantId);
    	if(result!=null){
    		baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
    		baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
    		baseResultModel.setData(result);
    	}else{
    		baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
    		baseResultModel.setError_code(ConfigStatusCode.FAILURE_MSG);
    	}
    	return baseResultModel;
    }
}
