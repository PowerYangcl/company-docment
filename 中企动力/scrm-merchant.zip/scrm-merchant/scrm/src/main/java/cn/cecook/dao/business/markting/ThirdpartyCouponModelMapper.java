package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.markting.ThirdPartyCouponModel;
import cn.cecook.model.business.markting.ThirdPartyCouponModelParam;
@Repository("thirdpartyCouponModelMapper")
public interface ThirdpartyCouponModelMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(ThirdPartyCouponModel record);

    int insertSelective(ThirdPartyCouponModel record);

    ThirdPartyCouponModel selectByPrimaryKey(@Param("tenantId") String tenantId,@Param("modelId") Integer modelId);

    ThirdPartyCouponModel getDetailByName(@Param("name") String modelName);
    
    int updateByPrimaryKeySelective(ThirdPartyCouponModel record);

    
    List<ThirdPartyCouponModel> listThirdPartyCouponModel(ThirdPartyCouponModelParam param);
    
    int countThirdPartyCouponModel(ThirdPartyCouponModelParam param);
    
    int updateModelStatusByBatch(List<Integer> list);
    
    List<ThirdPartyCouponModel> modelListByIds(Map<String,Object> map);
}