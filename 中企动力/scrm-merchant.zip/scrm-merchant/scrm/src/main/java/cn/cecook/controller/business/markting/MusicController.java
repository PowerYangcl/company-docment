package cn.cecook.controller.business.markting;


import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.markting.BmMusicList;
import cn.cecook.service.business.markting.MusicService;
import cn.cecook.uitls.FileUploadUtils;
import cn.cecook.uitls.FastJsonUtil;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/api/music")
public class MusicController {
	@Autowired
	private MusicService musicService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		BmMusicList bmMusic = new BmMusicList();
		String name = request.getParameter("name");
		String uid = request.getParameter("uid");
		String size = request.getParameter("size");
		String duration = request.getParameter("duration");
		String author = request.getParameter("author");
		String url = request.getParameter("url");
		String lyric = request.getParameter("lyric");
		String format = request.getParameter("format");
		String background_pic = request.getParameter("background_pic");
		bmMusic.setDuration(duration);
		bmMusic.setCreateId(Long.parseLong(uid));
		bmMusic.setSize(size);
		bmMusic.setAuthor(author);
		bmMusic.setUrl(url);
		bmMusic.setLyric(lyric);
		bmMusic.setFormat(format);
		bmMusic.setBackgroundPic(background_pic);
		bmMusic.setName(name);
		return (musicService.insert(bmMusic));

	}

	@RequestMapping(value = "/list")
	@ResponseBody
	public Object getMusicList(String startIndex, String pageSize,
			String keyWord) {
		return (musicService.musicList(startIndex,
				pageSize, keyWord));
	}

	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object getMusicDetail(String id) {
		return (musicService.musicDetail(id));
	}

	@RequestMapping(value = "/deleted")
	@ResponseBody
	public Object delete(String id) {
		return (musicService.deleteMusic(id));
	}

	//上传图片
	@RequestMapping(value = "/musicUpload", method = RequestMethod.POST)
	public @ResponseBody Object file(HttpServletRequest request,
			@RequestParam(value = "typename", required = false) String typename) {
		System.out.println("111111111111111");

		JSONObject jsonObject = FileUploadUtils.getinstance().UploadFile(
				request, typename);
		
		
		if(jsonObject.get("message").equals("success")){
			BmMusicList bmMusic = new BmMusicList();
			bmMusic.setName(jsonObject.getString("fileName"));
			bmMusic.setUrl(jsonObject.getString("realSavePath"));
			BaseResultModel baseResultModel=musicService.insert(bmMusic);
			jsonObject.put("music_id", baseResultModel.getData());
		}
		System.out.println("上传返回结果-------->"+FastJsonUtil.createJsonString(jsonObject));
		return (jsonObject);
	}
}
