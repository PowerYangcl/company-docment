package cn.cecook.dao.business.markting;

import cn.cecook.bean.business.markting.GoodsStandardMedicine;

public interface GoodsStandardMedicineMapper {
    int deleteByPrimaryKey(Long id);

    int insert(GoodsStandardMedicine record);

    int insertSelective(GoodsStandardMedicine record);

    GoodsStandardMedicine selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(GoodsStandardMedicine record);

    int updateByPrimaryKey(GoodsStandardMedicine record);
    /**
     * 进行纠错
     * @param id
     * @return
     */
	int updateErrorCorrect(Integer id);
}