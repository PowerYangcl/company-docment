package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
public class LoginUser implements Serializable {

	private String account ;
	
	private String password;
	
	private String access_token ;
	
	private String tenant_id ;
	
	private String uid;

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getTenant_id() {
		return tenant_id;
	}

	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}

	public String getUid() {
		return uid;
	}

	public void setUid(String uid) {
		this.uid = uid;
	}

	@Override
	public String toString() {
		return "account=" + account + ",password=" + password
				+ ",access_token=" + access_token + ",tenant_id=" + tenant_id
				+ ",uid=" + uid ;
	}

	
	
	
}
