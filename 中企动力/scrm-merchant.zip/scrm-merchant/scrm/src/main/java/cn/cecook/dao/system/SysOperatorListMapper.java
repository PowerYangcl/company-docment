package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import cn.cecook.model.system.SysOperatorList;

public interface SysOperatorListMapper {


    int deleteByPrimaryKey(Integer id);

    int insert(SysOperatorList record);

    int insertSelective(SysOperatorList record);


    SysOperatorList selectByPrimaryKey(Integer id);



    int updateByPrimaryKeySelective(SysOperatorList record);

    int updateByPrimaryKey(SysOperatorList record);
    
    List<SysOperatorList> queryList(Map<String,Object> map);
}