package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmActivityTagDefined;
import cn.cecook.model.business.markting.BmActivityTagDefinedExample;

/**
 * 
* @explain 自定义活动标签表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BmActivityTagDefinedMapper {
    int countByExample(BmActivityTagDefinedExample example);

    int deleteByExample(BmActivityTagDefinedExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmActivityTagDefined record);

    int insertSelective(BmActivityTagDefined record);

    List<BmActivityTagDefined> selectByExample(BmActivityTagDefinedExample example);

    BmActivityTagDefined selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmActivityTagDefined record, @Param("example") BmActivityTagDefinedExample example);

    int updateByExample(@Param("record") BmActivityTagDefined record, @Param("example") BmActivityTagDefinedExample example);

    int updateByPrimaryKeySelective(BmActivityTagDefined record);

    int updateByPrimaryKey(BmActivityTagDefined record);
}