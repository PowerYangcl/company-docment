package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmCompanyCard;
import cn.cecook.model.business.markting.BmConverTopTen;
import cn.cecook.model.business.markting.BmOpenTopTen;

public interface BmCompanyCardMapper {
    int deleteByPrimaryKey(Long id);

    int insert(BmCompanyCard bmCompanyCard);

    //插入企业名片数据
    int insertSelective(BmCompanyCard bmCompanyCard);

    // 根据企业名片id查询数据 
    BmCompanyCard selectByPrimaryKey(Long id);

    // 根据user id查询数据 
    BmCompanyCard selectByUserId(Long id);
    //二次点击暂存时进行的修改操作
    int updateByPrimaryKeySelective(BmCompanyCard bmCompanyCard);

    int updateByPrimaryKey(BmCompanyCard bmCompanyCard);
    
    //删除名片
    int deleteCard(long card_id);
    //获取名片列表
    List<Map<String,Object>> queryCardList(Map<String, Object> map);
    //统计数量
    int countNum(Map<String, Object> map);
    //创建名片时查询是否有相同名字
    String queryName(String companyName);
   //重新编辑名片时查询是否有相同名字
    String queryNamebian(Map<String, Object> map);
    
    int setShardCard(long card_id);
    
    Long getShareCardId();
    //名片统计（微信）
    List<Map<String,Object>> statisticsByWeChat(Map<String,Object> map);
    //名片统计（其他）
    List<Map<String,Object>> statisticsByOther(Map<String,Object> map);
    //个人名片统计（当日）
    Map<String,Object> statisticsForDate(long card_id);
    //个人名片统计（当月）
    Map<String,Object> statisticsForMonth(long card_id);
    //个人名片统计（当年）
    Map<String,Object> statisticsForYear(long card_id);
    //统计打开量前十的数据
    List<BmOpenTopTen> openTopTen();
    //统计转化量前十的数据
    List<BmConverTopTen> convertTopTen();
    //根据名片统计打开量
    BmOpenTopTen openOfmine(long card_id);
    //根据名片统计转化量
    BmConverTopTen convertOfmine(long card_id);

    Integer selectUserIdByPrimaryKey(Long id);

    Integer getUserCardCount(String id);
    //组织架构-删除了员工后，名片列表页会报错，需删除员工时一并删除此员工名片
	int deleteCardById(long id);
}