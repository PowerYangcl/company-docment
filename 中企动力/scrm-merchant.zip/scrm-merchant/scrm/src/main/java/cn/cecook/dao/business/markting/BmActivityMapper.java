package cn.cecook.dao.business.markting;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.security.access.method.P;

import cn.cecook.bean.business.markting.ActivityBean;
import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.markting.BmActivity;
import cn.cecook.model.business.markting.BmActivityExample;
import cn.cecook.uitls.Pages;

/**
 * 
 * @explain 活动表
 * @author wschenyongyin
 * @date 2017年5月22日
 */
public interface BmActivityMapper {
	int countByExample(BmActivityExample example);

	int deleteByExample(BmActivityExample example);

	List<BmActivity> selectByExample(BmActivityExample example);

	int updateByExampleSelective(@Param("record") BmActivity record,
                                 @Param("example") BmActivityExample example);

	int updateByExample(@Param("record") BmActivity record,
                        @Param("example") BmActivityExample example);

	int deleteByPrimaryKey(Long id);

	int insert(BmActivity record);

	int insertSelective(BmActivity record);

	BmActivity selectByPrimaryKey(Long id);

	int updateByPrimaryKeySelective(BmActivity record);

	int updateByPrimaryKey(BmActivity record);

	int suspendActivity(Long id);

	int activateActivity(Long id);

	int checkActivity(Map<String, Object> map);

	List<ActivityBean> queryBmActivityList(Map<String, Object> map);

	int createShare(BmActivity record);

	ActivityBean queryDetail(Long id);

	// 获取热门活动列表
	List<ActivityBean> countHotActivity(Map<String, Object> map);

	// 统计
	int totalCount(Map<String, Object> map);

	int getTransmitRule(long id);

	List<Map<String, Object>> activityCount(Map<String, Object> map);

	String queryName(String name);

	// 更新时查询是否有重复
	String queryUpdateName(Map<String, Object> map);

	int updateStatistical(BmActivity record);

	// 活动用自定义模板创建的活动列表//
	List<Map<String, Object>> getActivityListByDefined(Map<String, Object> map);

	// 获取用系统模板创建的活动列表
	List<Map<String, Object>> getActivityListBySys(Map<String, Object> map);

	// 统计使用系统模板创建的活动的个数
	int countSysActivity(Map<String, Object> map);

	// 统计使用自定义模板创建的活动的个数
	int countDefinedActivity(Map<String, Object> map);

	// 查询其他渠道的点击数，领取优惠券数，转化比例 -->
	Map<String, Object> statisticsOtherChannel(@Param("id") long id,
                                               @Param("activity_type") int activity_type);

	// 人脉统计数据
	Map<String, Object> queryContacts(@Param("id") long id,
                                      @Param("transmitTag") String transmitTag,
                                      @Param("activity_type") int activity_type);

	// 根据活动截止时间更新活动状态
	int updateStatusByEndTime(long id);

	// <!-- 判断活动时间是否到期 -->
	long checkEndTime(long id);

	// 获取活动状态
	int getActivityState(long id);

	int countMicroPortalActivity(Map<String, Object> map);

	// 锁定编辑状态
	int lock(long id);

	// 解除编辑状态锁定
	int unlock(long id);

	// 查询编辑状态
	String queryLockStatus(long id);

	// 短信活动列表
	List<Map<String, Object>> getSmsActivity(String keyWord);

	// 获取活动连接
	String getActivityUrl(int id);

	// 获取所有活动转化数量
	public int getActivityConverNum(Map<String, Object> map);

	// 社交活动人数转化占比
	public List<Map<String,Object>> ActivityConverRatio(Map<String, Object> map);

	// 社交活动打开渠道占比
	public Map<String,Object> OpenChannelRatio();

	// 每日社交活动转化人数
	public List<Map<String,Object>> ActivityConverNumByDay(Map<String, Object> map);

	// 拿到所有活动的时间
	Map<String, Object> getActivityDate();

	//根据开始时间、结束时间获取活动次数
	int getActivityNums(Map<String, Object> map);
	
	//根据开始时间、结束时间获取活动分享次数
	Integer getActivityShareNums(Map<String, Object> map);

	//根据开始时间、结束时间获取活动渠道占比
	List<Map<String, Object>> getActivityShareGroupNums(Map<String, Object> map);

	//获取报告大厅最热活动
	List<Map<String, Object>> activityStatistics(Map<String, Object> map);
	
	//初始化微博找人数量线索总数
	Integer getInitPeoDiv();
	
	//首页表格活动展示内容
	List<Map<String, Object>> activityConverForDay(Map<String, Object> map);
	
	Integer insertCustomActivity(BmActivity activityBean);
	
	//---------------------业务-------------------------------------
	
	//业务列表
	List<Map<String, Object>> getDistinctionList(Pages<Map<String, Object>> page);

	//业务总条数
	Integer getCountDistinction();

	//业务添加
	Integer createDisinction(BmActivity activity);

	//业务删除
	Integer del_distinction(@Param("date") Date date, @Param("id") Integer id);

	//业务编辑回显
	BmActivity getData(@Param("id") Integer id);

	//业务编辑保存
	Integer updateDisinction(BmActivity activity);

	//业务预览页返回数据
	BmActivity getPreview(@Param("uuid_tenant_id") String uuid_tenant_id,@Param("id") Integer id);

    // 模糊查询总条数
	Integer selectCountSysActivity(@Param(value="name") String name);
	// 通过业务名字模糊查询
	public List<ActivityBean> getByName(@Param(value="startIndex")Object startIndex,
			                         @Param(value="pageSize")Object pageSize,
			                         @Param(value="name")String name);

	List<ActivityBean> getBusinessLikelist(Map<String, Object> map);

	int getBusinessLikelistCount(Map<String, Object> map);

	List<ActivityBean> getActivityLikelist(Map<String, Object> map);
	//模糊查询活动列表
	int getActivityLikelistCount(Map<String, Object> map);

	BmActivity getId(@Param("uuid") String uuid);

	void addWebUrl(@Param("webUrl") String webUrl,@Param("uuid") String uuid,@Param("id") Long id);
	
	List<String> activityNameListByThirdCouponModelId(@Param("modelId")int thirdPartyCouponModelId);
}