package cn.cecook.bean.business.markting;

import java.io.Serializable;

public class MusicBean implements Serializable {
	private long id;
	private String uuid;
	private String tenant_id;
	private int is_deleted;
	private String create_id;
	private String create_time;
	private String order_code;
	private int delete_time;
	private String remarks;
	private String attachment;
	private String name;
	private double size;
	private int duration;
	private String author;
	private String url;
	private String lyric;
	private String format;
	private String background_pic;
	public long getId() {
		return id;
	}
	public void setId(long id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}
	public int getIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}
	public String getCreate_id() {
		return create_id;
	}
	public void setCreate_id(String create_id) {
		this.create_id = create_id;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public String getOrder_code() {
		return order_code;
	}
	public void setOrder_code(String order_code) {
		this.order_code = order_code;
	}
	public int getDelete_time() {
		return delete_time;
	}
	public void setDelete_time(int delete_time) {
		this.delete_time = delete_time;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public double getSize() {
		return size;
	}
	public void setSize(double size) {
		this.size = size;
	}
	public int getDuration() {
		return duration;
	}
	public void setDuration(int duration) {
		this.duration = duration;
	}
	public String getAuthor() {
		return author;
	}
	public void setAuthor(String author) {
		this.author = author;
	}
	public String getUrl() {
		return url;
	}
	public void setUrl(String url) {
		this.url = url;
	}
	public String getLyric() {
		return lyric;
	}
	public void setLyric(String lyric) {
		this.lyric = lyric;
	}
	public String getFormat() {
		return format;
	}
	public void setFormat(String format) {
		this.format = format;
	}
	public String getBackground_pic() {
		return background_pic;
	}
	public void setBackground_pic(String background_pic) {
		this.background_pic = background_pic;
	}
	@Override
	public String toString() {
		return "musicBean [id=" + id + ", uuid=" + uuid + ", tenant_id="
				+ tenant_id + ", is_deleted=" + is_deleted + ", create_id="
				+ create_id + ", create_time=" + create_time + ", order_code="
				+ order_code + ", delete_time=" + delete_time + ", remarks="
				+ remarks + ", attachment=" + attachment + ", name=" + name
				+ ", size=" + size + ", duration=" + duration + ", author="
				+ author + ", url=" + url + ", lyric=" + lyric + ", format="
				+ format + ", background_pic=" + background_pic + "]";
	}
	
	
	
}
