package cn.cecook.controller.business.markting;

import java.util.Map;

import cn.cecook.uitls.StringUtils;

import org.apache.log4j.Logger;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import cn.cecook.thirdparty.weibo.util.URLEncodeUtils;
import cn.cecook.uitls.CookieUtil;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@Controller
@RequestMapping("/api/bm/ui")
public class BmUIController {
	Logger logger=Logger.getLogger(BmUIController.class);
	
	@Value("#{configProperties['WEIXIN_AUTH_REDIRECT_PATH']}")
	private String WEIXIN_AUTH_REDIRECT_PATH;
	@Value("#{configProperties['OPEN_ACTIVITY_URL']}")
	private String OPEN_ACTIVITY_URL;

	@Value("#{configProperties['OPEN_CARD_URL']}")
	private String OPEN_CARD_URL;

	@Value("#{configProperties['IS_ONLINE']}")
	private String IS_ONLINE;
	@Value("#{configProperties['WEIXIN_APPID']}")
	private String WEIXIN_APPID;
	@Value("#{configProperties['WEIXIN_APPSECRET']}")
	private String WEIXIN_APPSECRET;

	@RequiresPermissions("scrm_markting_activity_h5")
	@RequestMapping("/activityHome")
	public String activityManage() {
		return "bm/activityList";
	}

	@RequiresPermissions("login")
	@RequestMapping("/activityDetail")
	public String activityDetail() {
		return "bm/activityDetail";
	}

	@RequiresPermissions("login")
	@RequestMapping("/createActivity1")
	public String activityCreate1() {
		return "bm/createActivity1";
	}

	@RequiresPermissions("login")
	@RequestMapping("/createActivity2")
	public String activityCreate2() {
		return "bm/createActivity2";
	}

	@RequiresPermissions("login")
	@RequestMapping("/createActivity3")
	public String activityCreate3() {
		return "bm/createActivity3";
	}

	@RequestMapping("/createActivity4")
	public String activityCreate4() {
		return "bm/createActivity4";
	}

	@RequiresPermissions("login")
	@RequestMapping("/model")
	public String modelManage() {
		return "bm/activityModelList";
	}

	@RequiresPermissions("scrm_markting_activity_coupon")
	@RequestMapping("/write_off")
	public String writeOff() {
		return "bm/writeOff";
	}

	@RequestMapping("mobileTerminal")
	public String inddd() {
		return "bm/mobileTerminal";
	}

	@RequestMapping("/mobileComment")
	public String indee() {
		return "bm/mobileComment";
	}

	@RequestMapping("/mobileActivity1")
	public ModelAndView openActivity(HttpServletRequest request,
			HttpServletResponse response) {
		String userAgent = request.getHeader("user-agent").toLowerCase();
		ModelAndView mav = new ModelAndView();
		String strBackUrl = "http://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath()
				+ OPEN_ACTIVITY_URL + "?" + (request.getQueryString());
		// 判断cookies是否存在openId
		Cookie[] cookies = request.getCookies();
		Map map = CookieUtil.getCookieSet(cookies);
		String openId = "";
		if (map != null) {
			openId = (String) map.get("weixinOpenId");
		}
		if (userAgent.indexOf("micromessenger") > -1
				&& StringUtils.isEmpty(openId) && IS_ONLINE.equals("true")) {// 微信客户端
			request.setAttribute("isWx", "1");
			strBackUrl = URLEncodeUtils.encodeURL(strBackUrl);
			String redirect = URLEncodeUtils
					.encodeURL(WEIXIN_AUTH_REDIRECT_PATH + strBackUrl);
			String weixinUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="
					+ WEIXIN_APPID
					+ "&redirect_uri="
					+ redirect
					+ "&response_type=code&scope=snsapi_base&state=123#wechat_redirect";
			mav.setView(new RedirectView(weixinUrl));
			logger.info("进入微信获取openId");
			return mav;
		} else {
			mav.setView(new RedirectView(strBackUrl));
			return mav;
		}
	}

	@RequestMapping("/openActivity")
	public String indff() {
		return "bm/mobileActivity1";
	}

	@RequestMapping("/mobileActivity2")
	public String indgg() {
		return "bm/mobileActivity2";
	}

	@RequestMapping("/mobileActivity3")
	public String indhh() {
		return "bm/mobileActivity3";
	}

	@RequestMapping("/branchOffice")
	public String indii() {
		return "bm/branchOffice";
	}

	@RequiresPermissions("login")
	@RequestMapping("/photoAlbum")
	public String photoAlbum() {
		return "bm/photoAlbum";
	}

	@RequestMapping("/photoAlbum2")
	public String photoAlbum2() {
		return "bm/photo_mobile";
	}

	@RequestMapping("/photoPreview")
	public String photoPreview() {
		return "bm/photo_preview";
	}

	@RequiresPermissions("login")
	@RequestMapping("/createModel")
	public String createModel() {
		return "bm/createModel";
	}

	@RequiresPermissions("login")
	@RequestMapping("/marketList")
	public String marketList() {
		return "bm/marketHome";
	}

	@RequiresPermissions("login")
	@RequestMapping("/preview_model")
	public String preview_model() {
		return "bm/preview_model";
	}

	//跳转业务页面
	@RequiresPermissions("login")
	@RequestMapping("/activityDialig")
	public String activityDialig() {
		return "bm/activityDialig";
	}

	////跳转活动页面
	@RequiresPermissions("login")
	@RequestMapping("/tuijianDetailDialog")
	public String Activity_TuijianDetailDialog() {
		return "bm/activityDialig_tuijian";
	}

	/**
	 * 
	 * Title: companyCard Description:名片
	 * 
	 * @return
	 */

	@RequiresPermissions("login")
	@RequestMapping("companyCard")
	public String companyCard() {
		return "bm/companyCard";
	}

	@RequiresPermissions("login")
	@RequestMapping("cardPreview")
	public String cardPreview() {
		return "bm/cardPreview";
	}

	@RequestMapping("openCard")
	public String cardMobile() {
		return "bm/cardmobile";
	}

	@RequestMapping("/card")
	public ModelAndView openCard(HttpServletRequest request,
			HttpServletResponse response) {
		String userAgent = request.getHeader("user-agent").toLowerCase();
		ModelAndView mav = new ModelAndView();
		String strBackUrl = "http://" + request.getServerName() + ":"
				+ request.getServerPort() + request.getContextPath()
				+ OPEN_CARD_URL + "?" + (request.getQueryString());
		Cookie[] cookies = request.getCookies();
		Map map = CookieUtil.getCookieSet(cookies);
		String openId = "";
		if (map != null) {
			openId = (String) map.get("weixinOpenId");
		}
		if (userAgent.indexOf("micromessenger") > -1
				&& StringUtils.isEmpty(openId) && IS_ONLINE.equals("true")) {// 微信客户端
			request.setAttribute("isWx", "1");
			strBackUrl = URLEncodeUtils.encodeURL(strBackUrl);
			String redirect = URLEncodeUtils
					.encodeURL(WEIXIN_AUTH_REDIRECT_PATH + strBackUrl);
			String weixinUrl = "https://open.weixin.qq.com/connect/oauth2/authorize?appid="
					+ WEIXIN_APPID
					+ "&redirect_uri="
					+ redirect
					+ "&response_type=code&scope=snsapi_base&state=123#wechat_redirect";

			mav.setView(new RedirectView(weixinUrl));
			return mav;
		} else {

			mav.setView(new RedirectView(strBackUrl));
			return mav;
		}
	}

	@RequiresPermissions("scrm_markting_activity")
	@RequestMapping("cardHome")
	public String cardHome() {
		return "bm/companyCardHome";
	}

	/**
	 * 
	 * Title: preview_model Description:邀请函
	 * 
	 * @return
	 */
	// 编辑
	@RequiresPermissions("login")
	@RequestMapping("/invitation01")
	public String invitation_letter_edit() {
		return "bm/invitation_letter_edit";
	}

	@RequiresPermissions("login")
	@RequestMapping("/invitation02")
	public String invitation_letter_preview() {
		return "bm/invitation_letter_preview";
	}

	@RequiresPermissions("login")
	@RequestMapping("/invitation03")
	public String invitation_letter_share() {
		return "bm/invitation_letter_share";
	}

	@RequestMapping("/invitation04")
	public String invitation_letter_mobile(HttpServletRequest httpServletRequest) {
		String customer_id = httpServletRequest.getParameter("cid");
		if (StringUtils.isEmpty(customer_id)) {
			return "bm/invitation_letter_mobile";
		} else {
			return "bm/invitation_letter_mobile2";
		}

	}

	@RequiresPermissions("login")
	@RequestMapping("/marketdetail")
	public String market_detail() {
		return "bm/market_detail";
	}

	// 微门户
	@RequiresPermissions("scrm_information_send_template")
	@RequestMapping("/microPortal")
	public String microPortal() {
		return "bm/microPortal";
	}

	// 模板浏览跳转
	@RequestMapping("/graphic")
	public String graphicModel() {
		return "bm/model_graphic_mobile";
	}

	// 查看分店列表
	@RequestMapping("/branch")
	public String branchStore() {
		return "bm/mobile_branch_store";
	}

	// 查看分店列表
	@RequestMapping("/store")
	public String Store() {
		System.out.println("store------->");
		return "bm/store";
	}

	@RequestMapping("/microStore")
	public String microStore() {
		System.out.println("store------->");
		return "bm/microStore";
	}

	/**
	 * 智能营销
	 */
	// 智能营销模板
	@RequiresPermissions("login")
	@RequestMapping("/marketmodel")
	public String market_model() {
		return "bm/market_model";
	}

	@RequiresPermissions("login")
	@RequestMapping("/createMarket")
	public String createMarket() {
		return "bm/createMarket";
	}

	@RequiresPermissions("login")
	@RequestMapping("/createMarket02")
	public String createMarketByActivityOne() {
		return "bm/createMarketByActivityOne";
	}

	/**
	 * 优惠券
	 */
	@RequiresPermissions("login")
	@RequestMapping("/modal_coupon")
	public String modalCoupon() {
		return "social/modal_coupon";
	}
	@RequiresPermissions("login")
	@RequestMapping("/modal_coupon_multiple")
	public String modalCouponMultiple() {
		return "social/modal_coupon_multiple";
	}

	/**
	 * 短信营销
	 */
	@RequiresPermissions("login")
	@RequestMapping("/choseSendObject")
	public String choseSendObject() {
		System.out.println("------------------->");
		return "social/choseSendObject";
	}

	@RequiresPermissions("login")
	@RequestMapping("/editSendContent")
	public String editSendContent() {
		return "social/editSendContent";
	}

	@RequiresPermissions("scrm_information_send_many")
	@RequestMapping("/smsBatch")
	public String smsBatch() {
		return "social/smsBatch";
	}

	@RequiresPermissions("login")
	@RequestMapping("/smsStatistics")
	public String smsStatistics() {
		return "social/smsStatistics";
	}

	@RequiresPermissions("login")
	@RequestMapping("/social_coupon")
	public String socialScoupon() {
		return "social/social_coupon";
	}

	@RequiresPermissions("login")
	@RequestMapping("/conver_list")
	public String converList() {
		return "social/formConver";
	}

	@RequiresPermissions("login")
	@RequestMapping("/click_list")
	public String clickList() {
		return "social/formClick";
	}

	@RequiresPermissions("login")
	@RequestMapping("/socialTool")
	public String SocialTool() {
		return "social/socialTool";
	}

	@RequiresPermissions("login")
	@RequestMapping("/reportHall")
	public String ReportHall() {
		return "social/reportHall";
	}

	@RequiresPermissions("scrm_information_send_template")
	@RequestMapping("/smsModelHome")
	public String SmsModelHome() {
		return "social/smsModelHome";
	}

	@RequiresPermissions("login")
	@RequestMapping("/modalSmsModel")
	public String ModalSmsModel() {
		return "social/modalSmsModel";
	}

	@RequiresPermissions("login")
	@RequestMapping("/smsModelEdit")
	public String SmsModelEdit() {
		return "social/smsModelEdit";
	}

	@RequiresPermissions("scrm_markting_activity_report")
	@RequestMapping("/cardStatistics")
	public String cardStatistics() {
		return "social/cardStatistics";
	}
	 
    //统计报告页面
//    @RequiresPermissions("login")
	@RequestMapping(value="/statisticalReport",produces="text/plain;charset=UTF-8")
    public String statisticalReport() {
    	return "social/statisticalReport";
    }
	
	//统计详情页面
//  @RequiresPermissions("login")
	@RequestMapping(value="/statisticalInfo",produces="text/plain;charset=UTF-8")
	public String statisticalInfo() {
		return "social/statisticalInfo";
	}
	
	//统计详情页面
//  @RequiresPermissions("login")
	@RequestMapping(value="/cardMember",produces="text/plain;charset=UTF-8")
	public String cardMember() {
		return "social/cardMember";
	}
	
	/**
	 * 注券
	 */
	@RequestMapping("/couponBatch")
	public String couponBatch() {
		return "social/couponBatch";
	}
	
	@RequestMapping("/couponBatchStatistics")
	public String couponBatchStatistics() {
		return "social/couponBatchStatistics";
	}
	@RequestMapping("/couponBatchConverList")
	public String couponBatchConverList() {
		return "social/couponFormConver";
	}
	@RequestMapping("/couponBatchClickList")
	public String couponBatchClickList() {
		return "social/couponFormClick";
	}
	@RequestMapping("/couponBatchCreate")
	public String couponBatchCreate() {
		return "social/couponBatchCreate";
	}
	@RequestMapping("/couponBatchEdit")
	public String couponBatchEdit() {
		return "social/couponBatchEdit";
	}
	
	@RequestMapping("/createCoupon")
	public String createCoupon() {
		return "social/couponCreate";
	}
	@RequestMapping("/writeOffForm")
	public String writeOffForm() {
		return "social/writeOffForm";
	}
	
	@RequestMapping("/mobileCoupon")
	public String mobileCouponList() {
		return "social/mobileCouponPage";
	}
	
	@RequestMapping("/mobileBindCustomer")
	public String mobileBindCustomer() {
		return "social/bindCustomerPage";
	}
	
	@RequestMapping("/couponReport")
	public String couponBatchReport() {
		return "social/couponReport";
	}

	/**
	 * 二维码
	 */
	@RequestMapping("/qrCodeManager")
	public String qrCodeManager(){
		return "social/qrCodeManager";
	}
	@RequestMapping("/showActivity")
	public String showActivity(){
		return "social/showActivity";
	}
	
	
	@RequestMapping("/showActivity2")
	public String showActivity2(){
		return "system/showActivity";
	}
	@RequestMapping("/showActivity3")
	public String showActivity3(){
		return "system/activityDialig";
	}
	@RequestMapping("/showDepartment")
	public String showDepartment(){
		return "system/showDepartment";
	}
	@RequestMapping("/qrCount")
	public String qrCount(){
		return "social/qrCodeCount";
	}
	
	/**
	 * 业务页面
	 */
	@RequestMapping("/toDistinctionList")
	public String toDistinctionList(){
		return "bm/distinctionList";
	}
	
	/**
	 * 药品扫码页面
	 */
	@RequiresPermissions("scrm_drugs_inquiries")
	@RequestMapping("/showDrugScant")
	public String showDrugScant(){
		return "social/drugScanAdd";
	}
	/**
	 * 
	* Title: showDrugScant
	* Description:手机端查看优惠券详情
	* @return
	 */
	@RequestMapping("/mobileCouponDetail")
	public String mobileCouponDetail(){
		return "social/mobileCouponDetail";
	}
	
	/**
	 * 
	* @Description: 第三方券统计
	* @return
	*
	* @author: wschenyongyin
	* @date: 2018年3月20日 下午7:28:22
	 */
	@RequestMapping("/thirdPartyCouponStatistics")
	public ModelAndView thirdPartyCouponStatistics(String modelId){
		ModelAndView modelAndView = new ModelAndView("social/modalThirdPartyCouponStatistics");
		modelAndView.addObject("modelId",modelId);
		return modelAndView;
	}
	
}