package cn.cecook.model.business.automation;
/**
 * 药品用法用量表
 * @author majie
 * @date 2018年3月24日-下午3:53:15
 */
public class BaseMedicineDosage {
	private Integer id;
	//药品名称
	private String medicineName;
	//批准文号
	private String approvalNumber;
	//条形码
	private String barCode;
	//一次使用量
	private Integer onceUseNumber;
	//一天使用次数
	private Integer dayseNumber;
	//商品规格
	private Integer packingSpecifications;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getMedicineName() {
		return medicineName;
	}
	public void setMedicineName(String medicineName) {
		this.medicineName = medicineName;
	}
	public String getApprovalNumber() {
		return approvalNumber;
	}
	public void setApprovalNumber(String approvalNumber) {
		this.approvalNumber = approvalNumber;
	}
	public String getBarCode() {
		return barCode;
	}
	public void setBarCode(String barCode) {
		this.barCode = barCode;
	}
	public Integer getOnceUseNumber() {
		return onceUseNumber;
	}
	public void setOnceUseNumber(Integer onceUseNumber) {
		this.onceUseNumber = onceUseNumber;
	}
	public Integer getDayseNumber() {
		return dayseNumber;
	}
	public void setDayseNumber(Integer dayseNumber) {
		this.dayseNumber = dayseNumber;
	}
	public Integer getPackingSpecifications() {
		return packingSpecifications;
	}
	public void setPackingSpecifications(Integer packingSpecifications) {
		this.packingSpecifications = packingSpecifications;
	}
	@Override
	public String toString() {
		return "BaseMedicineDosage [id=" + id + ", medicineName=" + medicineName + ", approvalNumber=" + approvalNumber
				+ ", barCode=" + barCode + ", onceUseNumber=" + onceUseNumber + ", dayseNumber=" + dayseNumber
				+ ", packingSpecifications=" + packingSpecifications + "]";
	}	
}
