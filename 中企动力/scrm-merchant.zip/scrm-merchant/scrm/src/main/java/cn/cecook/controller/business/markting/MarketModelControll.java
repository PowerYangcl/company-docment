package cn.cecook.controller.business.markting;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.MarketModelService;

/**
 * 
 * @Title MarketModelControll.java
 * @Description 智能营销模板controll
 * @author wschenyongyin
 * @date 2017年6月1日
 * @version 1.0
 */

@Controller
@RequestMapping("api/market_model")
public class MarketModelControll {

    @Resource
    MarketModelService marketModelService;

    /**
     * 
     * Title: getList Description:获取模板列表
     * 
     * @param uid 用户id
     * @param tenant_id 租户id
     * @return
     */
    @RequestMapping(value = "/list")
    @ResponseBody
    public Object getList(String uid, String tenant_id,String key_word,String tag) {
        return (marketModelService.getModelList(uid, tenant_id,key_word,tag));
    }

    /**
     * 
     * Title: getDetail Description:获取模板详情
     * 
     * @param uid 用户id
     * @param tenant_id 租户id
     * @param model_id 模板id
     * @return
     */
    @RequestMapping(value = "/detail")
    @ResponseBody
    public Object getDetail(String uid, String tenant_id, String model_id) {
        return (marketModelService.getModelDetail(uid, tenant_id, model_id));
    }

    /**
     * 
     * Title: activate Description:启用模板
     * 
     * @param uid 用户id
     * @param tenant_id 租户id
     * @param model_id 模板id
     * @return
     */
    @RequestMapping(value = "/activate")
    @ResponseBody
    public Object activate(String uid, String tenant_id, String model_id) {
        return (marketModelService.activateModel(uid, tenant_id, model_id));

    }

    /**
     * 
     * Title: suppend Description:停用模板
     * 
     * @param uid 用户id
     * @param tenant_id 租户id
     * @param model_id 模板id
     * @return
     */
    @RequestMapping(value = "/suspend")
    @ResponseBody
    public Object suppend(String uid, String tenant_id, String model_id) {
        return (marketModelService.suspendModel(uid, tenant_id, model_id));

    }
    
	/**
	 * 
	 * Title: manageRecommend Description:管理推荐模型
	 * 
	 * @param tag
	 *            0表示取消推荐 1表示推荐
	 * @param model_id
	 *            模板id
	 * @return
	 */
    @RequestMapping(value = "/mangeRecommend")
    @ResponseBody
    public Object mangeRecommend(String model_id, String tag) {
        return (marketModelService.manageRecommend(tag, model_id));

    }

}
