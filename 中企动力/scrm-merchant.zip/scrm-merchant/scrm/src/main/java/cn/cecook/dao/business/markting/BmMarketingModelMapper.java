package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.bean.business.markting.MarketModelBean;
import cn.cecook.model.business.markting.BmMarketingModel;


public interface BmMarketingModelMapper {

	int insert(BmMarketingModel record);

	int insertSelective(BmMarketingModel record);

	BmMarketingModel selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(BmMarketingModel record);

	MarketModelBean getModelDetail(int id);

	List<Map<String,Object>> getModelList(Map<String, Object> map);

	int suspend(int id);

	int activate(int id);

	int countUseNum(int id);

	int manageRecommend(Map<String, Integer> map);
}