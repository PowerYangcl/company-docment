package cn.cecook.controller.business.markting;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.markting.SocialQrcodeBrowse;
import cn.cecook.model.business.markting.SocialQrcodeInfo;
import cn.cecook.service.business.markting.SocialQrcodeInfoService;

/**
 * 二维码管理控制器
 * @author majie
 *
 * 2017年12月13日-上午11:11:07
 */
@Controller
@RequestMapping("/api/social")
public class SocialQrcodeInfoController{
	
	@Resource 
	private SocialQrcodeInfoService socialQrcodeInfoService;
	
    private Logger logger = Logger.getLogger(SocialQrcodeInfoController.class);
	/**
	 * 添加二维码信息
	 * @param socialQrcodeInfo
	 * @return
	 * majie
	 */
	@RequestMapping("/addSocialQrcodeInfo")
	@ResponseBody
	public Object addSocialQrcodeInfo(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,SocialQrcodeInfo socialQrcodeInfo){
		socialQrcodeInfo.setTenantId(tenant_id);
		socialQrcodeInfo.setUuid(uid);
		return socialQrcodeInfoService.addSocialQrcodeInfo(socialQrcodeInfo);
	}
	/**
	 * 获得Url指定条件的扫码记录
	 * @param param
	 * @return
	 * majie
	 */
	@RequestMapping("/getAllBrowseByUrl")
	@ResponseBody
	public Object getAllBrowseByStore(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,@RequestBody String param){
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		JsonElement jsonElement = jsonObj.get("extra_search");
		JsonObject json = jsonElement.getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		JsonElement sorts =jsonObj.get("order");
		JsonArray asJsonArray=null;
		Map<String,Object> map=new HashMap<>();
		map.put("storeId",json.get("storeId"));
		map.put("date",json.get("date"));
		map.put("codeType",json.get("codeType"));
		map.put("startIndex", startIndex);
		map.put("pageSize", pageSize);
		map.put("bindType",json.get("bindType"));
		if(sorts!=null){
			asJsonArray = sorts.getAsJsonArray();
		}
		for (int i = 0; i < asJsonArray.size(); i++) {
			JsonObject sort = asJsonArray.get(i).getAsJsonObject();
			String column = sort.get("column").getAsString();
			if("2".equals(column)){
				map.put("clickSort",sort.get("dir").getAsString());
			}
			if("3".equals(column)){
				map.put("clickMemberSort",sort.get("dir").getAsString());
			}
		}	
		BaseResultModel  baseDatas= (BaseResultModel) socialQrcodeInfoService.getAllBrowseByUrl(map);
		BaseResultModel  baseCount= (BaseResultModel) socialQrcodeInfoService.getAllBrowseCount(map);
		if(baseCount!=null&&baseCount.getData()==null){
			baseCount.setData(0);
		}
		if(baseDatas!=null&&baseDatas.getData()==null){
			baseDatas.setData(new ArrayList<>());
		}
		Map<String,Object> resultMap=new HashMap<>();
		resultMap.put("recordsTotal", baseCount.getData());
		resultMap.put("data", baseDatas.getData());
		resultMap.put("recordsFiltered", baseCount.getData());
		resultMap.put("draw", draw);
		logger.info(resultMap);
		return resultMap;
	}
	/**
	 * 获得Url指定条件的扫码记录
	 * @param param
	 * @return
	 * majie
	 */
	@RequestMapping("/getAllBrowseByActivity")
	@ResponseBody
	public Object getAllBrowseActivity(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,@RequestBody String param){
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		JsonElement jsonElement = jsonObj.get("extra_search");
		JsonObject json = jsonElement.getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		JsonElement sorts =jsonObj.get("order");
		JsonArray asJsonArray=null;
		Map<String,Object> map=new HashMap<>();
		map.put("storeId",json.get("storeId"));
		map.put("date",json.get("date"));
		map.put("codeType",json.get("codeType"));
		map.put("startIndex", startIndex);
		map.put("pageSize", pageSize);
		map.put("bindType",json.get("bindType"));
		if(sorts!=null){
			asJsonArray = sorts.getAsJsonArray();
		}
		for (int i = 0; i < asJsonArray.size(); i++) {
			JsonObject sort = asJsonArray.get(i).getAsJsonObject();
			String column = sort.get("column").getAsString();
			if("2".equals(column)){
				map.put("clickSort",sort.get("dir").getAsString());
			}
			if("3".equals(column)){
				map.put("clickMemberSort",sort.get("dir").getAsString());
			}
		}
		BaseResultModel  baseDatas= (BaseResultModel) socialQrcodeInfoService.getAllBrowseByActivity(map);
		BaseResultModel  baseCount= (BaseResultModel) socialQrcodeInfoService.getAllBrowseCount(map);
		if(baseCount!=null&&baseCount.getData()==null){
			baseCount.setData(0);
		}
		if(baseDatas!=null&&baseDatas.getData()==null){
			baseDatas.setData(new ArrayList<>());
		}
		Map<String,Object> resultMap=new HashMap<>();
		resultMap.put("recordsTotal", baseCount.getData());
		resultMap.put("data", baseDatas.getData());
		resultMap.put("recordsFiltered", baseCount.getData());
		resultMap.put("draw", draw);
		logger.info(resultMap);
		return resultMap;
	}
	/**
	 * 跳转url
	 * @param request
	 * @param response
	 * @param params
	 * @param codeId
	 * @return
	 * majie
	 */
	@RequestMapping("/redirectUrl")
	public String redirectUrl(HttpServletRequest request,
			HttpServletResponse response){
		return "social/redirectUrl";
	}
	/**
	 * 添加记录
	 * @param request
	 * @param response
	 * @param params
	 * @param codeId
	 * @return
	 * majie
	 */
	@RequestMapping("/addQrcodeBrowse")
	@ResponseBody
	public Object addQrcodeBrowse(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,SocialQrcodeBrowse socialQrcodeBrowse){
		socialQrcodeBrowse.setTenantId(tenant_id);
		socialQrcodeBrowse.setUuid(uid);
		return socialQrcodeInfoService.addQrcodeBrowse(socialQrcodeBrowse);
	}
	/**
	 * 删除二维码信息
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param codeId
	 * @return
	 * majie
	 */
	@RequestMapping("/delelteQrcode")
	@ResponseBody
	public Object deleteQrcode(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String codeId){
		return socialQrcodeInfoService.deleteCode(codeId);
	}
	/**
	 * 删除门店下所有二维码信息
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param codeId
	 * @return
	 * majie
	 */
	@RequestMapping("/delelteQrcodeByStoreId")
	@ResponseBody
	public Object delelteQrcodeByStoreId(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String storeId,String codeType){
		Map<String,Object> map=new HashMap<>();
		map.put("storeId",storeId);
		map.put("codeType", codeType);
		return socialQrcodeInfoService.deleteQrcodeByStoreId(map);
	}
	/**
	 * 判断是否是活动
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param codeId
	 * @return
	 * majie
	 */
	@RequestMapping("/isActivity")
	@ResponseBody
	public Object isActivity(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String codeId){
		return socialQrcodeInfoService.isActivity(codeId);
	}
	/**
	 * 获取活动的统计数据
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param codeId
	 * @param startDate
	 * @param endDate
	 * @param flag
	 * @return
	 * majie
	 */
	@RequestMapping("/getCountByActivity")
	@ResponseBody
	public Object getCountByActivity(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String codeId,
			String startDate,String endDate,String flag,String storeId){
		Map<String,Object> map=new HashMap<>();
		map.put("uid", uid);
		map.put("access_token", access_token);
		map.put("tenant_id", tenant_id);
		map.put("flag", flag);
		map.put("codeId", codeId);
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("storeId", storeId);
		return socialQrcodeInfoService.getCountByActivity(map);
	}
	
	/**
	 * 获取自定义链接的统计数据
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param codeId
	 * @param startDate
	 * @param endDate
	 * @param flag
	 * @return
	 * majie
	 */
	@RequestMapping("/getCountByUrl")
	@ResponseBody
	public Object getCountByUrl(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String codeId,
			String startDate,String endDate,String flag,String storeId){
		Map<String,Object> map=new HashMap<>();
		map.put("uid", uid);
		map.put("access_token", access_token);
		map.put("tenant_id", tenant_id);
		map.put("flag", flag);
		map.put("codeId", codeId);
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("storeId", storeId);
		return socialQrcodeInfoService.getCountByUrl(map);
	}
	/**
	 * 导出统计数据
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param codeId
	 * @param startDate
	 * @param endDate
	 * @param flag
	 * @param storeId
	 * @return
	 * majie
	 */
	@RequestMapping("/exportExcel")
	@ResponseBody
	public Object exportExcel(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,String codeId,
			String startDate,String endDate,String flag,String storeId,String codeType,HttpServletResponse response,HttpServletRequest request){
		Map<String,Object> map=new HashMap<>();
		map.put("uid", uid);
		map.put("access_token", access_token);
		map.put("tenant_id", tenant_id);
		map.put("flag", flag);
		map.put("codeId", codeId);
		map.put("startDate", startDate);
		map.put("endDate", endDate);
		map.put("storeId", storeId);
		map.put("codeType",codeType);
		Object exportExcel = socialQrcodeInfoService.exportExcel(map,response);
		return exportExcel;
	}
}