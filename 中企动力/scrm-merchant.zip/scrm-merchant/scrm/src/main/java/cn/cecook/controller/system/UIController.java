package cn.cecook.controller.system;


import cn.cecook.bean.system.AuthorityModel;
import cn.cecook.intercept.shiro.shiroRedis.RedisManager;
import cn.cecook.intercept.shiro.shiroRedis.RedisSessionDAO;
import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpTicket;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpTicketService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.service.system.IAccountService;
import cn.cecook.service.system.ILoginService;
import cn.cecook.thirdparty.open.TokenUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.MD5Util;
import cn.cecook.uitls.StringUtils;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.authz.annotation.RequiresAuthentication;
import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import javax.servlet.http.HttpServletRequest;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Collection;
import java.util.Date;
import java.util.HashMap;
import java.util.List;

/**
 * @author LeeX
 * @explain 页面跳转专用
 * @date 2017年5月24日
 */
@Controller
@RequestMapping("/ui")
public class UIController {


    @Autowired
    private ILoginService iLoginService;

    @Autowired
    private IAccountService iAccountService;
    
    @Autowired
    private IMpAccountService iMpAccountService;
    
    @Autowired
    private IMpUserService iMpUserService;
    
    @Autowired
    private IMpTicketService iMpTicketService;

    /**
     * @explain 跳转到企业资料页（作废）
     * @author LeeX
     * @date 2017年6月3日 上午10:45:30
     */
    @RequiresAuthentication
    @RequestMapping("/showCompanyInfo")
    public String showCompanyInfo() {
        return "system/showCompanyInfo";
    }

    /**
     * @explain 跳客户线索
     * @author LeeX
     * @date 2017年5月31日 下午1:19:23
     */
    @RequiresPermissions("login")
    @RequestMapping("/customer")
    public String customer() {
        return "system/personalInfor";
    }

    /**
     * @explain 跳转到主页
     * @author LeeX
     * @date 2017年5月24日 下午8:50:28
     */
    @RequestMapping("/home")
    public String home() {
        return "system/home";
    }

    /**
     * @explain 跳转到注册页
     * @author LeeX
     * @date 2017年5月24日 下午8:50:40
     */
    @RequestMapping("/registerOne")
    public String registerOne() {
        
    	
    	return "system/registerOne";
    }

    /**
     * @explain 跳转到登录页（密码登录）
     * @author LeeX
     * @date 2017年5月24日 下午8:51:01
     */
    @RequestMapping("/loginPwd")
    public String loginPwd() {
        return "system/loginPwd";
    }


    /**
     * 跳转到注册第二个页面
     *
     * @explain
     * @author sunny
     * @date 2017年6月5日
     */
    @RequestMapping("/registerTwo")
    public String registerTwo() {
        return "system/registerTwo";
    }

    /**
     * 跳转到注册第三个页面
     *
     * @explain
     * @author sunny
     * @date 2017年6月5日
     */
    @RequestMapping("/registerThree")
    public String registerThree() {
        return "system/registerThree";
    }

    /**
     * 跳转到注册第四个页面
     *
     * @explain
     * @author sunny
     * @date 2017年6月5日
     */
    @RequestMapping("/registerFour")
    public String registerFour() {
        return "system/registerFour    ";
    }


    /**
     * @explain 跳转到企业资料页
     * @author LeeX
     * @date 2017年6月3日 上午10:45:30
     */
    @RequiresPermissions("login")
    @RequestMapping("/companyInfoShow")
    public String companyInfoShow() {
        return "system/editCompanyInfo";
    }
    
    /**
     * @explain 跳转添加活动权限控制页面
     * @author XuWei
     * @date 2017年12月20日 上午10:45:30
     */
    @RequiresPermissions("login")
    @RequestMapping("/activityAuthority")
    public String activityAuthority() {
        return "system/activityAuthority";
    }


    /**
     * @explain 跳转到登录页（验证码）
     * @author LeeX
     * @date 2017年5月24日 下午8:52:36
     */
    @RequestMapping("/loginCode")
    public String loginCode() {
        return "system/loginCode";
    }

    /**
     * @explain 跳转到找回密码页
     * @author LeeX
     * @date 2017年5月24日 下午8:53:15
     */
    @RequestMapping("/recoverPwd")
    public String recoverPwd() {
        return "system/recoverPwd";
    }

    /**
     * @explain 跳转到重置密码的新密码页
     * @author LeeX
     * @date 2017年6月2日 下午3:55:37
     */
    @RequestMapping(value = "/resetPwd")
    public String resetPwd(HttpServletRequest request) {
        String cz = request.getParameter("cz");
        if ("t".equalsIgnoreCase(cz)) {
            return "system/resetPwd";
        } else {
            return "system/recoverPwd";
        }
    }

    /**
     * @explain 跳转到密码重置成功页
     * @author LeeX
     * @date 2017年6月2日 下午3:56:38
     */
    @RequestMapping("/resetPwdSucc")
    public String resetPwdSucc() {
        return "system/resetPwdSucc";
    }

    /**
     * @explain 跳转到企业信息修改页面
     * @author XuW
     * @date 2017年12月13日 下午14:40:40
     */
    @RequiresPermissions("login")
    @RequestMapping("/companyInfoRegist")
    public String companyInfoRegist() {
        return "system/compangInfoRegist";
    }



    /**
     * @explain 跳转到企业注册修改信息页面
     * @author LeeX
     * @date 2017年6月5日 下午1:29:42
     */
    @RequiresPermissions("login")
    @RequestMapping("/companyInfoEdit")
    public String companyInfoEdit() {
        return "system/compangInfoEdit";
    }

    /**
     * @explain 跳转到账号管理页面
     * @author sunny
     * @date 2017年6月7日
     */
    @RequiresPermissions("login")
    @RequestMapping("/accountManagement")
    public String accountManagement() {
        return "system/accountManagement";
    }

    /**
     * @explain 跳转到部门管理
     * @author LeeX
     * @date 2017年6月3日 上午10:45:30
     */
    @RequiresPermissions("login")
    @RequestMapping("/divisionalManagement")
    public String divisionalManagement() {
        return "system/divisionalManagement";
    }

    /**
     * @explain 跳转到角色设置
     * @author LeeX
     * @date 2017年6月3日 上午10:45:30
     */
    @RequiresPermissions("login")
    @RequestMapping("/roleSet")
    public String roleSet() {
        return "system/roleSet";
    }

    /**
     * @explain 跳转个人资料页
     * @author LeeX
     * @date 2017年6月20日 下午4:37:16
     */
    @RequiresPermissions("scrm_setting_personal_center")
    @RequestMapping("/hplus_personalInfor")
    public String personalInfor() {
        return "system/hplus_personalInfor";
    }

    /**
     * @explain 跳社交账号
     * @author LeeX
     * @date 2017年6月20日 下午5:14:30
     */
    @RequiresPermissions("login")
    @RequestMapping("/wbbangding")
    public String wbbangding() {
        return "system/wbbangding";
    }

    /**
     * @explain 跳个人选择门店信息页
     * @author LeeX
     * @date 2017年6月28日 下午3:54:29
     */
    /*@RequiresPermissions("login")*/
    @RequestMapping("/perChooseInfo")
    public String perChooseInfo() {
        return "system/personalChooseStoreInfo";
    }
    
    /**
     * @explain 跳个人信息确定
     * @author LeeX
     * @date 2017年6月28日 下午3:54:29
     */
    /*@RequiresPermissions("login")*/
    @RequestMapping("/perInforCon")
    public String perInforCon() {
        return "system/personalInforConfirmation";
    }

    /**
     * @explain 跳转到组织架构
     * @author zh
     * @date 2017年10月16日 上午10:45:30
     */
    @RequiresPermissions("scrm_setting_org")
    @RequestMapping("/organizationalStr")
    public String organizationalStr() {
        return "system/organizationalStructure";
    }

    /**
     * @explain 跳转到门店管理
     * @author MAJIE
     * @date 2017年10月14日 下午5:03:26
     */
    @RequiresPermissions("scrm_setting_store")
    @RequestMapping("/hplus_storeManagement")
    public String storeManagement() {
        return "system/hplus_storeManagement";
    }

    /**
     * @explain 跳转到平台首页
     * @author zh
     * @date 2017年10月16日 下午17:20
     */
    @RequiresPermissions("main_page")
    @RequestMapping("/terraceIndex")
    public String terraceIndex() {
        return "system/terraceIndex";
    }

    /**
     * @explain 跳转到设置门店页面
     * @author MAJIE
     * @date 2017年10月16日 下午6:09:26
     */
    @RequiresPermissions("login")
    @RequestMapping("/setStore")
    public String setStroe() {
        return "system/hplus_setStore";
    }

    /**
     * @explain 跳转到报告大厅
     * @author zh
     * @date 2017年10月16日 下午17:20
     */
    @RequiresPermissions("scrm_markting_activity_report")
    @RequestMapping("/reportHall")
    public String reportHall() {
        return "system/reportHall";
    }
    /**
     * 跳转到企业信息
     * @return
     * majie
     */
	@RequestMapping("/editCompanyInfo")
	public String editCompany(){
		return "system/editCompanyInfo";
	}

    @RequiresPermissions("login")
    @RequestMapping("/main")
    public ModelAndView toMainPage(HttpServletRequest httpServletRequest) {
        Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        String uid = String.valueOf(session.getAttribute("userId"));
        String tenantId = String.valueOf(session.getAttribute("tenantId"));

        ModelAndView modelAndView = new ModelAndView("main");

        SimpleDateFormat simpleDateFormat = new SimpleDateFormat("yyyy-MM-dd");

        String sign = MD5Util.encodeString(MD5Util.encodeString("api_crm_anPOSCrmGerD4KOO1CO8iTq9WPuT" + simpleDateFormat.format(new Date()) + "login"));

        List<AuthorityModel> auths = iLoginService.getMenuListByUid(uid,tenantId);
        
        //如果是店员，则所有角色都在店员工作台一级菜单下显示
        Long tagCrmDy = 0l;
        for(int i=0;i<auths.size();i++){
        	if(auths.get(i).getId() == 66 || auths.get(i).getName().indexOf("店员工作台") > -1){
        		tagCrmDy = auths.get(i).getId();
        	}
        }
        List<AuthorityModel> authsCrm = new ArrayList<AuthorityModel>();
        //如果店员存在
        if(tagCrmDy > 0){
            for(int i=0;i<auths.size();i++){
            	if(auths.get(i).getId() == tagCrmDy){
            		authsCrm.add(auths.get(i));
            	}
            	//如果不是一级菜单
            	if(auths.get(i).getParentCode() != 0 && auths.get(i).getId() != tagCrmDy){
            		auths.get(i).setParentCode(tagCrmDy);
            		authsCrm.add(auths.get(i));
            	}
            	
            }
            auths = authsCrm;
        }
        //将用户的菜单权限放入session
        session.setAttribute("auths", auths);

        String mainPage = "";

        if (auths.size() > 0) {

            for (AuthorityModel auth : auths) {
                if (mainPage.length() == 0 && auth.getParentCode() > 0) {
                    mainPage = auth.getUrl();
                }
                if ("main_page".equals(auth.getNameEn())) {
                    mainPage = auth.getUrl();
                }
            }
        }

        if (auths.size() == 2) {

            RedirectView redirectView = new RedirectView(httpServletRequest.getContextPath() + (auths.get(0).getUrl() == null ? auths.get(0).getUrl() : auths.get(1).getUrl()));
            redirectView.setStatusCode(HttpStatus.TEMPORARY_REDIRECT);
            return new ModelAndView(redirectView);

        }

        SysUser sysUser = iAccountService.selectNameAndRoleByUid(uid);
        modelAndView.addObject("sysUser", sysUser);
        modelAndView.addObject("account", sysUser.getAccount());
        modelAndView.addObject("sign", sign);
        modelAndView.addObject("auths", auths);
        modelAndView.addObject("main_page", mainPage);
        return modelAndView;
    }


    @RequiresPermissions("scrm_setting_social")
    @RequestMapping("/social_media")
    public String SocialMedia(HttpServletRequest request) {
    	String preAuthCode = TokenUtil.getInstance().getPreAuthCode();
    	System.out.println("preAuthCode===="+preAuthCode);
    	if(StringUtils.isEmpty(preAuthCode)) {
    		MpTicket mpTicket = iMpTicketService.selectOne();
    		if(mpTicket != null) {
    			TokenUtil.getInstance().refreshPreAuthCode(mpTicket.getComponentAccessToken());
    		}
    	}
    	preAuthCode = TokenUtil.getInstance().getPreAuthCode();
    	System.out.println("preAuthCode2===="+preAuthCode);
//    	String tenant_id = request.getParameter("tenant_id");
//    	System.out.println("----tenant_id-----"+tenant_id);
		Subject subject = SecurityUtils.getSubject();
        Session session = subject.getSession();
        String tenantId = String.valueOf(session.getAttribute("tenantId"));
        MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenantId);
        String nickname = null;
        String headimg = "";
        long days = 0;
        long users = 0;
        if(mpAccount != null) {
        	request.setAttribute("wx_exist", true);
        	nickname = mpAccount.getNickName();
        	if(StringUtils.isNotEmpty(mpAccount.getHeadImg())) {
        		headimg = mpAccount.getHeadImg();
        	}
        	days = DateUtils.subtrationDate(mpAccount.getCreateTime(), new Date());
        	users = iMpUserService.getAllCount(new HashMap<String, Object>());
        }
    	request.setAttribute("wx_preAuthCode", preAuthCode);
    	request.setAttribute("wx_nickname", nickname);
    	request.setAttribute("wx_headimg", headimg);
    	request.setAttribute("wx_days", Math.abs(days));
    	request.setAttribute("wx_users", users);
    	request.setAttribute("tenant_id", tenantId);
  
    	
        return "system/hplus_social_media";
    }

    @RequiresPermissions("login")
    @RequestMapping("/createRole")
    public String CreateRole() {
        return "system/hplus_role_create";
    }

    @RequiresPermissions("scrm_setting_role")
    @RequestMapping("/roleList")
    public String RoleList() {
        //System.out.println("---->");
        return "system/hplus_role_list";
    }

    /**
     * 二级菜单展示
     *
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/mainView")
    public String mainView() {
        return "main_view";
    }

    //拿到全部的在线用户
    @RequestMapping("/testshrio")
    public void testshrio() {
        //重写的shrio的sessionDao，操作都经过redis
        RedisSessionDAO redisSessionDAO = new RedisSessionDAO();
        RedisManager redisManager = new RedisManager();
        redisSessionDAO.setRedisManager(redisManager);
        Collection<Session> sessions = redisSessionDAO.getActiveSessions();
        for (Session session : sessions) {
            if (session.getAttribute("userAccount") != null && !"".equals(session.getAttribute("userAccount"))) {
                System.out.println("登陆手机号" + session.getAttribute("userAccount") + "sessionId" + session.getId());
            }
        }
    }

    //将指定用户的会话设置为失效，跳转到登录页
    @RequestMapping("/testshrioDel")
    public void testshrioDel() {
        //重写的shrio的sessionDao，操作都经过redis
        RedisSessionDAO redisSessionDAO = new RedisSessionDAO();
        RedisManager redisManager = new RedisManager();
        redisSessionDAO.setRedisManager(redisManager);
        Collection<Session> sessions = redisSessionDAO.getActiveSessions();
        for (Session session : sessions) {
            if (session.getAttribute("userAccount") != null && !"".equals(session.getAttribute("userAccount"))) {
                if ("15810355456".equals(session.getAttribute("userAccount"))) {
                    session.setTimeout(0);
                    redisSessionDAO.update(session);
                }
            }
        }
    }

}
