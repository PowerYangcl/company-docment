package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.dao.business.markting.BmActivityBrowseMapper;
import cn.cecook.model.business.markting.SocialCouponBatch;
import cn.cecook.model.business.markting.SocialCouponBrowse;
import cn.cecook.service.business.markting.SocialCouponBatchService;
import cn.cecook.uitls.StringUtils;

@Controller
@RequestMapping("/social/coupon_batch")
public class SocialCouponBatchController {

	@Autowired
	private SocialCouponBatchService socialCouponBatchService;
	@Autowired
	private BmActivityBrowseMapper bmActivityBrowseDao;

	/**
	 * 
	 * Title: create Description:创建
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		SocialCouponBatch socialCouponBatch = new SocialCouponBatch();
		String uid = request.getParameter("uid");
		String send_num = request.getParameter("send_num");
		String tenant_id = request.getParameter("tenant_id");
		String sendObjectType = request.getParameter("sendObjectType");
		String groupId = request.getParameter("groupId");
		String redisKey = request.getParameter("redisKey");
		if (!StringUtils.isEmpty(uid))
			socialCouponBatch.setCreateId(Integer.parseInt(uid));
		socialCouponBatch.setTenantId(tenant_id);
		if (!StringUtils.isEmpty(sendObjectType))
			socialCouponBatch.setSendObjectType(Integer
					.parseInt(sendObjectType));
		socialCouponBatch.setGroupId(groupId);
		if (!StringUtils.isEmpty(send_num))
			socialCouponBatch.setCustomerNum(Integer.parseInt(send_num));

		return socialCouponBatchService.insert(socialCouponBatch, redisKey);
	}

	@RequestMapping(value = "/createByAutomate")
	@ResponseBody
	public Object createByAutomate(HttpServletRequest request,
			HttpServletResponse response) {
		String id = request.getParameter("id");
		String couponModelId = request.getParameter("coupon_model_id");
		String name = request.getParameter("name");
		String smsInform = request.getParameter("sms_inform");
		String autograph = request.getParameter("autograph");
		String smsContent = request.getParameter("sms_content");
		String remindContent = request.getParameter("remind_content");
		String expireRemindFlag = request.getParameter("expire_remind_flag");
		String sms_equivalen_num = request.getParameter("sms_equivalen_num");
		String sms_remind_equivalen_num = request
				.getParameter("sms_remind_equivalen_num");
		String activityId = request.getParameter("activity_id");
		String activityUrl = request.getParameter("activity_url");
		String expireDay = request.getParameter("expire_day");
		String type = request.getParameter("type");
		String template_id= request.getParameter("template_id");
		String couponModelType=request.getParameter("couponModelType");
		SocialCouponBatch socialCouponBatch = new SocialCouponBatch();
		socialCouponBatch.setName(name);
		socialCouponBatch.setAutograph(autograph);
		socialCouponBatch.setSmsContent(smsContent);
		socialCouponBatch.setRemindContent(remindContent);
		socialCouponBatch.setActivityUrl(activityUrl);

		if (!StringUtils.isEmpty(id))
			socialCouponBatch.setId(Integer.parseInt(id));
		socialCouponBatch.setCouponIds(couponModelId);
		if (!StringUtils.isEmpty(smsInform))
			socialCouponBatch.setSmsInformFlag(Integer.parseInt(smsInform));
		if (!StringUtils.isEmpty(expireRemindFlag))
			socialCouponBatch.setExpireRemindFlag(Integer
					.parseInt(expireRemindFlag));
		if (!StringUtils.isEmpty(sms_remind_equivalen_num))
			socialCouponBatch.setSmsEquivalenNum(Integer
					.parseInt(sms_equivalen_num));
		if (!StringUtils.isEmpty(sms_remind_equivalen_num))
			socialCouponBatch.setSmsRemindEquivalenNum(Integer
					.parseInt(sms_remind_equivalen_num));
		if (!StringUtils.isEmpty(activityId))
			socialCouponBatch.setActivityId(Integer.parseInt(activityId));
		if (!StringUtils.isEmpty(expireDay))
			socialCouponBatch.setExpireDay(Integer.parseInt(expireDay));
		if (!StringUtils.isEmpty(type))
			socialCouponBatch.setType(Integer.parseInt(type));
		
		if(!StringUtils.isEmpty(template_id)) {
			socialCouponBatch.setTemplateId(Integer.parseInt(template_id));
		}
		if(!StringUtils.isEmpty(couponModelType))
			socialCouponBatch.setCouponModelType(Integer.parseInt(couponModelType));
		return socialCouponBatchService.createByAutomate(socialCouponBatch);
	}

	/**
	 * 
	 * Title: update Description:更新
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/update")
	@ResponseBody
	public Object update(HttpServletRequest request,
			HttpServletResponse response) {
		String id = request.getParameter("id");
		String couponModelId = request.getParameter("coupon_model_id");
		String name = request.getParameter("name");
		String smsInform = request.getParameter("sms_inform");
		String autograph = request.getParameter("autograph");
		String smsContent = request.getParameter("sms_content");
		String remindContent = request.getParameter("remind_content");
		String expireRemindFlag = request.getParameter("expire_remind_flag");
		String sms_equivalen_num = request.getParameter("sms_equivalen_num");
		String sms_remind_equivalen_num = request
				.getParameter("sms_remind_equivalen_num");
		String activityId = request.getParameter("activity_id");
		String activityUrl = request.getParameter("activity_url");
		String expireDay = request.getParameter("expire_day");
		String type = request.getParameter("type");
		String couponModelType=request.getParameter("couponModelType");
		
		
		
		SocialCouponBatch socialCouponBatch = new SocialCouponBatch();
		socialCouponBatch.setName(name);
		socialCouponBatch.setAutograph(autograph);
		socialCouponBatch.setSmsContent(smsContent);
		socialCouponBatch.setRemindContent(remindContent);
		socialCouponBatch.setActivityUrl(activityUrl);

		if (!StringUtils.isEmpty(id))
			socialCouponBatch.setId(Integer.parseInt(id));
		socialCouponBatch.setCouponIds(couponModelId);
		if (!StringUtils.isEmpty(smsInform))
			socialCouponBatch.setSmsInformFlag(Integer.parseInt(smsInform));
		if (!StringUtils.isEmpty(expireRemindFlag))
			socialCouponBatch.setExpireRemindFlag(Integer
					.parseInt(expireRemindFlag));
		if (!StringUtils.isEmpty(sms_remind_equivalen_num))
			socialCouponBatch.setSmsEquivalenNum(Integer
					.parseInt(sms_equivalen_num));
		if (!StringUtils.isEmpty(sms_remind_equivalen_num))
			socialCouponBatch.setSmsRemindEquivalenNum(Integer
					.parseInt(sms_remind_equivalen_num));
		if (!StringUtils.isEmpty(activityId))
			socialCouponBatch.setActivityId(Integer.parseInt(activityId));
		if (!StringUtils.isEmpty(expireDay))
			socialCouponBatch.setExpireDay(Integer.parseInt(expireDay));
		if (!StringUtils.isEmpty(type))
			socialCouponBatch.setType(Integer.parseInt(type));
		if(!StringUtils.isEmpty(couponModelType))
			socialCouponBatch.setCouponModelType(Integer.parseInt(couponModelType));
		
		
		return socialCouponBatchService.update(socialCouponBatch);
	}

	/**
	 * 
	 * Title: delete Description:详情
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object detail(String id) {

		return socialCouponBatchService.detail(id);

	}

	/**
	 * 
	 * Title: detail Description:详情(不包括分组数据)
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/detailEdit")
	@ResponseBody
	public Object detailEdit(String id) {

		return (socialCouponBatchService.detailEdit(id));

	}

	/**
	 * 
	 * Title: delete Description:详情
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/submitAudit")
	@ResponseBody
	public Object submitAudit(String id) {
		return socialCouponBatchService.submitAudit(id);
	}

	/**
	 * 
	 * Title: delete Description:删除
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/delete")
	@ResponseBody
	public Object delete(String id, String tenant_id) {

		return socialCouponBatchService.delete(id, tenant_id);

	}

	/**
	 * 
	 * Title: deleteBatch Description:批量删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteBatch")
	@ResponseBody
	public Object deleteBatch(String ids, String tenant_id) {
		System.out.println("----ids--->" + ids);

		return socialCouponBatchService.deleteBatch(ids, tenant_id);

	}

	/**
	 * 
	 * Title: getList Description:获取列表
	 * 
	 * @param startIndex
	 * @param PageSize
	 * @param keyWord
	 * @param status
	 * @param orderBy
	 * @return
	 */
	@RequestMapping(value = "/getCouponBatchList")
	@ResponseBody
	public Object getList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		String startTime = jsonObj.get("startTime").getAsString();
		String endTime = jsonObj.get("endTime").getAsString();
		String keyWord = "";
		String status = "";
		String type="";
		if (jsonObj.get("keyWord") != null) {
			keyWord = jsonObj.get("keyWord").getAsString();
		}
		if (jsonObj.get("status") != null) {
			status = jsonObj.get("status").getAsString();
		}
		if (jsonObj.get("type") != null) {
			type = jsonObj.get("type").getAsString();
		}
		return socialCouponBatchService.getCouponBatchList(startIndex,
				pageSize, keyWord, status, startTime, endTime, draw,type);
	}

	@RequestMapping(value = "/sendBatch")
	@ResponseBody
	public Object send(String id, String sendTimeType, String sendTime,
			String redisKey, String taskId) {
		return socialCouponBatchService.send(id, sendTimeType, sendTime,
				redisKey, taskId);
	}

	/**
	 * 
	 * Title: Statistics Description:统计列表
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/statistics")
	@ResponseBody
	public Object Statistics(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();

		String keyWord = "";
		String orderBy = "";
		String start_time = null;
		String end_time = null;
		String id = "";
		if (jsonObj.get("keyWord") != null) {
			keyWord = jsonObj.get("keyWord").getAsString();
		}
		if (jsonObj.get("orderBy") != null) {
			orderBy = jsonObj.get("orderBy").getAsString();
		}
		if (jsonObj.get("start_time") != null) {
			start_time = jsonObj.get("start_time").getAsString();
		}
		if (jsonObj.get("end_time") != null) {
			end_time = jsonObj.get("end_time").getAsString();
		}
		if (jsonObj.get("id") != null) {
			id = jsonObj.get("id").getAsString();
		}
		return socialCouponBatchService.batchStatistics(startIndex, pageSize,
				keyWord, start_time, end_time, orderBy, draw, id);

	}

	@RequestMapping(value = "/converStatistics")
	@ResponseBody
	public Object converStatistics(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		int batchId = jsonObj.get("batchId").getAsInt();
		return socialCouponBatchService.converStatistics(batchId, startIndex,
				pageSize, draw);
	}

	@RequestMapping(value = "/clickStatistics")
	@ResponseBody
	public Object clickStatistics(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		int batchId = jsonObj.get("batchId").getAsInt();
		String type=jsonObj.get("type").getAsString();
		return socialCouponBatchService.clickStatistics(batchId, startIndex,
				pageSize, draw,type);
	}

	// 导出注券统计报表
	@RequestMapping(value = "/exportCouponBatchForm")
	@ResponseBody
	public Object exportCouponBatchForm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		String orderBy = request.getParameter("orderBy");
		String startTime = request.getParameter("startTime");
		String endTime = request.getParameter("endTime");
		String keyWord = request.getParameter("keyWord");
		return socialCouponBatchService.exportCouponBatchForm(keyWord,
				startTime, endTime, orderBy, response);

	}

	// 导出注券统计报表
	@RequestMapping(value = "/exportConverForm")
	@ResponseBody
	public Object exportConverForm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		int batchId = 0;

		if (!StringUtils.isEmpty(request.getParameter("batchId")))
			batchId = Integer.parseInt(request.getParameter("batchId"));
		return socialCouponBatchService.exportConverForm(batchId, response);

	}

	// 导出注券统计报表
	@RequestMapping(value = "/exportClickForm")
	@ResponseBody
	public Object exportClickForm(HttpServletRequest request,
			HttpServletResponse response) throws Exception {
		int batchId = 0;

		if (!StringUtils.isEmpty(request.getParameter("batchId")))
			batchId = Integer.parseInt(request.getParameter("batchId"));
		String type=request.getParameter("type");
		return socialCouponBatchService.exportClickForm(batchId, type,response);

	}

	// 审核通过
	@RequestMapping(value = "/auditApproval")
	@ResponseBody
	public Object auditApproval(String id, String tenant_id,String template_id) {
		return (socialCouponBatchService.auditApproval(tenant_id, id,template_id));
	}

	// 审核不通过
	@RequestMapping(value = "/auditApprovalRefused")
	@ResponseBody
	public Object auditApprovalRefused(String id, String tenant_id,String template_id) {
		return (socialCouponBatchService.auditApprovalRefused(tenant_id, id,template_id));
	}

	
	@RequestMapping(value = "/auditApprovalByBJC")
	@ResponseBody
	public Object auditApprovalByBJC(String id, String taskId) {
		return (socialCouponBatchService.auditApprovalByBJC(id, taskId));
	}
	/**
	 * 
	* Title: createCouponBrowse
	* Description:用户浏览优惠券列表
	* @param request
	* @param response
	* @return
	 */
	@RequestMapping(value = "/createCouponBrowse")
	@ResponseBody
	public Object createCouponBrowse(HttpServletRequest request,
			HttpServletResponse response) {

		String couponBatch = request.getParameter("couponBatchId");

		String customerId = request.getParameter("customerId");

		String contacted = request.getParameter("contacted");

		String longitude = request.getParameter("longitude");

		String latitude = request.getParameter("latitude");

		String province = request.getParameter("province");

		String city = request.getParameter("city");

		String ip = request.getParameter("ip");
		SocialCouponBrowse socialCouponBrowse = new SocialCouponBrowse();

		if (!StringUtils.isEmpty(couponBatch)) {
			socialCouponBrowse.setCouponBatch(Integer.parseInt(couponBatch));
		}
		if (!StringUtils.isEmpty(customerId)) {
			socialCouponBrowse.setCustomerId(Integer.parseInt(customerId));
		}
		socialCouponBrowse.setContacted(contacted);
		socialCouponBrowse.setLatitude(latitude);
		socialCouponBrowse.setLongitude(longitude);
		socialCouponBrowse.setProvince(province);
		socialCouponBrowse.setCity(city);
		socialCouponBrowse.setIp(ip);

		return socialCouponBatchService.createBrowseCoupon(socialCouponBrowse);

	}

}
