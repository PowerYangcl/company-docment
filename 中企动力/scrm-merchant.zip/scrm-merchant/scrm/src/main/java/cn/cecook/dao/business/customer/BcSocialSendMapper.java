package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcSocialSend;
import cn.cecook.model.business.customer.BcSocialSendExample;

/**
 * 
* @explain 社交平台发送记录表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcSocialSendMapper {
    int countByExample(BcSocialSendExample example);

    int deleteByExample(BcSocialSendExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcSocialSend record);

    int insertSelective(BcSocialSend record);

    List<BcSocialSend> selectByExample(BcSocialSendExample example);

    BcSocialSend selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcSocialSend record, @Param("example") BcSocialSendExample example);

    int updateByExample(@Param("record") BcSocialSend record, @Param("example") BcSocialSendExample example);

    int updateByPrimaryKeySelective(BcSocialSend record);

    int updateByPrimaryKey(BcSocialSend record);
}