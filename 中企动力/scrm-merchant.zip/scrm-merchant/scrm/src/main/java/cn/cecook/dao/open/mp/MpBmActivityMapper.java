package cn.cecook.dao.open.mp;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmActivity;

public interface MpBmActivityMapper {

	List<BmActivity> findByActivityIds(@Param(value = "activityidList") List<Long> activityidList);
	
}
