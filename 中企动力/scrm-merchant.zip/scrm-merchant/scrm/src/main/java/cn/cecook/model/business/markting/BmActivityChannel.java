/**
 * @Title: BmActivityChannel.java
 * @Description: 活动分享渠道
 * @author peng
 * @date 2107/5/23 
 * @version V1.0
 */
package cn.cecook.model.business.markting;

import java.util.Date;

/**
 * 活动分享渠道
 * 
 * @author peng
 *
 */
public class BmActivityChannel {

	// id
	private Integer id;

	// uuid
	private String uuid;

	// 租户ID
	private String tenantId;

	// 删除标记
	private Integer isDeleted;

	// 创建人ID
	private Long createId;

	// 创建时间
	private Date createTime;

	// 排序标示
	private String orderCode;

	// 排序标示
	private Date deleteTime;

	// 备注
	private String remarks;

	// 附件
	private String attachment;

	// 名称
	private String name;

	// 描述
	private String description;

	// 备用字段
	private String bak1;

	// 备用字段
	private String bak2;

	// 备用字段
	private String bak3;

	// 备用字段
	private String bak4;

	// 备用字段
	private String bak5;

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid == null ? null : uuid.trim();
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId == null ? null : tenantId.trim();
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Long getCreateId() {
		return createId;
	}

	public void setCreateId(Long createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode == null ? null : orderCode.trim();
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks == null ? null : remarks.trim();
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment == null ? null : attachment.trim();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description == null ? null : description.trim();
	}

	public String getBak1() {
		return bak1;
	}

	public void setBak1(String bak1) {
		this.bak1 = bak1 == null ? null : bak1.trim();
	}

	public String getBak2() {
		return bak2;
	}

	public void setBak2(String bak2) {
		this.bak2 = bak2 == null ? null : bak2.trim();
	}

	public String getBak3() {
		return bak3;
	}

	public void setBak3(String bak3) {
		this.bak3 = bak3 == null ? null : bak3.trim();
	}

	public String getBak4() {
		return bak4;
	}

	public void setBak4(String bak4) {
		this.bak4 = bak4 == null ? null : bak4.trim();
	}

	public String getBak5() {
		return bak5;
	}

	public void setBak5(String bak5) {
		this.bak5 = bak5 == null ? null : bak5.trim();
	}
}