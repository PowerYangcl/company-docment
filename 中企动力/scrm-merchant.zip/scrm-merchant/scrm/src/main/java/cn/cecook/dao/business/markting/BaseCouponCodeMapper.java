package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BaseCouponCode;

public interface BaseCouponCodeMapper {
    int deleteByPrimaryKey(Integer id);

    int insert(BaseCouponCode record);

    int insertSelective(BaseCouponCode record);

    BaseCouponCode selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(BaseCouponCode record);

    int updateByPrimaryKey(BaseCouponCode record);
    
    int insertByBatch(List<String> ids);
    
    List<String> getCodeList(@Param("startIndex") int startIndex,@Param("pageSize") int pageSize);
}