package cn.cecook.controller.business.scan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonParser;

import cn.cecook.service.business.scan.ScanIntegralService;

@Controller
@RequestMapping("/scan/integral")
public class ScanIntegralController {
	private JsonParser jsonParser = new JsonParser();
	@Autowired
	private ScanIntegralService integralService;
	
	@RequestMapping(value="/getIntegralRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getIntegralRule() {
		return integralService.getIntegralRule();
	}
	
	@RequestMapping(value="/saveIntegralRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String saveIntegralRule(@RequestBody String json) {
		return integralService.saveIntegralRule(json);
	}
	
	
	/**
	 * 	冻结与解冻，和加减积分用
	 */
	@RequestMapping(value="/updateIntegralType",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String updateIntegralType(String memberIds,int integralType) {
		return integralService.updateIntegralType(memberIds, integralType);
	}
	
	/**
	 * 	手动修改积分
	 */
	@RequestMapping(value="/changeIntegral",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String changeIntegral(int memberId, int integral, String gainReason) {
		return integralService.changeIntegral(memberId, integral, gainReason);
	}
	
	@RequestMapping(value = "/getPage", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getPage(@RequestBody String param) {
        String page = integralService.getPage(jsonParser.parse(param).getAsJsonObject());
        return jsonParser.parse(page).getAsJsonObject().get("data").toString();
    }
}