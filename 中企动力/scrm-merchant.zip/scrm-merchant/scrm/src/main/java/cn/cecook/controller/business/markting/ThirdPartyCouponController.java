package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.markting.ThirdPartyCouponModel;
import cn.cecook.service.business.markting.ThirdpartyCouponService;
@Controller
@RequestMapping("/api/coupon/thirdparty")
public class ThirdPartyCouponController {
	@Autowired
	private ThirdpartyCouponService thirdpartyCouponService;

	@RequestMapping("/createModel")
	@ResponseBody
	public BaseResultModel createModel(HttpServletRequest request) {
		String name = request.getParameter("name");

		ThirdPartyCouponModel couponModel = new ThirdPartyCouponModel();
		couponModel.setName(name);
		return thirdpartyCouponService.createThirdPartyCouponModel(couponModel);

	}

	@RequestMapping("/deleteModel")
	@ResponseBody
	public BaseResultModel deleteModel(Integer modelId) {
		return thirdpartyCouponService.deleteThirdPartyCouponModel( modelId);
	}

	@RequestMapping("/editModel")
	@ResponseBody
	public BaseResultModel editModel(HttpServletRequest request) {
		return null;

	}

	@RequestMapping("/modelDetail")
	@ResponseBody
	public BaseResultModel modelDetail(Integer modelId) {
		return null;

	}

	@RequestMapping("/modelList")
	@ResponseBody
	public Object modelList(@RequestBody String param) {
		JSONObject jsonObject=JSONObject.parseObject(param);
		return thirdpartyCouponService.listThirdPartyCouponModel(jsonObject);

	}
	
	@RequestMapping("/modelStatistics")
	@ResponseBody
	public Object modelStatistics(Integer modelId) {
		System.out.println(modelId);
		return thirdpartyCouponService.couponModelStatistics(modelId);

	}
	
	@RequestMapping("/countCouponNum")
	@ResponseBody
	public Object countCouponNum(Integer modelId) {
		System.out.println(modelId);
		return thirdpartyCouponService.countCouponNumByModelId(modelId);

	}
	
	@RequestMapping("/countCouponNumByActivityId")
	@ResponseBody
	public Object countCouponNumByActivityId(Long modelId) {
		System.out.println(modelId);
		return thirdpartyCouponService.countCouponNumByActivityId(modelId);

	}
}