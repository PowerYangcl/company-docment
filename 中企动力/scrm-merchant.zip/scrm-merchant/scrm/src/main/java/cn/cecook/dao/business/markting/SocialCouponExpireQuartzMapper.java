package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.cecook.model.business.markting.SocialCouponExpireQuartz;
@Repository("socialCouponExpireQuartzMapper")
public interface SocialCouponExpireQuartzMapper {


    int deleteByPrimaryKey(Integer id);

    int insert(SocialCouponExpireQuartz record);

    int insertSelective(SocialCouponExpireQuartz record);


    SocialCouponExpireQuartz selectByPrimaryKey(Integer id);


    int updateByPrimaryKeySelective(SocialCouponExpireQuartz record);

    int updateByPrimaryKey(SocialCouponExpireQuartz record);
    
    int insertByBatch(Map<String, Object> map);
    
    List<SocialCouponExpireQuartz> getList(Map<String,Object> map);
    
    int updateStatusByBatch(Map<String,Object> map);
}