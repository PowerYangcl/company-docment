package cn.cecook.dao.business.markting;

import java.util.Map;

import cn.cecook.model.business.markting.BmMicroPortal;

public interface BmMicroPortalMapper {

    int deleteByPrimaryKey(Integer id);

    int insert(BmMicroPortal record);

    int insertSelective(BmMicroPortal record);


    BmMicroPortal selectByPrimaryKey(Integer id);


    int updateByPrimaryKeySelective(BmMicroPortal record);

    int updateByPrimaryKey(BmMicroPortal record);
    
    //获取门户信息
    Map<String,Object> queryDetail();
    
    
    int updateStoreIds(String ids);
}