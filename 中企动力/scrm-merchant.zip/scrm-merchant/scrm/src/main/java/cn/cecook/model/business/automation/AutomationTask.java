package cn.cecook.model.business.automation;

import java.util.Date;

/**
 * 自动化营销任务类
 * @author majie
 *
 * 2018年1月22日-下午4:38:57
 */
public class AutomationTask {
	private Integer id;
	private String uuid;
	private String tenantId;
	private Integer isDeleted;
	//创建时间
	private Date createTime;
	//删除时间
	private Date deleteTime;
	//父任务id
	private Integer parentId;
	//模板id
	private Integer templateId;
	//条件id
	private Integer ruleId;
	//执行动作
	private String exAction;
	//执行动作id
	private Integer exActionId;
	//执行顺序
	private String exTaskOrder;
	//是否循环 0循环 1不循环
	private Integer exLoop;
	//任务状态
	private String taskStatus;
	//执行时间类型
	private String exDateType;
	//执行时间信息
	private String exDateInfo;
	//对应节点信息的自增id
	private Integer pointId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}
	public Integer getParentId() {
		return parentId;
	}
	public void setParentId(Integer parentId) {
		this.parentId = parentId;
	}
	public Integer getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}
	public Integer getRuleId() {
		return ruleId;
	}
	public void setRuleId(Integer ruleId) {
		this.ruleId = ruleId;
	}
	public String getExAction() {
		return exAction;
	}
	public void setExAction(String exAction) {
		this.exAction = exAction;
	}
	public Integer getExActionId() {
		return exActionId;
	}
	public void setExActionId(Integer exActionId) {
		this.exActionId = exActionId;
	}
	public String getExTaskOrder() {
		return exTaskOrder;
	}
	public void setExTaskOrder(String exTaskOrder) {
		this.exTaskOrder = exTaskOrder;
	}
	public Integer getExLoop() {
		return exLoop;
	}
	public void setExLoop(Integer exLoop) {
		this.exLoop = exLoop;
	}
	public String getTaskStatus() {
		return taskStatus;
	}
	public void setTaskStatus(String taskStatus) {
		this.taskStatus = taskStatus;
	}
	public String getExDateType() {
		return exDateType;
	}
	public void setExDateType(String exDateType) {
		this.exDateType = exDateType;
	}
	public String getExDateInfo() {
		return exDateInfo;
	}
	public void setExDateInfo(String exDateInfo) {
		this.exDateInfo = exDateInfo;
	}
	
	public Integer getPointId() {
		return pointId;
	}
	public void setPointId(Integer pointId) {
		this.pointId = pointId;
	}
	@Override
	public String toString() {
		return "AutomationTask [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createTime=" + createTime + ", deleteTime=" + deleteTime + ", parentId=" + parentId
				+ ", templateId=" + templateId + ", ruleId=" + ruleId + ", exAction=" + exAction + ", exActionId="
				+ exActionId + ", exTaskOrder=" + exTaskOrder + ", exLoop=" + exLoop + ", taskStatus=" + taskStatus
				+ ", exDateType=" + exDateType + ", exDateInfo=" + exDateInfo + ", pointId=" + pointId + "]";
	}	
}
