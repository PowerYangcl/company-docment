package cn.cecook.controller.open;

import java.io.File;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;
import org.springframework.web.servlet.ModelAndView;

import cn.cecook.model.open.mp.MpUserInfo;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpUserInfoService;
import cn.cecook.thirdparty.open.ConfigUtil;
import cn.cecook.thirdparty.weibo.util.LongUrl2ShortUtil;
import cn.cecook.uitls.CDNUtil;
import cn.cecook.uitls.CookieUtil;

@Controller
@RequestMapping("/weixin")
public class WeixinUserInfoController {

	@Autowired
	private IMpAccountService mpAccountService;
	
	@Autowired
	private IMpUserInfoService mpUserInfoService;

	@RequestMapping(value = "/userInfo")
    public ModelAndView userInfo(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpUserInfo mpUserInfo = mpUserInfoService.getByTenantId(tenant_id);
		if(mpUserInfo != null) {
			String homeUrl = mpUserInfo.getHomeurl()+"?tenant_id="+tenant_id;
			String homeUrlShort = LongUrl2ShortUtil.toShortUrl(homeUrl);
			if(!homeUrlShort.startsWith("http")) {
				homeUrlShort = "http://"+homeUrlShort;
			}
			mpUserInfo.setHomeurl(homeUrl);
			mpUserInfo.setHomeurlShort(homeUrlShort);
			model.put("mpUserInfo", mpUserInfo);
		}else {
			MpUserInfo mpUserInfo_ = new MpUserInfo();
			mpUserInfo_.setLogo(ConfigUtil.getInstance().user_info_default_logo);
			mpUserInfo_.setBackground(ConfigUtil.getInstance().user_info_default_background);
			String homeUrl = ConfigUtil.getInstance().domain+"/open/me?tenant_id="+tenant_id;
			String homeUrlShort = LongUrl2ShortUtil.toShortUrl(homeUrl);
			if(!homeUrlShort.startsWith("http")) {
				homeUrlShort = "http://"+homeUrlShort;
			}
			mpUserInfo_.setHomeurl(homeUrl);
			mpUserInfo_.setHomeurlShort(homeUrlShort);
			mpUserInfoService.insert(mpUserInfo_);
			model.put("mpUserInfo", mpUserInfo);
		}
		modelAndView.setViewName("/open/personal");
		return modelAndView;
	}
	
	@RequestMapping(value = "/saveUserInfo", method= RequestMethod.POST)
	public ModelAndView saveUserInfo(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpUserInfo mpUserInfo = mpUserInfoService.getByTenantId(tenant_id);
		if(mpUserInfo != null) {//更新
			MultipartFile multipartLogo = ((MultipartHttpServletRequest) request).getFile("logo");
			if(multipartLogo != null && !multipartLogo.isEmpty()) {				
				try {
					String extraName = "jpg";
					String originalFilename = multipartLogo.getOriginalFilename();
					if (originalFilename.contains(".")) {
						String tmp_ = originalFilename.substring(originalFilename.lastIndexOf('.') + 1);
						if (StringUtils.isEmpty(tmp_)) {
							extraName = tmp_;
						}
					}
					File file = new File(request.getSession().getServletContext().getRealPath("/") + "logo_" + System.currentTimeMillis()+"."+extraName);
					multipartLogo.transferTo(file);
					String logoCeccokUrl = CDNUtil.uploadImage(file);
					file.delete();
					mpUserInfo.setLogo(logoCeccokUrl);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			MultipartFile multipartBg = ((MultipartHttpServletRequest) request).getFile("bg");
			if(multipartBg != null && !multipartBg.isEmpty()) {				
				try {
					String extraName = "jpg";
					String originalFilename = multipartBg.getOriginalFilename();
					if (originalFilename.contains(".")) {
						String tmp_ = originalFilename.substring(originalFilename.lastIndexOf('.') + 1);
						if (StringUtils.isEmpty(tmp_)) {
							extraName = tmp_;
						}
					}
					File file = new File(request.getSession().getServletContext().getRealPath("/") + "logo_" + System.currentTimeMillis()+"."+extraName);
					multipartBg.transferTo(file);
					String bgCeccokUrl = CDNUtil.uploadImage(file);
					file.delete();
					mpUserInfo.setBackground(bgCeccokUrl);
				} catch (Exception e1) {
					e1.printStackTrace();
				}
			}
			mpUserInfoService.update(mpUserInfo);
			model.put("mpUserInfo", mpUserInfo);
		}else {
			
		}
		modelAndView.setViewName("redirect:/weixin/userInfo");
		return modelAndView;
	}
}
