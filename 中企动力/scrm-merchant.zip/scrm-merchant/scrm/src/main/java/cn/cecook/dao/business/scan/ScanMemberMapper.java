package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcCustomer;
import cn.cecook.uitls.Pages;

public interface ScanMemberMapper {
	/**
     * 分页
     * @param page
     * @return
     */
    List<Map<String, Object>> getPage(Pages<Map<String, Object>> page);
    int count(Map<String, Object> where);
//    void insertMember(Map<String, Object> param);
    int insertSelective(BcCustomer customer);
    Map<String, Object> getMemberByPhone(String phone);
    int countPhoneExist(@Param("memberId")int memberId,@Param("phone")String phone);
    void updateMember(Map<String, Object> param);
    List<Map<String, Object>> getMemberList();
    Map<String, Object> getMember(int id);
    void updateMember2(Map<String, Object> param);
    List<Integer> listStoreIdByIds(@Param("tenantId")String tenantId,@Param("memberIds")String memberIds);
	Map<String, Object> getMemberByPhoneAndTenantId(@Param(value = "phone") String phone, @Param(value = "tenant_id") String tenant_id);
    /**
     * 	获取所有门店
     * @return
     */
    List<Map<String,Object>> listStore();
    
    /**
     * 会员数据管理页面所需接口
     * @param page
     * @return
     */
	List<Map<String, Object>> getPageForDataManage(
            Pages<Map<String, Object>> page);
	int countForDataManage(Map<String, Object> where);
	/**
	 * 判断该手机在数据库中是否存在
	 * @param phone
	 * @return
	 */
	Map<String, Object> getDataManageByPhone(@Param("phone") String phone,@Param("tenantId") String tenantId);
	
	/**
	 * 将导入的数据入库
	 * @param member
	 */
	int insertDataManage(Map<String, Object> member);
	/**
	 * 
	* Title: insertDataManageBySocial
	* Description:social导入
	* @param member
	* @return
	 */
	int insertDataManageBySocial(Map<String, Object> member);
	/**
	 * 将导入的数据覆盖
	 * @param member
	 */
	void updateDataManage(Map<String, Object> member);
	/**
	 * 拿到所有追溯的时间
	 * @return
	 */
	List<Map<String, Object>> initHsTime();
	/**
	 * 回溯到指定时间节点
	 * @param hsTime
	 * @return
	 */
	void updateHsTimeNow(String hsTime);
	/**
	 * 将其他回溯隐藏
	 * @param hsTime
	 * @return
	 */
	void updateHsTimeNow2(String hsTime);
	/**
	 * 初始化会员总数
	 * @return
	 */
	int initHyCount();
	/**
	 * 初始化全部会员总数
	 * @return
	 */
	Integer initAllHyCount();
	/**
	 * 初始自动化服务规则总数
	 * @return
	 */
	Integer initAutoSeivice();
	/**
	 * 查询全部一级菜单
	 * @return
	 */
	List<Map<String, Object>> getAllMemberType();
	/**
	 * 根据分类名称，type=1去scan_member_group表中查询是否含有该分类
	 * @param type_customer
	 * @return
	 */
	Map<String, Object> getParentMember(String type_customer);
	/**
	 * 根据一级分组ID查询全部的二级分组ID
	 * @param typeId
	 * @return
	 */
	List<Map<String, Object>> getAllChildren(String typeId);
	
	/**
	 * 根据memberId设置会员的门店id
	 * @param memberId
	 * @param storeId
	 * @return
	 */
	int updateMemberStore(@Param("memberId") int memberId,@Param("storeId") int storeId);
	
	BcCustomer getMemberModel(int memberId);
	
	int updateByPrimaryKeySelective(BcCustomer record);
}