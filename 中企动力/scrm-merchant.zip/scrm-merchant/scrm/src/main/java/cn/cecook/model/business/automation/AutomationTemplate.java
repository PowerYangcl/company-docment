package cn.cecook.model.business.automation;

import java.util.Date;

/**
 * 自动营销模板信息
 * @author majie
 *
 * 2018年1月22日-下午4:34:27
 */
public class AutomationTemplate {
	private Integer id;
	private String uuid;
	private String tenantId;
	private Integer isDeleted;
	//创建时间
	private Date createTime;
	//停止时间
	private Date stopTime;
	//启动时间
	private Date runTime;
	//删除时间
	private Date deleteTime;
	//是否启动
	private Integer isRun;
	//名称
	private String name;
	//审核状态 0 未审核 1审核成功  2审核失败
	private Integer auditing;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public Date getStopTime() {
		return stopTime;
	}
	public void setStopTime(Date stopTime) {
		this.stopTime = stopTime;
	}
	public Date getRunTime() {
		return runTime;
	}
	public void setRunTime(Date runTime) {
		this.runTime = runTime;
	}
	public Date getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}
	public Integer getIsRun() {
		return isRun;
	}
	public void setIsRun(Integer isRun) {
		this.isRun = isRun;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	
	public Integer getAuditing() {
		return auditing;
	}
	public void setAuditing(Integer auditing) {
		this.auditing = auditing;
	}
	@Override
	public String toString() {
		return "AutomationTemplate [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createTime=" + createTime + ", stopTime=" + stopTime + ", runTime=" + runTime + ", deleteTime="
				+ deleteTime + ", isRun=" + isRun + ", name=" + name + ", auditing=" + auditing + "]";
	}
	
}
