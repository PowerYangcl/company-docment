package cn.cecook.dao.business.markting;

import java.util.List;

import org.springframework.stereotype.Repository;

import cn.cecook.model.business.markting.SysTenantDatabase;

@Repository("sysTenantDatabaseMapper")
public interface SysTenantDatabaseMapper {

    int deleteByPrimaryKey(String tenant_id);

    int insert(SysTenantDatabase record);

    int insertSelective(SysTenantDatabase record);


    SysTenantDatabase selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SysTenantDatabase record);

    int updateByPrimaryKey(SysTenantDatabase record);
    String getTenantSchema(String tenant_id);
    
    int getTenantNum(String tenant_id);
    
    
    int getLastID();
    //判断是否有相同名称
    int sameName(String name);
    //查询所有租户的租户id
    List<String> tenantIdList();
}