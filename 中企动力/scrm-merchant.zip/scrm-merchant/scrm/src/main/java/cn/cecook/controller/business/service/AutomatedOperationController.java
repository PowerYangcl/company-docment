package cn.cecook.controller.business.service;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.service.business.service.AutomatedOperationService;
import cn.cecook.service.business.service.ImedicineService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.ArrayList;
import java.util.List;

@Controller
@RequestMapping("/api/ser")
public class AutomatedOperationController {
	@Autowired
	private AutomatedOperationService automatedOperationService;
	@Autowired
	private ImedicineService medicineService;
	@RequestMapping(value = "/test")
	@ResponseBody
	public Object test(){
		List<Integer> list=new ArrayList<Integer>();
		list.add(1);
		list.add(2);
		return (automatedOperationService.insertQuartzTaskByMedicine(2,list, "2", 14537, "2c9700d75d0b9f9c015d0b9f9c320000", "13161911660", "陈永银2", null));
	}
	
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(String ruleObj,long uid,String medicineIds,String tenant_id){
		return (automatedOperationService.insertAutomatedTask(ruleObj,uid,medicineIds,tenant_id));
	}
	
	@RequestMapping(value = "/update")
	@ResponseBody
	public Object update(String ruleObj,String medicineIds,int taskId,String tenant_id){
		return (automatedOperationService.updateAutomatedTask(ruleObj,medicineIds,taskId,tenant_id));
	}
	
	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object detail(int id){
		return (automatedOperationService.automatedTaskDetail(id));
	}
	
	
	@RequestMapping(value = "/automatedList")
	@ResponseBody
	public Object clickList(@RequestBody String param) {
		//System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		return (automatedOperationService.automatedTaskList(startIndex, pageSize, draw));
	}
	
	@RequestMapping(value = "/quartzTaskNum")
	@ResponseBody
	public Object quartzTaskNum(int id) {
		
		return (automatedOperationService.quartzTaskNum(id));
	}
	

	@RequestMapping(value = "/deleteAutomateTask")
	@ResponseBody
	public Object deleteAutomateTask(int id) {
		
		return (automatedOperationService.deleteAutomatedOperation(id));
	}
	@RequestMapping(value = "/medicineList")
	@ResponseBody
	public Object medicineList(@RequestBody String param){
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		String keyWord=jsonObj.get("keyWord").getAsString();
		return (medicineService.MedicineList(startIndex, pageSize, keyWord,draw));
	}
	
	@RequestMapping(value = "/getModelListByMedicineId")
	@ResponseBody
	public Object getModelListByMedicineId(int medicineId) {
		
		return (automatedOperationService.getModelListByMedicineId(medicineId));
	}
	
	@RequestMapping(value = "/isAppraise")
	@ResponseBody
	public Object isAppraise(int medicineId) {
		return (medicineService.isAppraiseByMedicineId(medicineId));
	}
	
}
