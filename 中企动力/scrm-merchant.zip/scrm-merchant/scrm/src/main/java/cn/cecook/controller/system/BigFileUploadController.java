package cn.cecook.controller.system;

import java.io.File;
import java.io.FileOutputStream;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.fileupload.servlet.ServletFileUpload;
import org.apache.commons.io.FileUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.context.WebApplicationContext;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Operator;

@Controller
@RequestMapping("/bigFileUpload")
public class BigFileUploadController {
	@Autowired
	private WebApplicationContext webApplicationContext;

	@RequestMapping("/uploadView")
	public String uploadView() {
		return "system/dataImport";
	}

	@RequestMapping(method = { RequestMethod.POST }, value = { "/webUploader" })
	@ResponseBody
	public void webUploader(HttpServletRequest request, HttpServletResponse response) throws Exception {
		try {
			String fileId = request.getParameter("uid");
			int chunk = 0;
			String fileName = "";
			String file_ext = request.getParameter("ext");
			if(null != request.getParameter("chunk")) {
				chunk = Integer.parseInt(request.getParameter("chunk"));
				fileName = fileId + "_" + chunk;
			}else {
				fileName = fileId+"."+file_ext;
			}
			String FPATH = this.getClass().getClassLoader().getResource("/").getPath();
			String savefilepath = FPATH + "upload/" + fileId;
			File parentFileDir = new File(savefilepath);
			if (!parentFileDir.exists()) {
				parentFileDir.mkdirs();
			}
			boolean isMultipart = ServletFileUpload.isMultipartContent(request);
			MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
			if (isMultipart) {
				MultipartFile multipartFile = multipartRequest.getFile("multiFile");// 获取表单
				File tempPartFile = new File(savefilepath, fileName);
				multipartFile.transferTo(tempPartFile);
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
	}

	@RequestMapping("/uploadSuccess")
	@ResponseBody
	public String uploadSuccess(String fileId, int chunks, String fileExtName,String beanName,String paramJsonStr,HttpServletRequest request) throws Exception {
		try {
			String FPATH = this.getClass().getClassLoader().getResource("/").getPath();
			String savefilepath = FPATH + "upload/" + fileId;
			File[] listFiles = new File(savefilepath).listFiles();
			File destFile = new File(savefilepath, fileId + "." + fileExtName);
			if (chunks>1 && listFiles.length == chunks) {
				FileOutputStream os = new FileOutputStream(destFile, true);
				for (int i = 0; i < chunks; i++) {
					File file = new File(savefilepath, fileId + "_" + i);
					FileUtils.copyFile(file, os);
				}
				os.close();
			}
			if(beanName != null) {
				Operator operator = (Operator) webApplicationContext.getBean(beanName);
				if(operator != null) {
					Map<String,Object> paramMap=null;
					if(!StringUtils.isEmpty(paramJsonStr)) {
						paramMap=FastJsonUtil.json2map(paramJsonStr);
					}
					operator.operate(destFile.getAbsolutePath(),paramMap);
				}
			}
			return "true";
		}catch (Exception e) {
			e.printStackTrace();
			return "false";
		}
	}
}