package cn.cecook.dao.business.service;

import java.util.List;

import cn.cecook.model.business.service.AuditingMedicine;
import cn.cecook.model.business.service.CriterionMedicine;

/**
 * 数据匹配mapper
 * @author majie
 *
 */
public interface AuditingMedicineMapper {
	/**
	 * 查询所有的数据
	 * @return
	 * majie
	 */
	public List<AuditingMedicine> findAll(AuditingMedicine auditingMedicine);
	/**
	 * 添加数据
	 * @param auditingMedicine
	 * @return
	 * majie
	 */
	public Integer addAuditingMedicine(AuditingMedicine auditingMedicine);
	/**
	 * 修改数据
	 * @param auditingMedicine
	 * @return
	 * majie
	 */
	public Integer updateAuditingMedicine(AuditingMedicine auditingMedicine);
	/**
	 * 获得数据量
	 * @param auditingMedicine
	 * @return
	 * majie
	 */
	public Integer getCount(AuditingMedicine auditingMedicine);
	/**
	 * 根据id获取信息
	 * @param auditingMedicine
	 * @return
	 * majie
	 */
	public AuditingMedicine getOne(AuditingMedicine auditingMedicine);
	/**
	 * 根据条形码和国药准字精确匹配
	 * @return
	 * majie
	 */
	public List<AuditingMedicine> findByBarCodeAndnumberApproval();
}
