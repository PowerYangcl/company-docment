package cn.cecook.dao.open.mp;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpMaterialNews;

public interface MpMaterialNewsMapper {
	
	public int getCount(@Param(value = "tenant_id") String tenant_id);
	public int getCountByCondition(@Param(value = "tenant_id") String tenant_id, @Param(value = "dateStart") Date dateStart, @Param(value = "dateEnd") Date dateEnd, @Param(value = "keyword") String keyword);

	public MpMaterialNews selectNewsById(int id);
	public MpMaterialNews selectNewsByMediaId(@Param(value = "tenant_id") String tenant_id, @Param(value = "media_id") String mediaId);
	public List<MpMaterialNews> selectMaterialByPage(@Param(value = "tenant_id") String tenant_id, @Param(value = "pageStart") int pageStart, @Param(value = "pageSize") int pageSize);
	public List<MpMaterialNews> selectMaterialByCondition(@Param(value = "tenant_id") String tenant_id, @Param(value = "pageStart") int pageStart, @Param(value = "pageSize") int pageSize, @Param(value = "dateStart") Date dateStart, @Param(value = "dateEnd") Date dateEnd, @Param(value = "keyword") String keyword);
	
	public int insertNews(MpMaterialNews mpMaterialNews);
	public void updateNews(@Param(value = "tenant_id") String tenant_id, @Param(value = "mediaNews") MpMaterialNews mpMaterialNews);

	public void delAll(String tenant_id);
	public void delById(@Param(value = "tenant_id") String tenant_id, @Param(value = "id") int id);
	public void delByMediaId(@Param(value = "tenant_id") String tenant_id, @Param(value = "media_id") String mediaId);

}
