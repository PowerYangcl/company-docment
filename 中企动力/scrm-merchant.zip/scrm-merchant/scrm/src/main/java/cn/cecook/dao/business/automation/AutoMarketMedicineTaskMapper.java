package cn.cecook.dao.business.automation;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.automation.AutoMarketMedicineTask;

public interface AutoMarketMedicineTaskMapper {
	int deleteByPrimaryKey(Integer id);

	int insert(AutoMarketMedicineTask record);

	int insertSelective(AutoMarketMedicineTask record);

	AutoMarketMedicineTask selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(AutoMarketMedicineTask record);

	int updateByPrimaryKey(AutoMarketMedicineTask record);

	List<AutoMarketMedicineTask> listAutoMarketMedicineTask(@Param("tenantId") String tenantId,
			@Param("executionTime") String executionTime);
	
	/**
	 * 
	* @Description: 
	* @param param 传入tenantId  executionTime  status
	* @return
	*
	* @author: wschenyongyin
	* @date: 2018年3月23日 下午8:34:11
	 */
	int updateStatusByExecutionTime(Map<String,Object> param);
}