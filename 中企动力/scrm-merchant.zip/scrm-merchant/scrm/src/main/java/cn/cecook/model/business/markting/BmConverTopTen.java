package cn.cecook.model.business.markting;

import java.io.Serializable;

import org.springframework.stereotype.Component;

/**
 * 名片转化排行实体
 * @author 0
 *
 */
@Component
public class BmConverTopTen implements Serializable{
    
	//名称
	private String name;
	
	//转化量
	private Integer converNum;
	
	//排名
	private Integer rownum;

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	

	public Integer getConverNum() {
		return converNum;
	}

	public void setConverNum(Integer converNum) {
		this.converNum = converNum;
	}

	public Integer getRownum() {
		return rownum;
	}

	public void setRownum(Integer rownum) {
		this.rownum = rownum;
	}

	@Override
	public String toString() {
		return "BmConverTopTen [name=" + name + ", converNum=" + converNum + ", rownum=" + rownum + "]";
	}

	
	
	

}