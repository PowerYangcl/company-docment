package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.SmartRuleBean;
import cn.cecook.model.business.markting.BmMarketRule;
import cn.cecook.model.business.markting.BmMarketRuleExample;

public interface BmMarketRuleMapper {
    int countByExample(BmMarketRuleExample example);

    int deleteByExample(BmMarketRuleExample example);

    int deleteByPrimaryKey(Long id);

    int insert(BmMarketRule record);

    int insertSelective(BmMarketRule record);

    List<BmMarketRule> selectByExample(BmMarketRuleExample example);

    BmMarketRule selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") BmMarketRule record, @Param("example") BmMarketRuleExample example);

    int updateByExample(@Param("record") BmMarketRule record, @Param("example") BmMarketRuleExample example);

    int updateByPrimaryKeySelective(BmMarketRule record);

    int updateByPrimaryKey(BmMarketRule record);
    
    SmartRuleBean getRuleDetail(long rule_id);
    
    //批量删除
    int deleteByCollection(List<Long> ids);
}