package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import cn.cecook.model.system.SysUser;
import cn.cecook.model.system.SysUserExample;
import cn.cecook.uitls.Pages;

/**
 * @author wschenyongyin
 * @explain 用户表
 * @date 2017年5月22日
 */
public interface SysUserMapper {
    int countByExample(SysUserExample example);

    int deleteByExample(SysUserExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SysUser record);

    int insertSelective(SysUser record);

    List<SysUser> selectByExample(SysUserExample example);

    SysUser selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SysUser record, @Param("example") SysUserExample example);

    int updateByExample(@Param("record") SysUser record, @Param("example") SysUserExample example);

    int updateByPrimaryKeySelective(SysUser record);

    int updateByPrimaryKey(SysUser record);

    //根据账号，查询用户
    SysUser selectSysUserByAccount(String account);

    //更新Sysuser
    int updateSysUserByIDAndTid(SysUser user);

    //根据租户id查询对象
    SysUser selectSysUserByTenantId(Map map);

    //根据id查询用户
    SysUser selectSysUserById(Long uid);

    /**
     * 根据登录手机账号查询用户
     *
     * @explain
     * @author sunny
     */
    SysUser findByAccount(String account);

    /**
     * sunny
     * 查询账号列表资料
     *
     * @author sunny
     */
    List<Map<String, Object>> sysuserDetailList(Pages<Map<String, Object>> pages);

    /**
     * sunny
     * 查询列表显示账户总数
     */
    int sysuserDetailListCount(Map<String, Object> where);

    /**
     * sunny
     * 查询用户详细信息
     */
    Map<String, Object> sysuserDetail(@Param("id") Long id);

    /**
     * sunny
     * 更新用户状态
     */
    int updateStatusByID(Long id, int status);

    /**
     * sunny
     * 删除用户
     */
    int updateisDeletedByID(@Param("id") Long id, @Param("isDeleted") int isDeleted);

    /**
     * 获取库中所有可用的角色
     *
     * @explain
     * @author sunny
     * @date 2017年6月13日
     */
    List<Map<String, Object>> getRoles(String tenant_id);

    /**
     * 管理员更新用户信息
     *
     * @explain
     * @author sunny
     * @date 2017年6月13日
     */
    int updateSysInfoByID(SysUser sysuser);
    

    /**
     * 获取库中所有可用的部门
     *
     * @explain
     * @author sunny
     * @date 2017年6月13日
     */
    List<Map<String, Object>> getDepartments(String tenant_id);

    /**
     * @explain 部门删除后，更新部门主管的部门id
     * @author LeeX
     * @date 2017年6月16日 下午8:23:42
     */
    int updateDepartmentByLeaderId(Long leaderId);

    /**
     * @explain 更新登陆后的access_token和失效时间
     * @author LeeX
     * @date 2017年6月19日 下午2:07:15
     */
    int updateTokenAndTimeByUser(SysUser user);

    /**
     * @explain 更新短信登录次数到bak4
     * @author LeeX
     * @date 2017年6月19日 下午3:03:04
     */
    int updateLoginCodeTimesByUser(SysUser sysUser);

    /**
     * @explain 更新User
     * @author LeeX
     * @date 2017年6月19日 下午8:34:11
     */
    int updateSysUserById(SysUser user);

    /**
     * @explain 查询单个系统管理员
     * @author LeeX
     * @date 2017年6月21日 下午3:37:31
     */
    SysUser selectSuperUserByTenantId(String tenant_id);

    /**
     * @explain 更新remarks   标记子账号的初次登陆
     * @author LeeX
     * @date 2017年6月28日 下午7:39:55
     */
    int updateRemarksByUser(SysUser user);

    /**
     * @explain 查部门成员
     * @author LeeX
     * @date 2017年6月29日 下午2:59:53
     */
    List<SysUser> selectUserByIdTidDid(Map<String, Object> map);

    /**
     * 更新个人兴趣
     *
     * @return int
     * @author LeeX
     * @time 2017年7月20日 上午9:14:18
     * @params updateUserHobbyByTidUid
     */
    int updateUserInfoByTidUid(Map map);

    /**
     * sunny
     * 删除客户
     */
    int delCustomer(@Param("id") Long id);

    /**
     * 根据租户ID查询用户,注册使用
     *
     * @explain
     * @author sunny
     */
    SysUser findByT(String tenant_id);

    /**
     * @explain 审核用户账号
     * @author wschenyongyin
     */
    int AuditAccount(Map<String, Object> map);

    /**
     * 按天获取短信商机转化按日
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getbmActivityBrowseDay(Map<String, Object> map);

    /**
     * 按天获取打开量
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getBmWriteOffDay(Map<String, Object> map);

    /**
     * 按天获取短信商机转化按月
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getbmActivityBrowseMonth(Map<String, Object> map);

    /**
     * 按天获取打开量按月
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getBmWriteOffMonth(Map<String, Object> map);

    /**
     * 获取短信商机转化按年
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getbmActivityBrowseYear(Map<String, Object> map);

    /**
     * 获取打开量按年
     *
     * @param map
     * @return
     */
    List<Map<String, Object>> getBmWriteOffYear(Map<String, Object> map);

    /**
     * * 根据工号查询
     *
     * @param tenant_id
     * @param staff_id
     * @return
     */
    SysUser findByJobNumber(@Param("tenant_id") String tenant_id, @Param("staff_id") String staff_id);

    /**
     * 查询刚入库的用户ID
     * @param account
     * @param tenant_id
     * @return
     */
    SysUser synWithCrm(@Param("account") String account, @Param("tenant_id") String tenant_id);

    /**
     * 根据服务类型ID动态维护授权表，将授权次数减1
     * @param i
     */
	void updateSqNum(@Param("sqNum") Integer sqNum, @Param("tenant_id") String tenant_id, @Param("productId") String productId);

    @Select("select company,district_name as districtName,account,tenant_id as tenantId,name,id from sys_user where tenant_id = #{tenant_id} order by create_time limit 1")
    SysUser findUserCreateWhoTenant(@Param("tenant_id") String tenant_id);
    /**
    * 获取用户的部门信息
    * @param uid
    * @param tenant_id
    * @return
    * majie
    */
   public Map<String,Object> getUserDepartment(Map<String,Object> map);
   /**
    * 获取用户的对接系统的权限信息
    * @param tenant_id
    * @return
    */
	List<Map<String, Object>> getDockList(String tenant_id);


	@Select("SELECT a.id,a.NAME,a.account,GROUP_CONCAT(c.NAME) AS remarks FROM sys_user a LEFT JOIN sys_user_role b ON a.id=b.user_id LEFT JOIN sys_role c ON b.role_id=c.id WHERE a.id=#{uid} AND a.is_deleted=0 AND b.is_deleted=0 AND c.is_deleted=0 GROUP BY a.id")
	SysUser selectNameAndRoleByUid(@Param("uid") String uid);

	/**
	 * 获取短信消耗条数
	 * @return
	 */
	List<Map<String, Object>> getSmsCount();

	/**
	 * 根据手机号查询用户是否存在
	 * @param sysUserExample
	 * @return
	 * majie
	 */
	public List<SysUser> selectByCount(SysUserExample sysUserExample);

	/**
	 * 获取导入数据
	 * @param tenant_id
	 * @return
	 */
	List<Map<String, Object>> getImportData(String tenant_id);
	
	/**
	 * 插入导入的数据
	 * @param user
	 * @return
	 */
	Long insertSelectiveImport(SysUser user);

    List<SysUser> getUserAllByNameOrPhone(Map<String, Object> map);
    List<SysUser> getUserAllBydepartment(String department_id);
    List<SysUser> getUserAll(String tenantId);
    
    int getUserCountByNameOrPhone(Map<String, Object> map);

    SysUser getUserNameByUserId(long l);

    List<SysUser> loadUserAll(Map<String, Object> map);

    int getUserNameCountByUserId(long l);

    int loadUserAllCount(Map<String, Object> map);
    /**
     * 根据部门id查询部门下所有员工
     * @param departmentId
     * @return
     * majie
     */
    public Integer getCountByDepartmentId(String departmentId);
    /**
     * 根据account,token,过期时间，更新数据库
     * @param account
     * @param token
     * @param token2
     * @return
     */
	int updateUserToken(@Param("account") String account,@Param("token") String token,@Param("expiryTime") String expiryTime);
	/**
	 * 根据token获取account、password、third_token_expiry_time
	 * @param token
	 * @return
	 */
	Map<String, Object> selectSysUserByToken(String token);
}
