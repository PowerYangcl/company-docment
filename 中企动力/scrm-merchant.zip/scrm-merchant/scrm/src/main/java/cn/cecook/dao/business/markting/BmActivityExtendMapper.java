package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmActivityExtend;

public interface BmActivityExtendMapper {


    int deleteByPrimaryKey(Long id);

    int insert(BmActivityExtend record);

    int insertSelective(BmActivityExtend record);


    BmActivityExtend selectByPrimaryKey(Long id);



    int updateByPrimaryKeySelective(BmActivityExtend record);

    int updateByPrimaryKey(BmActivityExtend record);
    
    int insertByBatch(List<BmActivityExtend> attachmentTables);
    
    int updateByBatch(List<BmActivityExtend> attachmentTables);
    
    List<Map<String,String>> queryList(long activity_id);
    
}