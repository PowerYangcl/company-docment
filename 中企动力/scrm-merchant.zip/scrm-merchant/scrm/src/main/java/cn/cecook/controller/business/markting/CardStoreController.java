package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.ICardStoreService;

@Controller
@RequestMapping("/api/card_store")
public class CardStoreController {
	@Autowired
	ICardStoreService cardStoreService;
	
	@RequestMapping(value="/insert")
    @ResponseBody
    public Object insert(String card_id,String store_ids){
        return (cardStoreService.insert(card_id, store_ids));
    }
	
	@RequestMapping(value="/query")
    @ResponseBody
    public Object query(String card_id,String store_ids){
        return (cardStoreService.query(card_id));
    }
}
