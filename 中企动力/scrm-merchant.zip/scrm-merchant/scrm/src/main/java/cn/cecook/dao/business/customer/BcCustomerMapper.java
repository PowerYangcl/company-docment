package cn.cecook.dao.business.customer;

import cn.cecook.model.business.customer.BcCustomer;
import cn.cecook.uitls.Pages;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import java.util.Date;
import java.util.List;
import java.util.Map;

/**
 * @author wschenyongyin
 * @explain 客户表
 * @date 2017年5月22日
 */
@Repository("bcCustomerMapper")
public interface BcCustomerMapper {

    /**
     * 查询客户资料列表
     *
     * @param page
     * @return
     */
    List<Map<String, Object>> customerDetailList(
            Pages<Map<String, Object>> pages);

    /**
     * 查询客户详细资料
     *
     * @param id
     * @return
     */
    BcCustomer customerDetail(@Param("id") int id);

    BcCustomer customerDetail2(@Param("id") int id, @Param("tenantId") String tenantId);

    /**
     * 添加客户
     *
     * @param customer
     * @return
     */
    int addCustomer(BcCustomer customer);

    /**
     * 编辑客户信息
     *
     * @param customer
     * @return
     */
    int editCustomer(@Param("customer") BcCustomer customer);

    /**
     * 删除客户信息
     *
     * @param id
     * @return
     */
    int delCustomer(@Param("id") int id);

    /**
     * 查询客户总数
     *
     * @param where
     * @return
     */
    int customerDetailListCount(@Param("where") Map<String, Object> where);

    /**
     * 根据用户手机号查询用户信息
     *
     * @param bcCustomer
     * @return
     */
    Integer findCustomerByPhoneCount(@Param("phone") String phone,
                                     @Param("name") String name);

    /**
     * 获取发送列表总条数
     *
     * @param count
     * @return
     */
    int customerConditionCount(@Param("count") String condition);

    /**
     * 获取发送列表信息
     *
     * @param condition
     * @param count
     * @return
     */
    List<Map<String, Object>> customerConditionList(
            @Param("condition") String condition, @Param("count") int count);

    /**
     * 获取客户分类列表数据
     *
     * @param condition
     * @return
     */
    List<Map<String, Object>> getCustomerClassification(
            @Param("condition") String condition, @Param("uid") Long uid,
            @Param("svalue") String svalue, @Param("bvalue") String bvalue);

    /**
     * 查询流失客户资料列表
     *
     * @param page
     * @return
     */
    List<Map<String, Object>> getLossCustromer(Pages<Map<String, Object>> pages);

    /**
     * 获取流失客户总条数
     *
     * @param condition
     * @return
     */
    int getLossCustromerCount(Pages<Map<String, Object>> page);


    /**
     * 未获取流失客户总条数
     *
     * @param condition
     * @return
     */
    int getNoLossCustromerCount(Pages<Map<String, Object>> page);

    /**
     * 获取流失客户总条数
     *
     * @param condition
     * @return
     */
    int getCustomerLoseCustomerCount(@Param("state") int state,
                                     @Param("loseCustomer") int loseCustomer, @Param("uid") Long uid);

    //查询客户总数
    int getCustomerTotalCount(@Param("uid") long uid);

    /**
     * 获取流失客户列表
     *
     * @param condition
     * @return
     */
    List<Map<String, Object>> getCustomerLoseCustomerList(
            @Param("state") int state, @Param("loseCustomer") int loseCustomer,
            @Param("map") Map<String, Object> map);


    List<Map<String, Object>> getCustomerTotalCustomerList(
            @Param("map") Map<String, Object> map);

    /**
     * 获取消费过客户数量
     *
     * @return
     */
    int getBmWriteOffCount(Pages<Map<String, Object>> pages);

    /**
     * 查询客户时间属性列表
     *
     * @param page
     * @return
     */
    List<Map<String, Object>> getTotalDay(Pages<Map<String, Object>> pages);

    /**
     * 获取客户交易量列表
     *
     * @param page
     * @return
     */
    List<Map<String, Object>> getTradingVolume(Pages<Map<String, Object>> pages);

    /**
     * 获取客户频率列表
     *
     * @param page
     * @return
     */
    List<Map<String, Object>> getTotalConsumption(
            Pages<Map<String, Object>> pages);

    /**
     * 获取客户来源分类数据
     *
     * @return
     */
    List<Map<String, Object>> getCustomerSourceChar(Map<String, Object> map);

    /**
     * 查询所有客户
     *
     * @return
     */
    int getCustomerCount();

    /**
     * 获取新用户数量
     *
     * @return
     */
    int getNewCustromerCount(@Param("day") int day,
                             @Param("frequency") int frequency, @Param("uid") Long uid);

    /**
     * 获取新用户列表
     *
     * @return
     */
    List<Map<String, Object>> getNewCustromerList(@Param("day") int day,
                                                  @Param("frequency") int frequency,
                                                  @Param("map") Map<String, Object> map);

    /**
     * 获取老用户数量
     *
     * @return
     */
    int getOldCustromerCount(@Param("day") int day,
                             @Param("frequency") int frequency, @Param("uid") Long uid);

    /**
     * 获取老用户列表
     *
     * @return
     */
    List<Map<String, Object>> getOldCustromerList(@Param("day") int day,
                                                  @Param("frequency") int frequency,
                                                  @Param("map") Map<String, Object> map);

    /**
     * 获取交易频率分类
     *
     * @param state
     * @param totalConsumption
     * @return
     */
    int getCustomerTotalConsumptionChar(Map<String, Object> map);

    /**
     * 获取 常、过、忠客列表
     *
     * @param state
     * @param totalConsumption
     * @return
     */
    /*
     * List<Map<String, Object>> getCustomerTotalConsumptionList(@Param("state")
	 * int state,
	 * 
	 * @Param("totalConsumption") Double
	 * totalConsumption,@Param("map")Map<String, Object> map);
	 */
    List<Map<String, Object>> getCustomerTotalConsumptionList(
            Map<String, Object> map);

    /**
     * 获取交易量
     *
     * @return
     */
    int getCustomerTradingVolumeChar(@Param("condition") String condition,
                                     @Param("svalue") String svalue, @Param("bvalue") String bvalue, @Param("uid") Long uid);

    /**
     * 获取 主力、一般、零散 客户
     *
     * @param condition
     * @param svalue
     * @param bvalue
     * @return
     */
    List<Map<String, Object>> getCustomerTradingVolumeList(
            @Param("condition") String condition,
            @Param("svalue") String svalue, @Param("bvalue") String bvalue,
            @Param("map") Map<String, Object> map);

    /**
     * @param phone
     * @return
     */
    List<BcCustomer> findCustomerByPhone(@Param("phone") String phone, @Param("uid") Long uid);

    /**
     * 删除客户信息
     *
     * @param id
     * @return
     */
    int delectCustomer(@Param("id") int id, @Param("date") Date date);

    /**
     * 删除客户核销信息
     *
     * @param id
     * @return
     */
    int delectWriteOffCustomer(@Param("id") int id, @Param("date") Date date);

    /**
     * 删除客户行为信息
     *
     * @param id
     * @return
     */
    int delectActionCustomer(@Param("id") int id, @Param("date") Date date);

    /**
     * 获取客户消费总数
     *
     * @param id
     * @return
     */
    int findMoneyTotalByid(@Param("id") int id);

    /**
     * 获取客户消费排名
     *
     * @return
     */
    int findMoneyRanking(@Param("id") int id);

    /**
     * 获取客户消费次数排名
     *
     * @return
     */
    int findCountRanking(@Param("id") int id);

    /**
     * 获取右侧新客户老客户信息
     *
     * @param state
     * @param day
     * @param count
     * @return
     */
    List<Map<String, Object>> rightNewOrOld(@Param("state") int state,
                                            @Param("day") String day, @Param("count") String count, @Param("uid") Long uid);

    /**
     * 获取右侧新客户老客户信息
     *
     * @param state
     * @param day
     * @param count
     * @return
     */
    /*
     * List<Map<String, Object>> rightTotalConsumption(@Param("state")int state,
	 * @Param("value")Double value, @Param("valueMax")Double valueMax);
	 */
    List<Map<String, Object>> rightTotalConsumption(Map<String, Object> map);

    /**
     * 获取右侧流失
     *
     * @param state
     * @param day
     * @param count
     * @return
     */
    List<Map<String, Object>> getRigehtLossCustromer(
            Map<String, Object> map);


    /**
     * CRM系统更新BcCustomer
     *
     * @param customer
     * @return
     */
    int editCustomerByCRM(@Param("customer") BcCustomer customer);


    BcCustomer findCustomerOnlyByPhone(@Param("phone") String phone);

    @Update("update bc_customer set cust_limit = cust_limit+#{transLimit} where id = #{id}")
    int updateTransLimit(@Param("id") Integer id, @Param("transLimit") int transLimit);

/*    @Update("update bc_customer set last_cost_time = #{lastCostTime} where id = #{id}")
    int editCustomerLastCostTime(BcCustomer bcCustomer);*/
    /**
     * 根据crm同步订单更新会员信息
     * @param bcCustomer
     * @return
     * majie
     */
    int editCustomerBySynCRMTransaction(BcCustomer bcCustomer);
}