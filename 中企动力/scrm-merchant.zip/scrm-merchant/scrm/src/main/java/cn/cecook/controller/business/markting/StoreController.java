package cn.cecook.controller.business.markting;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.markting.BmStore;
import cn.cecook.service.business.markting.StoreService;

@Controller
@RequestMapping("/api/store")
public class StoreController {

    @Autowired
    private StoreService storeService;

    /**
     * 查询所有列表
     *
     * @param allMap
     * @param key_word
     * @return
     */
    @RequestMapping(value = "/getAll")
    @ResponseBody
    public Object getAll(String key_word, String startIndex, String page_size) {
        return storeService.getAll(key_word, startIndex, page_size);
    }

    /**
     * 编辑操作
     *
     * @param upMap
     * @return
     */
    @RequestMapping(value = "/updateStore")
    @ResponseBody
    public Object updateStore(BmStore bmStore) {
        return storeService.updateStore(bmStore);
    }

    /**
     * 删除操作
     *
     * @param bmStore
     * @return
     */
    @RequestMapping(value = "/deleteStore")
    @ResponseBody
    public Object deleteStore(BmStore bmStore) {
    	
        return storeService.deleteStore(bmStore);
    }

    /**
     * 删除操作(无需确认是否被选中)
     *
     * @param bmStore
     * @return
     */
    @RequestMapping(value = "/direct_deleteStore")
    @ResponseBody
    public Object directDeleteStore(BmStore bmStore) {
    	
        return storeService.directDeleteStore(bmStore);
    }

    /**
     * 插入门店
     *
     * @param bmStore
     * @return
     */
    @RequestMapping(value = "/insertStore")
    @ResponseBody
    public Object insertStore(BmStore bmStore) {
    	
        return storeService.insertStore(bmStore);
    }


    /**
     * 根据id查询门店
     *
     * @param bmStore
     * @return
     */
    @RequestMapping(value = "/queryOne")
    @ResponseBody
    public Object queryOne(BmStore bmStore) {
    	
        return storeService.queryOne(bmStore);
    }

    /**
     * @explain 获取门店总数
     * @author MAJIE
     * @date 2017年10月15日 下午3:01:31
     */
    @RequestMapping(value = "/getCount")
    @ResponseBody
    public Object getCount() {
    	
        return storeService.getCount();
    }
    /**
     * 根据门店名称获取门店信息
     * @param name
     * @return
     * majie
     */
    @RequestMapping(value="/findByName")
    @ResponseBody
    public Object findByName(String name) {
        return storeService.findByName(name);
    }
}
