package cn.cecook.bean.business.markting;

public class MarketSendTimeBean {
	private int now;

	private String from_last_timer;

	private String from_first_time;

	private String from_last_activity;

	private String date;
	
	
	
	

}
