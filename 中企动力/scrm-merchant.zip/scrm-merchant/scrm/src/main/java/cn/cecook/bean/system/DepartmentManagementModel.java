package cn.cecook.bean.system;

import java.util.Date;

/**
 * 
 *@explain 部门管理bean
 * @author ZHIWEN
 * @data 2017年6月14日
 */



public class DepartmentManagementModel extends SysBaseResultModel {


    /**
	 * @explain
	 * @author ZHIWEN
	 * @date 2017年6月20日
	 */
	private static final long serialVersionUID = -3492722647695303727L;

	private Long id;
    
	private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Long createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String name;

    private String code;

    private String description;

    private Long parentDeptId;

    private Long leaderId;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;
	

	/**
	 * 继承BaseResultModel的bean，可查相关参数。
	 * 复制了一份部门pojo，牵涉到多表，可加入其他类 ：如private SysRole sysrole;
	 */
	


	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Long getCreateId() {
		return createId;
	}

	public void setCreateId(Long createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getCode() {
		return code;
	}

	public void setCode(String code) {
		this.code = code;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public Long getParentDeptId() {
		return parentDeptId;
	}

	public void setParentDeptId(Long parentDeptId) {
		this.parentDeptId = parentDeptId;
	}

	public Long getLeaderId() {
		return leaderId;
	}

	public void setLeaderId(Long leaderId) {
		this.leaderId = leaderId;
	}

	public String getBak1() {
		return bak1;
	}

	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}

	public String getBak2() {
		return bak2;
	}

	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}

	public String getBak3() {
		return bak3;
	}

	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}

	public String getBak4() {
		return bak4;
	}

	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}

	public String getBak5() {
		return bak5;
	}

	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}

	@Override
	public String toString() {
		return "DepartmentManagement [id=" + id + ", uuid=" + uuid
				+ ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createId=" + createId + ", createTime=" + createTime
				+ ", orderCode=" + orderCode + ", deleteTime=" + deleteTime
				+ ", remarks=" + remarks + ", attachment=" + attachment
				+ ", name=" + name + ", code=" + code + ", description="
				+ description + ", parentDeptId=" + parentDeptId
				+ ", leaderId=" + leaderId + ", bak1=" + bak1 + ", bak2="
				+ bak2 + ", bak3=" + bak3 + ", bak4=" + bak4 + ", bak5=" + bak5
				+ "]";
	}
		
}
