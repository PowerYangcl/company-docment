package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * 
 * @Title MarketModelBean.java
 * @Description
 * @author wschenyongyin
 * @date 2017年6月1日
 * @version 1.0
 */

@Component
public class MarketModelBean implements Serializable {
	private int model_id;
	private String uuid;
	private String remarks;
	private String attachment;
	private String model_name;
	private String deployment_id;
	private String model_key;
	private String description;
	private int status;
	private String model_url;
	
	
	
	public int getModel_id() {
		return model_id;
	}
	public void setModel_id(int model_id) {
		this.model_id = model_id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getDeployment_id() {
		return deployment_id;
	}
	public void setDeployment_id(String deployment_id) {
		this.deployment_id = deployment_id;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public String getModel_url() {
		return model_url;
	}
	public void setModel_url(String model_url) {
		this.model_url = model_url;
	}
	public String getModel_name() {
		return model_name;
	}
	public void setModel_name(String model_name) {
		this.model_name = model_name;
	}
	public String getModel_key() {
		return model_key;
	}
	public void setModel_key(String model_key) {
		this.model_key = model_key;
	}
	@Override
	public String toString() {
		return "MarketModelBean [model_id=" + model_id + ", uuid=" + uuid
				+ ", remarks=" + remarks + ", attachment=" + attachment
				+ ", model_name=" + model_name + ", deployment_id="
				+ deployment_id + ", model_key=" + model_key + ", description="
				+ description + ", status=" + status + ", model_url="
				+ model_url + "]";
	}
	


}
