package cn.cecook.controller.open;

import java.util.Calendar;
import java.util.Date;
import java.util.List;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpStatistic;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpStatisticService;
import cn.cecook.thirdparty.open.StatisticUtil;
import cn.cecook.uitls.DateUtils;

@Controller
@RequestMapping("/assist")
public class AssistController {
	private static int maxDay = 60;
	@Autowired
	private IMpAccountService iMpAccountService;
	
	@Autowired
	private IMpStatisticService iMpStatisticService;
	
	/**
	 * 重新获取maxDay天内的所有统计
	 */
	@RequestMapping(value = "/loadallStatistic", method = RequestMethod.GET)
	@ResponseBody
	public void loadallStatistic(HttpServletRequest request, HttpServletResponse response) {
		Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
        String tenantId = String.valueOf(session.getAttribute("tenantId"));
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenantId);
		if(mpAccount != null){			
			iMpStatisticService.delByTenantId(mpAccount.getTenantId());
			String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
			Calendar markCalendar = Calendar.getInstance();
			markCalendar.add(Calendar.DAY_OF_MONTH, 0 - Math.abs(maxDay));
			while(Math.abs(DateUtils.subtrationDate(markCalendar.getTime(), new Date())) >= 0) {
				Calendar startCalendar = Calendar.getInstance();
				startCalendar.setTime(markCalendar.getTime());
				startCalendar.add(Calendar.DAY_OF_MONTH, -7);
				Calendar endCalendar = Calendar.getInstance();
				endCalendar.setTime(markCalendar.getTime());
				endCalendar.add(Calendar.DAY_OF_MONTH, -1);
				List<MpStatistic> mpStatisticList = StatisticUtil.getSummaryAndCumulate(startCalendar.getTime(), endCalendar.getTime(), authorizer_access_token);
				for (int i = 0; i < mpStatisticList.size(); i++) {
					iMpStatisticService.save(tenantId, mpStatisticList.get(i));
				}
				int newdays = (int) Math.abs(DateUtils.subtrationDate(markCalendar.getTime(), new Date()));
				if(newdays > 7) {
					markCalendar.add(Calendar.DAY_OF_MONTH, 7);
				}else if(newdays==0){
					break;
				}else {
					markCalendar.add(Calendar.DAY_OF_MONTH, newdays);					
				}
			}
		}
	}
}
