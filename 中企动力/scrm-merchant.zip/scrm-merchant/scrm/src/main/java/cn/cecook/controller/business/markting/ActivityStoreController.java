package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.IActivityStroeService;

@Controller
@RequestMapping("/api/activity_store")
public class ActivityStoreController {
	
	@Autowired
	IActivityStroeService activityStoreService;
	
	@RequestMapping(value="/insert")
    @ResponseBody
    public Object insert(String activity_id,String store_ids){
		System.out.println(activity_id);
		System.out.println(store_ids);
        return (activityStoreService.insert(activity_id, store_ids));
    }
	
	@RequestMapping(value="/query")
    @ResponseBody
    public Object query(String activity_id){
        return (activityStoreService.query(activity_id));
    }
}
