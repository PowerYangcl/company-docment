package cn.cecook.bean.business.markting;

public class exportManageStoreBean {
	//门店ID
	private String storeId;
	//门店名称
	private String storeName;
	
	
	public String getStoreId() {
		return storeId;
	}
	public void setStoreId(String storeId) {
		this.storeId = storeId;
	}
	public String getStoreName() {
		return storeName;
	}
	public void setStoreName(String storeName) {
		this.storeName = storeName;
	}
	
}
