package cn.cecook.dao.business.markting;

import cn.cecook.model.business.markting.BmCoupon;
import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Map;

@Repository("bmCouponDao")
public interface BmCouponMapper {
	int deleteByPrimaryKey(Integer id);

	int insert(BmCoupon record);

	int insertSelective(BmCoupon record);

	BmCoupon selectByPrimaryKey(Integer id);

	int updateByPrimaryKeySelective(BmCoupon record);

	int updateByPrimaryKey(BmCoupon record);

	/**
	 * 核销验证
	 *
	 * @param map
	 * @return
	 */

	BmCoupon selectWriteOff(Map<String, Object> map);

	/**
	 * 获取最近一条参加的活动信息
	 *
	 * @param map
	 * @return
	 */
	BmCoupon lastcRecord(Map<String, Object> map);

	BmCoupon queryCouponDetail(Map<String, Object> map);

	// 更新优惠券使用状态
	int updateCoupongStatus(Map<String, Object> map);

	// 统计活动领取优惠券人数
	int countActivityCoupon(long activity);

	int countActivityCoupon2(long activity);

	// 统计不同渠道提交表单数
	Map<String, Integer> countSubmit(long activity_id);

	Map<String, Integer> countSubmit2(long activity_id);

	int countTotalSubmit(long activity_id);

	// 查询参与活动的用户
	List<Map<String, Object>> getJoinActivityCustomerList(Map<String, Object> map);

	// 查询当日活动转化列表（根据card_id）
	List<Map<String, Object>> selectActivityRevertListForDate(long card_id);

	// 查询当月活动转化列表（根据card_id）
	List<Map<String, Object>> selectActivityRevertListForMonth(long card_id);

	// 查询当年活动转化列表（根据card_id）
	List<Map<String, Object>> selectActivityRevertListForYear(long card_id);

	int updateConponStatus(Map<String, Object> map);

	// 根据反核销更新优惠券状态
	int updateStatus(BmCoupon bmcoupon);

	// 更新优惠券发送状态
	int updateSendStatus(String coupon_code);

	// 更新优惠券状态为1
	int updateStus(String couponCode);

	// 根据反核销更新优惠券状态为0
	int updateStatus(long id);

	// 判断是否已核销
	int selectStatus(String couponCode);

	int countCustomerNum(long activity_id);

	// 统计来源
	String getSource(long id);

	// 查询剩余优惠券
	int residueCoupon(long id);

	// 查询智能营销活动剩余优惠券
	int residueCouponMarket(long id);

	// 查询是否存在该优惠券
	BmCoupon selectCoupon(String couponCode);

	// v2.0版本查询
	Map<String, Object> selectCouponV2(String couponCode);

	Map<String, Object> selectCouponByApp(String couponCode);

	// 判断活动是否有未核销的优惠券
	int activityHaveCoupon(long id);

	Map<String, Object> getBatch(long id);

	// 用户没有登录的情况下查询优惠券是否使用
	int getCounponStatus(@Param("couponId") int couponId, @Param("tenantId") String tenantId);

	int getCounponStatusByCouponCode(@Param("couponCode") String couponCode, @Param("tenantId") String tenantId);

	@Select("SELECT coupon_name AS couponName,IFNULL(face_value,0) AS faceValue,expiry_date AS expiryDate,limit_price,coupon_code AS couponCode FROM bm_coupon WHERE is_used=0 AND is_deleted=0 AND customer_phone=#{phone}")
	List<BmCoupon> findCouponsByPhone(@Param("phone") String phone);

	Map<String, Object> getTempCouponCode(int thirdId);

	int updateTempCouponStatus(int id);

	int getTempRemainCounponNum(int thirdId);

	List<Map<String, Object>> queryCouponListByPhone(@Param("phone") String phone);

	BmCoupon queryDetailByIdAndTenantId(@Param("couponId") int couponId, @Param("tenantId") String tenantId);

	int insetByBatch(Map<String, Object> map);

	List<Map<String, Object>> getCouponListByCustomerId(int customerId);

	/**
	 * 
	 * Title: countNumByStatus Description:统计用户已使用优惠券数量
	 * 
	 * @param status
	 *            优惠券使用
	 * @return
	 */
	int countNumByUsed(@Param("customerId") int customerId);

	/**
	 * 
	 * Title: countNumByUnValid Description:统计用户过期优惠券数量
	 * 
	 * @param customerId
	 * @return
	 */
	int countNumByUnValid(@Param("customerId") int customerId);

	/**
	 * 
	 * Title: countNumByValid Description:统计用户未使用状态优惠券数量
	 * 
	 * @param customerId
	 * @return
	 */
	int countNumByValid(@Param("customerId") int customerId);

	/**
	 * 
	 * Title: getValidCouponListByCustomerId Description:获取用户优惠券列表
	 * 
	 * @param customerId
	 * @return
	 */

	List<Map<String, Object>> getValidCouponListByCustomerId(@Param("customerId") int customerId);

	/**
	 * 
	 * Title: getUnValidCouponListByCustomerId Description:获取用户过期列表
	 * 
	 * @param customerId
	 * @return
	 */
	List<Map<String, Object>> getUnValidCouponListByCustomerId(@Param("customerId") int customerId);

	/**
	 * 
	 * Title: getUsedCouponListByCustomerId Description:获取用户已使用列表
	 * 
	 * @param customerId
	 * @return
	 */
	List<Map<String, Object>> getUsedCouponListByCustomerId(@Param("customerId") int customerId);

	/**
	 * 
	 * @Description: 根据第三方优惠券模板id统计优惠券领取
	 * @param modelId
	 * @param type
	 * @return
	 *
	 * @author: wschenyongyin
	 * @date: 2018年3月20日 下午8:41:48
	 */
	List<Map<String, Object>> countActivityCouponNumByThirdPartyModelId(@Param("modelId") int modelId);
	
	
	List<Map<String, Object>> countCouponBatchNumByThirdPartyModelId(@Param("modelId") int modelId);
	
	List<Map<String, Object>> countTaskCouponNumByThirdPartyModelId(@Param("modelId") int modelId);

}