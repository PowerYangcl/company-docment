package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

@Component
public class ActivityModelBean {
	// 模板id
	private String id;
	// 备注
	private String remarks;

	// 附件
	private String attachment;

	// 名称
	private String name;

	// 描述
	private String description;

	// 模板标签
	private String tag;

	// 模板地址
	private String web_url;

	private String model_pic;

	private String type;
	private String protrait_tag;
	
	private String thumbnail_pic;

	public String getThumbnail_pic() {
		return thumbnail_pic;
	}

	public void setThumbnail_pic(String thumbnail_pic) {
		this.thumbnail_pic = thumbnail_pic;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getProtrait_tag() {
		return protrait_tag;
	}

	public void setProtrait_tag(String protrait_tag) {
		this.protrait_tag = protrait_tag;
	}

	public String getModel_pic() {
		return model_pic;
	}

	public void setModel_pic(String model_pic) {
		this.model_pic = model_pic;
	}

	@Override
	public String toString() {
		return "ActivityModelBean [id=" + id + ", remarks=" + remarks
				+ ", attachment=" + attachment + ", name=" + name
				+ ", description=" + description + ", tag=" + tag
				+ ", web_url=" + web_url + ", model_pic=" + model_pic
				+ ", getModel_pic()=" + getModel_pic() + ", getId()=" + getId()
				+ ", getRemarks()=" + getRemarks() + ", getAttachment()="
				+ getAttachment() + ", getName()=" + getName()
				+ ", getDescription()=" + getDescription() + ", getTag()="
				+ getTag() + ", getWeb_url()=" + getWeb_url() + ", getClass()="
				+ getClass() + ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getWeb_url() {
		return web_url;
	}

	public void setWeb_url(String web_url) {
		this.web_url = web_url;
	}

}
