package cn.cecook.controller.business.service;

import com.google.gson.Gson;
import com.google.gson.JsonArray;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.service.EvaluationInfo;
import cn.cecook.service.business.service.AutomatedOperationService;
import cn.cecook.service.business.service.EvaluateService;
import cn.cecook.service.business.service.ImedicineService;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.*;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
/**
 * 服务评价
 * @author majie
 *
 */
@Controller("evaluateController")
@RequestMapping("/ser/evaluate")
public class EvaluateController {
	@Resource
	private EvaluateService evaluateService;
	@Resource
	private ImedicineService medicineService;
	@Resource
	private AutomatedOperationService autoService;

	@RequestMapping(value = "/getAll", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String findEvaluate(@RequestBody String param,
			EvaluationInfo evaluationInfo) {
		JsonParser jsonParser = new JsonParser();
		//System.out.println(param);
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		JsonElement jsonElement = jsonObj.get("extra_search");
		JsonObject json = jsonElement.getAsJsonObject();
		JsonElement name = json.get("name");
		JsonElement phone = json.get("phone");
		JsonElement startDate = json.get("startDate");
		JsonElement endDate = json.get("endDate");
		JsonElement serviceFlag = json.get("serviceFlag");
		JsonElement monthFlag = json.get("monthFlag");
		JsonElement sorts =jsonObj.get("order");
		JsonArray asJsonArray=null;
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		Map<String, Object> map = new HashMap<>();
		if (startDate != null) {
			map.put("startDate", startDate.getAsString());
		}
		if (endDate != null) {
			map.put("endDate", endDate.getAsString());
		}
		if (name != null) {
			map.put("name", name.getAsString());
		}
		if (phone != null) {
			map.put("phone", phone.getAsString());
		}
		if (serviceFlag != null) {
			map.put("serviceFlag", serviceFlag.getAsString());
		}
		if (monthFlag != null) {
			map.put("monthFlag", monthFlag.getAsString());
		}
		if(sorts!=null){
			asJsonArray = sorts.getAsJsonArray();
		}
		for (int i = 0; i < asJsonArray.size(); i++) {
			JsonObject sort = asJsonArray.get(i).getAsJsonObject();
			String column = sort.get("column").getAsString();
			if("3".equals(column)){
				map.put("withSort",sort.get("dir").getAsString());
			}
		}	
		map.put("pageStart", startIndex);
		map.put("pageSize", pageSize);
		List<Map<String, Object>> findAll = (List<Map<String, Object>>) evaluateService
				.findAll(map);
		Integer count = (Integer) evaluateService.getCount(map);
		Map<String, Object> resultMap = new HashMap<>();
		resultMap.put("data", findAll);
		resultMap.put("recordsTotal", count);
		resultMap.put("recordsFiltered", count);
		resultMap.put("draw", draw);
		Gson g = new Gson();
		return g.toJson(resultMap);
	}

	@RequestMapping(value = "/addEvaluate", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String addEvaluate(
			@RequestParam(value = "uid", required = false) String uid,
			@RequestParam(value = "access_token", required = false) String access_token,
			@RequestParam(value = "tenant_id", required = false) String tenant_id,
			@RequestParam(value = "order_id", required = false) String order_id,
			@RequestParam(value = "globalEva", required = false) String globalEva,
			@RequestParam(value = "description", required = false) String description,
			@RequestParam(value = "detail", required = false) String detail,
			@RequestParam(value = "tags", required = false) String tags,
			HttpServletRequest request) {
		Map<String, Object> map = new HashMap<>();
		map.put("order_id", order_id);
		map.put("globalEva", globalEva);
		map.put("description", description);
		map.put("detail", detail);
		map.put("tags", tags);
		map.put("uid", uid);
		map.put("access_token", access_token);
		map.put("tenant_id", tenant_id);
		Gson g = new Gson();
		return g.toJson(evaluateService.addEvaluationInfo(map));
	}

	@RequestMapping(value = "/findById", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getMedicineInfo(String id) {
		return medicineService.findById(id).toString();
	}

	@RequestMapping(value = "/findByEvaluateId", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String getEvaluateDetail(String id) {
		// System.out.println("------------>id"+id);
		Gson g = new Gson();
		return g.toJson(evaluateService.findByEvaluationId(id));
	}

	@RequestMapping(value = "/sendEvaSms", method = RequestMethod.POST, produces = "text/plain;charset=UTF-8")
	@ResponseBody
	public String sendEvaSms(
			@RequestParam(value = "access_token", required = false) String access_token,
			@RequestParam(value = "tenant_id", required = false) String tenant_id,
			@RequestParam(value = "cid", required = false) Integer cid) {
		JsonObject jsonObj = new JsonObject();
		//System.out.println("------->cid" + cid);
		//System.out.println("------->tenant_id" + tenant_id);
		Object sendCouponCode = autoService.sendCouponCode(tenant_id, cid,
				"appraise");
		if (sendCouponCode != null) {
			jsonObj.addProperty("msg_code", 1);
		} else {
			jsonObj.addProperty("msg_code", 0);
			jsonObj.addProperty("msg_info", "发送失败！");
		}
		Gson g = new Gson();
		return g.toJson(jsonObj);
	}

	/**
	 * 
	 * Title: ClickUrl Description:点击
	 * 
	 * @param order_id
	 * @param tenant_id
	 * @param rule_id
	 * @param browse_ip
	 * @return
	 */
	@RequestMapping(value = "/click")
	@ResponseBody
	public Object clickUrl(@RequestParam(value = "tenant_id",required = false)String tenant_id,int order_id,
			String browse_ip) {
		return evaluateService
				.clickUrl(order_id, tenant_id, browse_ip);
	}

}
