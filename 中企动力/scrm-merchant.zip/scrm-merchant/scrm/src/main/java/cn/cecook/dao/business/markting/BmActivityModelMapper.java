package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.ActivityModelBean;
import cn.cecook.model.business.markting.BmActivityModel;
import cn.cecook.model.business.markting.BmActivityModelExample;
import cn.cecook.uitls.Pages;

/**
 * 
* @explain 活动模板表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BmActivityModelMapper {
    int countByExample(BmActivityModelExample example);

    int deleteByExample(BmActivityModelExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmActivityModel record);

    int insertSelective(BmActivityModel record);

    List<BmActivityModel> selectByExample(BmActivityModelExample example);

    Map<String,Object> selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmActivityModel record, @Param("example") BmActivityModelExample example);

    int updateByExample(@Param("record") BmActivityModel record, @Param("example") BmActivityModelExample example);

    int updateByPrimaryKeySelective(BmActivityModel record);

    int updateByPrimaryKey(BmActivityModel record);
    
    List<ActivityModelBean> queryBmActivityModelList(Pages<ActivityModelBean> page);
    
    int getCount(Map<String, Object> map);
    
    
}