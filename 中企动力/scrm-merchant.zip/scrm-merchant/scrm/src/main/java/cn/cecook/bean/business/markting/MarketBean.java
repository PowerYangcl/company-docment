package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import java.io.Serializable;

/**
 * 
 * @Title MarketBean.java
 * @Description 智能营销
 * @author wschenyongyin
 * @date 2017年5月31日
 * @version 1.0
 */

@Component
public class MarketBean implements Serializable{

	private Long market_id;
	private Long create_id;
	private String create_time;
	private String activitys;
	private String name;
	private Long model_id;
	private int status;
	private String model_key;
	private String deployment_id;
	private String definition_id;
	private Object activityData;
	private Long start_activity_id;
	private Integer home_show_flag;

	public Integer getHome_show_flag() {
		return home_show_flag;
	}

	public void setHome_show_flag(Integer home_show_flag) {
		this.home_show_flag = home_show_flag;
	}

	public Long getStart_activity_id() {
		return start_activity_id;
	}

	public void setStart_activity_id(Long start_activity_id) {
		this.start_activity_id = start_activity_id;
	}

	public Object getActivityData() {
		return activityData;
	}

	public void setActivityData(Object activityData) {
		this.activityData = activityData;
	}

	public Long getMarket_id() {
		return market_id;
	}

	public void setMarket_id(Long market_id) {
		this.market_id = market_id;
	}

	public Long getCreate_id() {
		return create_id;
	}

	public void setCreate_id(Long create_id) {
		this.create_id = create_id;
	}

	public String getCreate_time() {
		return create_time;
	}

	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}

	public String getActivitys() {
		return activitys;
	}

	public void setActivitys(String activitys) {
		this.activitys = activitys;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public Long getModel_id() {
		return model_id;
	}

	public void setModel_id(Long model_id) {
		this.model_id = model_id;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public String getModel_key() {
		return model_key;
	}

	public void setModel_key(String model_key) {
		this.model_key = model_key;
	}

	public String getDeployment_id() {
		return deployment_id;
	}

	public void setDeployment_id(String deployment_id) {
		this.deployment_id = deployment_id;
	}

	public String getDefinition_id() {
		return definition_id;
	}

	public void setDefinition_id(String definition_id) {
		this.definition_id = definition_id;
	}

	@Override
	public String toString() {
		return "MarketBean [market_id=" + market_id + ", create_id="
				+ create_id + ", create_time=" + create_time + ", activitys="
				+ activitys + ", name=" + name + ", model_id=" + model_id
				+ ", status=" + status + ", model_key=" + model_key
				+ ", deployment_id=" + deployment_id + ", definition_id="
				+ definition_id + "]";
	}

	
	
	
}
