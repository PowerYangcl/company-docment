package cn.cecook.dao.business.automation;

import java.util.List;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.automation.AutomationTemplate;

/**
 * 自动化模板
 * @author majie
 *
 * 2018年1月22日-下午7:16:43
 */
public interface AutomationTemplateMapper {
	/**
	 * 添加自动化模板
	 * @param automationTemplate
	 * majie
	 */
	public Integer addAutomationTemplate(AutomationTemplate automationTemplate);
	/**
	 * 查询模板id
	 * @param id
	 * @return
	 * majie
	 */
	public AutomationTemplate selectById(Integer id);
	/**
	 * 修改模板信息
	 * @param automationTemplate
	 * @return
	 * majie
	 */
	public Integer updateAutomationTemplate(AutomationTemplate automationTemplate);
	/**
	 * 查询所有模板信息
	 * @return
	 * majie
	 */
	public List<AutomationTemplate> findAll();
	/**
	 * 判断是否可以启动
	 * @param automationTemplate
	 * @return
	 * majie
	 */
	public Integer isRunAutomation(AutomationTemplate automationTemplate);
	/**
	 * 查询所有公共模板
	 * @return
	 * majie
	 */
	public List<AutomationTemplate> findAllByPublic();
	/*
	 * 校验模板名称
	 */
	public Integer checkAutomationTemplateByName(String name);
}
