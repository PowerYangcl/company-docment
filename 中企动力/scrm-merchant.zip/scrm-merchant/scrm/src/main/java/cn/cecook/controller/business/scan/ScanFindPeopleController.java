package cn.cecook.controller.business.scan;

import com.google.gson.Gson;
import com.google.gson.JsonParser;

import cn.cecook.dao.business.scan.ScanRuleMapper;
import cn.cecook.model.business.scan.ScanRule;
import cn.cecook.service.business.scan.ScanChatService;
import cn.cecook.service.business.scan.ScanFindPeopleService;
import cn.cecook.service.business.scan.ScanRuleService;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

@Controller
@RequestMapping("/scan/findPeople")
public class ScanFindPeopleController {
	@Autowired
	private ScanRuleService ruleService;
	@Autowired
	private ScanFindPeopleService findPeopleService;
	@Autowired
	private ScanRuleMapper ruleMapper;
	@Autowired
	private ScanChatService chatService;
	
	@RequestMapping(value="/saveRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String saveDialog(ScanRule rule) {
		rule.setType(1);
		return ruleService.saveRule(rule);
	}
	
	@RequestMapping(value="/getAddress",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getAddress(String parent_code) {
		Gson gson = new Gson();
		List<Map<String, Object>> address = ruleMapper.getAddress(parent_code);
		String json = gson.toJson(address);
		return json;
	}
	
	@RequestMapping(value="/getRuleList",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getRuleList() {
		return ruleService.getRuleList(1);
	}
	
	@RequestMapping(value="/getSex",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getSex(int ruleId) {
		return findPeopleService.getSex(ruleId);
	}
	
	@RequestMapping(value="/getIsV",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getIsV(int ruleId) {
		return findPeopleService.getIsV(ruleId);
	}
	
	@RequestMapping(value="/getIsFollowMe",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getIsFollowMe(int ruleId) {
		return findPeopleService.getIsFollowMe(ruleId);
	}
	
	@RequestMapping(value="/getPage",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getPage(@RequestBody String param) {
		JsonParser jsonParser = new JsonParser();
		String page = findPeopleService.getPage(jsonParser.parse(param).getAsJsonObject());
		return jsonParser.parse(page).getAsJsonObject().get("data").toString();
	}
	
	@RequestMapping(value="/updateType",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String updateType(int customerId,int type) {
		Map<String, Object> map = new HashMap<>();
		map.put("id", customerId);
		map.put("type", type);
		return findPeopleService.updateType(map);
	}
	
	@RequestMapping(value="/delRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String delRule(int ruleId) {
		return ruleService.deleteRule(ruleId);
	}
	
	@RequestMapping(value="/getRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getRule(int ruleId) {
		return ruleService.getRule(ruleId);
	}
	
	@RequestMapping(value="/copyRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String copyRule(int ruleId,String name) {
		return ruleService.copyRule(ruleId,name);
	}
	
	@RequestMapping(value="/openOrCloseRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String openOrCloseRule(int ruleId) {
		return ruleService.openOrCloseRule(ruleId);
	}
	
	@RequestMapping(value="/countByName",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String countByName(String name, int type,Integer ruleId) {
		return ruleService.countByName(name, type, ruleId);
	}
	
	
	/********************************************** 聊天 ******************************************************************/
	@RequestMapping(value="/getChat",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String getChat(String wbUserId,String statusId){
        return chatService.getChat(wbUserId, statusId);
    }
	
	@RequestMapping(value="/saveChat",produces="text/html;charset=UTF-8")
    @ResponseBody
	public String saveChat(String sendUserName,String wbUserId,String statusId,String type,String content) {
		Map<String, Object> param = new HashMap<>();
		param.put("sendUserName", sendUserName);
		param.put("wbUserId", wbUserId);
		param.put("statusId", statusId);
		param.put("type", type);
		param.put("content", content);
		return chatService.saveChat(param);
	}
	
	@RequestMapping(value="/bExpired",produces="text/html;charset=UTF-8")
	@ResponseBody
	public String bExpired() {
		return chatService.bExpired();
	}
	
	/**
	 * 根据开始时间、结束时间获取每日微博找人线索数量
	 */
	@RequestMapping(value="/getDayPeoChartList",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getDayPeoChartList(String startTime,String endTime,String ids) {
		return ruleService.getDayPeoChartList(startTime,endTime,ids);
	}
	
	/**
	 * 获取微博找人线索来源占比
	 */
	@RequestMapping(value="/getClueChart",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getClueChart() {
		return ruleService.getClueChart();
	}
	 
	/**
	 * 根据开始时间、结束时间、状态、规则Id、获取微博找人回复线索数量
	 */
	@RequestMapping(value="/getFindPeoChartList",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getFindPeoChartList(String startTime,String endTime,String type,String ruleId) {
		return ruleService.getFindPeoChartList(startTime,endTime,type,ruleId);
	}
	
	/**
	 * 根据日期获取全部线索及其对应的挖掘用户
	 * @return
	 */
	@RequestMapping(value = "/getExcavateUserNum")
	@ResponseBody
	public Object getExcavateUserNum(String startTime) {

		return (findPeopleService
				.getExcavateUserNum(startTime));
	}

}