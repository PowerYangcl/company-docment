package cn.cecook.model.business.automation;
/**
 * 任务执行状态
 * @author majie
 *
 * 2018年1月22日-下午4:49:39
 */
public enum TaskStatus {
	//任务状态 未开始、开始、结束
	NOSTART,START,END
}
