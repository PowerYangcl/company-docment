package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.system.PageBean;
import cn.cecook.model.system.SysRole;
import cn.cecook.model.system.SysRoleExample;

/**
 * 
* @explain 角色表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysRoleMapper {
    int countByExample(SysRoleExample example);

    int deleteByExample(SysRoleExample example);

    int deleteByPrimaryKey(Long id);

    int insert(SysRole record);

    int insertSelective(SysRole record);

    List<SysRole> selectByExample(SysRoleExample example);

    SysRole selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") SysRole record, @Param("example") SysRoleExample example);

    int updateByExample(@Param("record") SysRole record, @Param("example") SysRoleExample example);

    int updateByPrimaryKeySelective(SysRole record);

    int updateByPrimaryKey(SysRole record);
    //根据名称查询角色
	SysRole selectRoleByName(Map<String, Object> map);
	//根据条件查询角色
	List<SysRole> selectRolesForPage(PageBean pageBean);
	//根据roleid查询role
	SysRole selectRoleByRoleId(Map<String, Object> map);
	//分页查询的总条数
	int selectPageCount(PageBean pageBean);
	//根据roleid 更新删除状态
	int updateDelByRoleId(Map<String, Object> map);
	//根据role更新role
	int updateRoleNameByRIdTId(Map<String, Object> map);
	//创建用户
	int insertRole(SysRole sysNewRole);
	//查角色编号
	List<String> selectAllRoleCodeByTid(String tenantId);
	//所有没有被删除的角色
	List<SysRole> selectAllUsedRole();
	//一个角色的所有权限的id
	List<Long> selectOneRoleAuths(Map<String, Object> map);

	List<Map<String,Object>> RoleList(Map<String, Object> map);


	int CountRoleList(String tenant_id);

	SysRole selectByProductRoleId(@Param("crmRole") String crmRole, @Param("productId") String productId, @Param("tenant_id") String tenant_id);
	//获取全部的url，用于判断是否是最后一页
	List<Map<String, Object>> getAllUrl();
}