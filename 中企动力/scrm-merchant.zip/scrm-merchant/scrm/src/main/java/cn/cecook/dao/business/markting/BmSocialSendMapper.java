package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmSocialSend;


public interface BmSocialSendMapper {

    int deleteByPrimaryKey(Long id);

    int insert(BmSocialSend record);

    int insertSelective(BmSocialSend record);


    BmSocialSend selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BmSocialSend record);

    
    List<BmSocialSend> getSocialRecordList(Map<String, Object> map);

    BmSocialSend getSocialRecordDetail(long id);
}