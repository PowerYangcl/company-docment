package cn.cecook.controller.business.customer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.customer.BcCustomer;
import cn.cecook.model.business.customer.BcCustomerAction;
import cn.cecook.service.business.customer.IClueActivityService;
import cn.cecook.service.business.customer.IClueWeiboService;
import cn.cecook.service.business.customer.ICustomerActionService;
import cn.cecook.service.business.customer.ICustomerService;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Pages;
import cn.cecook.uitls.StringUtils;

/**
 *  客户行为
 * @author zhaoxin
 *
 */
@Controller
@RequestMapping("/api/customer_action")
public class ActionController {
    
    @Autowired
    private ICustomerActionService customerActionService;
    
    @Autowired
    private ICustomerService customerService;
    
    @Autowired
    private IClueWeiboService clueWeiboService;
    
    @Autowired
    private IClueActivityService clueActivityService;
    
    @RequiresPermissions("login")
    @RequestMapping("/actionCustomerView")
    public String actionCustomer(){
        return "bc/actionCustomer";
    }
    
    @RequiresPermissions("login")
    @RequestMapping("/customerChatView")
    public String customerChatView(){
        return "bc/customerChat";
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/customerChat",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String customerChat(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        
        int customerId = 0;
        int actionId = 0;
        int clueWeiboId = 0;
        int writeOffId = 0;
        String customerIdStr = request.getParameter("customerId");
        String actionIdStr = request.getParameter("actionId");
        String clueWeiboIdStr = request.getParameter("clueWeiboId");
        String writeOffIdStr = request.getParameter("writeOffId");
        if(customerIdStr != null){
            customerId = Integer.valueOf(customerIdStr);
        }
        if(actionIdStr != null){
            actionId = Integer.valueOf(actionIdStr);
        }
        if(clueWeiboIdStr != null){
            clueWeiboId = Integer.valueOf(clueWeiboIdStr);
        }
        if(writeOffIdStr != null){
            writeOffId = Integer.valueOf(writeOffIdStr);
        }
        
        //客户信息
        BcCustomer customerInfo = customerService.customerDetail(customerId);
        
        Map<String, Object> weiDu = customerService.getCustomerInfo(customerId+"");
        
        //消费信息
        Map<String, Object> map = new HashMap<>();
        map.put("customerId", customerId);
        map.put("actionId", actionId);
        map.put("clueWeiboId", clueWeiboId);
        map.put("writeOffId", writeOffId);
        Map<String, Object> customerCost = customerActionService.customerCost(map);
        
        //客户行为，聊天信息和备注信息
        List<Map<String, Object>> customerAction = null;
        
        if(actionId != 0){
            customerAction = customerActionService.getCustomerActionById(map);
        }else if(clueWeiboId != 0){
            List<Map<String, Object>> list = new ArrayList<>();
            list.add(clueWeiboService.getClueWeiboById(clueWeiboId));
            customerAction = list;
        }else if(writeOffId != 0){
            List<Map<String, Object>> list = new ArrayList<>();
            list.add(customerActionService.getWriteOffById(writeOffId));
            customerAction = list;
        }else{
            customerAction = customerActionService.getCustomerActionById(map);
        }
        
        List<Map<String, Object>> customerChat = customerActionService.customerChat(map);
        List<Map<String, Object>> chatRemark = customerActionService.chatRemark(map);
        
        
        //活动信息
        map.clear();
        map.put("count", 6);
        List<Map<String, Object>> activity = customerActionService.getActivity(map);
        
        
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        jsonObject.add("customerInfo", jsonParser.parse(gson.toJson(customerInfo)));
        jsonObject.add("weiDu", jsonParser.parse(gson.toJson(weiDu)));
        jsonObject.add("customerCost", jsonParser.parse(gson.toJson(customerCost)));
        jsonObject.add("customerAction", jsonParser.parse(gson.toJson(customerAction)));
        jsonObject.add("customerChat", jsonParser.parse(gson.toJson(customerChat)));
        jsonObject.add("chatRemark", jsonParser.parse(gson.toJson(chatRemark)));
        jsonObject.add("activity", jsonParser.parse(gson.toJson(activity)));
        
        return jsonObject.toString();
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/addChatRemark",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String addChatRemark(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        try{
            int customerId = 0;
            int actionId = 0;
            int clueWeiboId = 0;
            int writeOffId = 0;
            String content = request.getParameter("content");
            String customerIdStr = request.getParameter("customerId");
            String actionIdStr = request.getParameter("actionId");
            String clueWeiboIdStr = request.getParameter("clueWeiboId");
            String writeOffIdStr = request.getParameter("writeOffId");
            if(customerIdStr != null){
                customerId = Integer.valueOf(customerIdStr);
            }
            if(actionIdStr != null){
                actionId = Integer.valueOf(actionIdStr);
            }
            if(clueWeiboIdStr != null){
                clueWeiboId = Integer.valueOf(clueWeiboIdStr);
            }
            if(writeOffIdStr != null){
                writeOffId = Integer.valueOf(writeOffIdStr);
            }
            
            Map<String, Object> map = new HashMap<>();
            map.put("customerId", customerId);
            map.put("actionId", actionId);
            map.put("clueWeiboId", clueWeiboId);
            map.put("writeOffId", writeOffId);
            map.put("content", content);
            customerActionService.addChatRemark(map);
            jsonObject.addProperty("msg", "success");
        }catch (Exception e) {
            jsonObject.addProperty("msg", "failure");
            e.printStackTrace();
        }
        
        return jsonObject.toString();
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/delChatRemark",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String delChatRemark(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        try{
            int id = 0;
            String idStr = request.getParameter("id");
            if(idStr != null){
                id = Integer.valueOf(idStr);
            }
            
            Map<String, Object> map = new HashMap<>();
            map.put("id", id);
            map.put("isDelete", 1);
            customerActionService.updateChatRemark(map);
            jsonObject.addProperty("msg", "success");
        }catch (Exception e) {
            jsonObject.addProperty("msg", "failure");
            e.printStackTrace();
        }
        
        return jsonObject.toString();
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/addCustomerChat",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String addCustomerChat(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();

        try{
            int customerId = 0;
            int actionId = 0;
            int clueWeiboId = 0;
            int writeOffId = 0;
            String tenantId = request.getParameter("tenantid");
            String uid = request.getParameter("uid");
            String content = request.getParameter("content");
            String sendAccount = request.getParameter("sendAccount");
            String customerIdStr = request.getParameter("customerId");
            String actionIdStr = request.getParameter("actionId");
            String socialType = request.getParameter("socialType");
            String isWeibo = request.getParameter("isWeibo");
            String isDuanXin = request.getParameter("isDuanXin");
            String isEmail = request.getParameter("isEmail");
            String clueWeiboIdStr = request.getParameter("clueWeiboId");
            String writeOffIdStr = request.getParameter("writeOffId");
            if(tenantId == null){
                Cookie[] cookies = request.getCookies();
                Map cookie = CookieUtil.getCookieSet(cookies);
                tenantId = (String)cookie.get("tenantid");
                uid = (String)cookie.get("uid");
            }
            if(customerIdStr != null){
                customerId = Integer.valueOf(customerIdStr);
            }
            if(actionIdStr != null){
                actionId = Integer.valueOf(actionIdStr);
            }
            if(clueWeiboIdStr != null){
                clueWeiboId = Integer.valueOf(clueWeiboIdStr);
            }
            if(writeOffIdStr != null){
                writeOffId = Integer.valueOf(writeOffIdStr);
            }
            
            Map<String, Object> map = new HashMap<>();
            map.put("tenantId", tenantId);
            map.put("uid", uid);
            map.put("customerId", customerId);
            map.put("actionId", actionId);
            map.put("content", content);
            map.put("sendAccount", sendAccount);
            map.put("socialType", socialType);
            map.put("isWeibo", isWeibo);
            map.put("isDuanXin", isDuanXin);
            map.put("isEmail", isEmail);
            map.put("clueWeiboId", clueWeiboId);
            map.put("writeOffId", writeOffId);
            customerActionService.addCustomerChat(map);
            jsonObject.addProperty("msg", "success");
        }catch (Exception e) {
            jsonObject.addProperty("msg", "failure");
            e.printStackTrace();
        }
        
        return jsonObject.toString();
    }
    
    /**
     *  客户行为列表接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping(value="/actionList",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String actionList(HttpServletRequest request){
        JsonObject jsonObject = new JsonObject();
        
        int startIndex = 0;
        if(request.getParameter("startIndex") != null)
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        int pageSize = 10;
        if(request.getParameter("pageSize") != null)
            pageSize = Integer.valueOf(request.getParameter("pageSize"));
        String keyWord = request.getParameter("keyWord");
        String handleStatus = request.getParameter("handleStatus");
        String source = request.getParameter("source");
        String orderby = null;
        Map<String, Object> where = new HashMap<String, Object>();
        where.put("keyWord", keyWord);
        where.put("handleStatus", handleStatus);
        where.put("source", source);
        orderby = "id desc";
        
        Pages<BcCustomerAction> page = customerActionService.getPage(new Pages<BcCustomerAction>(startIndex, pageSize, where, orderby));
        
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        jsonObject.add("actionList", jsonParser.parse(gson.toJson(page.getItems())));
        jsonObject.addProperty("noHandleCount", customerActionService.getNoHandleCount());
        jsonObject.addProperty("totalCount", page.getTotalCount());
        
        return jsonObject.toString();
    }
    
    /**
     *  客户行为查询接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/findCustomerActionList")
    public String findCustomerActionList(){
        return "bc/";
    }
    /**
     *  客户行为添加接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/addAction")
    public String addAction(){
        return "bc/";
    }
    /**
     *  历史活动记录接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/activityList")
    public String activityList(){
        return "bc/";
    }
    /**
     *  微博评论接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/weiboComment")
    public String weiboComment(){
        return "bc/";
    }
    /**
     *  邮箱发送接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/mailSend")
    public String mailSend(){
        return "bc/";
    }
    /**
     *  活动备注接口
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping("/remarks")
    public String remarks(){
        return "bc/";
    }
    
    @RequiresPermissions("login")
    @RequestMapping(value="/getCustomerAction",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String getCustomerAction(HttpServletRequest request){
        JsonObject j = new JsonObject();
        String id = request.getParameter("id");
        int startIndex = 0;
        if(request.getParameter("startIndex") != null)
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        int pageSize = 10;
        if(request.getParameter("pageSize") != null)
            pageSize = Integer.valueOf(request.getParameter("pageSize"));
        String orderby = null;
        int customerId;
        if(StringUtils.isNotEmpty(id)){
            customerId= Integer.valueOf(id);
            Map<String, Object> where = new HashMap<String, Object>();
            where.put("id", customerId);
            Pages<BcCustomerAction> page = customerActionService.getCustomerActionPage(new Pages<BcCustomerAction>(startIndex * pageSize,(startIndex + 1)* pageSize, where, orderby));
            Gson gson = new Gson();
            JsonParser jsonParser = new JsonParser();
            j.add("actionList", jsonParser.parse(gson.toJson(page.getItems())));
            j.addProperty("totalCount", page.getTotalCount());
            System.out.println("客户行为---------->"+FastJsonUtil.createJsonString(j));
        }
        return j.toString();
    }
    
    /**
     * 	联想搜索名字
     * @param name
     * @return
     */
    @RequiresPermissions("login")
    @RequestMapping(value="/searchName",produces="text/html;charset=UTF-8")
    @ResponseBody
    public String searchName(String name) {
    	JsonObject jsonObject = new JsonObject();
        Gson gson = new Gson();
        JsonParser jsonParser = new JsonParser();
        try {
        	Map<String, Object> where = new HashMap<String, Object>();
        	where.put("name", name);
        	Pages<Map<String, Object>> page = clueActivityService.getPage2(new Pages<Map<String, Object>>(1, 10, where, null));
        	
        	jsonObject.add("name", jsonParser.parse(gson.toJson(page.getItems())));
        	jsonObject.addProperty("msgCode", "1");
        }catch (Exception e) {
        	jsonObject.addProperty("msgCode", "0");
		}
        return jsonObject.toString();
    }
}