package cn.cecook.controller.business.scan;

import java.util.HashMap;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.dao.business.scan.ScanRuleMapper;
import cn.cecook.model.business.scan.ScanRule;
import cn.cecook.service.business.scan.ScanFindThingService;
import cn.cecook.service.business.scan.ScanRuleService;

@Controller
@RequestMapping("/scan/findThing")
public class ScanFindThingController {
	@Autowired
	private ScanRuleService ruleService;
//	@Autowired
//	private ScanFindPeopleService findPeopleService;
	@Autowired
	private ScanFindThingService findThingService;
	@Autowired
	private ScanRuleMapper ruleMapper;
	
	@RequestMapping(value="/saveRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String saveDialog(ScanRule rule,String keyword) {
		rule.setType(2);
		return ruleService.saveRule(rule);
	}
	
	@RequestMapping(value="/getAddress",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getAddress(String parent_code) {
		Gson gson = new Gson();
		List<Map<String, Object>> address = ruleMapper.getAddress(parent_code);
		String json = gson.toJson(address);
		System.out.println(json);
		return json;
	}
	
	@RequestMapping(value="/getRuleList",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getRuleList() {
		return ruleService.getRuleList(2);
	}
	
	@RequestMapping(value="/getSex",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getSex(int ruleId) {
//		return findPeopleService.getSex(ruleId);
		return null;
	}
	
	@RequestMapping(value="/getIsV",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getIsV(int ruleId) {
//		return findPeopleService.getIsV(ruleId);
		return null;
	}
	
	@RequestMapping(value="/getIsFollowMe",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getIsFollowMe(int ruleId) {
//		return findPeopleService.getIsFollowMe(ruleId);
		return null;
	}
	
	@RequestMapping(value="/getPage",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getPage(@RequestBody String param) {
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObject = jsonParser.parse(param).getAsJsonObject();
		String order = jsonObject.get("order").getAsString();
		if(order.equals("a")) {
			order = "(status_reposts_count+status_comments_count+status_attitudes_count) desc";
		}else {
			order = "status_created_at desc";
		}
		jsonObject.addProperty("order", order);
		System.out.println(jsonObject);
		String page = findThingService.getPage(jsonObject);
		return jsonParser.parse(page).getAsJsonObject().get("data").toString();
	}
	
	@RequestMapping(value="/updateType",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String updateType(int customerId,int type) {
		Map<String, Object> map = new HashMap<>();
		map.put("id", customerId);
		map.put("type", type);
//		return findPeopleService.updateType(map);
		return null;
	}
	
	@RequestMapping(value="/delRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String delRule(int ruleId) {
		return ruleService.deleteRule(ruleId);
	}
	
	@RequestMapping(value="/getRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getRule(int ruleId) {
		return ruleService.getRule(ruleId);
	}
	
	@RequestMapping(value="/copyRule",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String copyRule(int ruleId,String name) {
		return ruleService.copyRule(ruleId,name);
	}
	
	@RequestMapping(value="/delWeibo",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String delWeibo(int id) {
		return findThingService.delWeibo(id);
	}
	
	/**
	 * 根据日期获取全部线索及其对应的挖掘用户
	 * @return
	 */
	@RequestMapping(value = "/getExcavateThingNum")
	@ResponseBody
	public Object getExcavateThingNum(String startTime) {

		return (findThingService
				.getExcavateThingNum(startTime));
	}
	
	
}