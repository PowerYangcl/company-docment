package cn.cecook.model.business.automation;

import java.util.Date;

/**
 * 自动化页面节点信息
 * @author majie
 *
 * 2018年1月22日-下午2:37:47
 */
public class AutomationPointInfo {
	//自增id
    private Integer id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Integer createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;
    //任务id
    private Integer taskId;
    //父任务id 没有为0
    private Integer parentTaskId;
    //当前节点位置
    private Integer pointId;
    //父节点位置
    private Integer parentPointId;
    //节点信息 json串
    private String pointInfo;
    //节点类型  枚举
    private String pointType;
    //模板id
    private Integer templateId;
	public Integer getId() {
		return id;
	}
	public void setId(Integer id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public Integer getIsDeleted() {
		return isDeleted;
	}
	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}
	public Integer getCreateId() {
		return createId;
	}
	public void setCreateId(Integer createId) {
		this.createId = createId;
	}
	public Date getCreateTime() {
		return createTime;
	}
	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}
	public String getOrderCode() {
		return orderCode;
	}
	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}
	public Date getDeleteTime() {
		return deleteTime;
	}
	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getBak1() {
		return bak1;
	}
	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}
	public String getBak2() {
		return bak2;
	}
	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}
	public String getBak3() {
		return bak3;
	}
	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}
	public String getBak4() {
		return bak4;
	}
	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}
	public String getBak5() {
		return bak5;
	}
	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public Integer getParentTaskId() {
		return parentTaskId;
	}
	public void setParentTaskId(Integer parentTaskId) {
		this.parentTaskId = parentTaskId;
	}
	public Integer getPointId() {
		return pointId;
	}
	public void setPointId(Integer pointId) {
		this.pointId = pointId;
	}
	public Integer getParentPointId() {
		return parentPointId;
	}
	public void setParentPointId(Integer parentPointId) {
		this.parentPointId = parentPointId;
	}
	public String getPointInfo() {
		return pointInfo;
	}
	public void setPointInfo(String pointInfo) {
		this.pointInfo = pointInfo;
	}
	public String getPointType() {
		return pointType;
	}
	public void setPointType(String pointType) {
		this.pointType = pointType;
	}
	public Integer getTemplateId() {
		return templateId;
	}
	public void setTemplateId(Integer templateId) {
		this.templateId = templateId;
	}
	@Override
	public String toString() {
		return "AutomationPointInfo [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted="
				+ isDeleted + ", createId=" + createId + ", createTime=" + createTime + ", orderCode=" + orderCode
				+ ", deleteTime=" + deleteTime + ", remarks=" + remarks + ", attachment=" + attachment + ", bak1="
				+ bak1 + ", bak2=" + bak2 + ", bak3=" + bak3 + ", bak4=" + bak4 + ", bak5=" + bak5 + ", taskId="
				+ taskId + ", parentTaskId=" + parentTaskId + ", pointId=" + pointId + ", parentPointId="
				+ parentPointId + ", pointInfo=" + pointInfo + ", pointType=" + pointType + ", templateId=" + templateId
				+ "]";
	}
	
}
