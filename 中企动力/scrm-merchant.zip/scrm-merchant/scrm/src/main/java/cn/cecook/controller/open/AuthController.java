package cn.cecook.controller.open;

import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.apache.log4j.Logger;
import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.subject.Subject;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.cecook.dao.business.scan.ScanMemberMapper;
import cn.cecook.dao.open.mp.MpRelateMapper;
import cn.cecook.dao.open.mp.MpUserMapper;
import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpRelate;
import cn.cecook.model.open.mp.MpTicket;
import cn.cecook.model.open.mp.MpUser;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpTicketService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.thirdparty.open.ConfigUtil;
import cn.cecook.thirdparty.open.MenuUtil;
import cn.cecook.thirdparty.open.UserUtil;
import cn.cecook.thirdparty.weibo.util.LongUrl2ShortUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.HttpRequestUtils;

import com.google.gson.Gson;
import com.google.gson.JsonElement;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Controller
@RequestMapping("/open")
public class AuthController {
	private Gson gson = new Gson();
	private JsonParser parser = new JsonParser();
	private Logger logger = Logger.getLogger(AuthController.class);
	
	@Resource
	private ScanMemberMapper memberMapper;
	
	@Autowired
	@Resource
	private MpRelateMapper mpRelateMapper;

	@Resource
	private IMpUserService iMpUserService;

	@Resource
	private MpUserMapper mpUserMapper;

	@Autowired
	private IMpAccountService iMpAccountService;

	@Autowired
	private IMpTicketService iMpTicketService;
	
	/**
	 * 删除授权信息
	 */
	@RequestMapping(value = "/delAuth", method = RequestMethod.GET)
	@ResponseBody
	public String delAuth(HttpServletRequest request, HttpServletResponse response) {
		JsonObject jsonObject = new JsonObject();
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		iMpAccountService.del(tenant_id);
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		jsonObject.addProperty("deleted", true);
		if (mpAccount != null) {//删除失败
			jsonObject.addProperty("deleted", false);
		}
		System.out.println("fun delAuth : " + jsonObject.toString());
		return jsonObject.toString();
	}
	
	/**
	 * 获取授权昵称
	 */
	@RequestMapping(value = "/getwxUsername", method = RequestMethod.GET)
	@ResponseBody
	public String getwxUsername(HttpServletRequest request, HttpServletResponse response) {
		JsonObject jsonObject = new JsonObject();
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		if (mpAccount != null) {
			jsonObject.addProperty("wx_nick", mpAccount.getNickName());
		}
		return jsonObject.toString();
	}

	/**
	 * 租户授权
	 */
	@RequestMapping(value = "/authmp", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView authmp(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		String tenant_id = request.getParameter("tenant_id");
		String auth_code = request.getParameter("auth_code");
		Subject subject = SecurityUtils.getSubject();
		Session session = subject.getSession();
		String uid = String.valueOf(session.getAttribute("userId"));

		System.out.println("uid:" + uid);
		System.out.println("auth_code:" + auth_code);
		model.put("info", "授权完成啦!");

		try {
			MpTicket mpTicket = iMpTicketService.selectOne();
			if(mpTicket == null) {
				//TODO error
			}else {
				Map<String, Object> params = new HashMap<String, Object>();
				Properties P = ConfigUtil.getInstance().getProperties();
				String appid = P.getProperty("APPID");
				params.put("component_appid", appid);
				params.put("authorization_code", auth_code);
				String url = P.getProperty("OPEN_API_QUERY_AUTH") + "?component_access_token=" + mpTicket.getComponentAccessToken();
				String result = HttpRequestUtils.jsonPost(url, params);
				JsonObject jsonObject = parser.parse(result).getAsJsonObject();
				String authorizer_appid = jsonObject.get("authorization_info").getAsJsonObject().get("authorizer_appid").getAsString();
				String authorizer_access_token = jsonObject.get("authorization_info").getAsJsonObject().get("authorizer_access_token").getAsString();
				String authorizer_refresh_token = jsonObject.get("authorization_info").getAsJsonObject().get("authorizer_refresh_token").getAsString();
				if (StringUtils.isNotEmpty(uid) && StringUtils.isNotEmpty(authorizer_access_token)) {
					boolean exist = true;
					MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
					if (mpAccount == null) {
						exist = false;
						mpAccount = new MpAccount();
						mpAccount.setUid(uid);
					}
					mpAccount.setTokenStatus(1);
					mpAccount.setTenantId(tenant_id);
					mpAccount.setAuthorizerAppid(authorizer_appid);
					mpAccount.setAuthorizerAccessToken(authorizer_access_token);
					mpAccount.setAuthorizerRefreshToken(authorizer_refresh_token);
					mpAccount.setTokenTime(new Date());
					// db base info
					try {
						String OPEN_AUTHORIZER_INFO = P.getProperty("OPEN_AUTHORIZER_INFO") + "?component_access_token=" + mpTicket.getComponentAccessToken();
						Map<String, Object> params2 = new HashMap<String, Object>();
						params2.put("component_appid", appid);
						params2.put("authorizer_appid", authorizer_appid);
						String result2 = HttpRequestUtils.jsonPost(OPEN_AUTHORIZER_INFO, params2);
						JsonObject jsonObject2 = parser.parse(result2).getAsJsonObject();
						logger.debug("OPEN_AUTHORIZER_INFO:::" + jsonObject2.toString());
						JsonObject infoObject = jsonObject2.get("authorizer_info").getAsJsonObject();
						String nick_name_ = infoObject.has("nick_name") ? infoObject.get("nick_name").getAsString() : "";
						mpAccount.setNickName(nick_name_);
						String head_img_ = infoObject.has("head_img") ? infoObject.get("head_img").getAsString() : "";
						mpAccount.setHeadImg(head_img_);
						String principal_name_ = infoObject.has("principal_name") ? infoObject.get("principal_name").getAsString() : "";
						mpAccount.setPrincipalName(principal_name_);
						String appid_ = infoObject.has("appid") ? infoObject.get("appid").getAsString() : "";
						mpAccount.setAppid(appid_);
						String user_name_ = infoObject.has("user_name") ? infoObject.get("user_name").getAsString() : "";
						mpAccount.setUserName(user_name_);
					} catch (Exception e) {
						e.printStackTrace();
					}
					MpAccount mpAccountdb = iMpAccountService.selectMpAccountByUserName(mpAccount.getUserName());
					if(mpAccountdb != null && StringUtils.isNotEmpty(mpAccountdb.getTenantId()) && !mpAccountdb.getTenantId().equals(tenant_id)) {
						model.put("info", "该公众号已被授权绑定!");
						modelAndView.setViewName("open/authFinish");
						return modelAndView;
					}else {
						if (exist) {
							iMpAccountService.updateMpAccountByUid(uid, mpAccount);
						} else {
							iMpAccountService.insertSelective(mpAccount);
						}
						//初始化菜单
						String menuUrl = ConfigUtil.getInstance().domain+"/open/me?tenant_id="+tenant_id;
						url = LongUrl2ShortUtil.toShortUrl(menuUrl);
						MenuUtil.initMemberMenu(authorizer_access_token, menuUrl);
					}
					// 授权后触发获取用户
					List<MpUser> reloadUsers = UserUtil.reloadUsers(mpAccount.getAuthorizerAccessToken());
					if(reloadUsers!= null && reloadUsers.size() > 0){
						//清空数据库
						try {
							if(StringUtils.isNotEmpty(tenant_id)){
								mpUserMapper.delByTenantId(tenant_id);							
							}
						} catch (Exception e) {
							e.printStackTrace();
						}
					}
					for (int j = 0; j < reloadUsers.size(); j++) {
						MpUser mpUser = reloadUsers.get(j);
						mpUser.setTenantId(tenant_id);
						MpRelate mpRelate = mpRelateMapper.selectMpRelateByOpenid(tenant_id, mpUser.getOpenid());
						if(mpRelate != null && StringUtils.isNotEmpty(mpRelate.getPhone())) {			
							Map<String, Object> memberByPhone = memberMapper.getMemberByPhone(mpRelate.getPhone());
							JsonElement jsonElement = parser.parse(gson.toJson(memberByPhone));
							if(jsonElement != null) {
								mpUser.setMembered(1);
								mpUser.setPhone(mpRelate.getPhone());
								mpUser.setMemberId(jsonElement.getAsJsonObject().get("id").getAsInt());
							}
						}
						mpUserMapper.insert(mpUser);
					}
				}
			}
		} catch (Exception e) {
			e.printStackTrace();
		}
		modelAndView.setViewName("open/authFinish");
		return modelAndView;
	}

}
