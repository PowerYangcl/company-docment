package cn.cecook.controller.open;

import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.uitls.redis.RedisStringUtil;

@Controller
@RequestMapping("/open/menu")
public class MenuController {

	@RequestMapping(value = "/saveKey", method = RequestMethod.POST)
    @ResponseBody
    public String recvinfo(HttpServletRequest request, HttpServletResponse response) {
		String eventType = request.getParameter("eventType");
		String eventKey = request.getParameter("eventKey");
		String eventContent = request.getParameter("eventContent");
		RedisStringUtil.setData(eventKey+"_type", eventType);
		RedisStringUtil.setData(eventKey+"_content", eventContent);
		return "ok";
	}
	
	@RequestMapping(value = "/getMenu")
    @ResponseBody
    public Object getMenu(HttpServletRequest request, HttpServletResponse response) {
		String eventKey = request.getParameter("eventKey");
		String eventType =RedisStringUtil.getValue( eventKey+"_type");
		String eventContent = RedisStringUtil.getValue(eventKey+"_content");
		Map<String, String> menu = new HashMap<String,String>();
		menu.put("menuKey", eventKey);
		menu.put("menuType", eventType);
		menu.put("menuContent", eventContent);
		return menu;
	}
}
