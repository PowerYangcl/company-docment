package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmCardModel;

public interface BmCardModelMapper {

    int deleteByPrimaryKey(Integer id);


    int insertSelective(BmCardModel record);


    BmCardModel selectByPrimaryKey(Integer id);



    int updateByPrimaryKeySelective(BmCardModel record);
    
    List<Map<String,Object>> queryCardModelList(long id);
    
   int  updateByCardId(long id);
   


}