package cn.cecook.dao.business.automation;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.automation.AutomationTask;

/**
 * 自动化营销任务mapper
 * @author majie
 *
 * 2018年1月22日-下午5:20:55
 */
public interface AutomationTaskMapper {
	/**
	 * 添加任务信息
	 * @return
	 * majie
	 */
	public Integer addAutomationTask(AutomationTask automationTask);
	/**
	 * 根据taskId获取task任务详细
	 * @param taskId
	 * @return
	 * majie
	 */
	public AutomationTask selectById(Integer Id);
	/**
	 * 根据ruleId和模板Id去查询第一个task的信息
	 * @return
	 * majie
	 */
	public AutomationTask selectByRuleId(Map<String,Object> map);
	/**
	 * 根据模板id和parentTaskId去查询task
	 * @param automationTask
	 * @return
	 * majie
	 */
	public AutomationTask selectByParentId(Map<String,Object> map);
	/**
	 * 判断是否存在相同的task
	 * @param automationTask
	 * @return
	 * majie
	 */
	public AutomationTask isExist(AutomationTask automationTask);
	/**
	 * 根据模板Id查询所有短信Id
	 */
	public List<AutomationTask> selectByActionId(Integer templateId);
	/**
	 * 根据模板Id删除所有信息
	 * @param templateId
	 * @return
	 * majie
	 */
	public Integer deleteAutomationTask(Integer templateId);
	/**
	 * 根据节点自增id查询任务信息
	 * @param pointId
	 * @return
	 * majie
	 */
	public AutomationTask findByPointId(Integer pointId);
}
