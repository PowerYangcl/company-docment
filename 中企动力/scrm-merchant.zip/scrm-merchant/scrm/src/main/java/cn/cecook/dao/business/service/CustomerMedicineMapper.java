package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.service.CustomerMedicine;

public interface CustomerMedicineMapper {
	/**
	 * 查询所有数据(可分页和条件查询)
	 * @return
	 * majie
	 */
	public List<CustomerMedicine> findList(CustomerMedicine customerMedicine);
	/**
	 * 添加数据
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public Integer addCustomerMedicine(CustomerMedicine customerMedicine);
	/**
	 * 修改数据
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public Integer updateCustomerMedicine(CustomerMedicine customerMedicine);
	/**
	 * 得到记录总数
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public Integer getCount(CustomerMedicine customerMedicine);
	/**
	 * 根据Id查询得到单个记录
	 * @param id
	 * @return
	 * majie
	 */
	public CustomerMedicine getCustomerMedicine(CustomerMedicine customerMedicine);
	/**
	 * 根据指定条件查询
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public List<CustomerMedicine> findByProp(Map<String,Object> map);
}
