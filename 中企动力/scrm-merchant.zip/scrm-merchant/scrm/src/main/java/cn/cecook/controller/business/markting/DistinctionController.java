package cn.cecook.controller.business.markting;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.markting.BmActivity;
import cn.cecook.service.business.markting.DistinctionService;
import cn.cecook.uitls.UUIDHex;

/**
 * 
 * @author sufubin
 *
 */
@Controller
@RequestMapping(value="/api/distinction")
public class DistinctionController {
	
	@Autowired
	private DistinctionService disinctionService;
	
		//业务列表展示
		@RequestMapping(value = "/getPage", produces = "text/plain;charset=UTF-8")
		@ResponseBody
		public String getPage(@RequestBody String param,String startIndex,String pageSize) {
			String page = disinctionService.getPage(param , startIndex, pageSize);
			return page;
	    }
		//跳到新建业务页面
		@RequestMapping(value = "/toAddDistinction", produces = "text/plain;charset=UTF-8")
		public String toAddDistinction() {
			return "bm/createDistinction";
		}

		//执行业务添加
		@RequestMapping(value = "/create")
		@ResponseBody
		public Integer create(HttpServletRequest request,
				HttpServletResponse response) {
			String title = request.getParameter("title");
			String weixin_qrcode = request.getParameter("weixin_qrcode");
			String weibo_qrcode = request.getParameter("weibo_qrcode");
			String pic = request.getParameter("pic");
			String description = request.getParameter("description");
			String content = request.getParameter("content");
			String status = request.getParameter("status");
			BmActivity activity = new BmActivity();
			Integer statuss=Integer.parseInt(status);
			String uuid_tenant_id = UUIDHex.getInstance().generate();
			if(statuss==1){
				request.getSession().setAttribute("distinction_id", null);
			}
			request.getSession().setAttribute("uuid_tenant_id", uuid_tenant_id);
			activity.setOrderCode(uuid_tenant_id);
			activity.setTitle(title);
			activity.setWeibo_qrcode(weibo_qrcode);
			activity.setWeixin_qrcode(weixin_qrcode);
			activity.setPic(pic);
			activity.setDescription(description);
			activity.setContent(content);
			Date date = new Date();
			activity.setCreateTime(date);
			activity.setName(title);
			activity.setStatus(1);
			Integer result = disinctionService.createDisinction(activity);
			addWebUrl(uuid_tenant_id);
			return result;
		}
		
		private void addWebUrl(String uuid){
			disinctionService.addWebUrl(uuid);
		}
		
		//执行跳到业务预览页
		@RequestMapping(value = "/toPreview")
		public String toPreview() {
			return "bm/distinctionPreview";
		}
		//业务预览页返回的数据
		@RequestMapping(value = "/getPreview")
		@ResponseBody
		public BmActivity getPreview(HttpServletRequest request) {
			return disinctionService.getPreview(request);
		}
		//执行业务删除
		@RequestMapping(value = "/del")
		@ResponseBody
		public Integer del(Integer id) {
			return disinctionService.del(id);
		}
		//执行业务编辑
		@RequestMapping(value = "/update/{id}")
		public String update(@PathVariable Integer id,HttpServletRequest request) {
			request.getSession().setAttribute("distinction_id", id);
			return "bm/distinctionUpdate";
		}
		//初始化业务编辑页面
		@RequestMapping(value = "/getData")
		@ResponseBody
		public BmActivity getData(HttpServletRequest request) {
			Integer id=(Integer) request.getSession().getAttribute("distinction_id");
			return disinctionService.getData(id);
		}
		//保存修改后的业务
		@RequestMapping(value = "/doUpdate")
		@ResponseBody
		public Integer doUpdate(HttpServletRequest request) {
			//从session中取到ID
			Integer id=(Integer) request.getSession().getAttribute("distinction_id");
			//添加时预览模拟id现在设置null现在是修改
			request.getSession().setAttribute("uuid_tenant_id", null);
			String title = request.getParameter("title");
			String weixin_qrcode = request.getParameter("weixin_qrcode");
			String weibo_qrcode = request.getParameter("weibo_qrcode");
			String pic = request.getParameter("pic");
			String description = request.getParameter("description");
			String content = request.getParameter("content");
			BmActivity activity = new BmActivity();
			activity.setTitle(title);
			activity.setPic(pic);
			activity.setDescription(description);
			activity.setContent(content);
			activity.setId(Long.valueOf(id));
			activity.setName(title);
			activity.setWeixin_qrcode(weixin_qrcode);
			activity.setWeibo_qrcode(weibo_qrcode);
			return disinctionService.updateDisinction(activity);
		}

		//
	@RequestMapping(value = "/getActivityListByDefined")
	@ResponseBody
	public Object getActivityListByDefined(String startIndex, String pageSize,
										   String status, String orderBy) {
		return disinctionService.getActivityListByDefined(startIndex, pageSize,
				status, orderBy);
	}
}
