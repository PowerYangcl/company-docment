package cn.cecook.model.business.automation;
/**
 * 节点类型
 * @author majie
 *
 * 2018年1月22日-下午2:49:14
 */
public enum PointType {
	//action --动作
	//rule --条件
	//date --时间
	ACTION,RULE,DATE
}
