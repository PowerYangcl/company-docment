package cn.cecook.bean.system;

import java.io.Serializable;


public class DepartmentBean implements Serializable{

}
