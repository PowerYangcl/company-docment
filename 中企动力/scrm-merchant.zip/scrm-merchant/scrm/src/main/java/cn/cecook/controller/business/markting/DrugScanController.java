package cn.cecook.controller.business.markting;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.DrugScanService;

/**
 * 药品扫码
 * @author zhanghao
 *
 */
@Controller
@RequestMapping(value="/api/drugScan")
public class DrugScanController {
	
	@Autowired
	DrugScanService drugScanService;
	
	/**
	 * 根据条形码查询药品基本信息
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/getDataByDrugScan", method = RequestMethod.POST)
	public Object getDataByDrugScan(HttpServletRequest request, HttpServletResponse response) {
        //条形码
        String barCode = request.getParameter("barCode");
		return drugScanService.getDataByDrugScan(barCode);
	}
	
	/**
	 * 进行纠错操作
	 * @param request
	 * @param response
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value = "/errorCorrect", method = RequestMethod.POST)
	public Object errorCorrect(HttpServletRequest request, HttpServletResponse response) {
        String id = request.getParameter("id");
		return drugScanService.errorCorrect(id);
	}
	/**
	 * 查询所有自动化营销相关商品信息
	 * @param name
	 * @param tenantId
	 * @return
	 */
	@ResponseBody
	@RequestMapping(value="/getGoods",method=RequestMethod.POST)
	public Object getGoodsByName(String tenantId){
		return drugScanService.getGoods(tenantId);
	}
	/**
	 * 根据药品编码查询药品信息
	 * @param goodsNumber
	 * @param tenantId
	 * @return
	 */
	@RequestMapping(value="/getGoodsByGoodsNumber",method=RequestMethod.POST)
	@ResponseBody
	public Object getGoodsByGoodsNumber(String goodsNumber,String tenantId){
		return drugScanService.getDataByGoodsNumber(goodsNumber,tenantId);
	}
	
}
