package cn.cecook.bean.business.markting;

import org.springframework.util.StringUtils;

public class CouponBatchClickStatistics {

	private String name;
	private String phone;
	private String email;
	private String gender;
	private String city;
	private String tempName;
	private String create_time;
	private String activityUrl;
	private String activityName;
	private String couponName;
	private Integer activityId;
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getGender() {
		return gender;
	}
	public void setGender(String gender) {
		if(gender.equals("f")){
			gender="女";
		}else if(gender.equals("m")){
			gender="男";
		}else{
			gender="未知";
		}
		this.gender = gender;
	}
	public String getCity() {
		return city;
	}
	public void setCity(String city) {
		this.city = city;
	}
	public String getTempName() {
		return tempName;
	}
	public void setTempName(String tempName) {
		this.tempName = tempName;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public String getActivityUrl() {
		return activityUrl;
	}
	public void setActivityUrl(String activityUrl) {
		this.activityUrl = activityUrl;
	}
	public String getActivityName() {
		return activityName;
	}
	public void setActivityName(String activityName) {
		if(!StringUtils.isEmpty(activityName))
			tempName=activityName;
		this.activityName = activityName;
	}
	public String getCouponName() {
		return couponName;
	}
	public void setCouponName(String couponName) {
		if(!StringUtils.isEmpty(couponName))
			tempName=couponName;
		this.couponName = couponName;
	}
	public Integer getActivityId() {
		return activityId;
	}
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}
	
	
}
