package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.SocialQrcodeInfo;

/**
 * 二维码管理接口
 * @author majie
 *
 * 2017年12月13日-上午10:03:03
 */
public interface SocialQrcodeInfoMapper {
	/**
	 * 添加二维码信息
	 * @param socialQrcodeInfo
	 * @return
	 * majie
	 */
	public Integer addSocialQrcodeInfo(SocialQrcodeInfo socialQrcodeInfo);
	/**
	 * 查询是否存在二维码对象
	 * @param socialQrcodeInfo
	 * @return
	 * majie
	 */
	public Integer isExistSocialQrcodeInfo(SocialQrcodeInfo socialQrcodeInfo);
	/**
	 * 删除二维码信息
	 * @param socialQrcodeInfo
	 * @return
	 * majie
	 */
	public Integer deleteSocialQrcodeInfo(String codeId);
	/**
	 * 删除门店下所有二维码信息
	 * @param storeId
	 * @return
	 * majie
	 */
	public Integer deleteQrcodeByStoreId(Map<String,Object> map);
	/**
	 * 通过id查询二维码信息
	 * @param id
	 * @return
	 * majie
	 */
	public SocialQrcodeInfo findById(Integer id);
	/**
	 * 修改二维码的二维码链接信息
	 * @param id
	 * @param codeInfo
	 * @return
	 * majie
	 */
	public Integer updateSocialQrcodeInfoById(SocialQrcodeInfo socialQrcodeInfo);
	/**
	 * 查询自定义链接的扫码记录(门店)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getAllBrowseByUrlAndStore(Map<String,Object> map);
	/**
	 * 查询H5活动的扫码记录(门店)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getAllBrowseByActivityAndStore(Map<String,Object> map);
	/**
	 * 查询自定义链接的扫码记录(员工和渠道)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getAllBrowseByUrl(Map<String,Object> map);
	/**
	 * 查询活动的扫码明细记录(员工和渠道)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getAllBrowseByActivity(Map<String,Object> map);
	/**
	 * 查询门店数
	 * @param map
	 * @return
	 * majie
	 */
	public Integer getAllBrowseCountByStore(String codeType);
	/**
	 * 查询门店下明细
	 * @param map
	 * @return
	 * majie
	 */
	public Integer getAllBrowseCount(Map<String,Object> map);
	/**
	 * 查询是否是活动二维码
	 * @param codeId
	 * @return
	 * majie
	 */
	public Integer isActivity(String codeId);
	/**
	 * 获取当天的活动统计(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowCountByActivity(Map<String,Object> map);
	/**
	 * 获取指定条件的活动统计(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCountByActivity(Map<String,Object> map);
	/**
	 * 获取门店的活动统计(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowCountByActivityAndStore(Map<String,Object> map);
	
	/**
	 * 获取门店的活动统计(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCountByActivityAndStore(Map<String,Object> map);
	/**
	 * 获取当天的自定义链接统计(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowCountByUrl(Map<String,Object> map);
	/**
	 * 获取指定条件的自定义链接统计(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCountByUrl(Map<String,Object> map);
	/**
	 * 获取门店的自定义链接统计(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowCountByUrlAndStore(Map<String,Object> map);
	
	/**
	 * 获取门店的自定义链接统计(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCountByUrlAndStore(Map<String,Object> map);
	/**
	 * 获取转化量(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowChangeCount(Map<String,Object> map);
	/**
	 *  获取点击量(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowClickCount(Map<String,Object> map);
	/**
	 * 获取核销量(按小时统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getNowCancelCount(Map<String,Object> map);
	/**
	 * 获取转化量(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getChangeCount(Map<String,Object> map);
	/**
	 *  获取点击量(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getClickCount(Map<String,Object> map);
	/**
	 * 获取核销量(按天统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCancelCount(Map<String,Object> map);
	/**
	 * 获取转化量(按门店统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getChangeCountByStore(Map<String,Object> map);
	/**
	 *  获取点击量(按门店统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getClickCountByStore(Map<String,Object> map);
	/**
	 * 获取核销量(按门店统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCancelCountByStore(Map<String,Object> map);
	/**
	 * 获取转化量(按明细统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getChangeCountByDetail(Map<String,Object> map);
	/**
	 *  获取点击量(按明细统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getClickCountByDetail(Map<String,Object> map);
	/**
	 * 获取核销量(按明细统计)
	 * @param map
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> getCancelCountByDetail(Map<String,Object> map);
}
