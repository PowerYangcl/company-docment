package cn.cecook.controller.business.markting;

import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.business.markting.BmActivity;
import cn.cecook.service.business.markting.ActivityService;
import cn.cecook.service.business.markting.SmartActivityService;
import cn.cecook.thirdparty.weibo.util.LongUrl2ShortUtil;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.ErrorCodeConfigUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.StringUtils;

@Controller
@RequestMapping("/api/activity")
public class ActivityController {

	@Autowired
	private ActivityService activityService;
	private SmartActivityService smartActivityService;

	/**
	 * Title: create Description: 活动创建接口
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		BmActivity bmActivity = new BmActivity();
		String tenant_id = request.getParameter("tenant_id");
		String uid = request.getParameter("uid");
		String activity_name = request.getParameter("activity_name");
		String coupon_send_type = request.getParameter("coupon_send_type");
		String model_id = request.getParameter("model_id");
		String head_pic = request.getParameter("head_pic");
		String pics = request.getParameter("activity_pics");
		String activity_content = request.getParameter("activity_content");

		String commit_info = request.getParameter("commit_info");
		String activity_restrict = request.getParameter("activity_restrict");
		String equipment_facilities = request
				.getParameter("equipment_facilities");
		String discount_price = request.getParameter("discount_price");
		String original_price = request.getParameter("original_price");
		String weixin_qrcode = request.getParameter("weixin_qrcode");
		String weibo_qrcode = request.getParameter("weibo_qrcode");
		String activity_detail_rule = request
				.getParameter("activity_detail_rule");
		String tag = request.getParameter("tag");
		String background_pic = request.getParameter("background_pic");
		String background_music = request.getParameter("background_music");
		String button_text = request.getParameter("button_text");
		String button_css = request.getParameter("button_css");

		String theme_info = request.getParameter("theme_info");
		String theme_info_color = request.getParameter("theme_info_color");
		String text_info_color = request.getParameter("text_info_color");
		String sms_content = request.getParameter("sms_content");
		String status = request.getParameter("status");
		String priceHint = request.getParameter("priceHint");
		String background_color = request.getParameter("background_color");
		String extendField = request.getParameter("extendField");
		String couponId = request.getParameter("couponId");
		String couponName = request.getParameter("couponName");
		String activity_tag = request.getParameter("activityTag");
		String couponFlag = request.getParameter("couponFlag");

		bmActivity.setActivity_tag(activity_tag);
		// 2表示活动仅仅为暂存 此时活动还不能激活分享
		bmActivity.setTenantId(tenant_id);
		bmActivity.setStatus(2);
		bmActivity.setTheme_info(theme_info);
		bmActivity.setTheme_info_color(theme_info_color);
		bmActivity.setText_info_color(text_info_color);
		bmActivity.setButton_css(button_css);
		bmActivity.setButton_text(button_text);
		bmActivity.setTenantId(tenant_id);
		bmActivity.setBak2(priceHint);
		System.out.println("extendField----->" + extendField);
		System.out.println("button_css---->" + button_css);
		if (!StringUtils.isEmpty(uid))
			bmActivity.setCreateId(Long.parseLong(uid));
		bmActivity.setName(activity_name);
		bmActivity.setCouponSendType(coupon_send_type);
		bmActivity.setDescription(activity_content);
		bmActivity.setHead_pic(head_pic);
		bmActivity.setPicUrl(pics);
		if (!StringUtils.isEmpty(couponId))
			bmActivity.setCoupon_id(Integer.parseInt(couponId));
		bmActivity.setCoupon_name(couponName);
		System.out.println("-----需要插入的活动信息-->"
				+ FastJsonUtil.createJsonString(bmActivity));
		if (!StringUtils.isEmpty(model_id))
			bmActivity.setModel_id(Integer.parseInt(model_id));
		// bmActivity.setStartDate(start_date);
		if (!StringUtils.isEmpty(status))
			bmActivity.setStatus(Integer.parseInt(status));
		bmActivity.setDiscount_price(discount_price);
		bmActivity.setOriginal_price(original_price);
		bmActivity.setCommit_info(commit_info);
		bmActivity.setActivity_restrict(activity_restrict);
		bmActivity.setEquipment_facilities(equipment_facilities);
		bmActivity.setWeixin_qrcode(weixin_qrcode);
		bmActivity.setWeibo_qrcode(weibo_qrcode);
		bmActivity.setDetail_rule(activity_detail_rule);
		bmActivity.setTag(tag);
		bmActivity.setBackground_pic(background_pic);
		bmActivity.setBackground_music(background_music);
		bmActivity.setBak1(sms_content);
		bmActivity.setRemarks(background_color);
		if(!StringUtils.isEmpty(couponFlag))
			bmActivity.setCouponFlag(Integer.parseInt(couponFlag));
		return (activityService.createActivity(bmActivity, extendField));
	}

	/**
	 * Title: create Description: 活动创建接口
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/editActivity")
	@ResponseBody
	public Object editActivity(HttpServletRequest request,
			HttpServletResponse response) {
		BmActivity bmActivity = new BmActivity();
		String tenant_id = request.getParameter("tenant_id");
		String uid = request.getParameter("uid");
		String activity_name = request.getParameter("activity_name");
		String coupon_send_type = request.getParameter("coupon_send_type");
		String model_id = request.getParameter("model_id");
		String head_pic = request.getParameter("head_pic");
		String pics = request.getParameter("activity_pics");
		String activity_content = request.getParameter("activity_content");
		String activity_id = request.getParameter("activity_id");
		String commit_info = request.getParameter("commit_info");
		String activity_restrict = request.getParameter("activity_restrict");
		String equipment_facilities = request
				.getParameter("equipment_facilities");
		String discount_price = request.getParameter("discount_price");
		String original_price = request.getParameter("original_price");
		String weixin_qrcode = request.getParameter("weixin_qrcode");
		String weibo_qrcode = request.getParameter("weibo_qrcode");
		String activity_detail_rule = request
				.getParameter("activity_detail_rule");
		String background_pic = request.getParameter("background_pic");
		String background_music = request.getParameter("background_music");
		String theme_info = request.getParameter("theme_info");
		String theme_info_color = request.getParameter("theme_info_color");
		String text_info_color = request.getParameter("text_info_color");
		String button_text = request.getParameter("button_text");
		String button_css = request.getParameter("button_css");
		String sms_content = request.getParameter("sms_content");
		String status = request.getParameter("status");
		System.out.println("text_info_color------>" + text_info_color);
		System.out.println("button_css---->" + button_css);
		String priceHint = request.getParameter("priceHint");
		String background_color = request.getParameter("background_color");
		String extendField = request.getParameter("extendField");
		String couponId = request.getParameter("couponId");
		String couponName = request.getParameter("couponName");
		String activity_tag = request.getParameter("activityTag");
		String couponFlag = request.getParameter("couponFlag");

		bmActivity.setActivity_tag(activity_tag);
		bmActivity.setRemarks(background_color);
		bmActivity.setBak2(priceHint);
		bmActivity.setButton_css(button_css);
		bmActivity.setButton_text(button_text);
		bmActivity.setTheme_info(theme_info);
		bmActivity.setTheme_info_color(theme_info_color);
		bmActivity.setText_info_color(text_info_color);
		bmActivity.setTenantId(tenant_id);
		if (!StringUtils.isEmpty(uid))
			bmActivity.setCreateId(Long.parseLong(uid));
		bmActivity.setName(activity_name);
		bmActivity.setCouponSendType(coupon_send_type);
		bmActivity.setDescription(activity_content);
		bmActivity.setHead_pic(head_pic);
		bmActivity.setPicUrl(pics);
		if (!StringUtils.isEmpty(model_id))
			bmActivity.setModel_id(Integer.parseInt(model_id));
		// bmActivity.setStartDate(start_date);
		bmActivity.setDiscount_price(discount_price);
		bmActivity.setOriginal_price(original_price);
		if (!StringUtils.isEmpty(status))
			bmActivity.setStatus(Integer.parseInt(status));

		bmActivity.setCommit_info(commit_info);
		bmActivity.setActivity_restrict(activity_restrict);
		bmActivity.setEquipment_facilities(equipment_facilities);
		bmActivity.setWeixin_qrcode(weixin_qrcode);
		bmActivity.setWeibo_qrcode(weibo_qrcode);
		bmActivity.setDetail_rule(activity_detail_rule);
		bmActivity.setId(Long.parseLong(activity_id));
		bmActivity.setBackground_pic(background_pic);
		bmActivity.setBackground_music(background_music);
		bmActivity.setBak1(sms_content);
		if (!StringUtils.isEmpty(couponId))
			bmActivity.setCoupon_id(Integer.parseInt(couponId));
	
		bmActivity.setCoupon_name(couponName);
		if(!StringUtils.isEmpty(couponFlag))
			bmActivity.setCouponFlag(Integer.parseInt(couponFlag));
		

		return (activityService.editActivity(bmActivity, extendField));
	}

	/**
	 * Title: create Description: 活动分享页编辑
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/create_share")
	@ResponseBody
	public Object create_share(HttpServletRequest request,
			HttpServletResponse response) {
		BmActivity bmActivity = new BmActivity();
		String tenant_id = request.getParameter("tenant_id");
		String uid = request.getParameter("uid");
		String effective_day = request.getParameter("effective_day");
		String coupon_number = request.getParameter("coupon_number");
		String tag_defined = request.getParameter("tag_defined");
		String share_title = request.getParameter("share_title");
		String share_content = request.getParameter("share_content");
		String share_pic = request.getParameter("share_pic");
		String activity_id = request.getParameter("activity_id");
		String start_time = request.getParameter("start_time");
		String end_time = request.getParameter("end_time");
		String coupon_expire_day = request.getParameter("coupon_expire_day");
		String status = request.getParameter("status");
		String headPic = request.getParameter("head_pic");
		String activityName = request.getParameter("activityName");

		if (!StringUtils.isEmpty(headPic))
			bmActivity.setHead_pic(headPic);

		if (!StringUtils.isEmpty(effective_day) && !"0".equals(effective_day)){
			bmActivity.setEffectiveDay(Integer.parseInt(effective_day));
			bmActivity.setStart_time(DateUtils.transDate(DateUtils.getDayStartTimeDate(new Date())));
			bmActivity.setEnd_time(DateUtils.transDate(DateUtils.getDayEndTimeDate(DateUtils.afterNDay(Integer.parseInt(effective_day)))));
		}else if(!StringUtils.isEmpty(end_time) || !StringUtils.isEmpty(start_time)) {
			if (!StringUtils.isEmpty(start_time)) {
				bmActivity.setStart_time(DateUtils.formatFromYYYYMMDDhhmmss(DateUtils.getDayStartTime(start_time)));
			} 

			if (!StringUtils.isEmpty(end_time)) {
				bmActivity.setEnd_time(DateUtils.formatFromYYYYMMDDhhmmss(DateUtils.getDayEndTime(end_time)));
			} 
			bmActivity.setEffectiveDay(0);
		}else {
			bmActivity.setStart_time(DateUtils.transDate(DateUtils.getDayStartTimeDate(new Date())));
			bmActivity.setEnd_time(null);
			bmActivity.setEffectiveDay(0);
		}
		
		
		if (!StringUtils.isEmpty(coupon_number))
			bmActivity.setCouponNumber(Integer.parseInt(coupon_number));
		if (!StringUtils.isEmpty(activity_id)) {
		}
		bmActivity.setId(Long.parseLong(activity_id));
		
		if (!StringUtils.isEmpty(coupon_expire_day)) {
			bmActivity
					.setCoupon_expire_day(Integer.parseInt(coupon_expire_day));
		} else {
			bmActivity.setCoupon_expire_day(0);
		}

		if (!StringUtils.isEmpty(status))
			bmActivity.setStatus(Integer.parseInt(status));
		bmActivity.setTagDefined(tag_defined);
		bmActivity.setTitle(share_title);
		bmActivity.setContent(share_content);
		bmActivity.setPic(share_pic);
		bmActivity.setName(activityName);
		return (activityService.createShare(uid, tenant_id, bmActivity));
	}

	/**
	 * Title: create Description: 活动分享页编辑
	 *
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/edit")
	@ResponseBody
	public Object edit(HttpServletRequest request, HttpServletResponse response) {
		return response;
	}

	/**
	 * Title: activateActivity Description: 启动活动
	 *
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param activity_id
	 *            活动id
	 * @return
	 */
	@RequestMapping(value = "/activate")
	@ResponseBody
	public Object activateActivity(String tenant_id, String uid,
			String activity_id) {
		return activityService.activateActivity(tenant_id, uid, activity_id);
	}

	/**
	 * Title: suspendActivity Description:活动停止
	 *
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param activity_id
	 *            活动id
	 * @return
	 */
	@RequestMapping(value = "/suspend")
	@ResponseBody
	public Object suspendActivity(String tenant_id, String uid,
			String activity_id) {
		return (activityService.suspendActivity(tenant_id, uid, activity_id));
	}

	/**
	 * Title: check Description:活动审核
	 *
	 * @param check_description
	 *            审核描述
	 * @param check_status
	 *            审核状态码
	 * @param activity_id
	 *            活动id
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @return
	 */
	@RequestMapping(value = "/check")
	@ResponseBody
	public Object check(String check_description, String check_status,
			String activity_id, String tenant_id, String uid) {
		return (activityService.checkActivity(tenant_id, uid, check_status,
				activity_id, check_description));
	}

	/**
	 * Title: delete Description:活动删除接口
	 *
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param activity_id
	 *            活动id
	 * @return
	 */
	@RequestMapping(value = "/delete")
	@ResponseBody
	public Object delete(String tenant_id, String uid, String activity_id) {
		return (activityService.deleteActivity(tenant_id, uid, activity_id));
	}

	/**
	 * Title: check Description:查询活动详情
	 *
	 * @param activity_id
	 *            活动id
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @return
	 */
	@RequestMapping(value = "/countdetail")
	@ResponseBody
	public Object countDetail(String activity_id, String tenant_id, String uid,
			String activity_type) {
		if (!StringUtils.isEmpty(activity_type) && activity_type.equals("1")) {
			return (smartActivityService.getStatisticalDetail(activity_id));
		} else {
			return (activityService.getActivityCountDetail(tenant_id, uid,
					activity_id));
		}

	}

	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object detail(String activity_id, String tenant_id, String uid,
			String activity_type) {
		if (!StringUtils.isEmpty(activity_type) && activity_type.equals("1")) {
			return (smartActivityService.getStatisticalDetail(activity_id));
		} else {
			return (activityService.getActivityDetail(tenant_id, uid,
					activity_id));
		}

	}

	/**
	 * Title: openActivity Description:用户打开活动
	 *
	 * @param activity_id
	 * @param tenant_id
	 * @param activity_type
	 * @return
	 */
	@RequestMapping(value = "/openActivity")
	@ResponseBody
	public Object openActivity(HttpServletRequest request,
			HttpServletResponse response) {
		String activity_id=request.getParameter("activity_id");
		String tenant_id=request.getParameter("tenant_id");
		String activity_type= request.getParameter("activity_type");
		String customer_id= request.getParameter("customer_id");
		String browse_ip=request.getParameter("browse_ip");
		String open_way= request.getParameter("open_way");
		String transmitTag= request.getParameter("transmitTag");
		String batch= request.getParameter("batch");
		String card_id=request.getParameter("card_id");
		String open_id=request.getParameter("open_id");
		String channel_type=request.getParameter("channel_type");
		String longitude=request.getParameter("longitude");
		String latitude=request.getParameter("latitude");
		String province=request.getParameter("province");
		String city=request.getParameter("city");
		String district=request.getParameter("district");
		String couponBatch=request.getParameter("couponBatch");
		String taskId=request.getParameter("taskId");
		
		
		Map<String,String> map=new HashMap<String,String>();
		map.put("activity_id", activity_id);
		map.put("tenant_id", tenant_id);
		map.put("activity_type", activity_type);
		map.put("customer_id", customer_id);
		map.put("browse_ip", browse_ip);
		map.put("open_way", open_way);
		map.put("transmitTag", transmitTag);
		map.put("batch", batch);
		map.put("card_id", card_id);
		map.put("open_id", open_id);
		map.put("channel_type", channel_type);
		map.put("longitude", longitude);
		map.put("latitude", latitude);
		map.put("province", province);
		map.put("city", city);
		map.put("district", district);
		map.put("couponBatch", couponBatch);
		map.put("taskId", taskId);
		
		return (activityService.OpenActivity(map));
	}

	/**
	 * Title: query_list 获取活动列表 Description:
	 *
	 * @param tenant_id
	 *            租户id
	 * @param uid
	 *            用户id
	 * @param self_id
	 *            分页id
	 * @param current_page
	 *            当前页码
	 * @param next_page
	 *            下一页
	 * @param page_size
	 *            每页数据大小
	 * @param query_keys
	 *            查询标签
	 * @return
	 */
	@RequestMapping(value = "/query_list")
	@ResponseBody
	public Object query_list(String tenant_id, String uid, String self_id,
			String current_page, String next_page, String page_size,
			String key_word, String status, String key_ratio,
			String key_ratio_where, String ratio_vaule) {

		return (activityService.getBmActivityList(tenant_id, uid, self_id,
				current_page, next_page, page_size, key_word, status,
				key_ratio, key_ratio_where, ratio_vaule));
	}

	/**
	 * 获最热模板
	 *
	 * @param tenant_id
	 * @param uid
	 * @return
	 */
	@RequestMapping(value = "/hotList")
	@ResponseBody
	public Object hotList(String tenant_id, String uid) {

		return (activityService.getHotActivityList(tenant_id, uid));

	}

	/**
	 * 报告大厅最热活动
	 *
	 * @param start_time
	 * @param end_time
	 * @return
	 */
	@RequestMapping(value = "/hotActivityBatch")
	@ResponseBody
	public Object HotActivityBatch(String startIndex, String pageSize,
			String start_time, String end_time) {
		return activityService.HotActivityBatch(start_time, end_time,
				startIndex, pageSize);
	}

	/**
	 * Title: browseCreate Description:增加活动浏览记录
	 *
	 * @param tenant_id
	 *            租户id
	 * @param activity_id
	 *            活动id
	 * @param activity_name
	 *            活动名称
	 * @param browse_ip
	 *            浏览ip
	 * @return
	 */
	
	//已废弃
	@RequestMapping(value = "/browse_create")
	@ResponseBody
	public Object browseCreate(HttpServletRequest request,
			HttpServletResponse response) {

		String activity_id=request.getParameter("activity_id");
		String tenant_id=request.getParameter("tenant_id");
		String activity_type= request.getParameter("activity_type");
		String customer_id= request.getParameter("customer_id");
		String browse_ip=request.getParameter("browse_ip");
		String open_way= request.getParameter("open_way");
		String transmitTag= request.getParameter("transmitTag");
		String batch= request.getParameter("batch");
		String card_id=request.getParameter("card_id");
		String open_id=request.getParameter("open_id");
		String channel_type=request.getParameter("channel_type");
		String longitude=request.getParameter("longitude");
		String latitude=request.getParameter("latitude");
		String province=request.getParameter("province");
		String city=request.getParameter("city");
		String district=request.getParameter("district");
		String couponBatch=request.getParameter("couponBatch");
		String taskId=request.getParameter("taskId");
		String activityName=request.getParameter("activityName");
		
		
		Map<String,String> map=new HashMap<String,String>();
		map.put("activity_id", activity_id);
		map.put("tenant_id", tenant_id);
		map.put("activity_type", activity_type);
		map.put("customer_id", customer_id);
		map.put("browse_ip", browse_ip);
		map.put("open_way", open_way);
		map.put("transmitTag", transmitTag);
		map.put("batch", batch);
		map.put("card_id", card_id);
		map.put("open_id", open_id);
		map.put("channel_type", channel_type);
		map.put("longitude", longitude);
		map.put("latitude", latitude);
		map.put("province", province);
		map.put("city", city);
		map.put("district", district);
		map.put("couponBatch", couponBatch);
		map.put("taskId", taskId);
		map.put("activityName", activityName);
		return activityService.BrowseCreate(map);

	}

	/**
	 * Title: browseList Description:活动浏览记录列表接口
	 *
	 * @param tenant_id
	 *            租户id
	 * @param activity_id
	 *            活动id
	 * @return
	 */
	@RequestMapping(value = "/browse_list")
	@ResponseBody
	public Object browseList(String tenant_id, String activity_id,
			String startIndex, String pageSize, String orderBy,
			String activity_type, String keyWord) {
		return activityService.BroseList(tenant_id, activity_id, startIndex,
				pageSize, orderBy, activity_type, keyWord);

	}

	/**
	 * Title: getActivityCustomerList Description:查询参加活动的客户列表
	 *
	 * @param startIndex
	 * @param page_size
	 * @param activity_id
	 * @param uid
	 * @param tenant_id
	 * @return
	 */
	@RequestMapping(value = "/join_activity_customer")
	@ResponseBody
	public Object getActivityCustomerList(String startIndex, String page_size,
			String activity_id, String uid, String tenant_id) {

		return activityService.getActivityCustomerList(startIndex, page_size,
				activity_id, uid, tenant_id);

	}

	/**
	 * Title: getActivityAction Description:查询活动的客户行为列表
	 *
	 * @param startIndex
	 * @param page_size
	 * @param activity_id
	 * @param uid
	 * @param tenant_id
	 * @param type
	 * @return
	 */
	@RequestMapping(value = "/activity_action")
	@ResponseBody
	public Object getActivityAction(String startIndex, String page_size,
			String activity_id, String uid, String tenant_id, String type,
			String handle_status) {

		return activityService.getActivityAction(startIndex, page_size,
				activity_id, uid, tenant_id, type, handle_status);

	}

	/**
	 * 微门户查询正在进行的活动列表
	 *
	 * @param tenant_id
	 * @param uid
	 * @param startIndex
	 * @param page_size
	 * @param status
	 * @param activity_id
	 * @return
	 */
	@RequestMapping(value = "/activiting")
	@ResponseBody
	public Object getAcList(String tenant_id, String uid, String startIndex,
			String page_size, String status, String store_id) {

		return activityService.getAcList(tenant_id, uid, startIndex, page_size,
				status, store_id);
	}

	/**
	 * Title: receiveCoupon Description:
	 *
	 * @param mobile
	 * @param name
	 * @param activity_id
	 * @param activity_type
	 * @return
	 */
	@RequestMapping(value = "/receive_coupon")
	@ResponseBody
	public Object receiveCoupon(String mobile, String name, String activity_id,
			String activity_type) {

		return activityService.receiveCounpon(mobile, name, activity_id,
				activity_type);

	}

	/**
	 * Title: receiveCoupon Description:用户参加活动
	 *
	 * @param mobile
	 * @param name
	 * @param activity_id
	 * @param activity_type
	 * @return
	 */
	@RequestMapping(value = "/join")
	@ResponseBody
	public Object joinActivity(String mobile, String name, String activity_id,
			String activity_type, String weixin, String email, String weibo,
			String job, String company, String open_way, String transmitTag,
			String batch, String card_id,String channel_type,String longitude,String latitude,String province,String city,String district,String taskId) {

		if (activity_type.equals("1")) {
			return smartActivityService.JoinSmartActivity(mobile, name,
					activity_id, weixin, email, weibo, job, company, open_way,
					transmitTag, card_id);
		} else {
			return activityService.JoinActivity(mobile, name, activity_id,
					activity_type, weixin, email, weibo, job, company,
					open_way, transmitTag, batch, card_id,channel_type,longitude,latitude, province, city, district,taskId);
		}
	}

	/**
	 * Title: getBrowseActivityContent Description:用户浏览活动需要的简要信息
	 *
	 * @param activity_id
	 *            活动id
	 * @param activity_type
	 *            活动类型
	 * @return
	 */
	@RequestMapping(value = "/browseActivityContent")
	@ResponseBody
	public Object browseActivityContent(String activity_id, String activity_type) {
		return activityService.getBrowseActivityContent(activity_id,
				activity_type);
	}

	/**
	 * Title: getBriefActivityList Description://获取活动的简略信息列表（不包括数据统计）
	 *
	 * @param startIndex
	 *            起始页
	 * @param pageSize
	 *            数据大小
	 * @param keyWord
	 *            关键字
	 * @return
	 */
	@RequestMapping(value = "/getBriefActivityList")
	@ResponseBody
	public Object getBriefActivityList(String startIndex, String pageSize,
			String keyWord) {
		return activityService.getBriefActivityList(startIndex, pageSize,
				keyWord);
	}

	@RequestMapping(value = "/getBusinessLikelist")
	@ResponseBody
	public Object getBusinessLikelist(String startIndex, String pageSize,
									   String keyWord) {
		return activityService.getBusinessLikelist(startIndex, pageSize,
				keyWord);
	}
	@RequestMapping(value = "/getActivityLikelist")
	@ResponseBody
	public Object getActivityLikelist(String startIndex, String pageSize,
									  String keyWord) {
		return activityService.getActivityLikelist(startIndex, pageSize,
				keyWord);
	}

	@RequestMapping(value = "/joinReserve")
	@ResponseBody
	public Object joinReserveActivity(String customer_id, String name,
			String mobile, String reserve_time, String reserve_number,
			String activity_id, String reserve_store_id, String activity_type,
			String open_way, String transmitTag, String card_id) {
		System.out.println("------------>" + reserve_store_id);
		Map<String, String> map = new HashMap<String, String>();
		map.put("activity_id", activity_id);
		map.put("mobile", mobile);
		map.put("activity_type", activity_type);
		map.put("reserve_time", reserve_time);
		map.put("customer_name", name);
		map.put("reserve_number", reserve_number);
		map.put("reserve_store_id", reserve_store_id);
		map.put("open_way", open_way);
		map.put("transmitTag", transmitTag);
		map.put("customer_id", customer_id);
		if (activity_type.equals("1")) {
			return smartActivityService.JoinSmartActivity(mobile, name,
					activity_id, "", "", "", "", "", open_way, transmitTag,
					card_id);
		} else {
			return activityService.JoinReserveActivity(map);
		}
	}

	/**
	 * Title: joinReserveActivity Description:
	 *
	 * @param customer_id
	 * @param name
	 * @param mobile
	 * @param reserve_time
	 * @param reserve_number
	 * @param activity_id
	 * @param reserve_store_id
	 * @param activity_type
	 * @param open_way
	 * @param transmitTag
	 * @return
	 */
	@RequestMapping(value = "/joinReserveFriend")
	@ResponseBody
	public Object joinReserveActivityFriend(String customer_id, String name,
			String mobile, String reserve_number, String activity_id,
			String activity_type, String open_way, String transmitTag) {
		Map<String, String> map = new HashMap<String, String>();
		map.put("activity_id", activity_id);
		map.put("mobile", mobile);
		map.put("activity_type", activity_type);
		map.put("customer_name", name);
		map.put("reserve_number", reserve_number);
		map.put("open_way", open_way);
		map.put("transmitTag", transmitTag);
		map.put("customer_id", customer_id);

		return activityService.JoinReserveFriendActivity(map);
	}

	/**
	 * Title: getActivityListBySys Description:获取用自定义模板创建的活动列表
	 *
	 * @param startIndex
	 * @param pageSize
	 * @param keyWord
	 * @return
	 */
	@RequestMapping(value = "/getActivityListByDefined")
	@ResponseBody
	public Object getActivityListByDefined(String startIndex, String pageSize,
			String status, String orderBy) {
		return activityService.getActivityListByDefined(startIndex, pageSize,
				status, orderBy);
	}

	/**
	 * Title: getActivityListBySys Description:获取用系统模板创建的活动列表
	 *
	 * @param startIndex
	 * @param pageSize
	 * @param keyWord
	 * @return
	 */
	@RequestMapping(value = "/getActivityListBySys")
	@ResponseBody
	public Object getActivityListBySys(String startIndex, String pageSize,
			String status) {
		return activityService.getActivityListBySys(startIndex, pageSize,
				status);
	}

	// 锁定编辑
	@RequestMapping(value = "/lock")
	@ResponseBody
	public Object lock(String id) {
		return activityService.lock(id);
	}

	// 解除编辑
	@RequestMapping(value = "/unlock")
	@ResponseBody
	public Object unlock(String id) {
		return activityService.unlock(id);
	}

	// 获取预约信息、列表
	@RequestMapping(value = "/reserveInfo")
	@ResponseBody
	public Object getReserveInfo(String activity_id, String customer_id) {
		return activityService.getReserveInfo(activity_id, customer_id);

	}

	// 用于编辑短信选取活动列表
	@RequestMapping(value = "/smsActivity")
	@ResponseBody
	public Object getSmsActivity(String keyWord) {
		System.out.println("keyWoed------->" + keyWord);

		return activityService.getSmsActivity(keyWord);

	}

	// 用于编辑短信选取活动列表
	@RequestMapping(value = "/shorUrl")
	@ResponseBody
	public Object getActivityShortUrl(String id) {

		return activityService.getActivityShortUrl(id);

	}

	// 获取所有活动转化数量
	@RequestMapping(value = "/getActivityConverNum")
	@ResponseBody
	public Object getActivityConverNum(String startTime, String endTime) {

		return activityService.getActivityConverNum(startTime, endTime);

	}

	// 首页表格活动展示内容
	@RequestMapping(value = "/activityConverForDay")
	@ResponseBody
	public Object activityConverForDay(String startTime) {
		return activityService.activityConverForDay(startTime);
	}

	@RequestMapping(value = "/activityConverRatio")
	@ResponseBody
	public Object ActivityConverRatio(int days, String startTime) {
		return activityService.ActivityConverRatio(days, startTime);
	}

	// 社交活动打开渠道占比
	@RequestMapping(value = "/openChannelRatio")
	@ResponseBody
	public Object OpenChannelRatio() {
		return activityService.OpenChannelRatio();
	}

	// 每日社交活动转化人数
	@RequestMapping(value = "/activityConverNumByDay")
	@ResponseBody
	public Object ActivityConverNumByDay(int startIndex, int pageSize,
			String startTime, String endTime, String days) {
		if (StringUtils.isEmpty(days)) {
			days = "0";
		}
		return activityService.ActivityConverNumByDay(startIndex, pageSize,
				startTime, endTime, Integer.parseInt(days));

	}

	// 获取全部活动所在的转化活动天数(按日)、全部线索所对应的事件天数(按日)、全部线索对应的挖掘用户天数(按日)
	@RequestMapping(value = "/getAllCalTableDate")
	@ResponseBody
	public Object getAllCalTableDate() {
		return activityService.getAllCalTableDate();

	}

	// 根据开始时间、结束时间获取活动次数
	@RequestMapping(value = "/getActivityNums")
	@ResponseBody
	public Object getActivityNums(String startTime, String endTime) {

		return activityService.getActivityNums(startTime, endTime);

	}

	// 根据开始时间、结束时间获取总分享量
	@RequestMapping(value = "/getActivityShareNums")
	@ResponseBody
	public Object getActivityShareNums(String startTime, String endTime) {

		return activityService.getActivityShareNums(startTime, endTime);

	}

	// 初始化微博找人数量线索总数
	@RequestMapping(value = "/getInitPeoDiv")
	@ResponseBody
	public Object getInitPeoDiv(String startTime, String endTime) {
		return activityService.getInitPeoDiv();

	}

	@RequestMapping(value = "/longUrlToShort")
	@ResponseBody
	public Object getShortUrl(String longUrl) {
		BaseResultModel baseResultModel = new BaseResultModel();
		if (!MyCatFilter.getToken_Valid()) {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return baseResultModel;
		} else if (StringUtils.isEmpty(longUrl)) {
			baseResultModel.setError_code(ConfigStatusCode.DATA_EMPTY);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20027);
			return baseResultModel;
		} else {
			String shortUrl = LongUrl2ShortUtil.toShortUrl(longUrl);
			if(!shortUrl.startsWith("http://")){
				shortUrl="http://"+shortUrl;
			}
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			baseResultModel
					.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			baseResultModel.setData(shortUrl);
			return baseResultModel;
		}

	}
	/**
	* 插入用户自定义H5链接
	* @param:
	* @return:
	*/
	@RequestMapping(value = "/insertCustomActivity")
	@ResponseBody
	public Object insertCustomActivity(BmActivity activityBean){
		BaseResultModel baseResultModel = new BaseResultModel();
		if (MyCatFilter.getToken_Valid()) {
			activityBean.setName(activityBean.getTitle());
			activityBean.setType(1);
			Integer id = activityService.insertCustomActivity(activityBean);
			Long dd = activityBean.getId();
			if (dd != null) {
				baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
				baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
				baseResultModel.setData(dd);
				return baseResultModel;
			} else {
				baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
				baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
				return baseResultModel;
			}

		} else {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return baseResultModel;
		}
	}
	
	/* 
	 * 2017-12-25  xuwei 
	 * 模糊查询  活动  
	 * */
	@RequestMapping(value = "/selectLikeByName")
	@ResponseBody
	public BaseResultModel getByName(String startIndex,
            String pageSize,String name){
		
		return activityService.getByName(startIndex, pageSize, name);
	}
	
}
