package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.MarketBean;
import cn.cecook.model.business.markting.BmMarket;
import cn.cecook.model.business.markting.BmMarketExample;

public interface BmMarketMapper {
	int countByExample(BmMarketExample example);

	int deleteByExample(BmMarketExample example);

	int deleteByPrimaryKey(Long id);

	int insert(BmMarket record);

	int insertSelective(BmMarket record);

	List<BmMarket> selectByExample(BmMarketExample example);

	BmMarket selectByPrimaryKey(Long id);

	int updateByExampleSelective(@Param("record") BmMarket record,
                                 @Param("example") BmMarketExample example);

	int updateByExample(@Param("record") BmMarket record,
                        @Param("example") BmMarketExample example);

	int updateByPrimaryKeySelective(BmMarket record);

	int updateByPrimaryKey(BmMarket record);

	int updateStatus(Map<String, Object> map);

	int getStatus(long market_id);

	MarketBean getDetail(long market_id);

	List<MarketBean> getMarketList(Map<String, Object> map);

	String queryName(String name);

	String queryUpdateName(Map<String, Object> map);
	//设置首页显示
	int setHomeShow(@Param("id") Long id);
	//获取首页显示的智能营销方案
	MarketBean queryHomeMarket();

	int countClueNum(List<Long> list);
	//判断智能营销是否产生线索
	int marketClueNum(long market_id);

	//统计数量
	int countMarket(Map<String, Object> map);

}