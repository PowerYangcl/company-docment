package cn.cecook.bean.business.markting;

import java.io.Serializable;

/**
 * 
 * @Title MarketSendCustomer.java
 * @Description 只能营销发送对象标签表（按照四个维度，交易时间、交易频率，交易额度、流失状态）
 * @author wschenyongyin
 * @date 2017年5月26日
 * @version 1.0
 */
public class MarketSendCustomerBean implements Serializable {
	//按照交易时间，分为老客户和新客户    1表示新客户，2表示老客户
	private int time_dimension;
	//按照交易频率 分为过客、常客、忠诚客户  1表示客户、2表示常客、3表示忠诚客户
	private int frequency_dimension;
	//按照交易额度   1表示零散，2表示一般 3表示主力
	private int amount_dimension;
	//按照流失状态   1表示流失 2表示非流失
	private int lose_status;

	public int getTime_dimension() {
		return time_dimension;
	}

	public void setTime_dimension(int time_dimension) {
		this.time_dimension = time_dimension;
	}

	public int getFrequency_dimension() {
		return frequency_dimension;
	}

	public void setFrequency_dimension(int frequency_dimension) {
		this.frequency_dimension = frequency_dimension;
	}

	public int getAmount_dimension() {
		return amount_dimension;
	}

	public void setAmount_dimension(int amount_dimension) {
		this.amount_dimension = amount_dimension;
	}

	public int getLose_status() {
		return lose_status;
	}

	public void setLose_status(int lose_status) {
		this.lose_status = lose_status;
	}

}
