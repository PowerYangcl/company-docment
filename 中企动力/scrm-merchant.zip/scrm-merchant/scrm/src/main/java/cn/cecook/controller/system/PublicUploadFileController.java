package cn.cecook.controller.system;

import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.amazonaws.services.s3.model.ObjectMetadata;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.amazonaws.FileUtil;
import net.sf.json.JSONObject;

/**
 * 
 * @explain
 * @author ZHIWEN
 * @data 2017年7月1日
 */
@Controller
@RequestMapping("/api/uploadfile")
public class PublicUploadFileController {
	
	@Value("#{configProperties['UplaodBaseUrl']}")
    private String UPLOAD_BASE_URL;
	
	private  Logger log=Logger.getLogger(PublicUploadFileController.class);
	
	/**
	 * 
	 * @explain 上传文件接口
	 * @author ZHIWEN
	 * @data 2017年6月17日
	 */
	/*
	 * @RequestMapping(value="/file" ,method = RequestMethod.POST,produces =
	 * "application/json;charset=UTF-8") public @ResponseBody Object
	 * file(HttpServletRequest request,HttpServletResponse response
	 * ,@RequestParam(value = "typename",required = false)String typename
	 * ,@RequestParam(value = "isFile",required = false)Boolean isFile ){
	 * System.out.println("111111111111111");
	 * 
	 * response.setHeader("Access-Control-Allow-Origin","*");
	 * response.setHeader("Access-Control-Allow-Methods","GET,POST"); if
	 * (isFile!=null&&isFile==true) { typename+="_FILE";//加入文件类型标记 }
	 * 
	 * JSONObject jsonObject=
	 * FileUploadUtils.getinstance().UploadFile(request,typename);
	 * System.out.println(jsonObject); return (jsonObject); }
	 */

	@RequestMapping(value = "/file", method = RequestMethod.POST, produces = "application/json;charset=UTF-8")
	public @ResponseBody Object file(
			HttpServletRequest request,
			HttpServletResponse response,
			@RequestParam(value = "typename", required = false) String typename,
			@RequestParam(value = "isFile", required = false) Boolean isFile) {
		JSONObject jsonObject = new JSONObject();
		
		MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
		MultipartFile multipartFile = multipartRequest.getFile(typename);// 获取表单
	    String filename = multipartFile.getOriginalFilename();//获取文件名
	    
	    InputStream is;
	    String path=null;
		try {
			is = multipartFile.getInputStream();
			ObjectMetadata metadata = new ObjectMetadata();
			metadata.setContentType("image/jpeg");
			path=FileUtil.uploadFile(is, metadata);
			log.info("上传成功返回的path："+path);
		} catch (IOException e) {
			log.error("上传失败 抛出异常：", e);
		}
		if (path != "" && path != null && path.length() > 0) {
			jsonObject.put("message", "文件上传成功");
            jsonObject.put("saveFilename", filename);
            jsonObject.put("file_url", "");
            //jsonObject.put("realSavePath", realSavePath);
            jsonObject.put("realSavePath", path);
			
		} else {
			jsonObject.put("message", "文件上传失败");
		}
		return jsonObject;
	}
}
