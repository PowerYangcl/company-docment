package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import java.sql.Timestamp;

@Component
public class SmartRuleBean {

	private long rule_id;
	private String send_object;
	private String send_time;
	private String send_type;
	private String behavior_rule;
	private String receive_rule;
	private Timestamp create_time;

	public long getRule_id() {
		return rule_id;
	}

	public void setRule_id(long rule_id) {
		this.rule_id = rule_id;
	}

	public String getSend_object() {
		return send_object;
	}

	public void setSend_object(String send_object) {
		this.send_object = send_object;
	}

	public String getSend_time() {
		return send_time;
	}

	public void setSend_time(String send_time) {
		this.send_time = send_time;
	}

	public String getSend_type() {
		return send_type;
	}

	public void setSend_type(String send_type) {
		this.send_type = send_type;
	}

	public String getBehavior_rule() {
		return behavior_rule;
	}

	public void setBehavior_rule(String behavior_rule) {
		this.behavior_rule = behavior_rule;
	}

	public String getReceive_rule() {
		return receive_rule;
	}

	public void setReceive_rule(String receive_rule) {
		this.receive_rule = receive_rule;
	}

	public Timestamp getCreate_time() {
		return create_time;
	}

	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}

}
