package cn.cecook.dao.system;

import cn.cecook.bean.system.DockAuthorizeInfo;

public interface DockAuthorizeInfoMapper {
    int deleteByPrimaryKey(Long id);

    int insert(DockAuthorizeInfo record);

    int insertSelective(DockAuthorizeInfo record);

    DockAuthorizeInfo selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(DockAuthorizeInfo record);

    int updateByPrimaryKey(DockAuthorizeInfo record);
}