package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.springframework.stereotype.Repository;

import cn.cecook.model.business.markting.BmSmsSend;
import cn.cecook.model.business.markting.BmSmsSendExample;

@Repository("bmSmsSendMapper")
public interface BmSmsSendMapper {

	int deleteByPrimaryKey(Long id);

	int insert(BmSmsSend record);

	int insertSelective(BmSmsSend record);

	List<BmSmsSend> selectByExample(BmSmsSendExample example);

	BmSmsSend selectByPrimaryKey(Long id);

	int updateByPrimaryKey(BmSmsSend record);

	List<BmSmsSend> getSmsRecordList(Map<String, Object> map);

	BmSmsSend getSmsRecordDetail(long id);
	
	int insetByBatch(Map<String,Object> params);
	//批量修改短信发送状态
	int batchUpdate(Map<String,Object> map);
	/**
	 * 
	* Title: countReceiveByCouponBatch
	* Description:统计注券批次成功到达的数量
	* @param couponBatchId
	* @return
	 */
	int countReceiveByCouponBatch(int couponBatchId);
}