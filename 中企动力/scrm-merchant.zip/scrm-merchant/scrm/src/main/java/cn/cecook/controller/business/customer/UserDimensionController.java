package cn.cecook.controller.business.customer;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.customer.BcUserDimension;
import cn.cecook.service.business.customer.IUserDimensionService;
import cn.cecook.uitls.AjaxJson;
import cn.cecook.uitls.StringUtils;

/**
 * 
 * @Title: CustomerDimensionController
 * @Package
 * @Description:
 * @author : ning
 * @date : 2017年5月26日
 * @version V1.0
 */
@Controller
@RequestMapping("/api/userDimension")
public class UserDimensionController {

    @Autowired
    private IUserDimensionService userDimensionService;
    
    /**
     * 添加客户接口
     * @return
     */
    @RequestMapping("/addUserDimension")
    @ResponseBody
    public AjaxJson addUserDimension(HttpServletRequest request) {
        AjaxJson j = new AjaxJson();
        BcUserDimension bcUserDimension = new BcUserDimension();
        String oldCustomerDay = request.getParameter("old_customer_day"); // 老用户天数
        String oldCustomerFrequency = request.getParameter("old_customer_frequency");// 老用户次数
        String newCustomerDay = request.getParameter("new_customer_day"); //新用户天数
        String newCustomerFrequency = request.getParameter("new_customer_frequency");//新用户次数
        String travelerDay = request.getParameter("traveler_day");// 过客天数
        String travelerFrequency = request.getParameter("traveler_frequency");// 过客次数
        String regularDay = request.getParameter("regular_day");// 常客天数
        String regularFrequency = request.getParameter("regular_frequency");//常客次数
        String loyalCustomerDay = request.getParameter("loyal_customer_day");//  忠实的客户天数
        String loyalCustomerFrequency = request.getParameter("loyal_customer_frequency");// 忠实的客户次数
        String mainForce = request.getParameter("main_force"); //主力客户
        String sCommonlyCustomer = request.getParameter("s_commonly_customer");// 一般客户最小值
        String bCommonlyCustomer = request.getParameter("b_commonly_customer");// 一般客户最大值
        String scatteredCustomer = request.getParameter("scattered_customer");// 零散客户
        String loseCustomer = request.getParameter("lose_customer");// 流失客户
        String userDimensionId = request.getParameter("userDimensionId");// 流失客户
        if(StringUtils.isNotEmpty(userDimensionId)){
            bcUserDimension.setId(Integer.parseInt(userDimensionId));
        }
        bcUserDimension.setCreateTime(new Date());
        bcUserDimension.setOldCustomerDay(oldCustomerDay);
        bcUserDimension.setOldCustomerFrequency(oldCustomerFrequency);
        bcUserDimension.setNewCustomerDay(newCustomerDay);
        bcUserDimension.setNewCustomerFrequency(newCustomerFrequency);
        bcUserDimension.setTravelerDay(travelerDay);
        bcUserDimension.setTravelerFrequency(travelerFrequency);
        bcUserDimension.setRegularDay(regularDay);
        bcUserDimension.setRegularFrequency(regularFrequency);
        bcUserDimension.setLoyalCustomerDay(loyalCustomerDay);
        bcUserDimension.setLoyalCustomerFrequency(loyalCustomerFrequency);
        bcUserDimension.setMainForce(mainForce);
        bcUserDimension.setsCommonlyCustomer(sCommonlyCustomer);
        bcUserDimension.setbCommonlyCustomer(bCommonlyCustomer);
        bcUserDimension.setScatteredCustomer(scatteredCustomer);
        bcUserDimension.setLoseCustomer(loseCustomer);
        int count = userDimensionService.addOrUpdateUserDimension(bcUserDimension);
        if (count == 1) {
            j.setError_msg("操作成功");
        } else {
            j.setError_code(1);
            j.setError_msg("操作失败");
        }
        return j;
    }
    
    /**
     * 获取维度信息
     * @param request
     * @return
     */
    @ResponseBody
    @RequestMapping("getUserDimension")
    public String getUserDimension(HttpServletRequest request){
        JsonObject j = new JsonObject();
        Gson g = new Gson();
        JsonParser jsonParser = new JsonParser();
        BcUserDimension bcUserDimension = userDimensionService.getUserDimension();
        if(bcUserDimension == null){
            j.addProperty("bcUserDimension", "");
        }else{
            j.add("bcUserDimension", jsonParser.parse(g.toJson(bcUserDimension)));
        }
        return j.toString();
    }
}
