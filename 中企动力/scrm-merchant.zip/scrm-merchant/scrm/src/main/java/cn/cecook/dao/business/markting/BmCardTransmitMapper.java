package cn.cecook.dao.business.markting;

import cn.cecook.model.business.markting.BmCardTransmit;

public interface BmCardTransmitMapper {


    int deleteByPrimaryKey(Long id);

    int insert(BmCardTransmit record);

    int insertSelective(BmCardTransmit record);

    BmCardTransmit selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BmCardTransmit record);

    int updateByPrimaryKey(BmCardTransmit record);
}