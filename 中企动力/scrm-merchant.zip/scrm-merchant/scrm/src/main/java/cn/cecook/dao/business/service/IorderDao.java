package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;
import org.apache.ibatis.annotations.Update;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.Order;


/**
 * @作者 马杰
 * @时间 2017年5月13日-下午4:47:46
 * @介绍 dao方法接口
 */
@Repository
public interface IorderDao {
    /**
     * 查询(可分页)
     *
     * @param order 条件模糊查询
     * @return
     */
    public List<Order> findAll(Order order);

    /**
     * 查询(可分页)
     *
     * @param order 条件模糊查询
     * @return
     */
    public List<Order> findAllByTag(Order order);

    /**
     * 获取记录总数
     *
     * @param order 多条件获取
     * @return
     */
    public Integer getCount(Order order);

    /**
     * @explain 查询录入体质
     * @author MAJIE
     * @date 2017年10月24日 上午12:47:21
     */
    public Integer getTagCount(Order order);

    /**
     * @explain 查询录入会员
     * @author MAJIE
     * @date 2017年10月24日 上午12:47:21
     */
    public int getUserCount(Order order);

    /**
     * 添加
     *
     * @param order
     * @return
     */
    public int addOrder(Order order);
    /**
     * 统计订单数量
     * @return
     */
    /*public Integer getOrderCount(Order order);*/

    /**
     * 删除信息
     *
     * @param id
     * @return
     */
    public int delete(int id);

    /**
     * 查询单条记录
     *
     * @param order
     * @return
     */
    public Order findOne(Order order);

    /**
     * 修改信息
     *
     * @return
     */
    public int update(Order order);

    /**
     * 根据posId查询
     *
     * @param order
     * @return
     */
    public Order findPosId(Order order);

    /**
     * 从上次处理的位置开始查询
     *
     * @param order
     * @return
     */
    public List<Order> findOrderByBeforeId(Order order);

    /**
     * Title: getMedicineListByOrderId
     * Description:根据orderId 查询药品购买列表
     *
     * @param id
     * @param tenantId
     * @return
     */
    List<Map<String, Object>> getMedicinesByOrderId(@Param("id") int id, @Param("tenantId") String tenantId);

    @Select("select id,card_no cardNo from ser_order_info where trade_no = #{tradeNo}")
    Order findOrderByTradeNo(@Param("tradeNo") String tradeNo);

    @Update("update ser_order_info set cancel_id = #{cancelId},cancel_time = #{cancelTime},status=2 where id = #{id}")
    int cancel(Order order);
}
