package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmCoupon;

public interface TempMapper {

	
	List<Map<String,Object>> ListTempCustomer();
	
	int insertCoupon(BmCoupon bmCoupon);
}
