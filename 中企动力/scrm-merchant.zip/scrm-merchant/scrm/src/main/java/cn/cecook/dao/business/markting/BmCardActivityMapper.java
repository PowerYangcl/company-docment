package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmCardActivity;

public interface BmCardActivityMapper {


    int deleteByPrimaryKey(Integer id);

    int insertSelective(BmCardActivity record);

    BmCardActivity selectByPrimaryKey(Integer id);
    List<BmCardActivity> selectByCardIdActivityId(@Param(value="card_id") Integer card_id,@Param(value="activity_id") Integer activity_id);
    int updateByPrimaryKeySelective(BmCardActivity record);
    
    List<Map<String,Object>> queryCardActivityList(long id);

    List<Map<String,Object>> queryCardOperationList(long id);
    
    
    int updateByCardId(Map<String, Object> map);
}