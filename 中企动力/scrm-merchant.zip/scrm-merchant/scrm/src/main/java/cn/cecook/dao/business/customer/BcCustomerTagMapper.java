package cn.cecook.dao.business.customer;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcCustomerTag;
import cn.cecook.model.business.customer.BcCustomerTagExample;

/**
 * 
* @explain 客户标签表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcCustomerTagMapper {
    int countByExample(BcCustomerTagExample example);

    int deleteByExample(BcCustomerTagExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcCustomerTag record);

    int insertSelective(BcCustomerTag record);

    List<BcCustomerTag> selectByExample(BcCustomerTagExample example);

    BcCustomerTag selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcCustomerTag record, @Param("example") BcCustomerTagExample example);

    int updateByExample(@Param("record") BcCustomerTag record, @Param("example") BcCustomerTagExample example);

    int updateByPrimaryKeySelective(BcCustomerTag record);

    int updateByPrimaryKey(BcCustomerTag record);
}