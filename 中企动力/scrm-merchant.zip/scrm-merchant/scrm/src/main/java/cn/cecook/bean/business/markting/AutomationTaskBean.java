package cn.cecook.bean.business.markting;

import cn.cecook.model.business.automation.ActionType;
import cn.cecook.model.business.automation.AutomationTaskRule;
import cn.cecook.model.business.automation.TaskOrder;

/**
 * 自动化营销任务bean
 * @author majie
 *
 * 2018年1月23日-下午2:34:20
 */
public class AutomationTaskBean {
	//TaskId
	private Integer taskId;
	//执行时间 
	private String date;
	//执行动作类型
	private String actionType;
	//执行动作id
	private Integer actionId;
	//执行条件
	private AutomationTaskRule automationTaskRule;
	//执行顺序
	private String taskOrder;
	public Integer getTaskId() {
		return taskId;
	}
	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}
	public String getDate() {
		return date;
	}
	public void setDate(String date) {
		this.date = date;
	}
	
	public String getActionType() {
		return actionType;
	}
	public void setActionType(String actionType) {
		this.actionType = actionType;
	}
	public Integer getActionId() {
		return actionId;
	}
	public void setActionId(Integer actionId) {
		this.actionId = actionId;
	}
	public AutomationTaskRule getAutomationTaskRule() {
		return automationTaskRule;
	}
	public void setAutomationTaskRule(AutomationTaskRule automationTaskRule) {
		this.automationTaskRule = automationTaskRule;
	}
	
	public String getTaskOrder() {
		return taskOrder;
	}
	public void setTaskOrder(String taskOrder) {
		this.taskOrder = taskOrder;
	}
	@Override
	public String toString() {
		return "AutomationTaskBean [taskId=" + taskId + ", date=" + date + ", actionType=" + actionType + ", actionId="
				+ actionId + ", automationTaskRule=" + automationTaskRule + ", taskOrder=" + taskOrder + "]";
	}

}
