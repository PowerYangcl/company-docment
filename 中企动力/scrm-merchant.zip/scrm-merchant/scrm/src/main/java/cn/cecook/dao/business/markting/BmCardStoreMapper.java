package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmCardStore;

public interface BmCardStoreMapper {

    int deleteByPrimaryKey(Long id);

    int insertSelective(BmCardStore record);

    List<Map<String,Object>> selectByPrimaryKey(Long id);

    int updateByPrimaryKeySelective(BmCardStore record);
    //通过card_id查询store_id
    BmCardStore getDetailByCardId(int cardId);

}