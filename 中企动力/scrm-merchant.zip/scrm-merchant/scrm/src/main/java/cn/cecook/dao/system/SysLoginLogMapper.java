package cn.cecook.dao.system;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.apache.ibatis.annotations.Select;

import cn.cecook.bean.system.AuthorityModel;
import cn.cecook.model.system.SysLoginLog;
import cn.cecook.model.system.SysLoginLogExample;

/**
 * @author wschenyongyin
 * @explain 登录日志表
 * @date 2017年5月22日
 */
public interface SysLoginLogMapper {
    int countByExample(SysLoginLogExample example);

    int deleteByExample(SysLoginLogExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysLoginLog record);

    int insertSelective(SysLoginLog record);

    List<SysLoginLog> selectByExample(SysLoginLogExample example);

    SysLoginLog selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysLoginLog record, @Param("example") SysLoginLogExample example);

    int updateByExample(@Param("record") SysLoginLog record, @Param("example") SysLoginLogExample example);

    int updateByPrimaryKeySelective(SysLoginLog record);

    int updateByPrimaryKey(SysLoginLog record);

    void updateOutTimeById(Long logId);

    @Select("SELECT b.id,b.menu_type AS menuType,b.menu_icon AS menuIcon,b.menu_desc AS menuDesc,b.parent_code AS parentCode,a.authority_name AS NAME,a.authority_name_en AS nameEn,b.url FROM sys_role_authority a,sys_authority b WHERE a.role_id IN (SELECT role_id FROM sys_user_role WHERE user_id=#{uid} UNION SELECT crm_role_id FROM dock_product_synch WHERE user_id=#{uid}) AND a.authority_id=b.id AND b.is_deleted=0 AND a.is_deleted = 0 AND a.tenant_id =#{tenantId}  ORDER BY b.parent_code,b.weight")
//    @Select("SELECT b.id , b.parent_code AS parentCode , a.authority_name AS NAME , a.authority_name_en AS nameEn , b.url FROM sys_role_authority a , sys_authority_copy b WHERE a.authority_id = b.id AND b.is_deleted = 0 GROUP BY id ORDER BY b.parent_code")
    List<AuthorityModel> getMenuListByUid(@Param("uid") String uid,@Param("tenantId") String tenantId);
    /**
     * 用于获取全部二级菜单列表
     * @param keyWord
     * @return
     */
	List<Map<String, Object>> getMenuTwos(@Param("keyWord") String keyWord,@Param("tenantId") String tenantId,@Param("uid") String uid);
}