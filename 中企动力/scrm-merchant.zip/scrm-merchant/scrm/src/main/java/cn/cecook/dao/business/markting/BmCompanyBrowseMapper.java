package cn.cecook.dao.business.markting;

import cn.cecook.model.business.markting.BmCompanyBrowse;

public interface BmCompanyBrowseMapper {
    int insertSelective(BmCompanyBrowse record);

    BmCompanyBrowse selectByPrimaryKey(Long id);
}