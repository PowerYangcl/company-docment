package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.sql.Timestamp;

@Component
public class SmartActivityBean implements Serializable{
	private Long id;
	private String uuid;
	private String tenant_id;
	private int is_deleted;
	private Long create_id;
	private Timestamp create_time;
	private String order_code;
	private Timestamp delete_time;
	private String remarks;
	private String attachment;
	private String name;
	private String description;
	private String web_url;
	private String head_pic;
	private String pic_url;
	private String coupon_send_type;
	private String start_date;
	private int effective_day;
	private int effective_status;
	private int coupon_number;
	private String tag;
	private String tag_defined;
	private String title;
	private String content;
	private String pic;
	private int status;
	private int check_status;
	private String check_descrption;
	private String overview;
	private String share_channel;
	private int browse_number;
	private int submit_numer;
	private String ratio;
private int transmitNum;
	private String send_object;
	private String send_time;
	private String send_type;
	private int behavior_rule;
	private String receive_rule;
	private int type;
	private int write_off_num;
	private double consumption_amount;
	private Long rule_id;
	private String commit_info;
	private int transmit_rule;
	private String weixin_qrcode;
	private String weibo_qrcode;
    private String background_pic;
	private String background_music;
	private String protrait_tag;
	private String button_text;
	private String button_css;
	private String theme_info;
	private String theme_info_color;
	private String text_info_color;
	private String bak1;
	private String bak2;
	private String detail_rule;
	private Object extendField;
	private String activity_restrict;
	private String sms_content;
	private String coupon_name;
	private String face_value;
	private Timestamp start_time;
	private Timestamp end_time;
	private int coupon_id;

	
	public Timestamp getStart_time() {
		return start_time;
	}
	public void setStart_time(Timestamp start_time) {
		this.start_time = start_time;
	}
	public Timestamp getEnd_time() {
		return end_time;
	}
	public void setEnd_time(Timestamp end_time) {
		this.end_time = end_time;
	}
	public int getCoupon_id() {
		return coupon_id;
	}
	public void setCoupon_id(int coupon_id) {
		this.coupon_id = coupon_id;
	}
	public String getCoupon_name() {
		return coupon_name;
	}
	public void setCoupon_name(String coupon_name) {
		this.coupon_name = coupon_name;
	}
	public String getFace_value() {
		return face_value;
	}
	public void setFace_value(String face_value) {
		this.face_value = face_value;
	}
	public String getSms_content() {
		return sms_content;
	}
	public void setSms_content(String sms_content) {
		this.sms_content = sms_content;
	}
	public Object getExtendField() {
		return extendField;
	}
	public void setExtendField(Object extendField) {
		this.extendField = extendField;
	}
	public String getActivity_restrict() {
		return activity_restrict;
	}
	public void setActivity_restrict(String activity_restrict) {
		this.activity_restrict = activity_restrict;
	}
	public String getDetail_rule() {
		return detail_rule;
	}
	public void setDetail_rule(String detail_rule) {
		this.detail_rule = detail_rule;
	}
	public int getTransmitNum() {
		return transmitNum;
	}
	public void setTransmitNum(int transmitNum) {
		this.transmitNum = transmitNum;
	}
	public String getBackground_pic() {
		return background_pic;
	}
	public void setBackground_pic(String background_pic) {
		this.background_pic = background_pic;
	}
	public String getBackground_music() {
		return background_music;
	}
	public void setBackground_music(String background_music) {
		this.background_music = background_music;
	}
	public String getProtrait_tag() {
		return protrait_tag;
	}
	public void setProtrait_tag(String protrait_tag) {
		this.protrait_tag = protrait_tag;
	}
	public String getButton_text() {
		return button_text;
	}
	public void setButton_text(String button_text) {
		this.button_text = button_text;
	}
	public String getButton_css() {
		return button_css;
	}
	public void setButton_css(String button_css) {
		this.button_css = button_css;
	}
	public String getTheme_info() {
		return theme_info;
	}
	public void setTheme_info(String theme_info) {
		this.theme_info = theme_info;
	}
	public String getTheme_info_color() {
		return theme_info_color;
	}
	public void setTheme_info_color(String theme_info_color) {
		this.theme_info_color = theme_info_color;
	}
	public String getText_info_color() {
		return text_info_color;
	}
	public void setText_info_color(String text_info_color) {
		this.text_info_color = text_info_color;
	}
	public String getBak1() {
		return bak1;
	}
	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}
	public String getBak2() {
		return bak2;
	}
	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}
	public String getWeixin_qrcode() {
		return weixin_qrcode;
	}
	public void setWeixin_qrcode(String weixin_qrcode) {
		this.weixin_qrcode = weixin_qrcode;
	}
	public String getWeibo_qrcode() {
		return weibo_qrcode;
	}
	public void setWeibo_qrcode(String weibo_qrcode) {
		this.weibo_qrcode = weibo_qrcode;
	}
	public int getTransmit_rule() {
		return transmit_rule;
	}
	public void setTransmit_rule(int transmit_rule) {
		this.transmit_rule = transmit_rule;
	}
	public String getCommit_info() {
		return commit_info;
	}
	public void setCommit_info(String commit_info) {
		this.commit_info = commit_info;
	}
	public Long getRule_id() {
		return rule_id;
	}
	public void setRule_id(Long rule_id) {
		this.rule_id = rule_id;
	}
	public int getWrite_off_num() {
		return write_off_num;
	}
	public void setWrite_off_num(int write_off_num) {
		this.write_off_num = write_off_num;
	}
	public double getConsumption_amount() {
		return consumption_amount;
	}
	public void setConsumption_amount(double consumption_amount) {
		this.consumption_amount = consumption_amount;
	}
	public int getType() {
		return type;
	}
	public void setType(int type) {
		this.type = type;
	}
	public Long getId() {
		return id;
	}
	public void setId(Long id) {
		this.id = id;
	}
	public String getUuid() {
		return uuid;
	}
	public void setUuid(String uuid) {
		this.uuid = uuid;
	}
	public String getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}
	public int getIs_deleted() {
		return is_deleted;
	}
	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}
	public Long getCreate_id() {
		return create_id;
	}
	public void setCreate_id(Long create_id) {
		this.create_id = create_id;
	}
	public Timestamp getCreate_time() {
		return create_time;
	}
	public void setCreate_time(Timestamp create_time) {
		this.create_time = create_time;
	}
	public String getOrder_code() {
		return order_code;
	}
	public void setOrder_code(String order_code) {
		this.order_code = order_code;
	}
	public Timestamp getDelete_time() {
		return delete_time;
	}
	public void setDelete_time(Timestamp delete_time) {
		this.delete_time = delete_time;
	}
	public String getRemarks() {
		return remarks;
	}
	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}
	public String getAttachment() {
		return attachment;
	}
	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	public String getWeb_url() {
		return web_url;
	}
	public void setWeb_url(String web_url) {
		this.web_url = web_url;
	}
	public String getHead_pic() {
		return head_pic;
	}
	public void setHead_pic(String head_pic) {
		this.head_pic = head_pic;
	}
	public String getPic_url() {
		return pic_url;
	}
	public void setPic_url(String pic_url) {
		this.pic_url = pic_url;
	}
	public String getCoupon_send_type() {
		return coupon_send_type;
	}
	public void setCoupon_send_type(String coupon_send_type) {
		this.coupon_send_type = coupon_send_type;
	}
	public String getStart_date() {
		return start_date;
	}
	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}
	public int getEffective_day() {
		return effective_day;
	}
	public void setEffective_day(int effective_day) {
		this.effective_day = effective_day;
	}
	public int getEffective_status() {
		return effective_status;
	}
	public void setEffective_status(int effective_status) {
		this.effective_status = effective_status;
	}
	public int getCoupon_number() {
		return coupon_number;
	}
	public void setCoupon_number(int coupon_number) {
		this.coupon_number = coupon_number;
	}
	public String getTag() {
		return tag;
	}
	public void setTag(String tag) {
		this.tag = tag;
	}
	public String getTag_defined() {
		return tag_defined;
	}
	public void setTag_defined(String tag_defined) {
		this.tag_defined = tag_defined;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getPic() {
		return pic;
	}
	public void setPic(String pic) {
		this.pic = pic;
	}
	public int getStatus() {
		return status;
	}
	public void setStatus(int status) {
		this.status = status;
	}
	public int getCheck_status() {
		return check_status;
	}
	public void setCheck_status(int check_status) {
		this.check_status = check_status;
	}
	public String getCheck_descrption() {
		return check_descrption;
	}
	public void setCheck_descrption(String check_descrption) {
		this.check_descrption = check_descrption;
	}
	public String getOverview() {
		return overview;
	}
	public void setOverview(String overview) {
		this.overview = overview;
	}
	public String getShare_channel() {
		return share_channel;
	}
	public void setShare_channel(String share_channel) {
		this.share_channel = share_channel;
	}

	public int getBrowse_number() {
		return browse_number;
	}
	public void setBrowse_number(int browse_number) {
		this.browse_number = browse_number;
	}
	public int getSubmit_numer() {
		return submit_numer;
	}
	public void setSubmit_numer(int submit_numer) {
		this.submit_numer = submit_numer;
	}
	public String getRatio() {
		return ratio;
	}
	public void setRatio(String ratio) {
		this.ratio = ratio;
	}
	public String getSend_object() {
		return send_object;
	}
	public void setSend_object(String send_object) {
		this.send_object = send_object;
	}
	public String getSend_time() {
		return send_time;
	}
	public void setSend_time(String send_time) {
		this.send_time = send_time;
	}
	public String getSend_type() {
		return send_type;
	}
	public void setSend_type(String send_type) {
		this.send_type = send_type;
	}
	public int getBehavior_rule() {
		return behavior_rule;
	}
	public void setBehavior_rule(int behavior_rule) {
		this.behavior_rule = behavior_rule;
	}
	public String getReceive_rule() {
		return receive_rule;
	}
	public void setReceive_rule(String receive_rule) {
		this.receive_rule = receive_rule;
	}
	@Override
	public String toString() {
		return "SmartActivityBean [id=" + id + ", uuid=" + uuid
				+ ", tenant_id=" + tenant_id + ", is_deleted=" + is_deleted
				+ ", create_id=" + create_id + ", create_time=" + create_time
				+ ", order_code=" + order_code + ", delete_time=" + delete_time
				+ ", remarks=" + remarks + ", attachment=" + attachment
				+ ", name=" + name + ", description=" + description
				+ ", web_url=" + web_url + ", head_pic=" + head_pic
				+ ", pic_url=" + pic_url + ", coupon_send_type="
				+ coupon_send_type + ", start_date=" + start_date
				+ ", effective_day=" + effective_day + ", effective_status="
				+ effective_status + ", coupon_number=" + coupon_number
				+ ", tag=" + tag + ", tag_defined=" + tag_defined + ", title="
				+ title + ", content=" + content + ", pic=" + pic + ", status="
				+ status + ", check_status=" + check_status
				+ ", check_descrption=" + check_descrption + ", overview="
				+ overview + ", share_channel=" + share_channel
				+ ", browse_number=" + browse_number + ", submit_numer="
				+ submit_numer + ", ratio=" + ratio + ", send_object="
				+ "ss" + ", send_time=" + send_time + ", send_type="
				+ send_type + ", behavior_rule=" + behavior_rule
				+ ", receive_rule=" + receive_rule + "]";
	}
	
	
	

}
