package cn.cecook.intercept;

import cn.cecook.dao.business.markting.SysTenantDatabaseMapper;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.SpringApplicationContextHolderUtil;
import cn.cecook.uitls.StringUtils;
import cn.cecook.uitls.UUIDHex;
import org.apache.ibatis.executor.Executor;
import org.apache.ibatis.executor.statement.RoutingStatementHandler;
import org.apache.ibatis.executor.statement.StatementHandler;
import org.apache.ibatis.mapping.BoundSql;
import org.apache.ibatis.mapping.MappedStatement;
import org.apache.ibatis.plugin.*;
import org.apache.ibatis.session.ResultHandler;
import org.apache.ibatis.session.RowBounds;

import java.sql.Connection;
import java.util.Properties;


@Intercepts({
        @Signature(method = "query", type = Executor.class, args = {
                MappedStatement.class, Object.class, RowBounds.class,
                ResultHandler.class}),
        @Signature(method = "prepare", type = StatementHandler.class, args = {Connection.class})})
public class MyInterceptor implements Interceptor {

    private SysTenantDatabaseMapper tenantDao;
    public static String tenantId = "";

    public Object intercept(Invocation invocation) throws Throwable {
        String schema = MyCatFilter.getSchema();
        String tenant_id = MyCatFilter.getTenant_Id();
        String scrm_public_schema = ConfigUtil.SCHEMA_NAME;

        // System.out.println("拦截器当前线程ID:" + Thread.currentThread().getId());
        if (invocation.getTarget() instanceof RoutingStatementHandler) {
            RoutingStatementHandler statementHandler = (RoutingStatementHandler) invocation
                    .getTarget();
            StatementHandler delegate = (StatementHandler) ReflectHelper
                    .getFieldValue(statementHandler, "delegate");
            BoundSql boundSql = delegate.getBoundSql();
            Object obj = boundSql.getParameterObject();
            // 通过反射获取delegate父类BaseStatementHandler的mappedStatement属性
            MappedStatement mappedStatement = (MappedStatement) ReflectHelper
                    .getFieldValue(delegate, "mappedStatement");
            // 拦截到的prepare方法参数是一个Connection对象
            Connection connection = (Connection) invocation.getArgs()[0];
            // 获取当前要执行的Sql语句，也就是我们直接在Mapper映射语句中写的Sql语句
            String sql = boundSql.getSql();
            // 拦截insert语句统一加入租户id和uuid
//			System.out.println("拦截之前"+sql);
            if (checkSqlHasCecook(sql)) {
                // 根据租户id查询schema逻辑数据库
                String splitTenantId[] = sql.split("cecook2017");
                String tempSchema = null;
                sql = splitTenantId[0];
                if (splitTenantId.length > 1) {
                    String tempTenantId = splitTenantId[1];
                    tenantDao = (SysTenantDatabaseMapper) SpringApplicationContextHolderUtil
                            .getSpringBean("sysTenantDatabaseMapper");
                    tempSchema = tenantDao.getTenantSchema(tempTenantId);
                }
                if (tempSchema != null) {
                    schema = tempSchema;
                } else if (schema == null) {
                    schema = scrm_public_schema;
                }
            } else {
                if (sql.startsWith("insert")) {
                    String uuid = UUIDHex.getInstance().generate();
                    uuid = '"' + uuid + '"';
                    String[] sqlitSQL = sql.split("\\)");
                    String column = sqlitSQL[0];
                    String values = sqlitSQL[sqlitSQL.length - 1];
                    int state = sql.indexOf("tenant_id");
                    int state2 = sql.indexOf("uuid");

                    if (!StringUtils.isEmpty(tenant_id) && state == -1) {
                        tenant_id = '"' + tenant_id + '"';
                        column = column + ",uuid,tenant_id";
                        values = values + "," + uuid + "," + tenant_id + "";
                    } else if (state2 == -1) {
                        column = column + ",uuid";
                        values = values + "," + uuid + "";
                    }
                    sqlitSQL[0] = column;
                    sqlitSQL[sqlitSQL.length - 1] = values;
                    sql = StringUtils.join(sqlitSQL, ")") + ")";
                    // System.out.println(sql);
                }
            }
            // 检查sql语句是否涉及公有库操作 加上mycat註解
            String NowSql = "";
            if (checkSql(sql)) {
                NowSql = "/*!mycat:schema = " + scrm_public_schema + " */  "
                        + sql;
            } else {
                NowSql = "/*!mycat:schema = " + schema + " */  " + sql;
            }
//			 NowSql = "/*!mycat:schema = " + schema + " */  " + sql;
            System.out.println("拦截之后" + NowSql.replaceAll("[\\t\\n\\r]", " ").replaceAll(" +", " "));
            // 利用反射设置当前BoundSql对应的sql属性为我们建立好的分页Sql语句
            ReflectHelper.setFieldValue(boundSql, "sql", NowSql);
        } else {
            // System.out.println("-------------------->");
        }
        return invocation.proceed();
    }

    // 检查sql语句是否涉及公有库操作
    private static boolean checkSql(String sql) {
        for (int i = 0; i < ConfigUtil.scrm_public.length; i++) {
            int state = sql.indexOf(ConfigUtil.scrm_public[i]);
            if (state != -1) {
                return true;
            }
        }
        return false;
    }

    public Object plugin(Object target) {
        return Plugin.wrap(target, this);
    }

    public void setProperties(Properties properties) {
    }


    private static boolean checkSqlHasCecook(String sql) {
        if (sql.indexOf("cecook2017") != -1) {
            return true;
        } else {
            return false;
        }
    }

}