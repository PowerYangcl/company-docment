/**
 * @Title: BmCoupon.java
 * @Description: 优惠券（券码）
 * @author peng
 * @date 2107/5/23 
 * @version V1.0
 */
package cn.cecook.model.business.markting;

import org.springframework.stereotype.Component;

import cn.cecook.uitls.DateUtils;

import java.util.Date;

/**
 * 优惠券（券码）
 * @author peng
 *
 */
@Component
public class BmCoupon {
    
    //id
    private Integer id;

    //uuid
    private String uuid;

    //租户ID
    private String tenantId;

    //删除标记
    private Integer isDeleted;

    //创建人ID
    private Long createId;

    //创建时间
    private Date createTime;

    //排序标示
    private String orderCode;

    //删除时间
    private Date deleteTime;

    //备注
    private String remarks;

    //附件
    private String attachment;

    //描述
    private String describe;

    //expiry_date
    private Date expiryDate;

    //面值
    private Integer faceValue;

    //面值类型
    private String faceValueType;

    //类型
    private Integer type;

    //使用状态
    private Integer isUsed;

    //使用时间
    private Date usingTime;

    //备用字段
    private String bak1;

    //备用字段
    private String bak2;

    //备用字段
    private String bak3;

    //备用字段
    private String bak4;

    //备用字段
    private String bak5;

    //活动id
    private Long activityId;

    //活动名称
    private String activityName;

    //顾客姓名
    private String customerName;

    //顾客id
    private Long customerId;

    //顾客电话
    private String customerPhone;

    //通过的方式
    private String receiveWay;
    
    //优惠券码
    private String couponCode;
    
    //日期转换
    private String cTime;
    
    //优惠券名
    private String couponName;
    //发送状态 0表示未发送  1表示已发送
    private int send_status;
    
    private int activity_type;
    
    private String sms_batch;
    private int couponId;
    
    private int is_used;
    
    private Integer limit_price;
    //名片id
    private int card_id;
    
    private int channel_type;
    
    private int coupon_batch;
    
    
    private String longitude;
   
    private String latitude;

    private String province;
    
    private String city;
    
    private String district;
    
    private Integer taskId;
    
    private Integer couponModelType;
    
    

	public Integer getCouponModelType() {
		return couponModelType;
	}

	public void setCouponModelType(Integer couponModelType) {
		this.couponModelType = couponModelType;
	}

	public Integer getTaskId() {
		return taskId;
	}

	public void setTaskId(Integer taskId) {
		this.taskId = taskId;
	}

	public String getLongitude() {
		return longitude;
	}

	public void setLongitude(String longitude) {
		this.longitude = longitude;
	}

	public String getLatitude() {
		return latitude;
	}

	public void setLatitude(String latitude) {
		this.latitude = latitude;
	}

	public String getProvince() {
		return province;
	}

	public void setProvince(String province) {
		this.province = province;
	}

	public String getCity() {
		return city;
	}

	public void setCity(String city) {
		this.city = city;
	}

	public String getDistrict() {
		return district;
	}

	public void setDistrict(String district) {
		this.district = district;
	}

	public int getCoupon_batch() {
		return coupon_batch;
	}

	public void setCoupon_batch(int coupon_batch) {
		this.coupon_batch = coupon_batch;
	}

	public int getChannel_type() {
		return channel_type;
	}

	public void setChannel_type(int channel_type) {
		this.channel_type = channel_type;
	}

	public int getCard_id() {
		return card_id;
	}

	public void setCard_id(int card_id) {
		this.card_id = card_id;
	}

	public int getIs_used() {
		return is_used;
	}

	public void setIs_used(int is_used) {
		this.is_used = is_used;
	}


	public int getCouponId() {
		return couponId;
	}

	public void setCouponId(int couponId) {
		this.couponId = couponId;
	}

	public String getSms_batch() {
		return sms_batch;
	}

	public void setSms_batch(String sms_batch) {
		this.sms_batch = sms_batch;
	}

	public int getActivity_type() {
		return activity_type;
	}

	public void setActivity_type(int activity_type) {
		this.activity_type = activity_type;
	}

	public int getSend_status() {
		return send_status;
	}

	public void setSend_status(int send_status) {
		this.send_status = send_status;
	}

	public void setcTime(String cTime) {
		this.cTime = cTime;
	}

	public String getCouponName() {
        return couponName;
    }

    public void setCouponName(String couponName) {
        this.couponName = couponName;
    }

    public String getcTime() {
        return cTime;
    }

    public Integer getId() {
        return id;
    }

    public void setId(Integer id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId == null ? null : tenantId.trim();
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.cTime = DateUtils.parseDateFormat(createTime);
        this.createTime = createTime;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode == null ? null : orderCode.trim();
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment == null ? null : attachment.trim();
    }

    public String getDescribe() {
        return describe;
    }

    public void setDescribe(String describe) {
        this.describe = describe == null ? null : describe.trim();
    }

    public Date getExpiryDate() {
        return expiryDate;
    }

    public void setExpiryDate(Date expiryDate) {
        this.expiryDate = expiryDate;
    }


    public Integer getFaceValue() {
		return faceValue;
	}

	public void setFaceValue(Integer faceValue) {
		this.faceValue = faceValue;
	}

	public Integer getLimit_price() {
		return limit_price;
	}

	public void setLimit_price(Integer limit_price) {
		this.limit_price = limit_price;
	}

	public String getFaceValueType() {
        return faceValueType;
    }

    public void setFaceValueType(String faceValueType) {
        this.faceValueType = faceValueType == null ? null : faceValueType.trim();
    }

    public Integer getType() {
        return type;
    }

    public void setType(Integer type) {
        this.type = type;
    }

    public Integer getIsUsed() {
        return isUsed;
    }

    public void setIsUsed(Integer isUsed) {
        this.isUsed = isUsed;
    }

    public Date getUsingTime() {
        return usingTime;
    }

    public void setUsingTime(Date usingTime) {
        this.usingTime = usingTime;
    }

    public String getBak1() {
        return bak1;
    }

    public void setBak1(String bak1) {
        this.bak1 = bak1 == null ? null : bak1.trim();
    }

    public String getBak2() {
        return bak2;
    }

    public void setBak2(String bak2) {
        this.bak2 = bak2 == null ? null : bak2.trim();
    }

    public String getBak3() {
        return bak3;
    }

    public void setBak3(String bak3) {
        this.bak3 = bak3 == null ? null : bak3.trim();
    }

    public String getBak4() {
        return bak4;
    }

    public void setBak4(String bak4) {
        this.bak4 = bak4 == null ? null : bak4.trim();
    }

    public String getBak5() {
        return bak5;
    }

    public void setBak5(String bak5) {
        this.bak5 = bak5 == null ? null : bak5.trim();
    }

    public Long getActivityId() {
        return activityId;
    }

    public void setActivityId(Long activityId) {
        this.activityId = activityId;
    }

    public String getActivityName() {
        return activityName;
    }

    public void setActivityName(String activityName) {
        this.activityName = activityName == null ? null : activityName.trim();
    }

    public String getCustomerName() {
        return customerName;
    }

    public void setCustomerName(String customerName) {
        this.customerName = customerName == null ? null : customerName.trim();
    }

    public Long getCustomerId() {
        return customerId;
    }

    public void setCustomerId(Long customerId) {
        this.customerId = customerId;
    }

    public String getCustomerPhone() {
        return customerPhone;
    }

    public void setCustomerPhone(String customerPhone) {
        this.customerPhone = customerPhone == null ? null : customerPhone.trim();
    }

    public String getReceiveWay() {
        return receiveWay;
    }

    public void setReceiveWay(String receiveWay) {
        this.receiveWay = receiveWay == null ? null : receiveWay.trim();
    }

    public String getCouponCode() {
        return couponCode;
    }

    public void setCouponCode(String couponCode) {
        this.couponCode = couponCode ;
    }

    @Override
    public String toString() {
        return "BmCoupon [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
                        + ", createId=" + createId + ", createTime=" + createTime + ", orderCode=" + orderCode
                        + ", deleteTime=" + deleteTime + ", remarks=" + remarks + ", attachment=" + attachment
                        + ", describe=" + describe + ", expiryDate=" + expiryDate + ", faceValue=" + faceValue
                        + ", faceValueType=" + faceValueType + ", type=" + type + ", isUsed=" + isUsed + ", usingTime="
                        + usingTime + ", bak1=" + bak1 + ", bak2=" + bak2 + ", bak3=" + bak3 + ", bak4=" + bak4
                        + ", bak5=" + bak5 + ", activityId=" + activityId + ", activityName=" + activityName
                        + ", customerName=" + customerName + ", customerId=" + customerId + ", customerPhone="
                        + customerPhone + ", receiveWay=" + receiveWay + ", couponCode=" + couponCode + ", cTime="
                        + cTime + ", couponName=" + couponName + "]";
    }

 
    
    
}