package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.bean.business.markting.ActivityModelDefinedBean;
import cn.cecook.model.business.markting.BmActivityModelDefined;
import cn.cecook.model.business.markting.BmActivityModelDefinedExample;

public interface BmActivityModelDefinedMapper {
    int countByExample(BmActivityModelDefinedExample example);

    int deleteByExample(BmActivityModelDefinedExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmActivityModelDefined record);

    int insertSelective(BmActivityModelDefined record);

    List<BmActivityModelDefined> selectByExample(BmActivityModelDefinedExample example);

    ActivityModelDefinedBean selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmActivityModelDefined record, @Param("example") BmActivityModelDefinedExample example);

    int updateByExample(@Param("record") BmActivityModelDefined record, @Param("example") BmActivityModelDefinedExample example);

    int updateByPrimaryKeySelective(BmActivityModelDefined record);

    int updateByPrimaryKey(BmActivityModelDefined record);
    
    List<ActivityModelDefinedBean> queryActivityModelDefinedList(Map<String, Object> map);

    int modelListCount(Map<String, Object> map);

    String queryName(String name);
    String queryUpdateName(Map<String, Object> map);

    int updateUseTime(int id);
    //锁定状态
    int lockStatus(long id);

    //锁定状态
    int unlockStatus(long id);
    //根据类型查询模板列表

    List<Map<String,Object>> queryModelByType(Map<String, Object> map);

    //更新url
    int insertWebUrl(Map<String, Object> map);
}