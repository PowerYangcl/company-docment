package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.ThirdPartyCoupon;
import lombok.experimental.PackagePrivate;

public interface ThirdpartyCouponMapper {
	int deleteByPrimaryKey(Integer id);

	int insert(ThirdPartyCoupon record);

	int insertSelective(ThirdPartyCoupon record);

	ThirdPartyCoupon selectByPrimaryKey(String tenantId, Integer id);

	int updateByPrimaryKeySelective(ThirdPartyCoupon record);


	int insertByBatch(@Param("tenantId") String tenantId,@Param("list") List<ThirdPartyCoupon> coupons);

	ThirdPartyCoupon getThirdPartyCouponCode(@Param("tenantId") String tenantId, @Param("modelId") Integer modelId);

	List<ThirdPartyCoupon> listThirdPartyCouponCode(@Param("tenantId") String tenantId,
			@Param("modelId") Integer modelId, @Param("num") int num);

	int deleteByModelId(@Param("modelId") Integer modelId);

	int countUsedCouponNumByModelId(@Param("tenantId") String tenantId, @Param("modelId") Integer modelId);

	int countUnUsedCouponNumByModelId(@Param("tenantId") String tenantId, @Param("modelId") Integer modelId);
	/**
	 * 
	* @Function: ThirdpartyCouponMapper.java
	* @Description: 根据id批量更新优惠券状态为
	*
	* @param:
	* @return：
	* @throws：
	*
	* @author: wsche
	* @date: 2018年3月20日 下午4:15:21
	 */
	int updateStatusByBatch(@Param("tenantId") String tenantId,@Param("list") List<Integer> ids,@Param("status") int status);

	
	int updateCouponStatusByCouponCodes(@Param("tenantId") String tenantId,@Param("list") List<String> couponCodes,@Param("status") int status);
}