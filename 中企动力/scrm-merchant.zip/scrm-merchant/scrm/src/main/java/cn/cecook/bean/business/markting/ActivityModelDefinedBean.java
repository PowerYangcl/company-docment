package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import cn.cecook.uitls.DateUtils;

import java.sql.Timestamp;

@Component
public class ActivityModelDefinedBean {

	// id
	private Integer id;

	// uuid
	private String uuid;

	// 租户ID
	private String tenant_id;

	private Timestamp create_time;

	private String name;

	private Timestamp update_time;
	private String update_name;
	private Timestamp use_time;
	private String create_username;

	private String updateTime;

	private String useTime;

	private String createTime;

	private int count;
	
	private String pic_url;
	
	private String text_info;
	private String button_text;
	private String button_css;
	private String collect_info;
	private String background_pic;

	private String weixin_qrcode;
	private String weibo_qrcode;
	private String background_music;
	private String type;
	private String thumbnail_pic;
	private String theme_info;
	private String theme_info_color;
	private String text_info_color;
	private String model_pic;
	
	private String bak1;
	private String bak2;
	private String bak3;
	private String bak4;
	private String bak5;
	
	private String remarks;
	
	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getTheme_info() {
		return theme_info;
	}

	public void setTheme_info(String theme_info) {
		this.theme_info = theme_info;
	}

	public String getTheme_info_color() {
		return theme_info_color;
	}

	public void setTheme_info_color(String theme_info_color) {
		this.theme_info_color = theme_info_color;
	}

	public String getText_info_color() {
		return text_info_color;
	}

	public void setText_info_color(String text_info_color) {
		this.text_info_color = text_info_color;
	}

	public String getModel_pic() {
		return model_pic;
	}

	public void setModel_pic(String model_pic) {
		this.model_pic = model_pic;
	}

	public String getThumbnail_pic() {
		return thumbnail_pic;
	}

	public void setThumbnail_pic(String thumbnail_pic) {
		this.thumbnail_pic = thumbnail_pic;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public String getBackground_music() {
		return background_music;
	}

	public void setBackground_music(String background_music) {
		this.background_music = background_music;
	}

	public String getBackground_pic() {
		return background_pic;
	}

	public void setBackground_pic(String background_pic) {
		this.background_pic = background_pic;
	}

	public String getWeixin_qrcode() {
		return weixin_qrcode;
	}

	public void setWeixin_qrcode(String weixin_qrcode) {
		this.weixin_qrcode = weixin_qrcode;
	}

	public String getWeibo_qrcode() {
		return weibo_qrcode;
	}

	public void setWeibo_qrcode(String weibo_qrcode) {
		this.weibo_qrcode = weibo_qrcode;
	}

	public String getText_info() {
		return text_info;
	}

	public void setText_info(String text_info) {
		this.text_info = text_info;
	}

	public String getButton_text() {
		return button_text;
	}

	public void setButton_text(String button_text) {
		this.button_text = button_text;
	}

	public String getButton_css() {
		return button_css;
	}

	public void setButton_css(String button_css) {
		this.button_css = button_css;
	}

	public String getCollect_info() {
		return collect_info;
	}

	public void setCollect_info(String collect_info) {
		this.collect_info = collect_info;
	}

	public Timestamp getCreate_time() {
		return create_time;
	}

	public Timestamp getUpdate_time() {
		return update_time;
	}

	public Timestamp getUse_time() {
		return use_time;
	}

	public void setUpdateTime(String updateTime) {
		this.updateTime = updateTime;
	}

	public void setUseTime(String useTime) {
		this.useTime = useTime;
	}

	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}


	public String getPic_url() {
		return pic_url;
	}

	public void setPic_url(String pic_url) {
		this.pic_url = pic_url;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid;
	}

	public String getTenant_id() {
		return tenant_id;
	}

	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}

	public void setCreate_time(Timestamp create_time) {
		this.createTime = DateUtils.parseTimestampFormat(create_time);
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public void setUpdate_time(Timestamp update_time) {
		this.updateTime = DateUtils.parseTimestampFormat(update_time);
	}

	public String getUpdate_name() {
		return update_name;
	}

	public void setUpdate_name(String update_name) {
		this.update_name = update_name;
	}

	public void setUse_time(Timestamp use_time) {
		this.useTime = DateUtils.parseTimestampFormat(use_time);
	}

	public String getCreate_username() {
		return create_username;
	}

	public void setCreate_username(String create_username) {
		this.create_username = create_username;
	}

	public int getCount() {
		return count;
	}

	public void setCount(int count) {
		this.count = count;
	}

	public String getUpdateTime() {
		return updateTime;
	}

	public String getUseTime() {
		return useTime;
	}

	public String getCreateTime() {
		return createTime;
	}

	public String getBak1() {
		return bak1;
	}

	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}

	public String getBak2() {
		return bak2;
	}

	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}

	public String getBak3() {
		return bak3;
	}

	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}

	public String getBak4() {
		return bak4;
	}

	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}

	public String getBak5() {
		return bak5;
	}

	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}

}
