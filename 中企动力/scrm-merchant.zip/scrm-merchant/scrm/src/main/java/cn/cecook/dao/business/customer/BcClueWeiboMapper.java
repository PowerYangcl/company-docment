package cn.cecook.dao.business.customer;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcClueWeibo;
import cn.cecook.model.business.customer.BcClueWeiboExample;
import cn.cecook.uitls.Pages;

/**
 * 
* @explain 微博线索
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcClueWeiboMapper {
    int countByExample(BcClueWeiboExample example);

    int deleteByExample(BcClueWeiboExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcClueWeibo record);

    int insertSelective(BcClueWeibo record);

    List<BcClueWeibo> selectByExample(BcClueWeiboExample example);

    BcClueWeibo selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcClueWeibo record, @Param("example") BcClueWeiboExample example);

    int updateByExample(@Param("record") BcClueWeibo record, @Param("example") BcClueWeiboExample example);

    int updateByPrimaryKeySelective(BcClueWeibo record);

    int updateByPrimaryKey(BcClueWeibo record);
    
    /**
     *  根据当前登录用户，获取关键字
     * @param userId
     * @return
     */
    String getKeyWordByUserId(@Param("userId") String userId);
    
    /**
     *  根据关键字，统计对应微博数量
     * @param userId
     * @return
     */
    List<Map<String, Integer>> getKeyWordCount();
    
    /**
     *  分页统计
     * @param page
     * @return
     */
    List<BcClueWeibo> getPage(Pages<BcClueWeibo> page);
    int count(Map<String, Object> map);
    
    /**
     *  根据微博线索id，获取信息
     * @param id
     * @return
     */
    Map<String, Object> getClueWeiboById(int id);
    
    /**
     *  删除微博线索
     * @param id
     */
    void delClueWeibo(int id);
}