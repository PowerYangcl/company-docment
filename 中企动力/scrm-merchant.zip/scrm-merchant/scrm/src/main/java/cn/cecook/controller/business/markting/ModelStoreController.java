package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.IModelStroeService;

@Controller
@RequestMapping("/api/model_store")
public class ModelStoreController {
	
	@Autowired
	IModelStroeService modelStoreService;
	
	@RequestMapping(value="/insert")
    @ResponseBody
    public Object insert(String model_id,String store_ids){
		
		
		System.out.println("模板门店---》"+model_id+"---->"+store_ids);
        return (modelStoreService.insert(model_id, store_ids));
    }
	
	@RequestMapping(value="/query")
    @ResponseBody
    public Object query(String model_id){
		System.out.println("model_id-------->"+model_id);
        return (modelStoreService.query(model_id));
    }
}
