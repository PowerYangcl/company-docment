package cn.cecook.controller.business.markting;

import java.util.Date;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.markting.SocailCoupon;
import cn.cecook.service.business.markting.SocialCouponService;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.FastJsonUtil;

@Controller
@RequestMapping("/social/coupon")
public class SocialCouponController {

	@Autowired
	private SocialCouponService socialCouponService;

	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {
		String name=request.getParameter("name");
		String type=request.getParameter("type");
		String faceValue=request.getParameter("face_value");
		String validityPeriodType=request.getParameter("validity_period_type");
		String limitPrice=request.getParameter("limit_price");
		String useTimeType=request.getParameter("use_time_type");
		String periodTimeWeek=request.getParameter("period_time_week");
		String periodTimeHour=request.getParameter("period_time_hour");
		String start_time=request.getParameter("start_time");
		String end_time=request.getParameter("end_time");
		String afterDay=request.getParameter("after_day");
		String useRule=request.getParameter("useRule");
		String storeIds=request.getParameter("storeIds");
		String useDesc=request.getParameter("useDesc");
		
		SocailCoupon socailCoupon = new SocailCoupon();
		socailCoupon.setName(name);
		socailCoupon.setType(type);
		socailCoupon.setUseDescribe(useDesc);
		
		if(!StringUtils.isEmpty(validityPeriodType))
		socailCoupon.setValidity_period_type(Integer.parseInt(validityPeriodType));
		if(!StringUtils.isEmpty(limitPrice))
		socailCoupon.setLimit_price(Integer.parseInt(limitPrice));
		if(!StringUtils.isEmpty(useTimeType))
			socailCoupon.setUse_time_type(Integer.parseInt(useTimeType));
		socailCoupon.setPeriod_time_week(periodTimeWeek);
		socailCoupon.setPeriod_time_hour(periodTimeHour);
		Date startTime=null;
		Date endTime=null;
		if (!StringUtils.isEmpty(start_time)){
			startTime = DateUtils.getDayStartTimeDate(start_time);
			socailCoupon.setStart_time(startTime);
		}
		if (!StringUtils.isEmpty(end_time)){
			endTime = DateUtils.getDayEndTimeDate(end_time);
			socailCoupon.setEnd_time(endTime);
		}
		if(!StringUtils.isEmpty(afterDay))
			socailCoupon.setAfter_day(Integer.parseInt(afterDay));
		
		if(!StringUtils.isEmpty(faceValue)){
			if(faceValue.split("\\.").length>1){
				socailCoupon.setFaceValue(Integer.parseInt(faceValue.split("\\.")[0]));
			}else{
				socailCoupon.setFaceValue(Integer.parseInt(faceValue));
			}
		}
		
		if(!StringUtils.isEmpty(useRule))
			socailCoupon.setUse_rule(Integer.parseInt(useRule));
		socailCoupon.setStore_ids(storeIds);
		System.out.println(FastJsonUtil.createJsonString(socailCoupon));
		return socialCouponService.create(socailCoupon);
	}
	@RequestMapping(value = "/update")
	@ResponseBody
	public Object update(HttpServletRequest request,
			HttpServletResponse response) {
		String id=request.getParameter("id");
		String name=request.getParameter("name");
		String type=request.getParameter("type");
		String faceValue=request.getParameter("face_value");
		String validityPeriodType=request.getParameter("validity_period_type");
		String limitPrice=request.getParameter("limit_price");
		String useTimeType=request.getParameter("use_time_type");
		String periodTimeWeek=request.getParameter("period_time_week");
		String periodTimeHour=request.getParameter("period_time_hour");
		String start_time=request.getParameter("start_time");
		String end_time=request.getParameter("end_time");
		String afterDay=request.getParameter("after_day");
		String useRule=request.getParameter("useRule");
		String storeIds=request.getParameter("storeIds");
		
		SocailCoupon socailCoupon = new SocailCoupon();
		socailCoupon.setName(name);
		socailCoupon.setType(type);
		if(!StringUtils.isEmpty(validityPeriodType))
		socailCoupon.setValidity_period_type(Integer.parseInt(validityPeriodType));
		if(!StringUtils.isEmpty(limitPrice))
		socailCoupon.setLimit_price(Integer.parseInt(limitPrice));
		if(!StringUtils.isEmpty(useTimeType))
			socailCoupon.setUse_time_type(Integer.parseInt(useTimeType));
		socailCoupon.setPeriod_time_week(periodTimeWeek);
		socailCoupon.setPeriod_time_hour(periodTimeHour);
		Date startTime=null;
		Date endTime=null;
		if (!StringUtils.isEmpty(start_time)){
			startTime = DateUtils.getDayStartTimeDate(start_time);
			socailCoupon.setStart_time(startTime);
		}
		if (!StringUtils.isEmpty(end_time)){
			endTime = DateUtils.getDayEndTimeDate(end_time);
			socailCoupon.setEnd_time(endTime);
		}
		if(!StringUtils.isEmpty(afterDay))
			socailCoupon.setAfter_day(Integer.parseInt(afterDay));
		
		if(!StringUtils.isEmpty(useRule))
			socailCoupon.setUse_rule(Integer.parseInt(useRule));
		if(!StringUtils.isEmpty(id))
			socailCoupon.setId(Integer.parseInt(id));
		if(!StringUtils.isEmpty(faceValue)){
			socailCoupon.setFaceValue(Integer.parseInt(faceValue));
		}
		socailCoupon.setStore_ids(storeIds);
		System.out.println(FastJsonUtil.createJsonString(socailCoupon));
		return socialCouponService.update(socailCoupon);
	}
	@RequestMapping(value = "/delete")
	@ResponseBody
	public Object delete(String id) {
		return (socialCouponService.delete(id));
	}
	
	@RequestMapping(value = "/on_sgelves")
	@ResponseBody
	public Object OnTheShelves(String id) {
		return (socialCouponService.OnTheShelves(id));
	}
	
	@RequestMapping(value = "/off_sgelves")
	@ResponseBody
	public Object OffTheShelves(String id) {
		return (socialCouponService.OffTheShelves(id));
	}
	
	
	@RequestMapping(value = "/getList")
	@ResponseBody
	public Object getList(@RequestBody String param) {
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		return (socialCouponService.getList(jsonObj));

	}
	
	/**
	 * 
	 * Title: deleteBatch Description:批量删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteBatch")
	@ResponseBody
	public Object deleteBatch(String ids) {
		return (socialCouponService.deleteBatch(ids));

	}
	
	@RequestMapping(value = "/offSgelvesBatch")
	@ResponseBody
	public Object offSgelvesBatch(String ids) {
		return (socialCouponService.offSgelvesBatch(ids));

	}
}
