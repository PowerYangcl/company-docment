package cn.cecook.dao.business.scan;

import java.util.Date;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.scan.ScanMemberReport;
import cn.cecook.uitls.Pages;

public interface ScanMemberReportMapper {
	List<ScanMemberReport> getPages(Pages<ScanMemberReport> pages);
	int countByWhere(Map<String,Object> where);
	Map<String,Object> sumAll(Map<String,Object> where);
	
	List<ScanMemberReport> memberBarAll(Map<String,Object> where);
	List<ScanMemberReport> memberLine(Map<String,Object> where);
	
	List<Integer> listJoinMemberId(@Param("tenantId")String tenantId,@Param("date")String date);
	int insert(ScanMemberReport memberReport);
	Date getMaxDate(@Param("tenantId")String tenantId);
	List<ScanMemberReport> listMemberReport(@Param("tenantId")String tenantId,
			@Param("startTime")String startTime,@Param("endTime")String endTime,
			@Param("storeId")String storeId,@Param("storeIds")String storeIds);
}