package cn.cecook.dao.business.markting;

import java.util.Map;

import cn.cecook.model.business.markting.BmMarketCase;


public interface BmMarketCaseMapper {


    int insertSelective(BmMarketCase record);


    BmMarketCase selectByPrimaryKey(Long id);


    int updateByPrimaryKeySelective(BmMarketCase record);
    
    
    BmMarketCase queryDetail(Map<String, Object> map);

}