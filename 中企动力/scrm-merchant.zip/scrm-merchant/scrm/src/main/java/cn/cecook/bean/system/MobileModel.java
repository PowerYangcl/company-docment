package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;

@Component
public class MobileModel implements Serializable {
/*
 * reg_code：注册验证码；login_code：登录验证码；change_code：变更身份的验证码；identity_code：身份验证的验证码；
 */
	//手机号
	private String mobile;
	//验证码类型
	private String code_type;
	//验证码
	private String ver_code ;
	//注册验证码
	private String reg_code;
	//登录验证码
	private String login_code;
	//身份验证的验证码
	private String identity_code;
	
	public String getMobile() {
		return mobile;
	}
	public void setMobile(String mobile) {
		this.mobile = mobile;
	}
	public String getCode_type() {
		return code_type;
	}
	public void setCode_type(String code_type) {
		this.code_type = code_type;
	}
	public String getVer_code() {
		return ver_code;
	}
	public void setVer_code(String ver_code) {
		this.ver_code = ver_code;
	}
	public String getReg_code() {
		return reg_code;
	}
	public void setReg_code(String reg_code) {
		this.reg_code = reg_code;
	}
	public String getLogin_code() {
		return login_code;
	}
	public void setLogin_code(String login_code) {
		this.login_code = login_code;
	}
	public String getIdentity_code() {
		return identity_code;
	}
	public void setIdentity_code(String identity_code) {
		this.identity_code = identity_code;
	}
	
    @Override
    public String toString() {
        return "MobileModel [mobile=" + mobile + ", code_type=" + code_type + ", ver_code=" + ver_code + ", reg_code="
                        + reg_code + ", login_code=" + login_code + ", identity_code=" + identity_code + "]";
    }
	
	
}
