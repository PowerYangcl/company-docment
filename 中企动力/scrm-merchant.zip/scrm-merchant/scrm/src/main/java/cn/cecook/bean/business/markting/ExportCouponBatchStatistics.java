package cn.cecook.bean.business.markting;

public class ExportCouponBatchStatistics {
	private int id;
	private String name;
	private int sendNum;
	private int receiveNum;
	private int clickNum;
	private int converNum;
	private int converTotalMoney;
	private String createTime;
	private Integer activityId;
	
	public int getId() {
		return id;
	}
	public void setId(int id) {
		this.id = id;
	}
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public int getSendNum() {
		return sendNum;
	}
	public void setSendNum(int sendNum) {
		this.sendNum = sendNum;
	}
	public int getReceiveNum() {
		return receiveNum;
	}
	public void setReceiveNum(int receiveNum) {
		this.receiveNum = receiveNum;
	}
	public int getClickNum() {
		return clickNum;
	}
	public void setClickNum(int clickNum) {
		this.clickNum = clickNum;
	}
	public int getConverNum() {
		return converNum;
	}
	public void setConverNum(int converNum) {
		this.converNum = converNum;
	}
	public int getConverTotalMoney() {
		return converTotalMoney;
	}
	public void setConverTotalMoney(int converTotalMoney) {
		this.converTotalMoney = converTotalMoney;
	}
	public String getCreateTime() {
		return createTime;
	}
	public void setCreateTime(String createTime) {
		this.createTime = createTime;
	}
	public Integer getActivityId() {
		return activityId;
	}
	public void setActivityId(Integer activityId) {
		this.activityId = activityId;
	}
	
	

}
