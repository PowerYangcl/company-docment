package cn.cecook.dao.open.mp;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpMenu;

public interface MpMenuMapper {

	public MpMenu selectOne(@Param(value = "event_key") String event_key);
	
	public int getCount();
	
	public void save(MpMenu mpMenu);
	
	public void delAll(@Param(value = "tenant_id") String tenant_id);
	public void del(@Param(value = "event_key") String event_key);
}
