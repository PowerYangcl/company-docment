package cn.cecook.dao.business.service;

import java.util.List;

import cn.cecook.model.business.service.EvaluationDetail;


/**
 * 
 * @作者	马杰
 * @时间	2017年5月13日-下午4:47:46
 * @介绍	dao方法接口
 */
public interface EvaluationDetailMapper {	
	/**
	 * 查询(可分页)
	 * @param evaluationDetail	条件模糊查询
	 * @return
	 */
	public List<EvaluationDetail> findAll(EvaluationDetail evaluationDetail);
	/**
	 * 获取记录总数
	 * @param evaluationDetail	多条件获取
	 * @return
	 */
	public int getCount(EvaluationDetail evaluationDetail);
	/**
	 * 添加
	 * @param evaluationDetail
	 * @return
	 */
	public int addEvaluationDetail(EvaluationDetail evaluationDetail);
	/**
	 * 删除信息
	 * @param id
	 * @return
	 */
	public int delete(int id);
	/**
	 * 查询单条记录
	 * @param evaluationDetail
	 * @return
	 */
	public EvaluationDetail findOne(EvaluationDetail evaluationDetail);
	/**
	 * 修改信息
	 * @return
	 */
	public int update(EvaluationDetail evaluationDetail);
	
}
