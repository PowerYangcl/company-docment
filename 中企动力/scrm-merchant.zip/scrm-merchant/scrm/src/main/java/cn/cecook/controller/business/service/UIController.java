package cn.cecook.controller.business.service;

import org.apache.shiro.authz.annotation.RequiresPermissions;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller("/ser/ui")
@RequestMapping("/ser/ui")
public class UIController {
	@RequestMapping("/order")
	public String order(){
		return "service/order";
	}
	
	@RequiresPermissions("scrm_customer_service_stop")
	@RequestMapping("/orderCount")
	public String orderCount(){
		return "service/orderCount";
	}
	
	/**
	 * 	订单详情
	 * @return
	 */
	@RequestMapping(value="/orderDetail",produces="text/plain;charset=UTF-8")
	public String orderDetail() {
		return "service/orderDetail";
	}
	
	/**
	 * 	差评管理
	 * @return
	 */
    @RequiresPermissions("login")
	@RequestMapping(value="/badComment",produces="text/plain;charset=UTF-8")
	public String badComment() {
		return "service/badComment";
	}
    
	/**
	 * 查看用药评价
	 */
	@RequestMapping(value="/showEvaluate",produces="text/plain;charset=UTF-8")
	public String showEvaluate()
	{
		return "service/showEvaluate";
	}
    
	/**
	 * 用药评价
	 */
	@RequestMapping(value="/evaluate",produces="text/plain;charset=UTF-8")
	public String evaluate()
	{
		return "service/evaluate";
	}
	
	/**
	 * 评价成功
	 */
	@RequestMapping(value="/success",produces="text/plain;charset=UTF-8")
	public String Success()
	{
		return "service/success";
	}
    
	/**
	 * 查看药品详情
	 */
	@RequestMapping(value="/explain",produces="text/plain;charset=UTF-8")
	public String Explain()
	{
		return "service/explain";
	}
    
	/**
	 * 查看药品禁忌
	 * @return
	 */
	@RequestMapping(value="/contraindication",produces="text/plain;charset=UTF-8")
	public String MedicineContraindication()
	{
		return "service/contraindication";
	}
    
	/**
	 * 小票弹窗触发页面
	 * @return
	 */
    @RequiresPermissions("login")
	@RequestMapping(value="/orderPop",produces="text/plain;charset=UTF-8")
	public String orderPop()
	{
		return "service/orderPop";
	}
    
	/**
	 * 小票弹窗触发页面
	 * @return
	 */
    @RequiresPermissions("login")
	@RequestMapping(value="/auditingMedicine",produces="text/plain;charset=UTF-8")
	public String auditingMedicine()
	{
		return "service/auditingMedicine";
	}
}
