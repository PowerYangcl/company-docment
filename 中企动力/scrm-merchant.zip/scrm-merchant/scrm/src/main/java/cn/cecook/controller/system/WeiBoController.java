package cn.cecook.controller.system;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.ui.ModelMap;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.mvc.support.RedirectAttributes;

import com.alibaba.fastjson.JSONObject;

import cn.cecook.bean.system.SysBaseResultModel;
import cn.cecook.bean.system.WeiBoModel;
import cn.cecook.model.system.SysMailAccount;
import cn.cecook.service.system.IMailAccount;
import cn.cecook.service.system.IWeiBoService;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.FastJsonUtil;

/**
 * @author ZHIWEN
 * @explain
 * @data 2017年6月10日
 */
@Controller
@RequestMapping("/api/weibo")
public class WeiBoController {
    @Resource
    private IMailAccount imailaccount;
    @Resource
    private IWeiBoService IWeiBo;

    /**
     * @explain 绑定微博第一步获取Token
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/bindGetToken", method = RequestMethod.GET)
    public ModelAndView bind(@RequestParam(value = "uid", required = false) Long uid,
                             @RequestParam(value = "access_token", required = false) String access_token,
                             @RequestParam(value = "tenant_id", required = false) String tenant_id,
                             HttpServletResponse response, HttpServletRequest request) throws Exception {


        String forward = IWeiBo.bind();
        ModelAndView modelAndView = new ModelAndView();
        modelAndView.setViewName("redirect:" + forward);
        return modelAndView;
    }

    /**
     * @explain 绑定微博第二步获取access_Token
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/bindGetAccessToken", method = RequestMethod.GET)

    public ModelAndView bindGetAccessToken(@RequestParam(value = "uid", required = false) Long uid,
                                           @RequestParam(value = "access_token", required = false) String access_token,
                                           @RequestParam(value = "tenant_id", required = false) String tenant_id,
                                           @RequestParam(value = "code", required = false) String code,
                                           @RequestParam(value = "error_code", required = false) String error_code
            , ModelMap model, HttpServletRequest request, RedirectAttributes ar) throws Exception {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        ModelAndView modelAndView = new ModelAndView();

        if (error_code != null) {
            modelAndView.setViewName("redirect:/ui/social_media");
            return modelAndView;
        }

        if (tenant_id == null || id == null) {
            modelAndView.setViewName("redirect:/ui/social_media");
        } else {
            if (code != null) {
                uid = Long.parseLong(id);
                int status = IWeiBo.bind_next(code, uid, tenant_id);

                if (status == 2) {
                    Object Vcode = "账号已被绑定";
                    ar.addFlashAttribute("Vcode", Vcode);
                    ar.addFlashAttribute("error_code","0");
                }
                modelAndView.setViewName("redirect:/ui/social_media");

                return modelAndView;

            }

        }


        return modelAndView;

    }

    /**
     * @explain 解除绑定
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/removebind")
    @ResponseBody
    public String removebind(@RequestParam(value = "uid", required = false) Long uid,
                                   @RequestParam(value = "access_token", required = false) String access_token,
                                   @RequestParam(value = "tenant_id", required = false) String tenant_id,
                                   //@RequestParam(value = "result",required = false)String result,
                                   HttpServletResponse response, HttpServletRequest request) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        if (tenant_id == null || id == null) {
            return "";
        } else {
            uid = Long.parseLong(id);
            return IWeiBo.relieve(uid, tenant_id);
        }
    }


    /**
     * @explain 显示微博绑定状态
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/changebind", method = RequestMethod.POST)
    public @ResponseBody
    Object changebind(@RequestParam(value = "uid", required = false) Long uid,
                      @RequestParam(value = "access_token", required = false) String access_token,
                      @RequestParam(value = "tenant_id", required = false) String tenant_id,
                      HttpServletResponse response, HttpServletRequest request) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();

        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        WeiBoModel weiBoModel = new WeiBoModel();
        if (tenant_id == null || id == null) {
            weiBoModel.setError_code("1");
            weiBoModel.setError_msg("该租户不存在");
        } else {
            uid = Long.parseLong(id);
            weiBoModel = IWeiBo.removebind(uid, tenant_id);
        }
//        BaseResultModel baseResultModel=new BaseResultModel();
        System.out.println(FastJsonUtil.createJsonString(weiBoModel));
//        if(weiBoModel!=null){
//        	baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
//        	baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
//        	return baseResultModel;
//        }else{
//        	baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
//        	baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
//        	return baseResultModel;
//        }
        return weiBoModel;
        
    }

    /**
     * @explain 显示首页复选框
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/showfirstpage", method = RequestMethod.POST)
    public @ResponseBody
    Object showfirstpage(@RequestParam(value = "uid", required = false) Long uid,
                         @RequestParam(value = "access_token", required = false) String access_token,
                         @RequestParam(value = "tenant_id", required = false) String tenant_id,
                         HttpServletResponse response, HttpServletRequest request) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        String showstatus = "";
        if (tenant_id == null || id == null) {

        } else {
            uid = Long.parseLong(id);
            showstatus = IWeiBo.showfirstpage(uid, tenant_id);
        }


        JSONObject jsonObject = new JSONObject();
        jsonObject.put("showstatus", showstatus);

        return jsonObject;
    }

    /**
     * @explain 更新首页复选框
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/updatefirstpage", method = RequestMethod.POST)
    public @ResponseBody
    Object updatefirstpage(@RequestParam(value = "uid", required = false) Long uid,
                           @RequestParam(value = "access_token", required = false) String access_token,
                           @RequestParam(value = "tenant_id", required = false) String tenant_id,
                           @RequestParam(value = "bak5", required = false) String bak5,
                           HttpServletResponse response, HttpServletRequest request) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        WeiBoModel weiBoModel = new WeiBoModel();
        if (tenant_id == null || id == null) {
            weiBoModel.setError_code("1");
            weiBoModel.setError_msg("租户不存在");
        } else {
            uid = Long.parseLong(id);
            weiBoModel = IWeiBo.updatefirstpage(uid, bak5);
            //System.out.println(weiBoModel.toString());
        }


        return (weiBoModel);
    }

    /**
     * @explain 绑定邮箱
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/Emailbind", method = RequestMethod.POST)
    public @ResponseBody
    Object Emailbind(@RequestParam(value = "uid", required = false) Long uid,
                     @RequestParam(value = "access_token", required = false) String access_token,
                     @RequestParam(value = "tenant_id", required = false) String tenant_id,
                     @RequestParam(value = "EmailAccount", required = false) String EmailAccount,
                     @RequestParam(value = "EmailPawwordOrSky", required = false) String EmailPawwordOrSky,
                     HttpServletResponse response, HttpServletRequest request, RedirectAttributes ar) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        SysBaseResultModel resultModel = new SysBaseResultModel();
        if (tenant_id == null || id == null) {
            resultModel.setError_code("1");
            resultModel.setError_msg("租户不存在");
        } else {
            uid = Long.parseLong(id);
            resultModel = imailaccount.Insert_Mail_Account(uid, tenant_id, EmailAccount, EmailPawwordOrSky);
        }


        return (resultModel);
    }

    /**
     * @explain 解绑邮箱
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/removeEmailbind", method = RequestMethod.POST)
    public @ResponseBody
    Object removeEmailbind(@RequestParam(value = "uid", required = false) Long uid,
                           @RequestParam(value = "access_token", required = false) String access_token,
                           @RequestParam(value = "tenant_id", required = false) String tenant_id,

                           HttpServletResponse response, HttpServletRequest request) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        SysBaseResultModel resultModel = new SysBaseResultModel();
        if (tenant_id == null || id == null) {
            resultModel.setError_code("1");
            resultModel.setError_msg("租户不存在");
        } else {
            uid = Long.parseLong(id);
            resultModel = imailaccount.Delete_Mail_Account(uid, tenant_id);
        }


        return (resultModel);
    }

    /**
     * @explain 返回绑定邮箱部分信息
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/SelectEmailbind", method = RequestMethod.POST)
    public @ResponseBody
    Object SelectEmailbind(@RequestParam(value = "uid", required = false) Long uid,
                           @RequestParam(value = "access_token", required = false) String access_token,
                           @RequestParam(value = "tenant_id", required = false) String tenant_id,

                           HttpServletResponse response, HttpServletRequest request) {

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();

        SysMailAccount sysMailAccount = new SysMailAccount();
        if (tenant_id == null || id == null) {
            sysMailAccount.setError_code("1");
            sysMailAccount.setError_msg("租户不存在");
        } else {
            uid = Long.parseLong(id);
            sysMailAccount = imailaccount.SelectMailAccount(uid, tenant_id);
        }

        return (sysMailAccount);
    }
    /**
     * 
    * Title: getWeiBoUserInfo
    * Description:获取绑定微博用户的信息
    * @param tenant_id
    * @param uid
    * @return
     */
    @RequestMapping(value = "/weiboUserInfo")
    @ResponseBody
    public 
    Object getWeiBoUserInfo(String tenant_id,String uid){
    	
		return (IWeiBo.getWeiboUserInfo(tenant_id, uid));
    }
    
    
}
