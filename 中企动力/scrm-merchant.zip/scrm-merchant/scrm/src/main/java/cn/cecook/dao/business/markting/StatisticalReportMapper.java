package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

public interface StatisticalReportMapper {
	/**
	 * 名片打开量
	 * @return
	 */
	Long cardOpenCount(Map<String,Object> param);
	
	/**
	 * 名片分享量
	 * @return
	 */
	Long cardShareCount(Map<String,Object> param);
	
	/**
	 * 活动打开量
	 * @return
	 */
	Long activityOpenCount(Map<String,Object> param);
	
	/**
	 * 活动提交量
	 * @return
	 */
	Long activityCommitCount(Map<String,Object> param);
	
	/***********************************************************************************************************/
	
	/**
	 * 名片打开量，每天的量
	 * @return
	 */
	List<Map<String,Object>> cardOpenCountByDay(Map<String,Object> param);
	
	/**
	 * 名片分享量，每天的量
	 * @return
	 */
	List<Map<String,Object>> cardShareCountByDay(Map<String,Object> param);
	
	/**
	 * 活动打开量，每天的量
	 * @return
	 */
	List<Map<String,Object>> activityOpenCountByDay(Map<String,Object> param);
	
	/**
	 * 活动提交量，每天的量
	 * @return
	 */
	List<Map<String,Object>> activityCommitCountByDay(Map<String,Object> param);
	
	/***********************************************************************************************************/
	
	/**
	 * 名片打开量，员工排行
	 * @return
	 */
	List<Map<String,Object>> cardOpenCountGroupUser(Map<String,Object> param);
	
	/**
	 * 名片分享量，员工排行
	 * @return
	 */
	List<Map<String,Object>> cardShareCountByUserIds(Map<String,Object> param);
	
	/**
	 * 活动打开量，员工排行
	 * @return
	 */
	List<Map<String,Object>> activityOpenCountByUserIds(Map<String,Object> param);
	
	/**
	 * 活动提交量，员工排行
	 * @return
	 */
	List<Map<String,Object>> activityCommitCountByUserIds(Map<String,Object> param);
	
	/**
	 * 名片打开量，门店排行
	 * @return
	 */
	List<Map<String,Object>> cardOpenCountGroupStore(Map<String,Object> param);
	
	/**
	 * 名片分享量，门店排行
	 * @return
	 */
	List<Map<String,Object>> cardShareCountByStoreIds(Map<String,Object> param);
	
	/**
	 * 活动打开量，门店排行
	 * @return
	 */
	List<Map<String,Object>> activityOpenCountByStoreIds(Map<String,Object> param);
	
	/**
	 * 活动提交量，门店排行
	 * @return
	 */
	List<Map<String,Object>> activityCommitCountByStoreIds(Map<String,Object> param);
	
	/***********************************************************************************************************/
	
	/**
	 * 名片打开量，城市排行
	 * @return
	 */
	List<Map<String,Object>> cardOpenCountGroupCity(Map<String,Object> param);
	
	/**
	 * 名片分享量，城市排行
	 * @return
	 */
	List<Map<String,Object>> cardShareCountGroupCity(Map<String,Object> param);
	
	/**
	 * 活动打开量，城市排行
	 * @return
	 */
	List<Map<String,Object>> activityOpenCountGroupCity(Map<String,Object> param);
	
	/**
	 * 活动提交量，城市排行
	 * @return
	 */
	List<Map<String,Object>> activityCommitCountGroupCity(Map<String,Object> param);
	
	/**
	 * 计算总量
	 * @param param
	 * @return
	 */
	Long cardOpenCountByParam(Map<String,Object> param);
	
	/**
	 * 计算总量
	 * @return
	 */
	Long cardShareCountByParam(Map<String,Object> param);
	
	/**
	 * 计算总量
	 * @return
	 */
	Long activityOpenCountByParam(Map<String,Object> param);
	
	/**
	 * 计算总量
	 * @return
	 */
	Long activityCommitCountByParam(Map<String,Object> param);
	
	/***********************************************************************************************************/
	
	/**
	 * 获取部门，员工的对应关系
	 * @return
	 */
	List<Map<String,Object>> listDeptUserRelation(Map<String,Object> param);
	
	/**
	 * 员工分组
	 * @param param
	 * @return
	 */
	List<Map<String,Object>> getPageGroupUser(Map<String,Object> param);
	
	/**
	 * 门店分组
	 * @param param
	 * @return
	 */
	List<Map<String,Object>> getPageGroupStore(Map<String,Object> param);
	
	/**
	 * 活动分组
	 * @param param
	 * @return
	 */
	List<Map<String,Object>> getPageGroupActivity(Map<String,Object> param);
	
	/***********************************************************************************************************/
	
	/**
	 *	获取名片获取的会员
	 * @param param
	 * @return
	 */
	List<Map<String,Object>> getPageCardMember(Map<String,Object> param);
	long getPageCardMemberCount(Map<String,Object> param);
	List<Map<String,Object>> listCardMember();
	
	/**
	 * 标记联系
	 * @param id
	 * @return
	 */
	int markContacted(int id);
}