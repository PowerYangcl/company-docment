package cn.cecook.controller.business.markting;


import java.io.File;
import java.io.IOException;
import java.io.InputStream;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.codec.binary.Base64;
import org.apache.commons.io.FileUtils;
import cn.cecook.uitls.StringUtils;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.markting.BmActivityModelDefined;
import cn.cecook.service.business.markting.ActivityModelDefinedService;

@Controller
@RequestMapping("/api/activity_defined_model")
public class ActivityModelDefinedController {

    @Resource
    ActivityModelDefinedService activityModelDefinedService;

    @RequestMapping(value = "/create")
    @ResponseBody
    public Object createModel(HttpServletRequest request, HttpServletResponse response) {
        BmActivityModelDefined bmActivityModelDefined = new BmActivityModelDefined();
        String tenant_id = request.getParameter("tenant_id");// 租户id
        String uid = request.getParameter("uid");// 用户id
        String model_name = request.getParameter("model_name");// 模板名称
        String remarks = request.getParameter("remarks");// 备注
        String description = request.getParameter("description");// 描述
        String type = request.getParameter("type");// 类型
        String pics = request.getParameter("pics");// 图片集合
        String text_info = request.getParameter("text_info");// 文本信息
        String address_info = request.getParameter("address_info");// 地址信息
        String collect_info = request.getParameter("collect_info");// 收集信息
        String button_css = request.getParameter("button_css");// 按钮样式
        String button_text = request.getParameter("button_text");// 按钮文字
        String footer_info = request.getParameter("footer_info");// 页脚信息
        String background_music = request.getParameter("background_music");// 背景音乐
        String content = request.getParameter("content");// 页面内容
        String background_pic = request.getParameter("background_pic");// 页面内容
        String weixin_qrcode = request.getParameter("weixin_qrcode");// 页面内容
        String weibo_qrcode = request.getParameter("weibo_qrcode");// 页面内容
        String thumbnail_pic=request.getParameter("thumbnail_pic");
		String theme_info=request.getParameter("theme_info");
		String theme_info_color=request.getParameter("theme_info_color");
		String text_info_color=request.getParameter("text_info_color");
		String sms_content=request.getParameter("sms_content");
		String background_color=request.getParameter("background_color");
		bmActivityModelDefined.setTheme_info(theme_info);
		bmActivityModelDefined.setTheme_info_color(theme_info_color);
		bmActivityModelDefined.setText_info_color(text_info_color);
		bmActivityModelDefined.setTenantId(tenant_id);
        if (!StringUtils.isEmpty(uid)) bmActivityModelDefined.setCreateId(Long.parseLong(uid));
        bmActivityModelDefined.setName(model_name);
        bmActivityModelDefined.setRemarks(remarks);
        bmActivityModelDefined.setDescription(description);
        bmActivityModelDefined.setType(type);
        bmActivityModelDefined.setPicUrl(pics);
        bmActivityModelDefined.setTextInfo(text_info);
        bmActivityModelDefined.setAddressInfo(address_info);
        bmActivityModelDefined.setCollectInfo(collect_info);
        bmActivityModelDefined.setButtonCss(button_css);
        bmActivityModelDefined.setButtonText(button_text);
        bmActivityModelDefined.setFooterInfo(footer_info);
        bmActivityModelDefined.setBackgroundMusic(background_music);
        bmActivityModelDefined.setContent(content);
        bmActivityModelDefined.setBackground_pic(background_pic);
        bmActivityModelDefined.setWeixin_qrcode(weixin_qrcode);
        bmActivityModelDefined.setWeibo_qrcode(weibo_qrcode);
        bmActivityModelDefined.setThumbnail_pic(thumbnail_pic);
        bmActivityModelDefined.setModel_pic(thumbnail_pic);
        bmActivityModelDefined.setBak1(sms_content);
        bmActivityModelDefined.setRemarks(background_color);
        return (activityModelDefinedService
                        .createActivityDefinedModel(bmActivityModelDefined));
    }

    @RequestMapping(value = "/edit")
    @ResponseBody
    public Object editModel(HttpServletRequest request, HttpServletResponse response) {
        BmActivityModelDefined bmActivityModelDefined = new BmActivityModelDefined();
        String tenant_id = request.getParameter("tenant_id");// 租户id
        String model_id = request.getParameter("model_id");// 租户id
        String uid = request.getParameter("uid");// 用户id
        String model_name = request.getParameter("model_name");// 模板名称
        String description = request.getParameter("description");// 描述
        String type = request.getParameter("type");// 类型
        String pics = request.getParameter("pics");// 图片集合
        String text_info = request.getParameter("text_info");// 文本信息
        String address_info = request.getParameter("address_info");// 地址信息
        String collect_info = request.getParameter("collect_info");// 收集信息
        String button_css = request.getParameter("button_css");// 按钮样式
        String button_text = request.getParameter("button_text");// 按钮文字
        String footer_info = request.getParameter("footer_info");// 页脚信息
        String background_music = request.getParameter("background_music");// 背景音乐
        String content = request.getParameter("content");// 页面内容
        String background_pic = request.getParameter("background_pic");// 页面内容
        String weixin_qrcode = request.getParameter("weixin_qrcode");// 页面内容
        String weibo_qrcode = request.getParameter("weibo_qrcode");// 页面内容
        String thumbnail_pic=request.getParameter("thumbnail_pic");
		String theme_info=request.getParameter("theme_info");
		String theme_info_color=request.getParameter("theme_info_color");
		String text_info_color=request.getParameter("text_info_color");
		String sms_content=request.getParameter("sms_content");
		String background_color=request.getParameter("background_color");
		bmActivityModelDefined.setRemarks(background_color);
		System.out.println("background_color------------->"+bmActivityModelDefined.getRemarks());
		System.out.println("sms_content---->"+sms_content);
		bmActivityModelDefined.setTheme_info(theme_info);
		bmActivityModelDefined.setTheme_info_color(theme_info_color);
		bmActivityModelDefined.setText_info_color(text_info_color);
        bmActivityModelDefined.setTenantId(tenant_id);
        if (!StringUtils.isEmpty(uid)) bmActivityModelDefined.setCreateId(Long.parseLong(uid));
        bmActivityModelDefined.setName(model_name);
        if (!StringUtils.isEmpty(model_id)) bmActivityModelDefined.setId(Integer.parseInt(model_id));
        bmActivityModelDefined.setDescription(description);
        bmActivityModelDefined.setType(type);
        bmActivityModelDefined.setPicUrl(pics);
        bmActivityModelDefined.setTextInfo(text_info);
        bmActivityModelDefined.setAddressInfo(address_info);
        bmActivityModelDefined.setCollectInfo(collect_info);
        bmActivityModelDefined.setButtonCss(button_css);
        bmActivityModelDefined.setButtonText(button_text);
        bmActivityModelDefined.setFooterInfo(footer_info);
        bmActivityModelDefined.setBackgroundMusic(background_music);
        bmActivityModelDefined.setContent(content);
        bmActivityModelDefined.setBackground_pic(background_pic);
        bmActivityModelDefined.setWeixin_qrcode(weixin_qrcode);
        bmActivityModelDefined.setWeibo_qrcode(weibo_qrcode);
        bmActivityModelDefined.setThumbnail_pic(thumbnail_pic);
        bmActivityModelDefined.setModel_pic(thumbnail_pic);
        bmActivityModelDefined.setBak1(sms_content);
        return (activityModelDefinedService.editActivityDefinedModel(bmActivityModelDefined));
    }

    @RequestMapping(value = "/deleteModel")
    @ResponseBody
    public Object deleteModel(String tenant_id, String uid, String model_id) {
        return (activityModelDefinedService.deleteActivityDefinedModel(tenant_id, uid,
                        model_id));
    }

    @RequestMapping(value = "/detail")
    @ResponseBody
    public Object modelDetail(String tenant_id, String uid, String model_id) {
        return (activityModelDefinedService.getActivityModelDefinedDetail(tenant_id, uid,
                        model_id));
    }

    @RequestMapping(value = "/list")
    @ResponseBody
    public Object modelList(String tenant_id, String uid, String self_id, String key_word, String current_page,
                    String next_page, String page_size) {
        return (activityModelDefinedService.getBmActivityModelDefinedList(tenant_id, uid,
                        self_id, key_word, current_page, next_page, page_size));
    }

    @RequestMapping(value = "/lock")
    @ResponseBody
    public Object locakStatus(String model_id) {
        return (activityModelDefinedService.lockStatus(model_id));
    }
    @RequestMapping(value = "/unlock")
    @ResponseBody
    public Object unlocakStatus(String model_id) {
        return (activityModelDefinedService.unlockStatus(model_id));
    }
    
    
    /*
     * 图片命名格式
     */
    private static final String DEFAULT_SUB_FOLDER_FORMAT_AUTO = "yyyyMMddHHmmss";
    
    // 加载配置文件
    private Properties p = null;

    private Properties getProperties(String PropertiesUrl) throws IOException {
        InputStream inputStream = this.getClass().getClassLoader().getResourceAsStream(PropertiesUrl);
        if (p == null) {
            p = new Properties();
            if (inputStream != null) {
                try {
                    p.load(inputStream);

                } catch (IOException e) {
                    e.printStackTrace();
                    System.out.println("InputStream加载异常");
                } finally {
                    inputStream.close();
                    inputStream = null;
                }
            }
        }
        return p;
    }
    
    @RequestMapping(value = "/snapscreen")
    @ResponseBody
    public Object snapscreen(String base64ImgData) throws IOException{
        // 加载配置文件
        String FPATH = null;
        String BACKFPATH = null;

        Map<String, Object> map = new HashMap<String, Object>();
        String errorCode = "";
        String errorMsg = "截屏失败";
        
        Properties P = getProperties("conf/uploadFilePath.properties");
        FPATH = P.getProperty("UplaodBaseUrl");
        BACKFPATH = P.getProperty("backUplaodBaseUrl");
        String path = FPATH + "/upload";
        String snapScreenPath = "";
        
        try {
//            BASE64Decoder d = new BASE64Decoder();
            Base64 d = new Base64();
            // 去掉头部声明
            base64ImgData = base64ImgData.substring(base64ImgData.indexOf(",") + 1);
//            byte[] bs = d.decodeBuffer(base64ImgData);
            byte[] bs = d.decode(base64ImgData);
            //String snapScreenPath = "F:\\screen.png";
            // 保存图片到本地
            DateFormat df = new SimpleDateFormat(DEFAULT_SUB_FOLDER_FORMAT_AUTO);
            snapScreenPath = df.format(new Date()) + ".png";
            FileUtils.writeByteArrayToFile(new File(path + "/" +snapScreenPath), bs);
            errorCode = "0";
            errorMsg = "截屏成功";

        } catch (Exception e) {
            e.printStackTrace();
            errorCode="1";
            errorMsg = "截屏失败!失败原因:" + e.getMessage();
        }

        map.put("error_code", errorCode);
        map.put("error_msg", errorMsg);
        map.put("pic_url", BACKFPATH + "/upload/"
                        + snapScreenPath);
//        writer.write(GsonTools.createJsonString(map));
        
        return (map);
    }
}