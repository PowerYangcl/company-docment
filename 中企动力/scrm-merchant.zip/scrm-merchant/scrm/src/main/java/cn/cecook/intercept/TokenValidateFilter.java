package cn.cecook.intercept;

import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.net.URLEncoder;

/**
 * Servlet Filter implementation class TokenValidateFilter
 */
@WebFilter("/*")
public class TokenValidateFilter implements Filter {

    /**
     * Default constructor. 
     */
    public TokenValidateFilter() {
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see Filter#destroy()
	 */
	public void destroy() {
		// TODO Auto-generated method stub
	}

	/**
	 * @see Filter#doFilter(ServletRequest, ServletResponse, FilterChain)
	 */
	public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain) throws IOException, ServletException {
		HttpServletRequest req = (HttpServletRequest) request;
		HttpServletResponse resp = (HttpServletResponse) response;
		req.setCharacterEncoding("utf-8");
		resp.setCharacterEncoding("utf-8");
		
		String path = req.getServletPath();
		if(path.startsWith("/api/customer_action/")||path.startsWith("/api/clue_customer/")||path.startsWith("/api/custome/")
				||path.startsWith("/api/customeSource")||path.startsWith("/api/userDimension")) {
			if (MyCatFilter.getToken_Valid()) {
				chain.doFilter(request, response);
			}else {
			    System.out.println("12521");
				String msg = URLEncoder.encode("登录失效", "utf-8");
//				resp.sendRedirect(req.getContextPath()+"/index.jsp?msg="+msg);
				response.setContentType("text/html;charset=UTF-8");//解决乱码
				PrintWriter out = response.getWriter();
		        out.println("<html>");
		        out.println("<script language=\"javascript\">");
		        /*out.println("alert('"+msg+"');");*/
		        out.println("window.open ('"+req.getContextPath()+"/index.jsp','_top')");
		        out.println("</script>");
		        out.println("</html>");
			}
		}else {
			chain.doFilter(request, response);
		}
	}

	/**
	 * @see Filter#init(FilterConfig)
	 */
	public void init(FilterConfig fConfig) throws ServletException {
		// TODO Auto-generated method stub
	}

}
