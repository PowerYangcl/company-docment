package cn.cecook.intercept.shiro;

import java.io.Serializable;
import java.util.UUID;

import javax.servlet.ServletRequest;

import org.apache.shiro.SecurityUtils;
import org.apache.shiro.session.Session;
import org.apache.shiro.session.mgt.eis.SessionIdGenerator;
import org.apache.shiro.web.subject.WebSubject;

import cn.cecook.uitls.ConfigUtil;


public class MySessionIdGenerator implements SessionIdGenerator{

	/**
	 * 重写登录用户的sessionId,目前session和业务无关
	 * 在登陆之前session已创建
	 */
	@Override
	public Serializable generateId(Session session) {
		
		//ServletRequest request = ((WebSubject)SecurityUtils.getSubject()).getServletRequest();  
        //需要的请求参数
        //String account = request.getParameter("account");
        //String seesionId = ConfigUtil.REDIS_USER_SESSION_KEY + account;
        //return seesionId;
		//sessionId  redisKey+account+时间戳
        return UUID.randomUUID().toString();
	}
	

}
