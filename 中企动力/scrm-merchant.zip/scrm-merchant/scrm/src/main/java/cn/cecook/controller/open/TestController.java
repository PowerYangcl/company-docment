package cn.cecook.controller.open;

import java.awt.image.BufferedImage;
import java.io.ByteArrayInputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.apache.commons.lang.StringUtils;
import org.dom4j.DocumentException;
import org.dom4j.DocumentHelper;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.dao.open.mp.MpUserMapper;
import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpMass;
import cn.cecook.model.open.mp.MpMaterial;
import cn.cecook.model.open.mp.MpMaterialNews;
import cn.cecook.model.open.mp.MpMaterialNewsDetail;
import cn.cecook.model.open.mp.MpMenu;
import cn.cecook.model.open.mp.MpRelate;
import cn.cecook.model.open.mp.MpTag;
import cn.cecook.model.open.mp.MpUser;
import cn.cecook.model.open.mp.MpUserInfo;
import cn.cecook.model.open.mp.MpUserProvinceStat;
import cn.cecook.service.business.scan.ScanMemberService;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpMassService;
import cn.cecook.service.open.IMpMaterialNewsDetailService;
import cn.cecook.service.open.IMpMaterialNewsService;
import cn.cecook.service.open.IMpMaterialService;
import cn.cecook.service.open.IMpMenuService;
import cn.cecook.service.open.IMpRelateService;
import cn.cecook.service.open.IMpScanMemberGroupService;
import cn.cecook.service.open.IMpStatisticService;
import cn.cecook.service.open.IMpUserInfoService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.thirdparty.open.MassMsgStatusType;
import cn.cecook.thirdparty.open.MaterialUtil;
import cn.cecook.thirdparty.open.MediaUtil;
import cn.cecook.thirdparty.open.UserUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.ExportExcel;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/test")
public class TestController {
	
	@Resource
	private IMpAccountService mpAccountService;
	
	@Resource
	private IMpUserService iMpUserService;
	
	@Resource
	private MpUserMapper mpUserMapper;
	
	@Autowired
	private IMpAccountService iMpAccountService;
	
	@Autowired
	private IMpRelateService iMpRelateService;
	
	@Autowired
	private IMpMaterialService iMpMaterialService;
	
	@Autowired
	private IMpMenuService iMpMenuService;
	
	@Autowired
	private IMpMaterialNewsService mpMaterialNewsService;
	
	@Autowired
	private IMpMaterialNewsDetailService mpMaterialNewsDetailService;
	
	@Autowired
	private IMpMassService mpMassService;
	
	@Autowired
	private IMpUserInfoService mpUserInfoService;
	
	@Autowired
	private ScanMemberService scanMemberService;

	@Autowired
	private IMpStatisticService iMpStatisticService;
	
	@Autowired
	private IMpScanMemberGroupService mpScanMemberGroupService;

	@RequestMapping(value = "/getGroupidByMemeberid", method = RequestMethod.GET)
	@ResponseBody
	public String getGroupidByMemeberid(HttpServletRequest request, HttpServletResponse response) {
		String member_id = request.getParameter("member_id");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		List<Integer> selectGroupids = mpScanMemberGroupService.selectGroupids(tenant_id, member_id);
		System.out.println(selectGroupids);
		return "";
	}
	
	@RequestMapping(value = "/tmpRecv", method = RequestMethod.GET)
	@ResponseBody
	public String tmpRecv(HttpServletRequest request, HttpServletResponse response) {
		String xml = "<xml><ToUserName><![CDATA[gh_cf653da82112]]></ToUserName><FromUserName><![CDATA[oUclx0umC7GPJjSkrBueE6RgE5P8]]></FromUserName><CreateTime>1521496050</CreateTime><MsgType><![CDATA[event]]></MsgType><Event><![CDATA[MASSSENDJOBFINISH]]></Event><MsgID>3147483672</MsgID><Status><![CDATA[send success]]></Status><TotalCount>2</TotalCount><FilterCount>2</FilterCount><SentCount>2</SentCount><ErrorCount>0</ErrorCount><CopyrightCheckResult><Count>0</Count><ResultList></ResultList><CheckState>1</CheckState></CopyrightCheckResult></xml>";
		org.dom4j.Document resultDocument = null;
		String FromUserName = null;
		String ToUserName = null;
		String EventKey = null;
		String MsgType = null;
		String Content = null;
		try {
			resultDocument = DocumentHelper.parseText(xml);
			FromUserName = resultDocument.getRootElement().elementText("FromUserName");
			ToUserName = resultDocument.getRootElement().elementText("ToUserName");
			EventKey = resultDocument.getRootElement().elementText("EventKey");
			MsgType = resultDocument.getRootElement().elementText("MsgType");
			Content = resultDocument.getRootElement().elementText("Content");
		} catch (DocumentException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		if("event".equals(MsgType)){//处理响应事件
			String Event = resultDocument.getRootElement().elementText("Event");
			if("MASSSENDJOBFINISH".equals(Event)){//群发消息的回调
				MpAccount mpAccount = iMpAccountService.selectMpAccountByUserName(ToUserName);
				String msgId = resultDocument.getRootElement().elementText("MsgID");
				String TotalCount = resultDocument.getRootElement().elementText("TotalCount");
				String FilterCount = resultDocument.getRootElement().elementText("FilterCount");
				String SentCountStr = resultDocument.getRootElement().elementText("SentCount");
				String ErrorCount = resultDocument.getRootElement().elementText("ErrorCount");
				int SentCount = 0;
				try {
					SentCount = Integer.valueOf(SentCountStr);
				} catch (Exception e) {
					e.printStackTrace();
				}
				List<MpMass> mpMasses = mpMassService.selectByMsgId(mpAccount.getTenantId(), msgId);
				for (int i = 0; mpMasses != null && i < mpMasses.size(); i++) {
					MpMass mpMass = mpMasses.get(i);
					mpMass.setMsgPushNum(SentCount);
					mpMassService.update(mpAccount.getTenantId(), mpMass);
				}
			}
		}
		return "";
	}
	
	@RequestMapping(value = "/getMaxDate", method = RequestMethod.GET)
	@ResponseBody
	public String getMaxDate(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		Date maxDate = iMpStatisticService.getMaxDate(tenant_id);
		System.out.println(maxDate);
		return maxDate.toString();
	}
	
	@RequestMapping(value = "/getMemberByPhone", method = RequestMethod.GET)
	@ResponseBody
	public String getMemberByPhone(HttpServletRequest request, HttpServletResponse response) {
		String memberByPhone = scanMemberService.getMemberByPhone(request.getParameter("phone"));
		System.out.println("memberByPhone:"+memberByPhone);
		return memberByPhone;
	}
	
	@RequestMapping(value = "/loadUserInfo", method = RequestMethod.GET)
	@ResponseBody
	public void loadUserInfo(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		System.out.println("loadUserInfo tenant_id="+tenant_id);
		MpUserInfo mpUserInfo = new MpUserInfo();
		mpUserInfo.setLogo("123");
		mpUserInfo.setBackground("456");
		mpUserInfo.setHomeurl("78");
		mpUserInfo.setHomeurlShort("89");
		mpUserInfoService.insert(mpUserInfo);
	}
	
	@RequestMapping(value = "/sendmass", method = RequestMethod.GET)
	@ResponseBody
	public void sendmass(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		List<MpMass> mpMassList = mpMassService.selectOnTime(tenant_id);
		System.out.println("send mass("+mpMassList.size()+") : "+mpMassList);
		List<MpMass> mpMassByPage = mpMassService.selectByPage(tenant_id, 10, 10);
		System.out.println("page mass("+mpMassByPage.size()+") : "+mpMassByPage);
	}
	
	@RequestMapping(value = "/savemass", method = RequestMethod.GET)
	@ResponseBody
	public void savemass(HttpServletRequest request, HttpServletResponse response) {
		MpMass mpMass = new MpMass();
		mpMass.setSex("1");
		mpMass.setMsgTitle("test2");
		mpMass.setMsgStatus(MassMsgStatusType.NOTSTART.getType());
		mpMassService.insert(mpMass);
		System.out.println("save mass : "+mpMass);
	}
	
	@RequestMapping(value = "/savenews", method = RequestMethod.GET)
	@ResponseBody
	public void savenews(HttpServletRequest request, HttpServletResponse response) {
		MpMaterialNews mpMaterialNews = new MpMaterialNews();
		mpMaterialNews.setMediaId("123");
		mpMaterialNews.setCreateTime(new Date());
		mpMaterialNews.setUpdateTime(new Date());
		mpMaterialNews.setDetails(new ArrayList<MpMaterialNewsDetail>());
		int id = mpMaterialNewsService.insertNews(mpMaterialNews);
		System.out.println(id+" and " + mpMaterialNews.getId());
	}
	
	@RequestMapping(value = "/getnews", method = RequestMethod.GET)
	@ResponseBody
	public void getnews(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpMaterialNews newsById = mpMaterialNewsService.selectNewsById(tenant_id, 1);
		System.out.println(newsById);
		List<MpMaterialNews> materialByPage = mpMaterialNewsService.selectMaterialByPage(tenant_id, 0, 10);
		System.out.println(materialByPage);
	}
	
	@RequestMapping(value = "/cityinfo", method = RequestMethod.GET)
	@ResponseBody
	public void cityinfo(HttpServletRequest request, HttpServletResponse response) {
		List<MpUserProvinceStat> provinceInfo = iMpUserService.getProvinceInfo();
		System.out.println(provinceInfo);
	}
	
	@RequestMapping(value = "/addMenu", method = RequestMethod.GET)
	@ResponseBody
	public void addMenu(HttpServletRequest request, HttpServletResponse response) {
		MpMenu mpMenu = new MpMenu();
		mpMenu.setEventKey(request.getParameter("eventKey"));
		mpMenu.setEventType(request.getParameter("eventType"));
		mpMenu.setEventDetail(request.getParameter("eventDetail"));
		iMpMenuService.save(mpMenu);
	}
	
	@RequestMapping(value = "/mprelate", method = RequestMethod.GET)
	@ResponseBody
	public void mprelate(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpRelate mpRelate = new MpRelate();
		mpRelate.setOpenid("oid@004");
		mpRelate.setPhone("186");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount == null){
			System.out.println("请先登录");
		}else{
			iMpRelateService.insert(tenant_id, mpRelate);
			System.out.println("finish");
		}
	}
	
	@RequestMapping(value = "/getMaterialNews", method = RequestMethod.GET)
	@ResponseBody
	public void getMaterialNews(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount == null){
			System.out.println("请先登录");
		}else{
			MpMaterialNews selectNewsById = mpMaterialNewsService.selectNewsById(tenant_id, 117);
			System.out.println(selectNewsById);
		}
	}
	
	@RequestMapping(value = "/listMaterialNews", method = RequestMethod.GET)
	@ResponseBody
	public void listMaterialNews(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount == null){
			System.out.println("请先登录");
		}else{
			List<MpMaterialNews> materialNewsList = mpMaterialNewsService.selectMaterialByPage(tenant_id, 14, 10);
			for (int i = 0; i < materialNewsList.size(); i++) {
				MpMaterialNews mpMaterialNews = materialNewsList.get(i);
				System.out.println(mpMaterialNews);
			}
		}
	}
	
	@RequestMapping(value = "/loadMaterialNews", method = RequestMethod.GET)
	@ResponseBody
	public JSONObject loadMaterialNews(HttpServletRequest request, HttpServletResponse response) {
		JSONObject result = new JSONObject();
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount == null){
			System.out.println("请先登录");
		}else{
			mpMaterialNewsService.delAll(tenant_id, null);
			mpMaterialNewsDetailService.delAll(tenant_id);
			String filePath = request.getSession().getServletContext().getRealPath("");
			List<MpMaterialNews> material_News = new MaterialUtil().getMaterial_News(tenant_id, mpAccount.getAuthorizerAccessToken(), filePath, 0, 100);
			for (int i = 0; i < material_News.size(); i++) {
				MpMaterialNews mpMaterialNews = material_News.get(i);
				mpMaterialNewsService.insertNews(mpMaterialNews);
				String titles  = "";
				for (int j = 0; j < mpMaterialNews.getDetails().size(); j++) {
					MpMaterialNewsDetail mpMaterialNewsDetail = mpMaterialNews.getDetails().get(j);
					if(StringUtils.isNotEmpty(mpMaterialNewsDetail.getTitle())){
						if(StringUtils.isNotEmpty(titles)){
							titles += "|";
						}
						titles += mpMaterialNewsDetail.getTitle();
					}
					mpMaterialNewsDetail.setNewsId(mpMaterialNews.getId());
					mpMaterialNewsDetailService.insertNewsDetail(mpMaterialNewsDetail);
				}
				mpMaterialNews.setTitles(titles);
				mpMaterialNewsService.updateNews(tenant_id, mpMaterialNews);
			}
		}
		result.put("status", true);
		return result;
	}
	
	@RequestMapping(value = "/loadMaterial", method = RequestMethod.GET)
	@ResponseBody
	public void loadMaterial(HttpServletRequest request, HttpServletResponse response) {
		String filePath = request.getSession().getServletContext().getRealPath("");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		iMpMaterialService.reloadMaterial(tenant_id, filePath);
	}
	
	@RequestMapping(value = "/listMaterial", method = RequestMethod.GET)
	@ResponseBody
	public void listMaterial(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		List<MpMaterial> materialList = iMpMaterialService.selectMaterial(tenant_id, 0, 10);
		for (int i = 0; i < materialList.size(); i++) {
			System.out.println(materialList.get(i));
		}
	}
	
	@RequestMapping(value = "/delMaterial", method = RequestMethod.GET)
	@ResponseBody
	public void delMaterial(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		String media_id = request.getParameter("media_id");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount != null){			
			String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
			boolean del = iMpMaterialService.del(tenant_id, media_id, authorizer_access_token);
			System.out.println("del:::"+del);
		}
	}
	
	@RequestMapping(value = "/accountlist", method = RequestMethod.GET)
	@ResponseBody
	public String accountlist(HttpServletRequest request, HttpServletResponse response) {
		
		List<MpAccount> mpAccounts = iMpAccountService.selectTokenTimeMoreHour();
		for (int i = 0; i < mpAccounts.size(); i++) {
			System.out.println(mpAccounts.get(i));
		}
		return null;
	}
	
	@RequestMapping(value = "/insert", method = RequestMethod.GET)
	@ResponseBody
	public String insert(HttpServletRequest request, HttpServletResponse response) {
		
		String uid = request.getParameter("uid");
		String nick = request.getParameter("nick");
        
		/*MpAccount mpAccount = new MpAccount();
		mpAccount.setUid(uid);
		mpAccount.setUserName(nick);
		mpAccount.setNickName(nick);
		mpAccount.setAuthorizerAppid("123456");
		mpAccountService.insertSelective(mpAccount);*/
		
		MpUser mpUser = new MpUser();
		mpUser.setOpenid(uid);
		mpUser.setUnionid(nick);
		iMpUserService.insert(mpUser);
		
		return "已授权完成";
	}
	
	@RequestMapping(value = "/listuser", method = RequestMethod.GET)
	@ResponseBody
	public String listuser(HttpServletRequest request, HttpServletResponse response) {
		
		//String auth_code = request.getParameter("auth_code");
		//Subject subject = SecurityUtils.getSubject();
		//Session session = subject.getSession();
		//String uid = String.valueOf(session.getAttribute("userId"));
		String uid = "1";
		int page = 1;
		int pageSize = 10;
		Map<String, Object> condition = new HashMap<String, Object>();
		
		int start = (page - 1) * pageSize;
		
		condition.put("start", start);
		condition.put("pageSize", pageSize);
		
		condition.put("uid", uid);
		List<MpUser> users = iMpUserService.listByPage(condition);
		for (int i = 0; users != null && i < users.size(); i++) {
			System.out.println(users.get(i));
		}
		return "list is ok";
	}
	
	@RequestMapping(value = "/insertMpAccount", method = RequestMethod.GET)
	@ResponseBody
	public String insertMpAccount(HttpServletRequest request, HttpServletResponse response) {
		boolean exist = true;
		String uid = "1";
		String authorizer_appid = request.getParameter("appid");
		String authorizer_access_token = request.getParameter("token");
		MpAccount mpAccount = iMpAccountService.selectMpAccountByUid(uid);
		if(mpAccount == null){		
			exist = false;
			mpAccount = new MpAccount();
			mpAccount.setUid(uid);
		}
		mpAccount.setAuthorizerAppid(authorizer_appid);
		mpAccount.setAuthorizerAccessToken(authorizer_access_token);
		mpAccount.setTokenTime(new Date());
		if(exist){
			iMpAccountService.updateMpAccountByUid(uid, mpAccount);
		}else{
			iMpAccountService.insertSelective(mpAccount);
		}
		return "list is ok";
	}
}