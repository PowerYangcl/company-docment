package cn.cecook.bean.system;

import java.io.Serializable;

/**
 * 
 * @Title BaseResultModel.java
 * @Description
 * @author wschenyongyin
 * @date 2017年5月23日
 * @version copy   @author ZHIWEN
 */

public class SysBaseResultModel implements Serializable {
	/**
	 * @explain
	 * @author ZHIWEN
	 * @date 2017年6月27日
	 */
	private static final long serialVersionUID = -7837622598896928839L;
	// 错误代码
	private String error_code;
	// 错误描述
	private String error_msg;
	private int totalCount;

	private Object data;

	public int getTotalCount() {
		return totalCount;
	}

	public void setTotalCount(int totalCount) {
		this.totalCount = totalCount;
	}

	public String getError_code() {
		return error_code;
	}

	public void setError_code(String error_code) {
		this.error_code = error_code;
	}

	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public Object getData() {
		return data;
	}

	public void setData(Object data) {
		this.data = data;
	}

	@Override
	public String toString() {
		return "SysBaseResultModel [error_code=" + error_code + ", error_msg="
				+ error_msg + ", totalCount=" + totalCount + ", data=" + data
				+ ", getTotalCount()=" + getTotalCount() + ", getError_code()="
				+ getError_code() + ", getError_msg()=" + getError_msg()
				+ ", getData()=" + getData() + ", getClass()=" + getClass()
				+ ", hashCode()=" + hashCode() + ", toString()="
				+ super.toString() + "]";
	}

	
}
