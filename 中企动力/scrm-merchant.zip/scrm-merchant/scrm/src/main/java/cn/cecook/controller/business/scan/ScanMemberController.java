package cn.cecook.controller.business.scan;

import java.io.UnsupportedEncodingException;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.CookieValue;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.bean.business.markting.exportManageErrorBean;
import cn.cecook.bean.business.markting.exportManageStoreBean;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.dao.business.customer.BcCustomerMapper;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.business.customer.BcCustomer;
import cn.cecook.service.business.markting.SynWithCRMService;
import cn.cecook.service.business.scan.ScanMemberService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.ErrorCodeConfigUtil;
import cn.cecook.uitls.ExportExcel;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.PhoneUtil;
import cn.cecook.uitls.StringUtils;
import cn.cecook.uitls.redis.RedisStringUtil;

@Controller
@RequestMapping("/scan/member")
public class ScanMemberController {
    private JsonParser jsonParser = new JsonParser();
    @Autowired
    private ScanMemberService memberService;

    /************************************* 会员列表 **********************************************/

    @RequestMapping(value = "/getPage", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getPage(@RequestBody String param) {
        String page = memberService.getPage(jsonParser.parse(param).getAsJsonObject());
        return jsonParser.parse(page).getAsJsonObject().get("data").toString();
    }
    
    /**
     * 会员数据管理页面所需接口
     * @param param
     * @return
     */
    @RequestMapping(value = "/getPageForDataManage", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getPageForDataManage(@RequestBody String param) {
        String page = memberService.getPageForDataManage(jsonParser.parse(param).getAsJsonObject());
        return jsonParser.parse(page).getAsJsonObject().get("data").toString();
    }

    @RequestMapping(value = "/saveMember", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String saveMember(@RequestBody String param, @CookieValue("tenant_id") String tenantId) {
        JsonObject jsonObject = jsonParser.parse(param).getAsJsonObject();
        JsonObject result = new JsonObject();
//        Map<String, Object> map = new HashMap<>();
//        map.put("phone", jsonObject.get("phone").getAsString());
//        map.put("tenant_id", tenantId);
//        map.put("birthday", jsonObject.get("birthday").getAsString());
//        map.put("gender", jsonObject.get("sex").getAsString());
//        map.put("QQ", jsonObject.get("QQ").getAsString());
//        map.put("status", jsonObject.get("status").getAsInt());
//        map.put("name", jsonObject.get("name").getAsString());
//        map.put("remarks", jsonObject.get("remarks").getAsString());
        BcCustomer customer = new BcCustomer();
        customer.setPhone(jsonObject.get("phone").getAsString());
        customer.setTenantId(tenantId);
        customer.setBirthday(jsonObject.get("birthday").getAsString());
        customer.setGender(jsonObject.get("sex").getAsString());
        customer.setQq(jsonObject.get("QQ").getAsString());
        customer.setStatus(jsonObject.get("status").getAsInt());
        customer.setName(jsonObject.get("name").getAsString());
        customer.setRemarks(jsonObject.get("remarks").getAsString());
        try {
        	int saveMember = memberService.saveMember(customer);
        	if(saveMember<=0) {
        		result.addProperty("msg_text", "已存在该条记录");
        	}
        	result.addProperty("msg_code", 1);
        }catch (Exception e) {
        	e.printStackTrace();
        	result.addProperty("msg_code", 0);
		}
        return result.toString();
    }

    //导入会员
    @RequestMapping(value = "/importMember", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String importMember(MultipartFile file, int type) {
        return memberService.importMember(file, type);
    }

    //导出会员
    @RequestMapping(value = "/exportMember")
    public void exportMember(HttpServletResponse response) {
        memberService.exportMember(response);
    }
    
    // 导入会员 -数据管理使用 file:要解析的excel ,type:覆盖还是跳过
    @RequestMapping(value = "/importdataManage", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String importdataManage(MultipartFile file, int type,String access_token,String uid,String tenant_id) {
        return memberService.importdataManage(file, type,access_token,uid,tenant_id);
    }

    @RequestMapping(value = "/getMember", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getMember(int id) {
        return memberService.getMember(id);
    }
    
    @RequestMapping(value = "/getMemberByPhone", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String getMemberByPhone(String phone) {
    	return memberService.getMemberByPhone(phone);
    }

    @RequestMapping(value = "/updateMember", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String updateMember(@RequestBody String param) {
        JsonObject jsonObject = jsonParser.parse(param).getAsJsonObject();
        Map<String, Object> map = new HashMap<>();
        map.put("id", jsonObject.get("id").getAsInt());
        map.put("phone", jsonObject.get("phone").getAsString());
        map.put("name", jsonObject.get("name").getAsString());
        map.put("wechat", jsonObject.get("wechat").getAsString());
        map.put("gender", jsonObject.get("gender").getAsString());
        map.put("birthday", jsonObject.get("birthday").getAsString());
        map.put("email", jsonObject.get("email").getAsString());
        map.put("QQ", jsonObject.get("QQ").getAsString());
        map.put("province", jsonObject.get("province").getAsString());
        map.put("city", jsonObject.get("city").getAsString());
        map.put("province", jsonObject.get("province").getAsString());
        map.put("weibo", jsonObject.get("weibo").getAsString());
        map.put("crm_member_level", jsonObject.get("crm_member_level").getAsString());
        map.put("type", jsonObject.get("type").getAsInt());
        map.put("status", jsonObject.get("status").getAsInt());
        map.put("remarks", jsonObject.get("remarks").getAsString());
        return memberService.updateMember(map);
    }
    
    @RequestMapping(value = "/listStore", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String listStore() {
        return memberService.listStore();
    }

    /************************************* 会员分组 **********************************************/


    /************************************* 临时 **********************************************/
    @Autowired
    private SynWithCRMService synWithCRM;
    @Autowired
    private BcCustomerMapper bcCustomerMapper;


    @RequestMapping(value = "/synMember", produces = "text/plain;charset=UTF-8")
    @ResponseBody
    public String synMember(int id) {
        BcCustomer bcCustomer = bcCustomerMapper.customerDetail(id);
        if (bcCustomer == null) {
            return "";
        }
        return synWithCRM.synMember(bcCustomer);
    }
    
    /**
     * 初始化追溯时间节点
     * @return
     */
	@RequestMapping(value = "/initHsTime",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object initHsTime() {
		return memberService.initHsTime();

	}
	
    /**
     * 初始化导入会员总数
     * @return
     */
	@RequestMapping(value = "/initHyCount",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object initHyCount() {
		return memberService.initHyCount();

	}
	
    /**
     * 初始化全部会员总数
     * @return
     */
	@RequestMapping(value = "/initAllHyCount",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object initAllHyCount() {
		return memberService.initAllHyCount();

	}
	
    /**
     * 初始自动化服务规则总数
     * @return
     */
	@RequestMapping(value = "/initAutoSeivice",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object initAutoSeivice() {
		return memberService.initAutoSeivice();

	}
	
	
    /**
     * 回溯到指定时间节点
     * @return
     */
	@RequestMapping(value = "/hsTimeNow",produces = "application/json;charset=UTF-8")
	@ResponseBody
	public Object hsTimeNow(String hsTime) {
		return memberService.hsTimeNow(hsTime);

	}
	
	// 导出导入会员数据失败报表
	@RequestMapping(value = "/exportListErrorForm")
	@ResponseBody
	public Object exportListErrorForm(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		BaseResultModel baseResultModel = new BaseResultModel();

		if (!MyCatFilter.getToken_Valid()) {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return (baseResultModel);
		}
		String access_token = request.getParameter("access_token");
//		String keyWord = java.net.URLDecoder.decode(
//				request.getParameter("keyWord"), "UTF-8");
		//String errorList = java.net.URLDecoder.decode(request.getParameter("errorList"), "UTF-8");
		String errorList = RedisStringUtil.getValue(ConfigUtil.DATA_MANAGE_LISTERRORKEY + access_token);
		List<Map<String, Object>> ListMap = FastJsonUtil.jsonToMapList(errorList);

		ExportExcel<exportManageErrorBean> ee = new ExportExcel<exportManageErrorBean>();
		List<exportManageErrorBean> dataList = new ArrayList<exportManageErrorBean>();
		for(int i=0;i<ListMap.size();i++){
			Map<String, Object> map = ListMap.get(i);
			exportManageErrorBean bean = new exportManageErrorBean();
			bean.setPhone(String.valueOf(map.get("phone")));
			bean.setName(String.valueOf(map.get("name")));
			bean.setAddress(String.valueOf(map.get("address")));
			bean.setOffice_address(String.valueOf(map.get("office_address")));
			if("m".equals(String.valueOf(map.get("gender")))){
				bean.setGender("男");
			}else if("f".equals(String.valueOf(map.get("gender")))){
				bean.setGender("女");
			}else if("n".equals(String.valueOf(map.get("gender")))){
				bean.setGender("未知");
			}
			bean.setId_card(String.valueOf(map.get("id_card")));
			bean.setIncome_range(String.valueOf(map.get("income_range")));
			if(map.get("family_size") != null ){
			bean.setFamily_size(String.valueOf(map.get("family_size")));
			}else{
			bean.setFamily_size("");	
			}
			bean.setEducation(String.valueOf(map.get("education")));
			bean.setAge_bracket(String.valueOf(map.get("age_bracket")));
			bean.setChildren_name(String.valueOf(map.get("children_name")));
			bean.setChildren_age(String.valueOf(map.get("children_age")));
			bean.setParent_name(String.valueOf(map.get("parent_name")));
			bean.setParent_age(String.valueOf(map.get("parent_age")));
			bean.setEmail(String.valueOf(map.get("email")));
			bean.setWechat(String.valueOf(map.get("wechat")));
			bean.setWeibo(String.valueOf(map.get("weibo")));
			bean.setQQ(String.valueOf(map.get("QQ")));
			bean.setCool_coin(String.valueOf(map.get("cool_coin")));
			bean.setExport_time(String.valueOf(map.get("export_time")));
			bean.setCrmScore(String.valueOf(map.get("crmScore")));
			bean.setCrm_his_score(String.valueOf(map.get("crm_his_score")));
			bean.setLevel(String.valueOf(map.get("level")));
			bean.setSource(String.valueOf(map.get("source")));
			bean.setBelong_saleper(String.valueOf(map.get("belong_saleper")));
			bean.setReferee(String.valueOf(map.get("referee")));
			bean.setStore_name(String.valueOf(map.get("store_name")));
			bean.setValue_score(String.valueOf(map.get("value_score")));
			bean.setType_customer(String.valueOf(map.get("type_customer")));
			bean.setGroup_customer(String.valueOf(map.get("group_customer")));
			if(map.get("create_time") != null){
				bean.setCreate_time(String.valueOf(map.get("create_time")));
			}else{
				bean.setCreate_time("");
			}
			bean.setCost_count(String.valueOf(map.get("cost_count")));
			bean.setCost_total(String.valueOf(map.get("cost_total")));
			bean.setGoods_total(String.valueOf(map.get("goods_total")));
			bean.setTag(String.valueOf(map.get("tag")));
			if(map.get("last_cost_time") != null){
				bean.setLast_cost_time(String.valueOf(map.get("last_cost_time")));	
			}else{
				bean.setLast_cost_time("");
			}
			bean.setLast_cost(String.valueOf(map.get("last_cost")));
			if(map.get("first_cost_time") != null){
				bean.setFirst_cost_time(String.valueOf(map.get("first_cost_time")));
			}else{
				bean.setFirst_cost_time("");
			}
			bean.setFirst_cost(String.valueOf(map.get("first_cost")));
			dataList.add(bean);
		}
		String[] headers = {"手机号码（必填）","会员姓名","居住地址","办公地址","性别","身份证","收入区间","家庭人数","学历","年龄段","子女姓名","子女年龄",
							"家中老人","老人年龄","邮箱","微信号","微博号","QQ号","酷币","现有积分","历史积分","会员等级","渠道来源","所属销售","推荐人",
							"所属门店","价值评分","会员分类","会员分组","入会日期","购买次数","购买总额","购买总件数","标签","最后购买时间","最后次购买金额"," 首次购买时间","首次购买金额"};
		String fileName = "导出失败列表"
				+ DateUtils.DateToString(new Date(), "yyyy-MM-dd");
		int state = ee.exportExcel(headers, dataList, fileName, response);
		if (state == 1) {
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			return (baseResultModel);
		} else {
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			return baseResultModel;
		}

	}
	
	
	// 导出导入会员数据失败报表
	@RequestMapping(value = "/downExportTemplate")
	@ResponseBody
	public Object downExportTemplate(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		BaseResultModel baseResultModel = new BaseResultModel();
		
        //从缓存中获取当前用户的tenant_id，用作查询
        Cookie[] cookie=request.getCookies();
        //获取当前用户的租户ID
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {	
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
         } 
		
		if (!MyCatFilter.getToken_Valid()) {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return (baseResultModel);
		}
		String access_token = request.getParameter("access_token");
		//查询品牌下的全部门店
		List<exportManageStoreBean> dataList2 = memberService.getAllStoreByTenantId(tenant_id);

		ExportExcel<exportManageErrorBean> ee = new ExportExcel<exportManageErrorBean>();
		List<exportManageErrorBean> dataList1 = new ArrayList<exportManageErrorBean>();
		//List<exportManageStoreBean> dataList2 = new ArrayList<exportManageStoreBean>();
			
		String[] headers = {"手机号码（必填）","会员姓名","居住地址","办公地址","性别","身份证","收入区间","家庭人数","学历","年龄段","子女姓名","子女年龄",
							"家中老人","老人年龄","邮箱","微信号","微博号","QQ号","酷币","现有积分","历史积分","会员等级","渠道来源","所属销售","推荐人",
							"所属门店所属门店ID(需与当前品牌门店对应，详见Sheet2)","价值评分","会员分类","会员分组","入会日期","购买次数","购买总额","购买总件数","标签","最后购买时间","最后次购买金额"," 首次购买时间","首次购买金额"};
		
		String[] headers2 = {"门店ID","门店名称"};
		
		String fileName = "会员模板";
		String fileName2 = "门店范围";
		String templateName = "template";
		int state = ee.exportExcelTwoSheet(headers,headers2,dataList1,dataList2,fileName,fileName2,templateName,response);
		if (state == 1) {
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			return (baseResultModel);
		} else {
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			return baseResultModel;
		}

	}
	

	
	@RequestMapping(value = "/getCustomerIdByPhone")
    @ResponseBody
    public Object getCustomerIdByPhone(String phone) {
    	System.out.println(phone);
        return memberService.getCustomerIdByPhone(phone);
    }
}