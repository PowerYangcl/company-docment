package cn.cecook.model.business.customer;

import java.util.Date;

/**
 * 
 * @Title: BcCustomerDimension
 * @Package
 * @Description: 客户维度表
 * @author : ning
 * @date : 2017年5月26日
 * @version V1.0
 */
public class BcUserDimension {

    private int id; // ID
    private String uuid; // 唯一标识
    private String tenantId;// 租户ID
    private int userId;// 用户ID
    private Date createTime;// 创建时间
    private String oldCustomerDay;// 老用户天数
    private String oldCustomerFrequency; // 老用户次数
    private String newCustomerDay;// 新用户天数
    private String newCustomerFrequency;// 新用户次数
    private String travelerDay; // 过客天数
    private String travelerFrequency; // 过客天数
    private String regularDay;// 常客天数
    private String regularFrequency; // 常客次数
    private String loyalCustomerDay; // 忠实的客户天数
    private String loyalCustomerFrequency; // 忠实的客户天数
    private String mainForce; // 主力客户
    private String sCommonlyCustomer; // 一般客户最小值
    private String bCommonlyCustomer; // 一般客户最大值
    private String scatteredCustomer; // 零散客户
    private String loseCustomer; // 流失客户
    private String bak1;// 备用字段
    private String bak2;// 备用字段
    private String bak3;// 备用字段
    private String bak4;// 备用字段
    private String bak5;// 备用字段

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid;
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId;
    }

    public int getUserId() {
        return userId;
    }

    public void setUserId(int userId) {
        this.userId = userId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOldCustomerDay() {
        return oldCustomerDay;
    }

    public void setOldCustomerDay(String oldCustomerDay) {
        this.oldCustomerDay = oldCustomerDay;
    }

    public String getOldCustomerFrequency() {
        return oldCustomerFrequency;
    }

    public void setOldCustomerFrequency(String oldCustomerFrequency) {
        this.oldCustomerFrequency = oldCustomerFrequency;
    }

    public String getNewCustomerDay() {
        return newCustomerDay;
    }

    public void setNewCustomerDay(String newCustomerDay) {
        this.newCustomerDay = newCustomerDay;
    }

    public String getNewCustomerFrequency() {
        return newCustomerFrequency;
    }

    public void setNewCustomerFrequency(String newCustomerFrequency) {
        this.newCustomerFrequency = newCustomerFrequency;
    }

    public String getTravelerDay() {
        return travelerDay;
    }

    public void setTravelerDay(String travelerDay) {
        this.travelerDay = travelerDay;
    }

    public String getTravelerFrequency() {
        return travelerFrequency;
    }

    public void setTravelerFrequency(String travelerFrequency) {
        this.travelerFrequency = travelerFrequency;
    }

    public String getRegularDay() {
        return regularDay;
    }

    public void setRegularDay(String regularDay) {
        this.regularDay = regularDay;
    }

    public String getRegularFrequency() {
        return regularFrequency;
    }

    public void setRegularFrequency(String regularFrequency) {
        this.regularFrequency = regularFrequency;
    }

    public String getLoyalCustomerDay() {
        return loyalCustomerDay;
    }

    public void setLoyalCustomerDay(String loyalCustomerDay) {
        this.loyalCustomerDay = loyalCustomerDay;
    }

    public String getLoyalCustomerFrequency() {
        return loyalCustomerFrequency;
    }

    public void setLoyalCustomerFrequency(String loyalCustomerFrequency) {
        this.loyalCustomerFrequency = loyalCustomerFrequency;
    }

    public String getMainForce() {
        return mainForce;
    }

    public void setMainForce(String mainForce) {
        this.mainForce = mainForce;
    }

    public String getsCommonlyCustomer() {
        return sCommonlyCustomer;
    }

    public void setsCommonlyCustomer(String sCommonlyCustomer) {
        this.sCommonlyCustomer = sCommonlyCustomer;
    }

    public String getbCommonlyCustomer() {
        return bCommonlyCustomer;
    }

    public void setbCommonlyCustomer(String bCommonlyCustomer) {
        this.bCommonlyCustomer = bCommonlyCustomer;
    }

    public String getScatteredCustomer() {
        return scatteredCustomer;
    }

    public void setScatteredCustomer(String scatteredCustomer) {
        this.scatteredCustomer = scatteredCustomer;
    }

    public String getLoseCustomer() {
        return loseCustomer;
    }

    public void setLoseCustomer(String loseCustomer) {
        this.loseCustomer = loseCustomer;
    }

    public String getBak1() {
        return bak1;
    }

    public void setBak1(String bak1) {
        this.bak1 = bak1;
    }

    public String getBak2() {
        return bak2;
    }

    public void setBak2(String bak2) {
        this.bak2 = bak2;
    }

    public String getBak3() {
        return bak3;
    }

    public void setBak3(String bak3) {
        this.bak3 = bak3;
    }

    public String getBak4() {
        return bak4;
    }

    public void setBak4(String bak4) {
        this.bak4 = bak4;
    }

    public String getBak5() {
        return bak5;
    }

    public void setBak5(String bak5) {
        this.bak5 = bak5;
    }

}
