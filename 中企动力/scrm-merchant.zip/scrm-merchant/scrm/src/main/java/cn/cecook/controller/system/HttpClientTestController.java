package cn.cecook.controller.system;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.io.IOException;
import java.io.PrintWriter;
import java.util.Enumeration;


/**
 * 
 *@explain
 * @author ZHIWEN
 * @data 2017年7月13日
 */
@Controller
@RequestMapping("/test")
public class HttpClientTestController {
       /**
        * post请求测试
        */
	@RequestMapping(value="/HttpClientTest" 
			,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public void test(HttpServletRequest request,HttpServletResponse response) {
		String paramsString =request.getParameter("name");
		System.out.println("httpclient测试"+paramsString);
		 Enumeration headerNames = request.getHeaderNames();
		    while (headerNames.hasMoreElements()) {
		        String key = (String) headerNames.nextElement();
		        String value = request.getHeader(key);
		        System.out.println("响应头"+key+":"+value);
		    }
		    try {
		    	String string= "获取响应内容666";
		    	response.setContentType("application/json");
		    	response.setCharacterEncoding("utf-8");
				PrintWriter out = response.getWriter();
				out.write("获取响应内容777");
				out.print(string);
				Cookie cookie = new Cookie("test", "fake you mather");
		        response.addCookie(cookie);
				response.addHeader("qweq", "99999");
				response.addHeader("wenwen", "66666");
			} catch (IOException e) {
				// TODO Auto-generated catch block
				e.printStackTrace();
			}
	}

}
