package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.service.CriterionMedicine;

/**
 * 操作标准药品库的mapper
 * @author majie
 *
 */
public interface CriterionMedicineMapper {
	/**
	 * 查询所有数据(可分页和条件查询)
	 * @return
	 * majie
	 */
	public List<CriterionMedicine> findList(CriterionMedicine criterionMedicine);
	/**
	 * 添加数据
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public Integer addCriterionMedicine(CriterionMedicine criterionMedicine);
	/**
	 * 修改数据
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public Integer updateCriterionMedicine(CriterionMedicine criterionMedicine);
	/**
	 * 得到记录总数
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public Integer getCount(CriterionMedicine criterionMedicine);
	/**
	 * 根据Id查询得到单个记录
	 * @param id
	 * @return
	 * majie
	 */
	public CriterionMedicine getCriterionMedicine(Integer id);
	/**
	 * 根据指定条件查询
	 * @param criterionMedicine
	 * @return
	 * majie
	 */
	public List<CriterionMedicine> findByProp(Map<String,Object> map);

}
