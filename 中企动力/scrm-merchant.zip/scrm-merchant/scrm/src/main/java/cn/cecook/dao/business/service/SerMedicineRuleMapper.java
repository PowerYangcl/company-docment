package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.service.SerMedicineRule;

public interface SerMedicineRuleMapper {


    int deleteByPrimaryKey(Integer id);


    int insertSelective(SerMedicineRule record);

    
    int insertByBatch(List<SerMedicineRule> ruleList);

    SerMedicineRule selectByPrimaryKey(Integer id);



    int updateByPrimaryKeySelective(SerMedicineRule record);
    
    int updateBatch(List<Map<String, Object>> item);
    
    //根据药品id查询模板列表
    List<Map<String,Object>> getModelListByMedicineId(int medicineId);
    
    int deleteByBatch(@Param("automated_task_id")int automated_task_id);
}