package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.service.business.markting.CardActivityAuthorityService;
import cn.cecook.thirdparty.weibo.util.LongUrl2ShortUtil;
import cn.cecook.uitls.ConfigStatusCode;

@Controller
@RequestMapping("/api/CardActivityAuthor")
public class CardActivityAuthorityController {
	@Autowired
	CardActivityAuthorityService caas;
	@Value("#{configProperties['H5_LOGIN_URL']}")
    private String FILE_URL;
	
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(String tenant_id, String businessIds, Integer business_tag, String activityIds,Integer activity_tag, String departmentIds, String inform,String isSendSms) {
		
		return caas.update(tenant_id, businessIds, business_tag, activityIds, activity_tag, departmentIds, inform,isSendSms);
	}
	@RequestMapping(value = "/getUrl")
	@ResponseBody
	public Object getProjectUrl(){
		BaseResultModel baseResultModel=new BaseResultModel();		
		baseResultModel.setData(FILE_URL);
		baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		return baseResultModel;
	}
	
}
