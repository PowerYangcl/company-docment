package cn.cecook.dao.business.scan;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.scan.ScanFindPeople;
import cn.cecook.model.business.scan.ScanFindPeopleExample;
import cn.cecook.uitls.Pages;

public interface ScanFindPeopleMapper {
    long countByExample(ScanFindPeopleExample example);

    int deleteByExample(ScanFindPeopleExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ScanFindPeople record);

    int insertSelective(ScanFindPeople record);

    List<ScanFindPeople> selectByExample(ScanFindPeopleExample example);

    ScanFindPeople selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ScanFindPeople record, @Param("example") ScanFindPeopleExample example);

    int updateByExample(@Param("record") ScanFindPeople record, @Param("example") ScanFindPeopleExample example);

    int updateByPrimaryKeySelective(ScanFindPeople record);

    int updateByPrimaryKey(ScanFindPeople record);
    
    /**
     * 	根据ruleId获取最大时间
     * @param map
     * @return
     */
    Timestamp getMaxDate(Map<String, Object> map);
    
    /**
     * 	根据微博id，获取微博
     * @param status_id
     * @return
     */
    ScanFindPeople getWeibo(Map<String, Object> map);
    
    /**
     * 	获取性别统计
     * @param ruleId
     * @return
     */
    List<Map<String, Object>> getSex(Integer ruleId);
    
    /**
     * 	加V统计
     * @param ruleId
     * @return
     */
    List<Map<String, Object>> getIsV(Integer ruleId);
    
    /**
     * 	是否关注当前微博统计
     * @param ruleId
     * @return
     */
    List<Map<String, Object>> getIsFollowMe(Integer ruleId);
    
    /**
     * 分页
     * @param page
     * @return
     */
    List<Map<String, Object>> getPage(Pages<Map<String, Object>> page);
    int count(Map<String, Object> where);
    
    void delByRuleId(int ruleId);
    
    /**
     * 根据日期获取全部线索及其对应的挖掘用户
     * @return
     */
	List<Map<String, Object>> getExcavateUserNum(String startTime);
}