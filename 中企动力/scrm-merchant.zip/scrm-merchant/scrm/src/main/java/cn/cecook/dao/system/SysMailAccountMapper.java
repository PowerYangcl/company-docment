package cn.cecook.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysMailAccount;


public interface SysMailAccountMapper {
   int insert_mail_account(SysMailAccount sysMailAccount)throws Exception;
   int DeleteMailAccount(@Param(value = "userId") Long userId, @Param(value = "tenantId") String tenantId)throws Exception;
   SysMailAccount SelectMailAccount(@Param(value = "userId") Long userId, @Param(value = "tenantId") String tenantId)throws Exception;
   List<SysMailAccount> SelectMailAccountByAccount(@Param(value = "mail") String mail);
   SysMailAccount SelectMailAccountforother(@Param(value = "userId") Long userId);
   SysMailAccount SelectMailAccountforothers(String tenantId);
}
