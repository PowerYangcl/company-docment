package cn.cecook.model.business.automation;
/**
 * 会员行为
 * @author majie
 *
 * 2018年1月22日-下午5:14:09
 */
public enum CustomerAction {
	//核销，未核销，转化
	CANCEL,NO_CANCEL,CHANGE
}
