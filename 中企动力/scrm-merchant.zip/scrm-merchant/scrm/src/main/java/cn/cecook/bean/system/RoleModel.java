package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.HashMap;
import java.util.Map;

@Component
public class RoleModel implements Serializable {
	//公用部分
	//access_token
	private String access_token ;
	//用户id
	private String uid ;
	//租户id
	private String  tenant_id ;
	
	//角色
	//角色id
	private String role_id ;
	//角色名称
	private String rname ;
	//权限列表
	private Map auth_list ;
	private String description;
	private int operation;
	//将权限列表对象初始化
	{
		auth_list  =  new  HashMap<String, Object>();
		auth_list.put("menu_auth_id", null);
		auth_list.put("menu_auth_name", null);
		Map action_auth_list = new HashMap<>();
		action_auth_list.put("action_auth_id", null);
		action_auth_list.put("action_auth_name", null);
		auth_list.put("action_auth_list", action_auth_list);
		
	}
	
	public String getDescription() {
		return description;
	}
	public void setDescription(String description) {
		this.description = description;
	}
	//当前角色位置id 
	private String self;
	//上一页位置id
	private String prev;
	//下一页位置id
	private String next;

	
	public int getOperation() {
		return operation;
	}
	public void setOperation(int operation) {
		this.operation = operation;
	}
	/*
	 * set get
	 */
	public String getSelf() {
		return self;
	}
	public void setSelf(String self) {
		this.self = self;
	}
	public String getPrev() {
		return prev;
	}
	public void setPrev(String prev) {
		this.prev = prev;
	}
	public String getNext() {
		return next;
	}
	public void setNext(String next) {
		this.next = next;
	}
	public String getAccess_token() {
		return access_token;
	}
	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTenant_id() {
		return tenant_id;
	}
	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}
	public String getRole_id() {
		return role_id;
	}
	public void setRole_id(String role_id) {
		this.role_id = role_id;
	}
	public String getRname() {
		return rname;
	}
	public void setRname(String rname) {
		this.rname = rname;
	}
	public Map getAuth_list() {
		return auth_list;
	}
	public void setAuth_list(Map auth_list) {
		this.auth_list = auth_list;
	}
	
}
