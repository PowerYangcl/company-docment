package cn.cecook.controller.business.customer;

import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;

import cn.cecook.service.business.customer.ICustomerSourceService;

/**
 * 客户来源controller
 * @Title: CustomerSourceController
 * @Package 
 * @Description:
 * @author : ning
 * @date : 2017年6月16日
 * @version V1.0
 */
@RequestMapping("/api/customeSource")
@Controller
public class CustomerSourceController {

    @Autowired
    private ICustomerSourceService customerSourceService;

    /**
     * 获取用户来源列表
     * @param request
     * @return
     */
    @RequestMapping(value = "/getCustomerSourceList")
    @ResponseBody
    public String getCustomerSourceList(HttpServletRequest request) {
        JsonObject j = customerSourceService.getCustomerSourceList();
        return j.toString();
    }
}
