/**
 * 
 */
package cn.cecook.intercept.shiro;


import cn.cecook.dao.system.SysRoleAuthorityMapper;
import cn.cecook.dao.system.SysRoleMapper;
import cn.cecook.dao.system.SysUserMapper;
import cn.cecook.dao.system.SysUserRoleMapper;
import cn.cecook.model.system.SysRoleAuthority;
import cn.cecook.model.system.SysUser;
import cn.cecook.uitls.FastJsonUtil;

import org.apache.shiro.authc.*;
import org.apache.shiro.authz.AuthorizationInfo;
import org.apache.shiro.authz.SimpleAuthorizationInfo;
import org.apache.shiro.realm.AuthorizingRealm;
import org.apache.shiro.session.mgt.eis.SessionDAO;
import org.apache.shiro.subject.PrincipalCollection;
import org.springframework.beans.factory.annotation.Autowired;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import java.util.*;

/**
 * @explain
 * @author wschenyongyin
 * @date 2017年5月9日
 */
public class MyShiroRealm extends AuthorizingRealm {

	@Resource
	private SysUserMapper sysUserMapper;
	@Resource
	private SysRoleAuthorityMapper sysRoleAuthorityMapper;
	@Resource
	private SysUserRoleMapper sysUserRoleMapper;
	@Resource
	private SysRoleMapper sysRoleMapper;
	@Resource
	private HttpServletRequest request;
	@Autowired
	private SessionDAO sessionDAO;
	
    //@Autowired
    //private RedisCache<String, Object> redisCache;
    
	/**
	 * 权限认证 当需要检查用户权限时自动调用此方法。注意：该权限控制的是访问权限，不是菜单权限和数据权限
	 * 
	 */
	@Override
	protected AuthorizationInfo doGetAuthorizationInfo(
			PrincipalCollection principals) {
		//根据用户名获取到他所拥有的角色以及权限，然后赋值到SimpleAuthorizationInfo对象中即可，Shiro就会按照我们配置的XX角色对应XX权限来进行判断
		SimpleAuthorizationInfo authorizationInfo = new SimpleAuthorizationInfo();
		// 1.先获取用户名，然后根据用户名从数据库,PrincipalCollection这个可以理解为当事人的信息,登陆后会传递这个信息到doGetAuthorizationInfo方法
		SysUser user = (SysUser) getAvailablePrincipal(principals);
		//获取用户信息
		SysUser sysUser = sysUserMapper.selectSysUserByAccount(user.getAccount());
		//HttpSession session = request.getSession();
		List<String> auths = new ArrayList<String>();
		
		Map<String,Object> map = new HashMap<String, Object>();
		//如果用户为空，此处应编写逻辑跳转到登陆页面
		if(sysUser == null){
			return null;
		}else{
		//拿到用户id和租户id
		map.put("uid", sysUser.getId());
		map.put("tenant_id", sysUser.getTenantId());
		
		// 2.从数据库获取用户角色类型
		Set<String> roles = new HashSet<String>();
		// 3.从数据库获取用户权限
		Set<String> permissions = new HashSet<String>();
		//不管什么权限的用户登录，都会add一个login,登陆权限
		permissions.add("login");
		//根据用户和租户ID获取用户的全部角色
		List<Long> roleList = sysUserRoleMapper.selectRoleByUid(map);
		//遍历角色ID
		for (Long rid : roleList) {
			map.put("role_id", rid);
//			SysRole role = sysRoleMapper.selectRoleByRoleId(map);
//			roles.add(role.getName());
			//获取指定角色的权限集合
			ArrayList<SysRoleAuthority> authList = sysRoleAuthorityMapper.selectAuthorityByRoleId(map);
			//System.out.println("用户权限---->"+ GsonTools.createJsonString(authList));
			//遍历权限集合
			for (SysRoleAuthority sysRA : authList) {
				//给login增加含有的访问权限
				permissions.add(sysRA.getAuthorityNameEn());
				//增加用户放在session中的用户控制权限
				auths.add(sysRA.getAuthorityNameEn());
			}
		}
		
		//以下逻辑没有被其他处调用，故屏蔽 2017-11-29 zhangHao
		
		//将用户的控制权限放入session
		//if(session != null){
		//	String strip = StringUtils.strip(auths.toString(),"[]");
		//	session.setAttribute("authoritys", strip);
		//}
		
		//roles.add("admin");
		//permissions.add("create");
		//permissions.add("update");
		// 4.为用户设置角色、权限
		authorizationInfo.setStringPermissions(permissions);
		authorizationInfo.setRoles(roles);
		// 5.返回权限信息
		return authorizationInfo;
		}
	}

	/**
	 * 身份认证 当用户需要身份认证时会自动调用这个方法
	 */
	@Override
	protected AuthenticationInfo doGetAuthenticationInfo(
			AuthenticationToken token) throws AuthenticationException {
		// 1.获取用户名、密码  
		UsernamePasswordToken upt = (UsernamePasswordToken)token;
		String loginName= upt.getUsername();

		// 用户名
		String username = upt.getUsername();
		// 密码
		String password = new String((char[]) upt.getPassword());
		
		// 2.从数据库查询用户信息
		SysUser user = sysUserMapper.selectSysUserByAccount(username);
		// 3.将获取的用户名密码和数据库用户名密码进行比对
		if(user != null){
			return new SimpleAuthenticationInfo(user,user.getPwd(),this.getName());
		}
		// 4身份验证通过,返回一个身份信息

		return null;
	}

}
