package cn.cecook.dao.open.mp;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpUser;
import cn.cecook.model.open.mp.MpUserMemberStat;
import cn.cecook.model.open.mp.MpUserProvinceStat;
import cn.cecook.model.open.mp.MpUserSexStat;
import cn.cecook.model.open.mp.MpUserSystemStat;

public interface MpUserMapper {

	void insert(MpUser mpUser);

	public void delByTenantId(@Param(value = "tenant_id") String tenant_id);

	public List<MpUser> listByPage(Map<String, Object> condition);
	
	public int getAllCount(Map<String, Object> condition);
	
	public int updateUser(Map<String, Object> mpUser);
	
	public void clearUserMemberInfo(int user_id);

	public MpUser getUserByPhone(@Param(value = "phone") String phone);
	
	public MpUser getUserByOpenid(@Param(value = "openid") String openid);

	public int deleteUserGroup(int groupid);
	
	public void deleteTag(@Param(value = "tagId") int tagId);

	public int getTargetUserCount(@Param(value = "condition") Map<String, Object> condition);

	public List<MpUser> getTargetUserList(@Param(value = "tenant_id") String tenant_id, @Param(value = "condition") Map<String, Object> condition);
	
	public List<MpUserProvinceStat> getProvinceInfo();
	
	public List<MpUserSexStat> getSexStat();
	
	public List<MpUserMemberStat> getMemberStat();
	
	public List<MpUserSystemStat> getSystemStat();
	
}
