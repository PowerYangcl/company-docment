package cn.cecook.controller.api;


import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;
import org.springframework.web.servlet.view.RedirectView;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.thirdparty.weixin.WeiXinAccessTokenModel;
import cn.cecook.thirdparty.weixin.WeiXinOAuth;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.CookieUtil;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@Controller
@RequestMapping(value = "/api/auth")
public class WeiXinAuthController {
	@Autowired
	private WeiXinOAuth weiXinOAuth;

	/**
	 * 读取、存储OpenID
	 *
	 * @param code
	 * @param path
	 * @param request
	 * @param response
	 * @return
	 */
	
	
	@RequestMapping(value = "", method = { RequestMethod.GET })
	public ModelAndView auth(String code, String path,
			HttpServletRequest request, HttpServletResponse response) {
		ModelAndView mav = new ModelAndView();
		BaseResultModel result = weiXinOAuth.GetWeiXinInfo(code);
		if (result.getError_code().equals(ConfigStatusCode.SUCCESS_CODE)) {
			WeiXinAccessTokenModel weiXinUserInfoResult = (WeiXinAccessTokenModel) result
					.getData();
				CookieUtil.setCookie(response, "weixinOpenId",
						weiXinUserInfoResult.getOpenid(), 60 * 60);
		}
		mav.setView(new RedirectView(path));
		return mav;
	}

	/*
	 * 微信通过code获取用户openid
	 */
	@RequestMapping(value = "/getWeiXinAppInfo")
	@ResponseBody
	public BaseResultModel GetWeiXinInfo(String code) {
		return weiXinOAuth.getWeiXinAppInfo(code);
	}

}
