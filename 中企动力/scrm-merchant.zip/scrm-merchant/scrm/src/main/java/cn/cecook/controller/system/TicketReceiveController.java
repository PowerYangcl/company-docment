package cn.cecook.controller.system;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

@Controller
@RequestMapping("/ui/ticketReceive")
public class TicketReceiveController {


    @RequestMapping("/toSet")
    public ModelAndView toSetTicketTemplate() {
        ModelAndView modelAndView = new ModelAndView("sys/setTicketTemplate");
        return modelAndView;

    }


}
