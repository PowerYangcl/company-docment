package cn.cecook.dao.open.mp;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpStatistic;
import cn.cecook.model.open.mp.MpUserSourceStat;

public interface MpStatisticMapper {

	public int getCount(@Param(value = "tenant_id") String tenantId);
	public Date getMaxDate(@Param(value = "tenant_id") String tenantId);
	public List<MpStatistic> selectByTenantId(@Param(value = "tenant_id") String tenantId);
	public List<MpStatistic> selectByTime(@Param(value = "tenant_id") String tenantId, @Param(value = "startTime") Date startTime, @Param(value = "endTime") Date endTime);
	public void save(@Param(value = "tenant_id") String tenantId, @Param(value = "mpStatistic") MpStatistic mpStatistic);
	public void delByTenantId(@Param(value = "tenant_id") String tenantId);
	public MpUserSourceStat getSourceStat();
}
