package cn.cecook.model.business.automation;
/**
 * 执行时间类型
 * @author majie
 *
 * 2018年1月22日-下午4:51:27
 */
public enum DateType{
	//立即、自定义、生日、之后
	NOW,CUSTOM,BIRTHDAY,AFTER
}
