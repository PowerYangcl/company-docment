package cn.cecook.dao.open.mp;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpMaterial;

public interface MpMaterialMapper {

	public MpMaterial selectMaterialBymediaId(@Param(value = "tenant_id") String tenant_id, @Param(value = "media_id") String media_id);
	public List<MpMaterial> selectMaterial(@Param(value = "tenant_id") String tenant_id, @Param(value = "pageStart") int pageStart, @Param(value = "pageSize") int pageSize);
	
	public int getCount(@Param(value = "tenant_id") String tenant_id);
	
	public void save(MpMaterial mpMaterial);
	
	public void delAll(@Param(value = "tenant_id") String tenant_id);
	public void del(@Param(value = "tenant_id") String tenant_id, @Param(value = "media_id") String media_id);
}
