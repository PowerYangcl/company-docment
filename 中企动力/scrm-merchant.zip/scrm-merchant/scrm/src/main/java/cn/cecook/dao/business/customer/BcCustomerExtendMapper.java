package cn.cecook.dao.business.customer;

import java.util.ArrayList;
import java.util.Map;

import cn.cecook.model.business.customer.BcCustomerExtend;

/**
 * 
 *@explain 客户扩展信息dao
 * @author ZHIWEN
 * @data 2017年7月20日
 */

public interface BcCustomerExtendMapper {
	/*
	 * 新增客户扩展信息
	 */
    int Inster_BcCustomerExtend(BcCustomerExtend bcCustomerExtend);
    /*
	 * 查询客户扩展信息
	 */
    ArrayList<BcCustomerExtend>  Find_BcCustomerExtendById(Integer id);
    /*
	 * 移除客户扩展信息
	 */
    int Remove_BcCustomerExtendBytypeandkey(Map<String, Object> map);
    /*
	 * 查询客户扩展信息为条件判断新增或更新
	 */
    ArrayList<BcCustomerExtend> Find_BcCustomerExtendByIdandtypeandname(BcCustomerExtend bcCustomerExtend);
    /*
	 * 更新客户扩展信息
	 */
    int update_BcCustomerExtendByidtypeandkey(BcCustomerExtend bcCustomerExtend);
}
