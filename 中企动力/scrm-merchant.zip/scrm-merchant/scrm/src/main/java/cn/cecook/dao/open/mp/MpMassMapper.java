package cn.cecook.dao.open.mp;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpMass;

public interface MpMassMapper {

	public int getCount();
	public int getCountByCondition(@Param(value = "dateStart") Date dateStart, @Param(value = "dateEnd") Date dateEnd, @Param(value = "keyword") String keyword);
	public MpMass get(int id);
	public void insert(@Param(value = "mpMass") MpMass mpMass);
	public void update(@Param(value = "tenant_id") String tenantId, @Param(value = "mpMass") MpMass mpMass);
	public void del(int id);
	public List<MpMass> selectByMsgId(@Param(value = "tenant_id") String tenant_id, @Param(value = "msg_id") String msgId);
	public List<MpMass> selectByPage(@Param(value = "tenant_id") String tenant_id, @Param(value = "pageStart") int pageStart, @Param(value = "pageSize") int pageSize);
	public List<MpMass> selectByPageAndCondition(@Param(value = "tenant_id") String tenant_id, @Param(value = "pageStart") int pageStart, @Param(value = "pageSize") int pageSize, @Param(value = "dateStart") Date dateStart, @Param(value = "dateEnd") Date dateEnd, @Param(value = "keyword") String keyword);
	public List<MpMass> selectOnTime(@Param(value = "tenant_id") String tenant_id);

}
