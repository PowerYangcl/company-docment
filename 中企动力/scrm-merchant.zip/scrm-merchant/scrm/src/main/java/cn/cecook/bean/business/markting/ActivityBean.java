package cn.cecook.bean.business.markting;

import java.io.Serializable;
import java.sql.Timestamp;
import java.util.Date;

/**
 * 
 * @Title ActivityBean.java
 * @Description 活动实体类
 * @author wschenyongyin
 * @date 2017年5月24日
 * @version 1.0
 */
public class ActivityBean implements Serializable {
	//
	public String getPic_url() {
		return pic_url;
	}

	public void setPic_url(String pic_url) {
		this.pic_url = pic_url;
	}

	private String pic_url;
	// id
	private Long id;

	private String tenant_id;
	// 删除标记
	private Integer isDeleted;

	// 创建人ID
	private Long createId;

	// 创建时间
	private Timestamp createTime;

	// 排序标示
	private String orderCode;

	// 删除时间
	private Date deleteTime;

	// 备注
	private String remarks;

	// 附件
	private String attachment;

	// 名称
	private String name;
	// 活动头图
	private String head_pic;
	// 描述
	private String description;

	// 活动页面地址
	private String web_url;

	// 图片地址集合
	private String activity_pics;

	// 优惠券发送方式
	private String coupon_send_type;

	// 活动开始时间
	private String start_date;

	// 有效天数
	private Integer effective_day;

	// 有效状态
	private Integer effective_status;

	// 优惠券数量
	private Integer coupon_number;

	// 活动标签（酷客定义）
	private String tag;

	// 自定义标签
	private String tag_defined;

	// 分享显示的标题
	private String title;

	// 分享显示的文案
	private String content;

	// 分享显示的图
	private String pic;

	// 活动状态
	private Integer status;

	// 审核状态
	private Integer check_status;

	// 审核描述
	private String check_descrption;

	// 活动概览
	private String overview;

	// 统计值
	private String statistic;

	// 分享渠道
	private String share_channel;

	// 打开数
	private String browse_number;

	// 提交表单数
	private String submit_numer;

	// 活动模板id
	private int model_id;
	// 转化比例
	private String ratio;
	// 通过微信渠道打开次数
	private int weibo_num;
	// 通过微博渠道打开次数
	private int weixin_num;
	// 通过qq渠道打开次数
	private int qq_num;
	// 核销数量
	private int varication_num;
	// 提交表达数量
	private int submit_weixin_num;
	private int submit_weibo_num;
	private int submit_qq_num;
	// 领取优惠券数量
	private int receive_coupon;
	// 转发次数
	private int transmit_num;
	// 点击次数
	private int click_num;

	// 活动消费金额
	private double activity_amount;

	// 微信转化率
	private double weixin_ratio;
	// 微博转换率
	private double weibo_ratio;
	// qq转化率
	private double qq_ratio;
	// 领取优惠券数量
	private int total;
	// 其他渠道
	private int otherClick;
	private int otherSubmit;
	private double otherRatio;

	private int twiceClick;
	private int twiceReceive;
	private int twiceVarication;
	private int twiceTransmit;

	private int type;

	private int transmit_rule;

	private String start_time;

	private String end_time;
	private int coupon_expire_day;

	private String equipment_facilities;
	private String original_price;
	private String discount_price;
	private String activity_restrict;
	private String commit_info;
	private String weibo_qrcode;
	private String weixin_qrcode;
	private String detail_rule;
	private String background_pic;
	private String background_music;
	private String protrait_tag;
	private String button_text;
	private String button_css;
	private String theme_info;
	private String theme_info_color;
	private String text_info_color;

	private String bak1;
	private String bak2;
	private String bak3;
	private String bak4;
	private String bak5;
	
	private int coupon_id;
	private String coupon_name;
	private int sms_batch_id;
	
	private String activity_tag;
	
	private Integer distinction;
	
	private Integer couponFlag;
	

	public Integer getCouponFlag() {
		return couponFlag;
	}

	public void setCouponFlag(Integer couponFlag) {
		this.couponFlag = couponFlag;
	}

	public String getActivity_tag() {
		return activity_tag;
	}

	public void setActivity_tag(String activity_tag) {
		this.activity_tag = activity_tag;
	}

	public int getCoupon_id() {
		return coupon_id;
	}

	public void setCoupon_id(int coupon_id) {
		this.coupon_id = coupon_id;
	}

	public String getCoupon_name() {
		return coupon_name;
	}

	public void setCoupon_name(String coupon_name) {
		this.coupon_name = coupon_name;
	}

	public int getSms_batch_id() {
		return sms_batch_id;
	}

	public void setSms_batch_id(int sms_batch_id) {
		this.sms_batch_id = sms_batch_id;
	}

	private Object extendField;

	public Object getExtendField() {
		return extendField;
	}

	public void setExtendField(Object extendField) {
		this.extendField = extendField;
	}

	public int getOtherClick() {
		return otherClick;
	}

	public void setOtherClick(int otherClick) {
		this.otherClick = otherClick;
	}

	public int getOtherSubmit() {
		return otherSubmit;
	}

	public void setOtherSubmit(int otherSubmit) {
		this.otherSubmit = otherSubmit;
	}

	public double getOtherRatio() {
		return otherRatio;
	}

	public void setOtherRatio(double otherRatio) {
		this.otherRatio = otherRatio;
	}

	public int getTwiceClick() {
		return twiceClick;
	}

	public void setTwiceClick(int twiceClick) {
		this.twiceClick = twiceClick;
	}

	public int getTwiceReceive() {
		return twiceReceive;
	}

	public void setTwiceReceive(int twiceReceive) {
		this.twiceReceive = twiceReceive;
	}

	public int getTwiceVarication() {
		return twiceVarication;
	}

	public void setTwiceVarication(int twiceVarication) {
		this.twiceVarication = twiceVarication;
	}

	public int getTwiceTransmit() {
		return twiceTransmit;
	}

	public void setTwiceTransmit(int twiceTransmit) {
		this.twiceTransmit = twiceTransmit;
	}

	public String getTheme_info() {
		return theme_info;
	}

	public void setTheme_info(String theme_info) {
		this.theme_info = theme_info;
	}

	public String getTheme_info_color() {
		return theme_info_color;
	}

	public void setTheme_info_color(String theme_info_color) {
		this.theme_info_color = theme_info_color;
	}

	public String getText_info_color() {
		return text_info_color;
	}

	public void setText_info_color(String text_info_color) {
		this.text_info_color = text_info_color;
	}

	public String getButton_text() {
		return button_text;
	}

	public void setButton_text(String button_text) {
		this.button_text = button_text;
	}

	public String getButton_css() {
		return button_css;
	}

	public void setButton_css(String button_css) {
		this.button_css = button_css;
	}

	public String getProtrait_tag() {
		return protrait_tag;
	}

	public void setProtrait_tag(String protrait_tag) {
		this.protrait_tag = protrait_tag;
	}

	public String getBackground_music() {
		return background_music;
	}

	public void setBackground_music(String background_music) {
		this.background_music = background_music;
	}

	public String getBackground_pic() {
		return background_pic;
	}

	public void setBackground_pic(String background_pic) {
		this.background_pic = background_pic;
	}

	public String getEquipment_facilities() {
		return equipment_facilities;
	}

	public void setEquipment_facilities(String equipment_facilities) {
		this.equipment_facilities = equipment_facilities;
	}

	public String getOriginal_price() {
		return original_price;
	}

	public void setOriginal_price(String original_price) {
		this.original_price = original_price;
	}

	public String getDiscount_price() {
		return discount_price;
	}

	public void setDiscount_price(String discount_price) {
		this.discount_price = discount_price;
	}

	public String getActivity_restrict() {
		return activity_restrict;
	}

	public void setActivity_restrict(String activity_restrict) {
		this.activity_restrict = activity_restrict;
	}

	public String getCommit_info() {
		return commit_info;
	}

	public void setCommit_info(String commit_info) {
		this.commit_info = commit_info;
	}

	public String getWeibo_qrcode() {
		return weibo_qrcode;
	}

	public void setWeibo_qrcode(String weibo_qrcode) {
		this.weibo_qrcode = weibo_qrcode;
	}

	public String getWeixin_qrcode() {
		return weixin_qrcode;
	}

	public void setWeixin_qrcode(String weixin_qrcode) {
		this.weixin_qrcode = weixin_qrcode;
	}

	public String getDetail_rule() {
		return detail_rule;
	}

	public void setDetail_rule(String detail_rule) {
		this.detail_rule = detail_rule;
	}

	public String getStart_time() {
		return start_time;
	}

	public void setStart_time(String start_time) {
		this.start_time = start_time;
	}

	public String getEnd_time() {
		return end_time;
	}

	public void setEnd_time(String end_time) {
		this.end_time = end_time;
	}

	public int getCoupon_expire_day() {
		return coupon_expire_day;
	}

	public void setCoupon_expire_day(int coupon_expire_day) {
		this.coupon_expire_day = coupon_expire_day;
	}

	public int getTransmit_rule() {
		return transmit_rule;
	}

	@Override
	public String toString() {
		return "ActivityBean [pic_url=" + pic_url + ", id=" + id
				+ ", tenant_id=" + tenant_id + ", isDeleted=" + isDeleted
				+ ", createId=" + createId + ", createTime=" + createTime
				+ ", orderCode=" + orderCode + ", deleteTime=" + deleteTime
				+ ", remarks=" + remarks + ", attachment=" + attachment
				+ ", name=" + name + ", head_pic=" + head_pic
				+ ", description=" + description + ", web_url=" + web_url
				+ ", activity_pics=" + activity_pics + ", coupon_send_type="
				+ coupon_send_type + ", start_date=" + start_date
				+ ", effective_day=" + effective_day + ", effective_status="
				+ effective_status + ", coupon_number=" + coupon_number
				+ ", tag=" + tag + ", tag_defined=" + tag_defined + ", title="
				+ title + ", content=" + content + ", pic=" + pic + ", status="
				+ status + ", check_status=" + check_status
				+ ", check_descrption=" + check_descrption + ", overview="
				+ overview + ", statistic=" + statistic + ", share_channel="
				+ share_channel + ", browse_number=" + browse_number
				+ ", submit_numer=" + submit_numer + ", model_id=" + model_id
				+ ", ratio=" + ratio + ", weibo_num=" + weibo_num
				+ ", weixin_num=" + weixin_num + ", qq_num=" + qq_num
				+ ", varication_num=" + varication_num + ", submit_weixin_num="
				+ submit_weixin_num + ", submit_weibo_num=" + submit_weibo_num
				+ ", submit_qq_num=" + submit_qq_num + ", receive_coupon="
				+ receive_coupon + ", transmit_num=" + transmit_num
				+ ", click_num=" + click_num + ", activity_amount="
				+ activity_amount + ", weixin_ratio=" + weixin_ratio
				+ ", weibo_ratio=" + weibo_ratio + ", qq_ratio=" + qq_ratio
				+ ", total=" + total + ", type=" + type + ", transmit_rule="
				+ transmit_rule + ", start_time=" + start_time + ", end_time="
				+ end_time + ", coupon_expire_day=" + coupon_expire_day
				+ ", equipment_facilities=" + equipment_facilities
				+ ", original_price=" + original_price + ", discount_price="
				+ discount_price + ", activity_restrict=" + activity_restrict
				+ ", commit_info=" + commit_info + ", weibo_qrcode="
				+ weibo_qrcode + ", weixin_qrcode=" + weixin_qrcode
				+ ", detail_rule=" + detail_rule + "]";
	}

	public void setTransmit_rule(int transmit_rule) {
		this.transmit_rule = transmit_rule;
	}

	public int getType() {
		return type;
	}

	public void setType(int type) {
		this.type = type;
	}

	public int getTotal() {
		return total;
	}

	public void setTotal(int total) {
		this.total = total;
	}

	public String getTenant_id() {
		return tenant_id;
	}

	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}

	public double getWeixin_ratio() {
		return weixin_ratio;
	}

	public void setWeixin_ratio(double weixin_ratio) {
		this.weixin_ratio = weixin_ratio;
	}

	public double getWeibo_ratio() {
		return weibo_ratio;
	}

	public void setWeibo_ratio(double weibo_ratio) {
		this.weibo_ratio = weibo_ratio;
	}

	public double getQq_ratio() {
		return qq_ratio;
	}

	public void setQq_ratio(double qq_ratio) {
		this.qq_ratio = qq_ratio;
	}

	public double getActivity_amount() {
		return activity_amount;
	}

	public void setActivity_amount(double activity_amount) {
		this.activity_amount = activity_amount;
	}

	public int getClick_num() {
		return click_num;
	}

	public void setClick_num(int click_num) {
		this.click_num = click_num;
	}

	public int getVarication_num() {
		return varication_num;
	}

	public void setVarication_num(int varication_num) {
		this.varication_num = varication_num;
	}

	public int getSubmit_weixin_num() {
		return submit_weixin_num;
	}

	public void setSubmit_weixin_num(int submit_weixin_num) {
		this.submit_weixin_num = submit_weixin_num;
	}

	public int getSubmit_weibo_num() {
		return submit_weibo_num;
	}

	public void setSubmit_weibo_num(int submit_weibo_num) {
		this.submit_weibo_num = submit_weibo_num;
	}

	public int getSubmit_qq_num() {
		return submit_qq_num;
	}

	public void setSubmit_qq_num(int submit_qq_num) {
		this.submit_qq_num = submit_qq_num;
	}

	public int getReceive_coupon() {
		return receive_coupon;
	}

	public void setReceive_coupon(int receive_coupon) {
		this.receive_coupon = receive_coupon;
	}

	public int getTransmit_num() {
		return transmit_num;
	}

	public void setTransmit_num(int transmit_num) {
		this.transmit_num = transmit_num;
	}

	public int getWeibo_num() {
		return weibo_num;
	}

	public void setWeibo_num(int weibo_num) {
		this.weibo_num = weibo_num;
	}

	public int getWeixin_num() {
		return weixin_num;
	}

	public void setWeixin_num(int weixin_num) {
		this.weixin_num = weixin_num;
	}

	public int getQq_num() {
		return qq_num;
	}

	public void setQq_num(int qq_num) {
		this.qq_num = qq_num;
	}

	public Long getId() {
		return id;
	}

	public void setId(Long id) {
		this.id = id;
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Long getCreateId() {
		return createId;
	}

	public void setCreateId(Long createId) {
		this.createId = createId;
	}

	public Timestamp getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Timestamp createTime) {
		this.createTime = createTime;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode;
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks;
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getHead_pic() {
		return head_pic;
	}

	public void setHead_pic(String head_pic) {
		this.head_pic = head_pic;
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description;
	}

	public String getWeb_url() {
		return web_url;
	}

	public void setWeb_url(String web_url) {
		this.web_url = web_url;
	}

	public String getActivity_pics() {
		return activity_pics;
	}

	public void setActivity_pics(String activity_pics) {
		this.activity_pics = activity_pics;
	}

	public String getCoupon_send_type() {
		return coupon_send_type;
	}

	public void setCoupon_send_type(String coupon_send_type) {
		this.coupon_send_type = coupon_send_type;
	}

	public String getStart_date() {
		return start_date;
	}

	public void setStart_date(String start_date) {
		this.start_date = start_date;
	}

	public Integer getEffective_day() {
		return effective_day;
	}

	public void setEffective_day(Integer effective_day) {
		this.effective_day = effective_day;
	}

	public Integer getEffective_status() {
		return effective_status;
	}

	public void setEffective_status(Integer effective_status) {
		this.effective_status = effective_status;
	}

	public Integer getCoupon_number() {
		return coupon_number;
	}

	public void setCoupon_number(Integer coupon_number) {
		this.coupon_number = coupon_number;
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag;
	}

	public String getTag_defined() {
		return tag_defined;
	}

	public void setTag_defined(String tag_defined) {
		this.tag_defined = tag_defined;
	}

	public String getTitle() {
		return title;
	}

	public void setTitle(String title) {
		this.title = title;
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content;
	}

	public String getPic() {
		return pic;
	}

	public void setPic(String pic) {
		this.pic = pic;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public Integer getCheck_status() {
		return check_status;
	}

	public void setCheck_status(Integer check_status) {
		this.check_status = check_status;
	}

	public String getCheck_descrption() {
		return check_descrption;
	}

	public void setCheck_descrption(String check_descrption) {
		this.check_descrption = check_descrption;
	}

	public String getOverview() {
		return overview;
	}

	public void setOverview(String overview) {
		this.overview = overview;
	}

	public String getStatistic() {
		return statistic;
	}

	public void setStatistic(String statistic) {
		this.statistic = statistic;
	}

	public String getShare_channel() {
		return share_channel;
	}

	public void setShare_channel(String share_channel) {
		this.share_channel = share_channel;
	}

	public String getBrowse_number() {
		return browse_number;
	}

	public void setBrowse_number(String browse_number) {
		this.browse_number = browse_number;
	}

	public String getSubmit_numer() {
		return submit_numer;
	}

	public void setSubmit_numer(String submit_numer) {
		this.submit_numer = submit_numer;
	}

	public int getModel_id() {
		return model_id;
	}

	public void setModel_id(int model_id) {
		this.model_id = model_id;
	}

	public String getRatio() {
		return ratio;
	}

	public void setRatio(String ratio) {
		this.ratio = ratio;
	}

	public String getBak1() {
		return bak1;
	}

	public void setBak1(String bak1) {
		this.bak1 = bak1;
	}

	public String getBak2() {
		return bak2;
	}

	public void setBak2(String bak2) {
		this.bak2 = bak2;
	}

	public String getBak3() {
		return bak3;
	}

	public void setBak3(String bak3) {
		this.bak3 = bak3;
	}

	public String getBak4() {
		return bak4;
	}

	public void setBak4(String bak4) {
		this.bak4 = bak4;
	}

	public String getBak5() {
		return bak5;
	}

	public void setBak5(String bak5) {
		this.bak5 = bak5;
	}

	public Integer getDistinction() {
		return distinction;
	}

	public void setDistinction(Integer distinction) {
		this.distinction = distinction;
	}

}
