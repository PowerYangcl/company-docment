package cn.cecook.bean.business.markting;

public class StatisticsBean {
	private String name;
	private String openNum;
	private String converNum;
	private String sendNum;
	private String convertTime;
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getOpenNum() {
		return openNum;
	}
	public void setOpenNum(String openNum) {
		this.openNum = openNum;
	}
	public String getConverNum() {
		return converNum;
	}
	public void setConverNum(String converNum) {
		this.converNum = converNum;
	}
	public String getSendNum() {
		return sendNum;
	}
	public void setSendNum(String sendNum) {
		this.sendNum = sendNum;
	}
	public String getConvertTime() {
		return convertTime;
	}
	public void setConvertTime(String convertTime) {
		this.convertTime = convertTime;
	}
	

}
