package cn.cecook.controller.business.service;

import java.io.File;
import java.io.IOException;
import java.util.List;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.multipart.MultipartHttpServletRequest;

import com.alibaba.fastjson.JSONArray;
import com.alibaba.fastjson.JSONObject;
import com.google.gson.JsonObject;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.business.service.AuditingMedicine;
import cn.cecook.model.business.service.CriterionMedicine;
import cn.cecook.model.business.service.Medicine;
import cn.cecook.service.business.service.AuditingMedicineService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.amazonaws.FileUtil;

/**
 * 数据匹配controller
 * @author majie
 *
 */
@Controller
@RequestMapping("ser/auditingMedicine")
public class AuditingMedicineController {
	
	@Resource
	private AuditingMedicineService auditingMedicineService;
	/**
	 * 上传文件
	 * @param request
	 * @param response
	 * @param typename
	 * @param isFile
	 * @return
	 * majie
	 */
	@RequestMapping("/fileUpload")
	@ResponseBody
	public Object fileUpload(HttpServletRequest request,HttpServletResponse response
			,@RequestParam(value = "typename",required = false)String typename
			,@RequestParam(value = "isFile",required = false)Boolean isFile	){	
        MultipartHttpServletRequest multipartRequest = (MultipartHttpServletRequest) request;
        MultipartFile multipartFile = multipartRequest.getFile(typename);//获取表单
        String originalFilename = multipartFile.getOriginalFilename();
        BaseResultModel baseResultModel=new BaseResultModel();
 	    File file = new File("D:test_"+originalFilename);  
 	    if(!file.exists()){
 	    	try {
				file.createNewFile();
			} catch (IOException e) {
				baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
				baseResultModel.setError_msg(e.getMessage());
			}
 	    }
 	    try {
			multipartFile.transferTo(file);
		} catch (IOException e) {
			e.printStackTrace();
		}  
		String path = FileUtil.uploadFile(file);
		
		if(path!=""&&path!=null&&path.length()>0){
			baseResultModel.setData("D:test_"+originalFilename);
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		}else{
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
		}
		return baseResultModel;
	}
	/**
	 * 读取excel的标题
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param request
	 * @param path
	 * @return
	 * majie
	 */
	@RequestMapping("/readTitleExcel")
	@ResponseBody
	public Object readTitleExcel(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,String path){	
		return auditingMedicineService.readTitleExcel(path);
	}
	/**
	 * 把excel的数据插入数据表
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param request
	 * @param path
	 * @param colNums
	 * @return
	 * majie
	 */
	@RequestMapping("/addAuditingMedicine")
	@ResponseBody
	public Object addAuditingMedicine(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,String path,String arrays){
		JSONArray parseArray = JSONObject.parseArray(arrays);
		Integer[] colNums=new Integer[7];
		for (int i = 0; i < parseArray.size(); i++) {
			if(parseArray.get(i)!=null&&!"".equals(parseArray.get(i))&&parseArray.get(i)!=""){
				colNums[i]=Integer.parseInt((String)parseArray.get(i));
			}else{
				colNums[i]=null;
			}
		}
		BaseResultModel model =(BaseResultModel)auditingMedicineService.readContentExcel(uid, tenant_id, path, colNums);
		if(model.getError_code()==ConfigStatusCode.SUCCESS_CODE){
			return auditingMedicineService.addAuditingMedicine((List<AuditingMedicine>) model.getData());
		}else{
			return model;
		}
	}
	/**
	 * 查询所有的匹配数据
	 * @return
	 * majie
	 */
	@RequestMapping("/findAuditingMedicine")
	@ResponseBody
	public Object getAllAuditingMedicine(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,AuditingMedicine auditingMedicine){		
		return auditingMedicineService.getAll(auditingMedicine);		
	}
	/**
	 * 查询
	 * @return
	 * majie
	 */
	@RequestMapping("/getMedicineList")
	@ResponseBody
	public Object getMedicineList(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,AuditingMedicine auditingMedicine){		
		return auditingMedicineService.getMedicineList(auditingMedicine);
	}
	/**
	 * 根据药品id查询药品信息
	 * @return
	 * majie
	 */
	@RequestMapping("/getMedicine")
	@ResponseBody
	public Object getMedicine(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,CriterionMedicine criterionMedicine){		
		return auditingMedicineService.getMedicine(criterionMedicine);
	}
	/**
	 * 修改数据匹配的状态
	 * @return
	 * majie
	 */
	@RequestMapping("/updateAuditingMedicine")
	@ResponseBody
	public Object updateAuditingMedicine(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,AuditingMedicine auditingMedicine){		
		return auditingMedicineService.updateAuditingMedicine(auditingMedicine);
	}
	/**
	 * 上传数据（成功匹配）
	 * @return
	 * majie
	 */
	@RequestMapping("/uploadSuccessData")
	@ResponseBody
	public Object uploadData(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request,AuditingMedicine auditingMedicine){		
			//修改状态
			auditingMedicineService.updateAuditingMedicine(auditingMedicine);
			//插入数据和完善数据
		return auditingMedicineService.uploadSuccessMedicine(auditingMedicine);
	}
	@RequestMapping("/insertTable")
	@ResponseBody
	public Object insertTable(){		
		return auditingMedicineService.insertTable();
	}
	@RequestMapping("/batchMatching")
	@ResponseBody
	public Object batchMatching(){		
		return auditingMedicineService.batchMatching();
	}
}
