package cn.cecook.controller.system;

import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.CodeModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.dao.system.SysUserMapper;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.system.IRegisterService;
import cn.cecook.service.system.ISmsService;
import cn.cecook.uitls.PhoneUtil;
import cn.cecook.uitls.StringUtils;
import cn.cecook.uitls.UUIDHex;
import org.apache.log4j.Logger;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import java.util.HashMap;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

/**
 * 注册行为
 *
 * @author sunny
 * @explain
 * @date 2017年5月26日
 */
@Controller
@RequestMapping("/api/register")
public class RegisterController {

    private static Logger logger = Logger.getLogger(RegisterController.class);

    @Resource
    private IRegisterService registerService;
    @Resource
    private ISmsService smsService;
    @Resource
    private SysUserMapper sysUserMapper;

    @RequestMapping(value = "/apply_for_trial", method = RequestMethod.POST)
    @ResponseBody
    public Object applyForTrial(HttpServletRequest request,
                                HttpServletResponse response) throws Exception {
        // 增加js跨域支持
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        AccountModel accountModel = new AccountModel();
        CodeModel codeModel = new CodeModel();
        ResultModel resultModel = new ResultModel();

        String name = request.getParameter("name");
        String company = request.getParameter("company");
        String job = request.getParameter("job");
        String email = request.getParameter("email");
        String account = request.getParameter("mobile");
        String check_code = request.getParameter("ver_code");
        String code_type = "reg_code";

        String tenant_id = UUIDHex.getInstance().generate();
        if (!"".equals(tenant_id) && tenant_id != null) {
            accountModel.setTenant_id(tenant_id);
        }

        if (!"".equals(name) && name != null) {
            accountModel.setName(name);
        } else {
            resultModel.setError_code("1");
            resultModel.setError_msg("请输入姓名！");
            return (resultModel);
        }

        if (!"".equals(company) && company != null) {
            accountModel.setCompany(company);
        } else {
            resultModel.setError_code("1");
            resultModel.setError_msg("请输入企业名称！");
            return (resultModel);
        }

        if (!"".equals(job) && job != null) {
            accountModel.setJob(job);
        } else {
            resultModel.setError_code("1");
            resultModel.setError_msg("请输入公司职位！");
            return (resultModel);
        }

        if (!"".equals(check_code) && check_code != null) {
            accountModel.setVer_code(check_code);
        } else {
            resultModel.setError_code("1");
            resultModel.setError_msg("请输入验证码！");
            return (resultModel);
        }

        // 判断手机号码是否符合规范
        if (!PhoneUtil.isMobile(account)) {
            resultModel.setError_code("1");
            resultModel.setError_msg("手机号格式不正确！");
            return (resultModel);
        } else if (!"".equals(account) && account != null) {
            accountModel.setAccount(account);
        } else {
            resultModel.setError_code("1");
            resultModel.setError_msg("请输入手机号！");
            return (resultModel);
        }

        if (!"".equals(check_code) && check_code != null) {
            accountModel.setVer_code(check_code);
        } else {
            resultModel.setError_code("1");
            resultModel.setError_msg("请输入验证码！");
            return (resultModel);
        }
        if (!"".equals(code_type) && code_type != null) {
            accountModel.setCode_type(code_type);
        }

        // 验证码正确
        // 验证码error_code是0;
        ResultModel rm = new ResultModel();
        rm = smsService.verify(accountModel);
        System.out.println(rm);
        if (rm.getError_code().equals("0")) {
            resultModel = registerService.create(accountModel);
            return (resultModel);
        } else {
            // 返回验证码不正确的
            return (rm);
        }
    }

    /**
     * @throws Exception
     * @author sunny
     * @explain 创建注册
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    @ResponseBody
    public Object create(HttpServletRequest request,
                         HttpServletResponse response) throws Exception {
        // System.out.println("create controller");
        AccountModel accountModel = new AccountModel();
        CodeModel codeModel = new CodeModel();
        ResultModel resultModel = new ResultModel();
        String account = request.getParameter("account"); // System.out.println("account:"+account);
        String password = request.getParameter("password");// System.out.println("pwd:"+password);
        // UUIDHex gen = new UUIDHex();
        // String g = (String)gen .generate();
        String tenant_id = UUIDHex.getInstance().generate();
        // System.out.println(tenant_id);
        // 用户输入的验证码
        String check_code = request.getParameter("ver_code");
        String code_type = "reg_code";
        // 租户id
        if (!"".equals(tenant_id) && tenant_id != null) {
            accountModel.setTenant_id(tenant_id);
        }
        if (!"".equals(account) && account != null) {
            accountModel.setAccount(account);
        }
        if (!"".equals(password) && password != null) {
            accountModel.setPassword(password);
        }
        if (!"".equals(check_code) && check_code != null) {
            accountModel.setVer_code(check_code);
        }
        if (!"".equals(code_type) && code_type != null) {
            accountModel.setCode_type(code_type);
        }
        accountModel.setPassword(password);
        // 判断手机号码是否符合规范
        if (!PhoneUtil.isMobile(account)) {
            resultModel.setError_code("0");
            resultModel.setError_msg("手机号格式不正确");
            return (resultModel);
        }
        // 密码格式验证
        boolean flag = false;
        try {
            String regex = "^(?![0-9]+$)(?![a-zA-Z]+$)[0-9A-Za-z]{6,10}$";
            Pattern r = Pattern.compile(regex);
            // System.out.println(password);
            Matcher matcher = r.matcher(password);
            flag = matcher.matches();
        } catch (Exception e) {
            flag = false;
        }
        // System.out.println(flag);
        if (flag == false) {
            resultModel.setError_code("0");
            resultModel.setError_msg("密码格式不正确");
            return (resultModel);
        }
        // 验证码正确
        // 验证码error_code是0;
        ResultModel rm = new ResultModel();
        rm = smsService.verify(accountModel);
        System.out.println(rm);
        if (rm.getError_code().equals("0")) {
            resultModel = registerService.create(accountModel);
            if (resultModel.getError_msg().equals("注册成功")) {
                System.out.println("注册第一页成功");
                // 注册成功
                // 获取access_token
                // String access_token = TokenUtil.generateToken(account);
                // request.getSession().setAttribute("access_token",
                // access_token);
                // 注册用户名和密码存入缓存
                // 使用cookie将用户登录账户存入缓存
                Cookie cookie1 = new Cookie("account", account);
                cookie1.setPath("/");
                cookie1.setMaxAge(24 * 60 * 60);
                response.addCookie(cookie1);
                Cookie cookie2 = new Cookie("tenant_id", tenant_id);
                cookie2.setPath("/");
                cookie2.setMaxAge(24 * 60 * 60);
                response.addCookie(cookie2);
                // return (resultModel);
            }
            return (resultModel);
        } else {
            // 返回验证码不正确的
            return (rm);
        }
    }

    /**
     * @throws Exception
     * @author sunny
     * @explain 注册完成
     */
    @RequestMapping(value = "/finish", method = RequestMethod.POST)
    @ResponseBody
    public Object finish(HttpServletRequest request,
                         HttpServletResponse response) throws Exception {

        Cookie[] cookie = request.getCookies();
        String account = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().toString().equals("account")) { // 获取键
                account = cook.getValue().toString(); // 获取值
            }
        }
        AccountModel accountModel = new AccountModel();
        accountModel.setAccount(account);
        ResultModel resultModel = registerService.finish(accountModel);
        // 注册完成后，清空cookie
        for (Cookie cookie1 : cookie) {
            cookie1.setMaxAge(0);
            cookie1.setPath("/");
            response.addCookie(cookie1);
        }
        return (resultModel);

    }

    /**
     * @throws Exception
     * @author sunny
     * @explain 判断手机号码是否被注册
     */
    @RequestMapping(value = "/isReg", method = RequestMethod.POST)
    @ResponseBody
    public Object isReg(HttpServletRequest request, HttpServletResponse response)
            throws Exception {
        AccountModel accountModel = new AccountModel();
        ResultModel resultModel = new ResultModel();
        // 从前端获取手机号码
        String account = request.getParameter("mobile");
        logger.info(account);
        // 判断手机号码是否合法
        if (PhoneUtil.isMobile(account)) {
            if (!"".equals(account) && account != null) {
                accountModel.setAccount(account);
            }
            // 格式正确，判断是否注册
            resultModel = registerService.isReg(accountModel);
            return (resultModel);
        } else {
            // 格式不正确
            resultModel.setError_code("0");
            resultModel.setError_msg("手机号格式不正确");
            return (resultModel);

        }

    }

    @RequestMapping(value = "/openReg")
    @ResponseBody
    public Object openReg(HttpServletRequest request,
                          HttpServletResponse response) throws Exception {
        // 增加js跨域支持
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        AccountModel accountModel = new AccountModel();
        ResultModel resultModel = new ResultModel();
        Map<String, Object> resultMap = new HashMap<String, Object>();
        String name = request.getParameter("name");
        String company = request.getParameter("companyName");
        String job = request.getParameter("companyPosition");
        String email = request.getParameter("companyEmail");
        String account = request.getParameter("mobile");
        String check_code = request.getParameter("verifyCode");
        String code_type = "reg_code";
        if (StringUtils.isEmpty(name) || StringUtils.isEmpty(company)
                || StringUtils.isEmpty(job) || StringUtils.isEmail(account)
                || StringUtils.isEmpty(check_code)) {
            resultMap.put("error_code", "20001");
            resultMap.put("error_msg", "缺少必要参数");
            return resultMap;
        }

        // 判断手机号码是否符合规范
        if (!PhoneUtil.isMobile(account)) {
            resultMap.put("error_code", "20002");
            resultMap.put("error_msg", "无效手机号码 ");
            return resultMap;
        }

        if (!StringUtils.isEmpty(email) && !StringUtils.isEmail(email)) {
            resultMap.put("error_code", "20003");
            resultMap.put("error_msg", "邮箱格式不正确");
            return resultMap;
        }
        // 判断手机号码是否注册
        SysUser user = sysUserMapper.selectSysUserByAccount(account);
        if (user != null) {
            resultMap.put("error_code", "20004");
            resultMap.put("error_msg", "手机号码已注册");
            return resultMap;
        }
        String tenant_id = UUIDHex.getInstance().generate();


        // 验证码正确
        // 验证码error_code是0;
        accountModel.setCode_type(code_type);
        accountModel.setAccount(account);
        accountModel.setVer_code(check_code);
        accountModel.setCompany(company);
        accountModel.setJob(job);
        accountModel.setTenant_id(tenant_id);
        accountModel.setEmail(email);
        accountModel.setName(name);
        accountModel.setPhone(account);
        ResultModel rm = smsService.verify(accountModel);
        if (rm.getError_code().equals("0")) {
            resultModel = registerService.create(accountModel);
            if (resultModel.getError_code().equals("1")) {
                resultMap.put("error_code", "0");
                resultMap.put("error_msg", "申请试用成功");
                return resultMap;
            } else {
                resultMap.put("error_code", "20007");
                resultMap.put("error_msg", "申请试用失败");
                return resultMap;
            }
        } else {
            resultMap.put("error_code", "20006");
            resultMap.put("error_msg", rm.getError_msg());
            return resultMap;
        }
    }

    public static void main(String[] args) {
        System.out.println(PhoneUtil.isMobile("13161911660"));
    }
}
