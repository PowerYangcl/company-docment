package cn.cecook.bean.business.markting;


public class BrowseBean {
	/**
	 * 
	 */
	//访问ip
	//活动id
//	private String activity_id;
//	//活动名称
//	private String activity_name;
	
	private String name;
	private String phone;
	private String browse_ip;
	private String email;
	private String weibo;
	private String wechat;
	private String gener;
	private String create_time;
	
	
	
	public String getName() {
		return name;
	}
	public void setName(String name) {
		this.name = name;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getWeibo() {
		return weibo;
	}
	public void setWeibo(String weibo) {
		this.weibo = weibo;
	}
	public String getWechat() {
		return wechat;
	}
	public void setWechat(String wechat) {
		this.wechat = wechat;
	}
	public String getGener() {
		return gener;
	}
	public void setGener(String gener) {
		this.gener = gener;
	}
	public String getCreate_time() {
		return create_time;
	}
	public void setCreate_time(String create_time) {
		this.create_time = create_time;
	}
	public String getBrowse_ip() {
		return browse_ip;
	}
	public void setBrowse_ip(String browse_ip) {
		this.browse_ip = browse_ip;
	}
//	public String getActivity_id() {
//		return activity_id;
//	}
//	public void setActivity_id(String activity_id) {
//		this.activity_id = activity_id;
//	}
//	public String getActivity_name() {
//		return activity_name;
//	}
//	public void setActivity_name(String activity_name) {
//		this.activity_name = activity_name;
//	}
//	@Override
//	public String toString() {
//		return "BrowseBean [create_time=" + create_time + ", browse_ip="
//				+ browse_ip + ", activity_id=" + activity_id
//				+ ", activity_name=" + activity_name + "]";
//	}
	
	

}
