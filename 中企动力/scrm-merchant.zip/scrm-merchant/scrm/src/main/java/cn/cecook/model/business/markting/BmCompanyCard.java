package cn.cecook.model.business.markting;

import org.springframework.stereotype.Component;

import java.util.Date;


import java.io.Serializable;


@Component
public class BmCompanyCard implements Serializable{
    private Long id;

    private String uuid;

    private String tenantId;

    private Integer isDeleted;

    private Long createId;

    private Date createTime;

    private String orderCode;

    private Date deleteTime;

    private String remarks;

    private String attachment;

    private String bak1;

    private String bak2;

    private String bak3;

    private String bak4;

    private String bak5;

    private String companyName;

    private String headPicture;

    private String name;

    private String job;

    private String mobile;

    private String zuoMobile;

    private String mail;

    private String weixin;

    private String weibo;

    private String qq;

    private String userdefined;

    private String erCode;

    private String mdStore;

    private String url;

    private Integer userId;

    private String userName;

    public String getUserName() {
        return userName;
    }

    public void setUserName(String userName) {
        this.userName = userName;
    }

    public Integer getUserId() {
        return userId;
    }

    public void setUserId(Integer userId) {
        this.userId = userId;
    }

    public String getUrl() {
        return url;
    }

    public void setUrl(String url) {
        this.url = url;
    }

    public String getMdStore() {
        return mdStore;
    }

    public void setMdStore(String mdStore) {
        this.mdStore = mdStore;
    }

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getUuid() {
        return uuid;
    }

    public void setUuid(String uuid) {
        this.uuid = uuid == null ? null : uuid.trim();
    }

    public String getTenantId() {
        return tenantId;
    }

    public void setTenantId(String tenantId) {
        this.tenantId = tenantId == null ? null : tenantId.trim();
    }

    public Integer getIsDeleted() {
        return isDeleted;
    }

    public void setIsDeleted(Integer isDeleted) {
        this.isDeleted = isDeleted;
    }

    public Long getCreateId() {
        return createId;
    }

    public void setCreateId(Long createId) {
        this.createId = createId;
    }

    public Date getCreateTime() {
        return createTime;
    }

    public void setCreateTime(Date createTime) {
        this.createTime = createTime;
    }

    public String getOrderCode() {
        return orderCode;
    }

    public void setOrderCode(String orderCode) {
        this.orderCode = orderCode == null ? null : orderCode.trim();
    }

    public Date getDeleteTime() {
        return deleteTime;
    }

    public void setDeleteTime(Date deleteTime) {
        this.deleteTime = deleteTime;
    }

    public String getRemarks() {
        return remarks;
    }

    public void setRemarks(String remarks) {
        this.remarks = remarks == null ? null : remarks.trim();
    }

    public String getAttachment() {
        return attachment;
    }

    public void setAttachment(String attachment) {
        this.attachment = attachment == null ? null : attachment.trim();
    }

    public String getBak1() {
        return bak1;
    }

    public void setBak1(String bak1) {
        this.bak1 = bak1 == null ? null : bak1.trim();
    }

    public String getBak2() {
        return bak2;
    }

    public void setBak2(String bak2) {
        this.bak2 = bak2 == null ? null : bak2.trim();
    }

    public String getBak3() {
        return bak3;
    }

    public void setBak3(String bak3) {
        this.bak3 = bak3 == null ? null : bak3.trim();
    }

    public String getBak4() {
        return bak4;
    }

    public void setBak4(String bak4) {
        this.bak4 = bak4 == null ? null : bak4.trim();
    }

    public String getBak5() {
        return bak5;
    }

    public void setBak5(String bak5) {
        this.bak5 = bak5 == null ? null : bak5.trim();
    }

    public String getCompanyName() {
        return companyName;
    }

    public void setCompanyName(String companyName) {
        this.companyName = companyName == null ? null : companyName.trim();
    }

    public String getHeadPicture() {
        return headPicture;
    }

    public void setHeadPicture(String headPicture) {
        this.headPicture = headPicture == null ? null : headPicture.trim();
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name == null ? null : name.trim();
    }

    public String getJob() {
        return job;
    }

    public void setJob(String job) {
        this.job = job == null ? null : job.trim();
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile == null ? null : mobile.trim();
    }

    public String getZuoMobile() {
        return zuoMobile;
    }

    public void setZuoMobile(String zuoMobile) {
        this.zuoMobile = zuoMobile == null ? null : zuoMobile.trim();
    }

    public String getMail() {
        return mail;
    }

    public void setMail(String mail) {
        this.mail = mail == null ? null : mail.trim();
    }

    public String getWeixin() {
        return weixin;
    }

    public void setWeixin(String weixin) {
        this.weixin = weixin == null ? null : weixin.trim();
    }

    public String getWeibo() {
        return weibo;
    }

    public void setWeibo(String weibo) {
        this.weibo = weibo == null ? null : weibo.trim();
    }

    public String getQq() {
        return qq;
    }

    public void setQq(String qq) {
        this.qq = qq == null ? null : qq.trim();
    }

    public String getUserdefined() {
        return userdefined;
    }

    public void setUserdefined(String userdefined) {
        this.userdefined = userdefined == null ? null : userdefined.trim();
    }

    public String getErCode() {
        return erCode;
    }

    public void setErCode(String erCode) {
        this.erCode = erCode == null ? null : erCode.trim();
    }

	@Override
	public String toString() {
		return "BmCompanyCard [id=" + id + ", uuid=" + uuid + ", tenantId=" + tenantId + ", isDeleted=" + isDeleted
				+ ", createId=" + createId + ", createTime=" + createTime + ", orderCode=" + orderCode + ", deleteTime="
				+ deleteTime + ", remarks=" + remarks + ", attachment=" + attachment + ", bak1=" + bak1 + ", bak2="
				+ bak2 + ", bak3=" + bak3 + ", bak4=" + bak4 + ", bak5=" + bak5 + ", companyName=" + companyName
				+ ", headPicture=" + headPicture + ", name=" + name + ", job=" + job + ", mobile=" + mobile
				+ ", zuoMobile=" + zuoMobile + ", mail=" + mail + ", weixin=" + weixin + ", weibo=" + weibo + ", qq="
				+ qq + ", userdefined=" + userdefined + ", erCode=" + erCode + ", mdStore=" + mdStore + ", url=" + url
				+ ", userId=" + userId + ", userName=" + userName + "]";
	}


	

}