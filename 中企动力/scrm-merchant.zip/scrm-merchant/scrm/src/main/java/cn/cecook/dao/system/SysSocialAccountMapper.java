package cn.cecook.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysSocialAccount;
import cn.cecook.model.system.SysSocialAccountExample;

/**
 * 
* @explain 社交账号表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface SysSocialAccountMapper {
    int countByExample(SysSocialAccountExample example);

    int deleteByExample(SysSocialAccountExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(SysSocialAccount record);

    int insertSelective(SysSocialAccount record);

    List<SysSocialAccount> selectByExample(SysSocialAccountExample example);

    SysSocialAccount selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") SysSocialAccount record, @Param("example") SysSocialAccountExample example);

    int updateByExample(@Param("record") SysSocialAccount record, @Param("example") SysSocialAccountExample example);

    int updateByPrimaryKeySelective(SysSocialAccount record);

    int updateByPrimaryKey(SysSocialAccount record);
}