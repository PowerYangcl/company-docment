package cn.cecook.model.business.automation;
/**
 * 执行顺序枚举类型
 * @author majie
 *
 * 2018年1月22日-下午4:47:05
 */
public enum TaskOrder {
	//after 父执行完子执行
	//NOW 立即执行
	AFTER,NOW
}
