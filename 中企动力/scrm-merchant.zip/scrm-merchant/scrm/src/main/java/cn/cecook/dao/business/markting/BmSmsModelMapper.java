package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.markting.BmSmsModel;
@Repository("bmSmsModelMapper")
public interface BmSmsModelMapper {


    int deleteByPrimaryKey(Integer id);


    int insertSelective(BmSmsModel record);

    BmSmsModel selectByPrimaryKey(Integer id);


    int updateByPrimaryKeySelective(BmSmsModel record);
    /**
     * 
    * Title: getModelList
    * Description:获取短信模板列表
    * @param map
    * @return
     */
    List<BmSmsModel> getModelList(Map<String, Object> map);

    int countModelTotal(Map<String, Object> map);

    BmSmsModel getModelDetail(int id);

    int isSameName(@Param("name") String name, @Param("id") Integer id);
    /**
     * 
    * Title: modelIsUsed
    * Description:判断模板是否正在使用
    * @param id
    * @return
     */
    int modelIsUsed(int id);
    
    int deleteById(int id);

}