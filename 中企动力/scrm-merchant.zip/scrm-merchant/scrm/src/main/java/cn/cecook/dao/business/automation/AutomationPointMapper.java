package cn.cecook.dao.business.automation;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.automation.AutomationPointInfo;

/**
 * 自动化营销mapper
 * @author majie
 *
 * 2018年1月22日-下午2:58:32
 */
public interface AutomationPointMapper {
	/**
	 * 添加自动化营销节点信息
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public Integer addAutomationPointInfo(AutomationPointInfo automationPointInfo);
	/**
	 * 修改节点信息
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public Integer updateAutomationPointInfo(AutomationPointInfo automationPointInfo);
	/**
	 * 查询单个节点信息
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public AutomationPointInfo selectAutomationPointInfo(Integer id);
	/**
	 * 根据TemplateId查询所有节点
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public List<AutomationPointInfo> selectAutomationPointByTemplateId(Integer templateId);
	/**
	 * 根据TemplateId和节点类型查询
	 * @return
	 * majie
	 */
	public List<AutomationPointInfo> selectPointByTemplateIdAndType(AutomationPointInfo automationPointInfo);
	/**
	 * 根据pointId和templateIdid获取节点信息
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public AutomationPointInfo selectAutomationPointInfoByParentTaskId(AutomationPointInfo automationPointInfo);
	/**
	 * 判断是否是尾节点
	 * @param pointId
	 * @return
	 * majie
	 */
	public Integer isLastPoint(AutomationPointInfo automationPointInfo);
	/**
	 * 根据taskId、templateId、type查询节点信息
	 * @return
	 * majie
	 */
	public AutomationPointInfo selectPointInfoByTaskId(Map<String,Object> map);
	/**
	 * 根据pointId和templateId查询节点信息
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public AutomationPointInfo selectAutomationPointInfoByPointId(AutomationPointInfo automationPointInfo);
	/**
	 * 根据模板id查询最大节点信息
	 * @return
	 * majie
	 */
	public AutomationPointInfo validateType(Integer templateId);
	/*****************公共库方法***************/
	/**
	 * 查询模板下所有节点
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public List<AutomationPointInfo> selectTemplatePointByPublic(Integer id);
	/**
	 * 根据pointId和templateIdid获取节点信息
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	public AutomationPointInfo selectPointInfoByPublic(AutomationPointInfo automationPointInfo);
}
