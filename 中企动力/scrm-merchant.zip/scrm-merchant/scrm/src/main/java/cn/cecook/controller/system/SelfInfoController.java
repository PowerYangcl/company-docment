package cn.cecook.controller.system;


import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.service.system.ISelfInfoService;


/**
 * 个人信息
 * @explain 
 * @author sunny
 * @date 2017年5月28日
 */
@Controller
@RequestMapping("/api/self_info")
public class SelfInfoController {
    @Resource
    ISelfInfoService selfInfoService;
    /**
     * 录入个人信息
     * @explain 
     * @author sunny
     * @date 2017年5月28日
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    @ResponseBody
    public Object update(HttpServletRequest request, HttpServletResponse response,AccountModel accountModel) throws Exception {

        // 姓名
        String name = request.getParameter("name");
        // 邮件
        String email = request.getParameter("email");
         //地区
        String district_name = request.getParameter("district_name");
         //行业
        String industry = request.getParameter("industry");
        // 公司
        String company = request.getParameter("company");
        // 职位
        String job = request.getParameter("job");
        // 个人爱好
        String hobby = request.getParameter("hobby");
     // 个人爱好
        String intro = request.getParameter("intro");
        //登录账号
       //String acount= (String) request.getSession().getAttribute("account");
        ResultModel resultModel=new  ResultModel(); 
        //从cookie缓存中取出account
        Cookie[] cookie=request.getCookies();
        String account="";
        for (int i = 0; i < cookie.length; i++) {
                Cookie cook = cookie[i];
                if(cook.getName().toString().equals("account")){ //获取键 
                    account=cook.getValue().toString();    //获取值 
                }
         }
        //取出tenant_id
        String tenant_id="";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if(cook.getName().toString().equals("tenant_id")){ //获取键 
                tenant_id=cook.getValue().toString();    //获取值 
            }
        }
       //判断邮箱格式是否正确
       //正则表达式
//       String regex = "^(\w)+(\.\w+)*@(\w)+((\.\w+)+)$";
//       boolean flag = false;
//       try{
//       Pattern r = Pattern.compile(regex);
//       Matcher matcher = r.matcher(email);
//       flag = matcher.matches();
//       }catch(Exception e){
//           flag = false;
//       }
//       if(flag == false){
//         resultModel.setError_code("0");
//         resultModel.setError_msg("邮箱号格式不正确");
//         System.out.println("邮箱号格式不正确");
//         return (resultModel);
//       }
       //公司名称不能为空
       if(company==null||company.equals("")){
           resultModel.setError_code("0");
           resultModel.setError_msg("公司名称不能为空");
           System.out.println("公司名称不能为空");
           return (resultModel);
         }

       if (!"".equals(account) && account != null) {
           accountModel.setAccount(account);
           }
       if (!"".equals(name) && name != null) {
           accountModel.setName(name);
           }
       if (!"".equals(email) && email != null) {
           accountModel.setEmail(email);
           }
       if (!"".equals(district_name) && district_name != null) {
           accountModel.setDistrict_name(district_name);
           }
       if (!"".equals(industry) && industry != null) {
           accountModel.setIndustry(industry);
           }
       if (!"".equals(company) && company != null) {
           accountModel.setCompany(company);
           }
       if (!"".equals(job) && job != null) {
           accountModel.setJob(job);
           }
       if (!"".equals(hobby) && hobby != null) {
           accountModel.setHobby(hobby);
           }
       if (!"".equals(tenant_id) && tenant_id != null) {
           accountModel.setTenant_id(tenant_id);
           } 
       if (!"".equals(intro) && intro != null) {
           accountModel.setIntro(intro);
           }
        resultModel = selfInfoService.update(accountModel);
        return (resultModel);

    }
    /**
     * 修改绑定手机号码
     * @explain 
     * @author sunny
     * @date 2017年5月28日
     */
    @RequestMapping(value = "/changeMobil", method = RequestMethod.POST)
    @ResponseBody
    public Object changeMobil(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //手机号码
        String account= request.getParameter("account");
        return null;
    }
    
}
