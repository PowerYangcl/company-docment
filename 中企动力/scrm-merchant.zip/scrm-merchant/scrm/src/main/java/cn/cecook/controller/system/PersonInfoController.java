package cn.cecook.controller.system;

import java.util.HashMap;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonObject;

import cn.cecook.bean.system.SysBaseResultModel;
import cn.cecook.service.system.IPersonInfoService;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.MD5Util;

/**
 * 
 * @explain 设置--个人资料
 * @author ZHIWEN
 * @author 2017年6月5日 下午3:20:55
 */
@Controller
@RequestMapping("/api/self_info")
public class PersonInfoController {
	@Resource
	private IPersonInfoService iPersonInfoService;
	/**
	 * 
	 *@explain 查询用户信息
	 * @author ZHIWEN
	 * @data 2017年6月17日
	 */
	@RequestMapping(value="/SelectById" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody java.lang.Object SelectById(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			HttpServletRequest request)throws Exception{
		Cookie[] cookies= request.getCookies();
		tenant_id=	CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
		String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
		java.lang.Object object = null;
		if (tenant_id==null||id==null) {
				} else {
					uid = Long.parseLong(id);
					 object =iPersonInfoService.PersonInfoFindByUuid(uid, access_token, tenant_id);
				}
		return object;
	}
	/**
	 * 
	 *@explain 更新爱好
	 * @author ZHIWEN
	 * @data 2017年6月17日
	 */
	@RequestMapping(value="/Updata_Hobby" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody java.lang.Object Updata_Hobby(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,HttpServletRequest request)throws Exception{
		Cookie[] cookies= request.getCookies();
		tenant_id=	CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
		String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
		SysBaseResultModel sysBaseResultModel = new SysBaseResultModel();
		if (tenant_id==null||id==null) {
			sysBaseResultModel.setError_code("1");
			sysBaseResultModel.setError_msg("租户不存在");
		} else {
			uid = Long.parseLong(id);
			if (request.getParameter("hobby")!=null) {
				String Listhobby = request.getParameter("hobby");
				//String hobby_count = request.getParameter("count");
				
				
				int Updata_Status= iPersonInfoService.Updata_Hobby(uid, access_token, tenant_id,Listhobby);
				if (Updata_Status==1) {
					System.out.println("更新成功");
					sysBaseResultModel.setError_code("0");
					sysBaseResultModel.setError_msg("更新爱好成功");
				}else {
					System.out.println("更新失败");
					sysBaseResultModel.setError_code("1");
					sysBaseResultModel.setError_msg("更新爱好失败");
				}
			}else {
				sysBaseResultModel.setError_code("1");
				sysBaseResultModel.setError_msg("爱好不存在");
			}
		}
		return sysBaseResultModel;
	}
	/**
	 * 
	 *@explain 修改电话
	 * @author ZHIWEN
	 * @data 2017年6月17日
	 */
	@RequestMapping(value="/change_mobil" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody java.lang.Object change_mobil(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			@RequestParam(value = "account",required = false)String account,
			HttpServletRequest request)throws Exception{
		
		Cookie[] cookies= request.getCookies();
		tenant_id=	CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
		String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
		java.lang.Object object = null;
		if (tenant_id==null||id==null) {
		} else {
			uid = Long.parseLong(id);
			 object =iPersonInfoService.change_mobil(uid, access_token, tenant_id,account);
		}
		
		return object;
	}
	/**
	 * 
	 *@explain 修改姓名和邮箱
	 * @author MAJIE
	 * @data 2017年10月13日
	 */
	@RequestMapping(value="/update_name_email" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody java.lang.Object change_name_email(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			@RequestParam(value = "name",required = false)String name,
			@RequestParam(value = "email",required = false)String email,
			HttpServletRequest request)throws Exception{		
		Cookie[] cookies= request.getCookies();
		tenant_id=	CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
		String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
		int flag=0;
		if (tenant_id==null||id==null) {
		} else {
			uid = Long.parseLong(id);
			flag=iPersonInfoService.update_name_email(uid, access_token, tenant_id, name, email);
		}
		return flag;
	}	
	/**
	 * 
	 *@explain 修改密码
	 * @author ZHIWEN
	 * @data 2017年8月2日
	 */
	@RequestMapping(value="/update_password" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody java.lang.Object update_password(@RequestParam(value = "uid",required = false)Long uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,
			@RequestParam(value = "old_password",required = false)String old_password,
			@RequestParam(value = "new_password",required = false)String new_password,HttpServletRequest request
			){
		Cookie[] cookies= request.getCookies();
		JsonObject jsonObject = new JsonObject();
		Map<String, java.lang.Object> map = new HashMap<String, java.lang.Object>();
		if ((CookieUtil.getCookieSet(cookies).get("uid"))!=null) {
			String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
			map.put("id", Long.parseLong(id));
			if (old_password!=null&&old_password!=""&&
					new_password!=null&&new_password!="") {
				old_password=MD5Util.encodeString(MD5Util.encodeString(old_password)+ConfigUtil.MD5_PWD_STR);
				new_password=MD5Util.encodeString(MD5Util.encodeString(new_password)+ConfigUtil.MD5_PWD_STR);
				map.put("old_password", old_password);
				map.put("new_password", new_password);
				int status = iPersonInfoService.update_password(map);
				if (status==0) {
					jsonObject.addProperty("error_code", "1");
		            jsonObject.addProperty("error_message", "请检查旧密码是否正确");
				}
                if (status==1) {
                	jsonObject.addProperty("error_code", "0");
                    jsonObject.addProperty("error_message", "修改成功");
				}
			} else {
               jsonObject.addProperty("error_code", "1");
               jsonObject.addProperty("error_message", "新旧密码不存在");
			}
		} else {
			jsonObject.addProperty("error_code", "1");
            jsonObject.addProperty("error_message", "用户不存在,建议重新登录");
		}
		return jsonObject.toString();
	}
	
	
	
	//一下两个方法作废
//	@RequestMapping(value="/sendMessage" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
//	public void sendMessage(@RequestParam(value = "uid",required = false)Long uid,
//			@RequestParam(value = "access_token",required = false)String access_token,
//			@RequestParam(value = "tenant_id",required = false)String tenant_id,
//			@RequestParam(value = "account",required = false)String account,
//			@RequestParam(value = "code_type",required = false)String code_type,HttpServletRequest request,HttpServletResponse response
//			){
//		int random = (int)(Math.random()*(999999-100000)+100000);
//		String message =  Integer.toString(random);
//	
//		String activityidString ="1";
//		int smspriority = 1;
//		
//		EmaySmsUtils.getInstance().sendSMS(account, message, smspriority, code_type,activityidString);
//	}
	/**
	 * 
	 * @explain 文件上传测试接口
	 * @author ZHIWEN
	 * @date 2017年7月4日
	 */
//	@RequestMapping(value="/uploadcfiletest" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
//	public void uploadcfiletestHttpServletRequest(HttpServletRequest request,HttpServletResponse response
//		,@RequestParam(value = "typename",required = false)String typename	){
//	
//	  JSONObject jsonObject=   FileUploadUtils.getinstance().UploadFile(request,typename);
//	  System.err.println(jsonObject.toString());
//	  String jsString = jsonObject.getString("realSavePath");
//	  //String strasng ="\\";
//	  //String string="/";
//	  //jsString=jsString.replace(strasng,string);
//	  //jsString="http://localhost:8080"+jsString;
//	  //FileDownloadUtils.getinstance().FileDownload(jsString, response);
//			
//		
//	}
	
}
