package cn.cecook.controller.api;


import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.model.ResultStatus;
import cn.cecook.model.business.markting.BmCoupon;
import cn.cecook.service.business.markting.CouponService;
import cn.cecook.service.business.markting.WriteOffService;

import org.apache.log4j.Logger;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.alibaba.fastjson.JSONObject;

import java.util.HashMap;
import java.util.Map;

/**
 * Created by scar on 2017/9/27.
 * 卡劵接口类
 * 此方法为第三方服务商开放平台接口，无需验证登陆token但需要网关系统进行权限验证
 */
@Controller
@RequestMapping("/APICoupons")
public class APICoupons {

    private Logger dataLogger = Logger.getLogger("crmLog");

    @Autowired
    private WriteOffService writeOffService;
    
    @Autowired
    private CouponService couponService;

    /**
     * Title: queryCouponDetail
     * Description:获取优惠券详情
     *
     * @param uid         用户id
     * @param tenant_id   租户id
     * @param coupon_code 优惠券码
     * @return
     */
    @RequestMapping(value = "/query_coupon")
    @ResponseBody
    public Object queryCouponDetail(String uid, String tenant_id, String coupon_code) {
        return writeOffService.queryCouponDetail(tenant_id, uid, coupon_code);
    }
    
    @RequestMapping(value = "/query_coupon_v2")
    @ResponseBody
    public Object queryCouponDetailV2(String uid, String tenant_id, String coupon_code) {
        return writeOffService.queryCouponDetailV2(tenant_id, uid, coupon_code);
    }

    
    @RequestMapping(value = "/queryCouponByApp")
    @ResponseBody
    public Object queryCouponByApp(@RequestBody Map<String,Object> requestData) {
        return writeOffService.queryCouponByApp(String.valueOf(requestData.get("couponCode")));
    }
    /**
     * Title: queryCouponDetail
     * Description:获取优惠券详情(瑞恩)
     */
    @RequestMapping(value = "/query_coupon_ranning")
    @ResponseBody
    public BaseResultModel queryCouponDetails(String uid, String tenant_id, String coupon_code) {

        BaseResultModel resultModel = new BaseResultModel();

        BaseResultModel baseResultModel = writeOffService.queryCouponDetail(tenant_id, uid, coupon_code);

        if (baseResultModel.getError_code().equals("0")) {
            resultModel.setError_code(ResultStatus.SUCCESS.getStatus_code());
            resultModel.setError_msg("验证通过");
            try {

                BmCoupon bmCoupon = (BmCoupon) baseResultModel.getData();

                Map<String, Object> data = new HashMap<>();
                data.put("coupon_name", bmCoupon.getCouponName());
                data.put("coupon_price", bmCoupon.getFaceValue() * 100);
                data.put("limit_price", bmCoupon.getLimit_price() * 100);
                resultModel.setData(data);

            } catch (Exception e) {
                e.printStackTrace();
            }

        } else {
            resultModel.setError_code(ResultStatus.REQUEST_PARAM_ERROR.getStatus_code());
            resultModel.setError_msg("验证失败");
            resultModel.setData("");
        }

        return resultModel;

    }


    /**
     * 核销验证
     */
    @RequestMapping(value = "validate")
    @ResponseBody
    public Object validate(String tenant_id, String uid, String coupon_code, String coupon_id, String coupon_name,
                           String mobile, String activity_id, String customer_id, int price) {

        return (writeOffService.validateWriteOff(tenant_id, uid, coupon_code, coupon_id,
                coupon_name, mobile, activity_id, customer_id, price));
    }
    /**
     * app-核销验证
     */
    @RequestMapping(value = "app/validate")
    @ResponseBody
    public Object appValidate(@RequestBody Map<String,String> map) {
    	String tenant_id=map.get("tenant_id");
    	String uid=map.get("uid");
    	String coupon_code=map.get("coupon_code");
    	dataLogger.info("进入appValidate");
    	dataLogger.info("传入数据map="+map);
    	JSONObject appJson=new JSONObject();
    	BaseResultModel baseModel = writeOffService.queryCouponDetail(tenant_id, uid, coupon_code);
    	if(baseModel.getData()!=null&&"0".equals(baseModel.getError_code())){
    		BmCoupon bmCoupon=(BmCoupon) baseModel.getData();
    		JSONObject json = writeOffService.validateWriteOff(bmCoupon.getTenantId(), bmCoupon.getUuid(), bmCoupon.getCouponCode(),bmCoupon.getId()+"",bmCoupon.getCouponName(),bmCoupon.getCustomerPhone(), bmCoupon.getActivityId()+"", bmCoupon.getCustomerId()+"", bmCoupon.getLimit_price());
			if(json==null||!"0".equals(json.get("error_code"))){
				appJson.put("status",501);
        		appJson.put("message",json.get("error_msg"));
        		appJson.put("data", new Object());
        		dataLogger.info("返回数据"+appJson);
        		return appJson;
			}else{
				appJson.put("status",200);
        		appJson.put("message",json.get("error_msg"));
        		appJson.put("data", new Object());
        		dataLogger.info("返回数据"+appJson);
        		return appJson;
			}
    	}else{
    		appJson.put("status",501);
    		appJson.put("data", new Object());
    		appJson.put("message",baseModel.getError_msg());
    	}    	
		dataLogger.info("返回数据"+appJson);
    	return appJson;
    }

    /**
     * 反核销
     */

    @RequestMapping(value = "/reverse")
    @ResponseBody
    public Object Reverse(String tenant_id, String uid, String reverse_reason, String coupon_id, String reverse_name,
                          String activity_id, String customer_id) {

        return writeOffService.ReverseWriteOff(tenant_id, uid, reverse_reason, coupon_id,
                reverse_name, customer_id, activity_id);


    }
    
    @RequestMapping(value = "/query_coupon_byphone",method = { RequestMethod.POST })
    @ResponseBody
    public Object QueryCouponListByPhone(String phone,String tenant_id) {
        return couponService.queryCouponListByPhone(phone, tenant_id);
    }
    

}
