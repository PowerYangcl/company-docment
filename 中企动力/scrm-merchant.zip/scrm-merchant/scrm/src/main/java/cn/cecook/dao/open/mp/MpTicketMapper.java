package cn.cecook.dao.open.mp;

import cn.cecook.model.open.mp.MpTicket;

public interface MpTicketMapper {

	public MpTicket selectOne();
	public void update(MpTicket mpTicket);
	public void insert(MpTicket mpTicket);
}
