package cn.cecook.dao.system;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.system.SysSocialAccount;

public interface SysWeiBoMapper {
  SysSocialAccount	Select_WeiBoByUserIdandTenantId(@Param(value = "userId") Long userId, @Param(value = "tenantId") String tenantId);
  int Update_WeiBoByUserIdandTenantId(@Param(value = "userId") Long userId, @Param(value = "tenantId") String tenantId);
  String Select_showfirstpageByUserIdandTenantId(@Param(value = "id") Long id, @Param(value = "tenantId") String tenantId);
  int updateByPrimaryKeySelectiveforother(@Param(value = "bak5") String bak5, @Param(value = "id") Long id);
  List<SysSocialAccount> Select_WeiBoBybak3(@Param(value = "bak3") String bak3);
  int update_Select_WeiBoBybak3(SysSocialAccount sysSocialAccount);
}
