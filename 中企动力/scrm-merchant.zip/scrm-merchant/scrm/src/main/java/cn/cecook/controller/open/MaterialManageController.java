package cn.cecook.controller.open;

import java.awt.image.BufferedImage;
import java.io.BufferedInputStream;
import java.io.ByteArrayInputStream;
import java.io.File;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.HttpURLConnection;
import java.net.URL;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.UUID;

import javax.imageio.ImageIO;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.util.StringUtils;
import org.springframework.web.bind.ServletRequestUtils;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.common.collect.Lists;

import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpEmoji;
import cn.cecook.model.open.mp.MpMaterial;
import cn.cecook.model.open.mp.MpMaterialNews;
import cn.cecook.model.open.mp.MpMaterialNewsDetail;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpMaterialNewsDetailService;
import cn.cecook.service.open.IMpMaterialNewsService;
import cn.cecook.service.open.IMpMaterialService;
import cn.cecook.thirdparty.open.ConfigUtil;
import cn.cecook.thirdparty.open.ImageUtil;
import cn.cecook.thirdparty.open.MaterialType;
import cn.cecook.thirdparty.open.MaterialUtil;
import cn.cecook.thirdparty.open.MediaUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.EmojiUtil;
import cn.cecook.uitls.SqlUtil;
import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

@Controller
@RequestMapping("/weixin")
public class MaterialManageController {

	@Autowired
	private IMpAccountService mpAccountService;
	
	@Autowired
	private IMpMaterialService mpMaterialService;
	@Autowired
	private IMpMaterialNewsService mpMaterialNewsService;

	@Autowired
	private IMpMaterialNewsDetailService mpMaterialNewsDetailService;

	/**
	 * 同步图片素材
	 */
	@RequestMapping(value = "/loadMaterial", method = RequestMethod.GET)
	@ResponseBody
	public JSONObject loadMaterial(HttpServletRequest request, HttpServletResponse response) {
		JSONObject result = new JSONObject();
		String filePath = request.getSession().getServletContext().getRealPath("");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		mpMaterialService.reloadMaterial(tenant_id, filePath);
		result.put("status", true);
		return result;
	}
	
	/**
	 * 图文素材
	 */
	@RequestMapping(value = "/news-materials")
	public String newsMaterials(HttpServletRequest request, HttpServletResponse response) {
		String dateStartStr = ServletRequestUtils.getStringParameter(request, "dateStart", "");
		String dateEndStr = ServletRequestUtils.getStringParameter(request, "dateEnd", "");
		String keyword = ServletRequestUtils.getStringParameter(request, "keyword", "");
		keyword = SqlUtil.isValid(keyword) == true ? keyword : null;
		Date dateStart = DateUtils.toDate(SqlUtil.isValid(dateStartStr) == true ? dateStartStr : null);
		Date dateEnd = DateUtils.toDate(SqlUtil.isValid(dateEndStr) == true ? dateEndStr : null);
		if (dateEnd != null) {
			dateEnd.setHours(23);
			dateEnd.setMinutes(59);
			dateEnd.setSeconds(59);
		}
		request.setAttribute("dateStart", dateStartStr);
		request.setAttribute("dateEnd", dateEndStr);
		request.setAttribute("keyword", keyword);
		
		int page = ServletRequestUtils.getIntParameter(request, "page", 1);
		int pageSize = ConfigUtil.getInstance().pageSize;
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount != null) {			
			int pageStart = (page-1) * pageSize;
			List<MpMaterialNews> dataList = mpMaterialNewsService.selectMaterialByCondition(tenant_id,pageStart, pageSize,dateStart,dateEnd,keyword);
			for (MpMaterialNews mpMaterialNews : dataList) {
				for (MpMaterialNewsDetail mpMaterialNewsDetail : mpMaterialNews.getDetails()) {
					mpMaterialNewsDetail.setContentHtml(EmojiUtil.formatEmojiForEditor(mpMaterialNewsDetail.getContent()));
				}
			}
			int totalCount = mpMaterialNewsService.getCountByCondition(tenant_id,dateStart,dateEnd,keyword);
			int totalPage = totalCount%pageSize == 0? totalCount/pageSize : totalCount/pageSize +1;
			request.setAttribute("dataList", dataList);
			request.setAttribute("totalCount", totalCount);
			request.setAttribute("totalPage", totalPage);
			request.setAttribute("currentPage", page);
			request.setAttribute("nickName", mpAccount.getNickName());
			request.setAttribute("headImg", mpAccount.getHeadImg());
			return "open/news-materials";
		}else {
			return "open/needLogin";
		}
	}
	
	@RequestMapping(value = "/news-materials-ajax")
	public String newsMaterialsForAjax(HttpServletRequest request, HttpServletResponse response) {
		int page = ServletRequestUtils.getIntParameter(request, "page", 1);
		int pageSize = ConfigUtil.getInstance().pageSize;
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		int pageStart = (page-1) * pageSize;
		List<MpMaterialNews> dataList = mpMaterialNewsService.selectMaterialByPage(tenant_id,pageStart, pageSize);
		int totalCount = mpMaterialNewsService.getCount(tenant_id);
		int totalPage = totalCount%pageSize == 0? totalCount/pageSize : totalCount/pageSize +1;
		request.setAttribute("dataList", dataList);
		request.setAttribute("totalCount", totalCount);
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("currentPage", page);
		return "open/news-materials-list";
	}
	
	@RequestMapping(value = "/news-edit")
	public Object newsDetailForEdit(HttpServletRequest request, HttpServletResponse response) {
		String mediaId = ServletRequestUtils.getStringParameter(request, "mediaId", "");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount != null){
			request.setAttribute("nickName", mpAccount.getNickName());
			request.setAttribute("headImg", mpAccount.getHeadImg());
		}
		MpMaterialNews news = mpMaterialNewsService.selectNewsByMediaId(tenant_id, mediaId);
		List<MpMaterialNewsDetail> details = mpMaterialNewsDetailService.selectNewsDetailByNewsId(tenant_id, news.getId());
		for (MpMaterialNewsDetail mpMaterialNewsDetail : details) {
			mpMaterialNewsDetail.setContentHtml(EmojiUtil.formatEmojiForEditor(mpMaterialNewsDetail.getContent()));
		}
		news.setDetails(details);
		String jsonStr = JSONObject.fromObject(news).toString();
		List<MpEmoji> emojiList = EmojiUtil.getEmojiList();
		List<Map<String,String>> emojiMapList = Lists.newArrayList();
		for (MpEmoji mpEmoji : emojiList) {
			Map<String,String> emoji = new HashMap<String,String>();
			emoji.put("src", mpEmoji.getImage());
			emoji.put("alt", mpEmoji.getEmoji());
			emojiMapList.add(emoji);
		}
		
		request.setAttribute("emojiList", JSONArray.fromObject(emojiMapList));
		request.setAttribute("newsJSON", jsonStr);
		return "open/createNews";
	}
	
	@RequestMapping(value = "/news-materials-detail")
	public String newsMaterialsDetail(HttpServletRequest request, HttpServletResponse response) {
		String mediaId = ServletRequestUtils.getStringParameter(request, "mediaId", "");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpMaterialNews news = mpMaterialNewsService.selectNewsByMediaId(tenant_id, mediaId);
		List<MpMaterialNewsDetail> details = mpMaterialNewsDetailService.selectNewsDetailByNewsId(tenant_id, news.getId());
		news.setDetails(details);
		request.setAttribute("news", news);
		return "open/news-materials-detail";
	}
	
	@RequestMapping(value = "/createNews")
	public String createNews(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount != null) {				
			request.setAttribute("newsJSON", "{}");
			List<MpEmoji> emojiList = EmojiUtil.getEmojiList();
			List<Map<String,String>> emojiMapList = Lists.newArrayList();
			for (MpEmoji mpEmoji : emojiList) {
				Map<String,String> emoji = new HashMap<String,String>();
				emoji.put("src", mpEmoji.getImage());
				emoji.put("alt", mpEmoji.getEmoji());
				emojiMapList.add(emoji);
			}
			request.setAttribute("nickName", mpAccount.getNickName());
			request.setAttribute("emojiList", JSONArray.fromObject(emojiMapList));
			return "open/createNews";
		}else {
			return "open/needLogin";
		}
	}
	
	@ResponseBody
	@RequestMapping(value = "/uploadNewsImg")
	public Object uploadNewsImg(HttpServletRequest request, MultipartFile newsImg) throws IllegalStateException, IOException {
		Cookie[] cookies = request.getCookies();
		String uid = CookieUtil.getCookieSet(cookies).get("uid");
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		Map<String, Object> result = new HashMap<String, Object>();
		if (!newsImg.isEmpty()) {
			String path = request.getSession().getServletContext().getRealPath("");
			String originalFileName = newsImg.getOriginalFilename();
			// 新的图片名称
			String newFileName = UUID.randomUUID() + originalFileName.substring(originalFileName.lastIndexOf("."));
			// 新的图片
			File newFile = new File(path + newFileName);
			// 将内存中的数据写入磁盘
			newsImg.transferTo(newFile);
			String fileUrl = new MediaUtil().uploadnewsImg(authorizer_access_token, newFile);
			//图文中的图片不保存到素材库
			/*MpMaterial material = new MaterialUtil().uploadMaterial(uid, authorizer_access_token, newFile, MaterialType.IMAGE);
			mpMaterialService.save(material);*/
			//删除临时文件
			newFile.delete();
			result.put("errno", 0);
			List<String> files = new ArrayList<String>();
			files.add(fileUrl);
			result.put("data", files);
		}
		return result;
	}
	
	@ResponseBody
	@RequestMapping("/uploadThumb")
	public Object uploadThumb(HttpServletRequest request, MultipartFile thumbpic) throws IllegalStateException, IOException {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		String uid = CookieUtil.getCookieSet(cookies).get("uid");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		Map<String, Object> result = new HashMap<String, Object>();
		if (!thumbpic.isEmpty()) {
			String path = request.getSession().getServletContext().getRealPath("");
			String originalFileName = thumbpic.getOriginalFilename();
			// 新的图片名称
			String newFileName = UUID.randomUUID() + originalFileName.substring(originalFileName.lastIndexOf("."));
			// 新的图片
			File newFile = new File(path + newFileName);
			// 将内存中的数据写入磁盘
			thumbpic.transferTo(newFile);
			//String mediaId = MediaUtil.uploadMedia("1", authorizer_access_token, newFile, MaterialType.THUMB);
			MpMaterial material = new MaterialUtil().uploadMaterial(uid, authorizer_access_token, newFile, MaterialType.IMAGE);
			mpMaterialService.save(material);
			String mediaId = material.getMediaId();
			//删除临时文件
			newFile.delete();
			result.put("success", true);
			result.put("mediaId", mediaId);
			result.put("cecookUrl", material.getCecookUrl());
		}
		return result;
	}
	
	@ResponseBody
	@RequestMapping("/transToThumb")
	public Object transToThumb(HttpServletRequest request, HttpServletResponse response) throws IllegalStateException, IOException {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		String uid = CookieUtil.getCookieSet(cookies).get("uid");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		String fileUrl = ServletRequestUtils.getStringParameter(request, "imgUrl", "");
		File file = ImageUtil.saveUrlToFile(fileUrl);
		String mediaId = MediaUtil.uploadMedia(uid, authorizer_access_token, file, MaterialType.IMAGE);
		//删除临时文件
		file.delete();
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		result.put("mediaId", mediaId);
		return result;
	}
	
	@ResponseBody
	@RequestMapping(value = "/saveNews")
	public Object saveNewsMaterials(HttpServletRequest request, @RequestBody Map<String, String> map) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		//String articles = ServletRequestUtils.getStringParameter(request, "articles", "");
		JSONArray articlesJson = JSONArray.fromObject(map.get("articles"));
		String mediaId = map.get("mediaId");
		if (StringUtils.hasText(mediaId)) {
			for(int i = 0;i<articlesJson.size();i++){
				MediaUtil.updatenews(authorizer_access_token, mediaId, i, articlesJson.getJSONObject(i));
			}
		}else{
			mediaId = MediaUtil.uploadnews(authorizer_access_token, articlesJson);
		}
		Map<String, Object> result = new HashMap<String, Object>();
		//更新该素材
		if(org.apache.commons.lang.StringUtils.isNotEmpty(mediaId)) {			
			mpMaterialNewsService.delByMediaId(tenant_id, mediaId, null);
			String filePath = request.getSession().getServletContext().getRealPath("");
			MpMaterialNews mpMaterialNews = new MaterialUtil().getMaterialNews(mediaId, authorizer_access_token, filePath);
			mpMaterialNewsService.insertNews(mpMaterialNews);
			for (int j = 0; j < mpMaterialNews.getDetails().size(); j++) {
				MpMaterialNewsDetail mpMaterialNewsDetail = mpMaterialNews.getDetails().get(j);
				mpMaterialNewsDetail.setNewsId(mpMaterialNews.getId());
				mpMaterialNewsDetailService.insertNewsDetail(mpMaterialNewsDetail);
			}
			if (StringUtils.hasText(mediaId)) {
				result.put("success", true);
				result.put("mediaId", mediaId);
			}else{
				result.put("success", false);
			}
		}else {
			result.put("success", false);
		}
		return result;
	}
	
	@ResponseBody
	@RequestMapping("/delNewsMaterial")
	public Object delNewsMaterial(HttpServletRequest request, HttpServletResponse response)  {
		String mediaId = ServletRequestUtils.getStringParameter(request, "mediaId", "");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		mpMaterialNewsService.delByMediaId(tenant_id, mediaId, authorizer_access_token);;
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		return result;
	}
	
	@RequestMapping(value = "/picture-materials", method = RequestMethod.GET)
	public String pictureMaterials(HttpServletRequest request, HttpServletResponse response) {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		int page = ServletRequestUtils.getIntParameter(request, "page", 1);
		int pageSize = ConfigUtil.getInstance().pageSize;
		int pageStart = (page-1) * pageSize;
		List<MpMaterial> dataList = mpMaterialService.selectMaterial(tenant_id,pageStart, pageSize);
		int totalCount = mpMaterialService.getCount(tenant_id);
		int totalPage = totalCount%pageSize == 0? totalCount/pageSize : totalCount/pageSize +1;
		request.setAttribute("dataList", dataList);
		request.setAttribute("totalCount", totalCount);
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("currentPage", page);
		return "open/picture-materials";
	}

	@RequestMapping(value = "/picture-materials-datalist", method = RequestMethod.GET)
	public String pictureMaterialsForMassSendingForm(HttpServletRequest request, HttpServletResponse response) {
		int page = ServletRequestUtils.getIntParameter(request, "page", 1);
		int pageSize = ConfigUtil.getInstance().pageSize;
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		int pageStart = (page-1) * pageSize;
		List<MpMaterial> dataList = mpMaterialService.selectMaterial(tenant_id,pageStart, pageSize);
		int totalCount = mpMaterialService.getCount(tenant_id);
		int totalPage = totalCount%pageSize == 0? totalCount/pageSize : totalCount/pageSize +1;
		request.setAttribute("dataList", dataList);
		request.setAttribute("totalCount", dataList.size());
		request.setAttribute("totalPage", totalPage);
		request.setAttribute("currentPage", page);
		return "open/pictureList";
	}

	@ResponseBody
	@RequestMapping("/pictureUpload")
	public Object addPet(HttpServletRequest request, MultipartFile pic) throws IllegalStateException, IOException {
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		String uid = CookieUtil.getCookieSet(cookies).get("uid");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		Map<String, Object> result = new HashMap<String, Object>();
		if (!pic.isEmpty()) {
			String path = request.getSession().getServletContext().getRealPath("");
			String originalFileName = pic.getOriginalFilename();
			String newFileName = UUID.randomUUID() + originalFileName.substring(originalFileName.lastIndexOf("."));
			File newFile = new File(path + newFileName);
			pic.transferTo(newFile);
			MpMaterial material = new MaterialUtil().uploadMaterial(uid, authorizer_access_token, newFile, MaterialType.IMAGE);
			mpMaterialService.save(material);
			//删除临时文件
			newFile.delete();
			result.put("success", true);
			result.put("material", material);
		}
		return result;
	}
	
	@ResponseBody
	@RequestMapping("/delMaterial")
	public Object delMaterial(HttpServletRequest request, HttpServletResponse response)  {
		String mediaIds = ServletRequestUtils.getStringParameter(request, "mediaIds", "");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
		String[] mediaIdArray = mediaIds.split(",");
		for (String mediaId : mediaIdArray) {
			mpMaterialService.del(tenant_id, mediaId, authorizer_access_token);
		}
		Map<String, Object> result = new HashMap<String, Object>();
		result.put("success", true);
		return result;
	}
	
	/**
	 * 中转显示
	 */
	@RequestMapping(value = "/material", method = RequestMethod.GET)
	@ResponseBody
	public void material(HttpServletRequest request, HttpServletResponse response) {
		response.setContentType("image/png");
		Cookie[] cookies = request.getCookies();
		String tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id");
		String media_id = request.getParameter("media_id");
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount != null){			
			String authorizer_access_token = mpAccount.getAuthorizerAccessToken();
			try {
				MpMaterial mpMaterial = mpMaterialService.selectMaterialBymediaId(mpAccount.getTenantId(), media_id);
				if(mpMaterial != null && org.apache.commons.lang.StringUtils.isNotEmpty(mpMaterial.getCecookUrl())) {
					HttpURLConnection conn = (HttpURLConnection) new URL(mpMaterial.getCecookUrl()).openConnection();
		            conn.setReadTimeout(5000);
		            conn.setConnectTimeout(5000);
		            conn.setRequestMethod("GET");
		            if (conn.getResponseCode() == HttpURLConnection.HTTP_OK) {
		            	BufferedImage bi = ImageIO.read(conn.getInputStream());
		            	ImageIO.write(bi, "png", response.getOutputStream());
		            }
				}else {					
					ByteArrayInputStream in = new ByteArrayInputStream(new MaterialUtil().getMaterialImage(media_id, authorizer_access_token)); 
					BufferedImage bi = ImageIO.read(in);
					ImageIO.write(bi, "png", response.getOutputStream());
				}
			} catch (IOException e) {
				e.printStackTrace();
			}
		}
	}
}
