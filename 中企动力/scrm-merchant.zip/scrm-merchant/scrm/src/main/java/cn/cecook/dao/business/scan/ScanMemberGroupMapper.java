package cn.cecook.dao.business.scan;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.uitls.Pages;


public interface ScanMemberGroupMapper {
	void saveMemberGroup(Map<String, Object> param);
	void updateMemberGroup(Map<String, Object> param);
	/**
	 * 	获取顶层元素，也就是分类
	 * @return
	 */
	List<Map<String, Object>> getTop();
	/**
	 * 	根据父元素id，获取子元素
	 * @return
	 */
	List<Map<String, Object>> getByParentId(int parentId);
//	List<Long> getMemberByWhere(@Param("where") String where);
//	List<Long> getMemberByWhere(Map<String, Object> where);
	List<Map<String,Object>> getMemberByWhere(Map<String, Object> where);
	/**
	 * 	保存分组与会员映射
	 * @param groupId
	 * @param memberIds
	 */
	void saveGroupMemberMap(Map<String, Object> param);
	void saveGroupMemberMap4List(List<Map<String, Object>> param);
	/**
	 * 	组会员总数：人 （有邮箱人，有微博昵称人）
	 * @param groupId
	 * @return
	 */
	Map<String, Object> countPeople(long groupId);	//静态分组
//	Map<String, Object> countPeople2(@Param("where") String where);	//动态分组
	Map<String, Object> countPeople2(Map<String, Object> where);	//动态分组

	Map<String, Object> getGroup(long id);
	Map<String, Object> getGroupByName(@Param("name") String name);

	/**
	 * 	用于静态分组
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> getPageGroup(Pages<Map<String, Object>> page);
	int countGroup(Map<String, Object> where);

	/**
	 * 	用于动态分组
	 * @param page
	 * @return
	 */
	List<Map<String, Object>> getPageGroup2(Pages<Map<String, Object>> page);
	int countGroup2(Map<String, Object> where);

	void delGroup(long groupId);
	void delGroupMemberMap(long groupId);

	void selectGroup(@Param("groupId") long groupId, @Param("parentId") long parentId);

	//静态分组
	List<Map<String,Object>> listMemberByGroupId(long groupId);
	//动态分组
//	List<Map<String,Object>> listMemberByWhere(@Param("where") String where);
	List<Map<String,Object>> listMemberByWhere(Map<String, Object> where);

	void rename(@Param("groupId") int groupId, @Param("name") String name);

	List<Map<String,Object>> getCustomerGroup(Map<String, Object> map);

	List<Map<String,Object>> getGroupCustomeList1(@Param("groupId") Long groupId,@Param("tenantId") String tenant_id);

	List<Map<String,Object>> getGroupCustomeList2(Map<String, Object> where);
	//social模块使用 
	Map<String, Object> getGroupBySocial(@Param("id") long id,@Param("tenantId") String tenant_id);
	
	/**
	 * 增加分类、跟组
	 * @param param
	 */
	void saveMemberGroupAndSelect(Map<String, Object> param);
	/**
	 * 增加分组与会员的对应关系
	 * @param param
	 */
	void saveGroupMemberMapAndSelect(Map<String, Object> param);
	
	/**
	 * 商品名称模糊查找
	 * @param name
	 */
	List<String> listMedicineNameLikeName(@Param("name")String name);
	
	/**
	 * 查询所有分组信息（按名称查询）
	 * @return
	 * majie
	 */
	public List<Map<String,Object>> findByName(String name);
	/**
	 * 获取会员动态分组的数据
	 * @param tenantId 
	 * @param param
	 */
	List<Map<String, Object>> getDynamicGroupList(@Param("tenantId") String tenantId);
	/**
	 * 删除之前的旧数据
	 * @param tenantId 
	 * @param integer
	 */
	void deleteGroup(@Param("groupId") Integer groupId,@Param("tenantId") String tenantId);
	/**
	 *	保存分组会员数据
	 * @param param
	 */
	void saveGroupMemberMaps(Map<String, Object> param);
	/**
	 * 更新数据库里数据的条数
	 * @param count
	 * @param tenantId 
	 * @param integer 
	 */
	void updateMemberCount(@Param("count") Integer count,@Param("groupId") Integer groupId,@Param("tenantId") String tenantId);
	/**
	 * 根据Id查询分组名称
	 * @param id
	 * @return
	 * majie
	 */
	Map<String, Object> findNameById(Integer id); 
}