package cn.cecook.model.business.automation;
/**
 * 动作类型
 * @author majie
 *
 * 2018年1月22日-下午4:42:01
 */
public enum ActionType {
	//sms--短信
	//coupon--优惠券
	SMS,COUPON
}
