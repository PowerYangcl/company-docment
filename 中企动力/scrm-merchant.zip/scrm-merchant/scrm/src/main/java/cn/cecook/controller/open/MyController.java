package cn.cecook.controller.open;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.HashSet;
import java.util.List;
import java.util.Map;
import java.util.Set;

import javax.annotation.Resource;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import net.sf.json.JSONArray;
import net.sf.json.JSONObject;

import org.apache.commons.lang.StringUtils;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.servlet.ModelAndView;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.model.business.markting.BmActivity;
import cn.cecook.model.business.markting.BmCoupon;
import cn.cecook.model.open.mp.MpAccount;
import cn.cecook.model.open.mp.MpRelate;
import cn.cecook.model.open.mp.MpTicket;
import cn.cecook.model.open.mp.MpUser;
import cn.cecook.model.open.mp.MpUserInfo;
import cn.cecook.service.business.customer.ICustomerService;
import cn.cecook.service.business.markting.ActivityService;
import cn.cecook.service.open.IBmCouponService;
import cn.cecook.service.open.IMpAccountService;
import cn.cecook.service.open.IMpBmActivityService;
import cn.cecook.service.open.IMpDockAuthorizeInfoService;
import cn.cecook.service.open.IMpRelateService;
import cn.cecook.service.open.IMpTicketService;
import cn.cecook.service.open.IMpUserInfoService;
import cn.cecook.service.open.IMpUserService;
import cn.cecook.service.system.ISmsService;
import cn.cecook.thirdparty.open.ConfigUtil;
import cn.cecook.thirdparty.open.HttpUtil;
import cn.cecook.thirdparty.open.TokenUtil;
import cn.cecook.uitls.CookieUtil;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

@Controller
@RequestMapping("open")
public class MyController {
	private static JsonParser parser = new JsonParser();
	private static String cookie_openid_key = "openid";
	
	@Autowired
	private ICustomerService iCustomerService;
	
	@Autowired
	private IMpAccountService mpAccountService;

	@Autowired
	private IMpTicketService mpTicketService;
	
	@Autowired
	private IMpUserService iMpUserService;
	
	@Autowired
	private IBmCouponService iBmCouponService;
	
	@Autowired
	private ActivityService activityService;
	
	@Autowired
	private IMpBmActivityService iBmActivityService;
	
	@Autowired
	private IMpUserInfoService mpUserInfoService;
	
	@Autowired
	private IMpRelateService iMpRelateService;
	
	@Autowired
	private IMpDockAuthorizeInfoService dockAuthorizeInfoService;
	
	@Resource
	ISmsService smsService;

	@RequestMapping(value = "/me", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView me(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		String mobile = CookieUtil.getCookieSet(request.getCookies()).get("mobile");
		String tenant_id = CookieUtil.getCookieSet(request.getCookies()).get("tenant_id");
		String cookieOpenid = CookieUtil.getCookieSet(request.getCookies()).get(cookie_openid_key);
		if(StringUtils.isEmpty(tenant_id) || "undefined".equals(tenant_id)) {
			tenant_id = request.getParameter("tenant_id");
		}
		if(StringUtils.isNotEmpty(tenant_id)){
			CookieUtil.setCookie(response, "tenant_id", tenant_id, ConfigUtil.getInstance().cookieExpire);
		}
		MpAccount mpAccount = mpAccountService.selectMpAccountByTenantId(tenant_id);
		if(mpAccount != null) {
			String code = request.getParameter("code");
			String appid = request.getParameter("appid");
			if(StringUtils.isNotEmpty(code)){
				MpTicket mpTicket = mpTicketService.selectOne();
				String openId = TokenUtil.getInstance().getOpenidByCode(code, mpAccount.getAuthorizerAppid(), mpTicket.getComponentAccessToken());
				if(StringUtils.isNotEmpty(cookieOpenid) && !cookieOpenid.equals(openId)) {//异账号登录，强制退出
					CookieUtil.setCookie(response, cookie_openid_key, openId, ConfigUtil.getInstance().cookieExpire);
					modelAndView.setViewName("open/H5/login");			
					return modelAndView;
				}
				CookieUtil.setCookie(response, cookie_openid_key, openId, ConfigUtil.getInstance().cookieExpire);				
			}
			model.put("wx_component_appid", ConfigUtil.getInstance().getProperties().getProperty("APPID"));
			model.put("wx_user_name", mpAccount.getAuthorizerAppid());
		}
		//判断是CRM会员
		boolean isCRMer = dockAuthorizeInfoService.isCRMer(tenant_id);
		CookieUtil.setCookie(response, "isCRMer", isCRMer?"1":"0", ConfigUtil.getInstance().cookieExpire);
		
		MpUserInfo mpUserInfo = mpUserInfoService.getByTenantId(tenant_id);
		model.put("mpUserInfo", mpUserInfo);
		if(StringUtils.isNotEmpty(mobile) && StringUtils.isNotEmpty(tenant_id)){
			model.put("mobile", mobile);
			model.put("tenant_id", tenant_id);
			BaseResultModel customer_ = (BaseResultModel) iCustomerService.getCustomerIdByPhone(mobile);
			model.put("cid", customer_ == null ? "" : customer_.getData());
			MpUser mpUser = iMpUserService.getUserByPhone(mobile);
			model.put("mpUser", mpUser);
			//其他基本信息
			if(mpUser != null){				
				String url = HttpUtil.scrmbase + "/user/userQuery";
				JSONObject jsonParam = new JSONObject();  
				jsonParam.put("mobile", mobile);
				jsonParam.put("tenantId", tenant_id);
				String result = HttpUtil.httpPostWithJSON(url, jsonParam);
				JsonObject resultObject = parser.parse(result).getAsJsonObject();
				int status = resultObject.get("status").getAsInt();
				if(status == 200){
					try {
						JsonObject dataJson = resultObject.get("data").getAsJsonObject();
						if(!dataJson.get("realname").isJsonNull()) {
							mpUser.setNickname(dataJson.get("realname").getAsString());
						}
						if(!dataJson.get("memberLevel").isJsonNull()) {							
							model.put("memberLevel", dataJson.get("memberLevel").getAsString());
						}
						if(!dataJson.get("credits").isJsonNull()){							
							model.put("credits", dataJson.get("credits").getAsInt()/100f);
						}
						if(!dataJson.get("balance").isJsonNull()) {	
							model.put("balance", dataJson.get("balance").getAsInt()/100);
						}
					} catch (Exception e) {
						model.put("credits", "--");
						model.put("balance", "--");
					}
				}else {
					model.put("credits", "--");
					model.put("balance", "--");
				}
			}
			modelAndView.setViewName("open/H5/me");
		}else{
			modelAndView.setViewName("open/H5/login");			
		}
		return modelAndView;
	}
	
	@RequestMapping(value = "/login", method = RequestMethod.POST)
	@ResponseBody
	public ModelAndView login(HttpServletRequest request, HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		String mobile = request.getParameter("mobile");
		String code = request.getParameter("code");
		String tenant_id = CookieUtil.getCookieSet(request.getCookies()).get("tenant_id");
		boolean codeRight = false;
		MpUserInfo mpUserInfo = mpUserInfoService.getByTenantId(tenant_id);
		model.put("mpUserInfo", mpUserInfo);
		if(StringUtils.isEmpty(tenant_id)) {
			modelAndView.setViewName("/open/H5/error");			
			return modelAndView;
		}
		//判断验证码正确
		if(StringUtils.isNotEmpty(code)){
			AccountModel  accountModel = new AccountModel();
			ResultModel resultModel = new ResultModel();
			accountModel.setAccount(mobile);
			accountModel.setVer_code(code);
			accountModel.setCode_type("login_code");
			try {
				resultModel = smsService.verify(accountModel);
				//测试用
				//resultModel.setError_code("0");
			} catch (Exception e) {
				//resultModel = smsService.verifyDB(accountModel);
				e.printStackTrace();
			}
			if(resultModel != null) {
				if("0".equals(resultModel.getError_code())) {					
					codeRight = true;
				}else {
					model.put("errormsg", resultModel.getError_msg());
				}
			}else {
				model.put("errormsg", "验证码错误");
			}
		}else {
			model.put("errormsg", "验证码错误");
		}
		//判断是CRM会员
		boolean isCRMer = dockAuthorizeInfoService.isCRMer(tenant_id);
		CookieUtil.setCookie(response, "isCRMer", isCRMer?"1":"0", ConfigUtil.getInstance().cookieExpire);
		//判断是粉丝
		if(StringUtils.isNotEmpty(mobile)) {	
			model.put("tenant_id", tenant_id);
			model.put("mobile", mobile);
			if(codeRight) {
				try {
					//存储用户手机系统
					String userSystem = "";
					String ua = request.getHeader("User-Agent");
					if(ua.toUpperCase().contains(" IPHONE ") || ua.toUpperCase().contains(" IOS ")) {
						userSystem = "ios";
					}else if(ua.toUpperCase().contains(" ANDROID ")) {
						userSystem = "android";						
					}
					BaseResultModel customerIdByPhone = (BaseResultModel) iCustomerService.getCustomerIdByPhone(mobile);
					if(StringUtils.isNotEmpty(mobile) && customerIdByPhone != null && "ok".equals(customerIdByPhone.getError_code())){
						CookieUtil.setCookie(response, "mobile", mobile, ConfigUtil.getInstance().cookieExpire);
						CookieUtil.setCookie(response, "tenant_id", tenant_id, ConfigUtil.getInstance().cookieExpire);
						String cookieOpenid = CookieUtil.getCookieSet(request.getCookies()).get(cookie_openid_key);
						if(StringUtils.isNotEmpty(cookieOpenid)) {
							iMpRelateService.deleteByPhone(tenant_id, mobile);
							iMpRelateService.deleteByOpenid(tenant_id, cookieOpenid);
							MpRelate mpRelate = new MpRelate();
							mpRelate.setTenantId(tenant_id);
							mpRelate.setOpenid(cookieOpenid);
							mpRelate.setPhone(mobile);
							mpRelate.setUserSystem(userSystem);
							iMpRelateService.insert(tenant_id, mpRelate);
							
							//更新用户表手机号
							MpUser userByPhone = iMpUserService.getUserByPhone(mobile);
							if(userByPhone != null && !cookieOpenid.equals(userByPhone.getOpenid())) {
								iMpUserService.clearUserMemberInfo(userByPhone.getId());
							}
							MpUser mpUser = iMpUserService.getUserByOpenid(cookieOpenid);
							if(mpUser != null) {
								Map<String, Object> mpUserMap = new HashMap<String, Object>();
								mpUserMap.put("userId", mpUser.getId());
								mpUserMap.put("phone", mobile);
								iMpUserService.updateUser(mpUserMap);
							}
						}
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}else {
				modelAndView.setViewName("open/H5/login");
				return modelAndView;
			}
		}else {
			model.put("errormsg", "请输入手机号");
			modelAndView.setViewName("open/H5/login");
			return modelAndView;
		}
		modelAndView.setViewName("redirect:/open/me");
		return modelAndView;
	}
	
	@RequestMapping(value = "/list/{someList}", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView integralList(HttpServletRequest request, 
			@PathVariable String someList,
			HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		modelAndView.setViewName("open/H5/"+someList);			
		return modelAndView;
	}
	
	/**
	 * 各种明细
	 */
	@RequestMapping(value = "/me/detailList", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView me_detailList(
			HttpServletRequest request, 
			HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		String mobile = CookieUtil.getCookieSet(request.getCookies()).get("mobile");
		String tenant_id = CookieUtil.getCookieSet(request.getCookies()).get("tenant_id");
		String callback = request.getParameter("callback");
		String startNumStr = request.getParameter("startNum");
		String limitStr = request.getParameter("limit");
		String tradeTypeStr = request.getParameter("tradeType");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 200);
		jsonObject.put("message", "ok");
		JSONObject jsonParam = new JSONObject();  
        jsonParam.put("mobile", mobile);
        jsonParam.put("tenantId", tenant_id);
        jsonParam.put("startNum", startNumStr);
        jsonParam.put("limit", limitStr);
        jsonParam.put("tradeType", tradeTypeStr);
        String url = HttpUtil.scrmbase + "/user/tradeList";
		String result = HttpUtil.httpPostWithJSON(url, jsonParam);
		JsonObject resultObject = parser.parse(result).getAsJsonObject();
		int status = resultObject.get("status").getAsInt();
		if(status == 200){
			JSONArray dataArr = new JSONArray();
			JsonArray datas_ = resultObject.get("data").getAsJsonArray();
			for (int i = 0; i < datas_.size(); i++) {
				JSONObject itemObj = new JSONObject();
				JsonObject itemObj_ = datas_.get(i).getAsJsonObject();
				String[] split = itemObj_.get("datetime").getAsString().split(" ");
				if(split.length == 2){
					itemObj.put("day", split[0]);
					itemObj.put("time", split[1]);					
				}
				itemObj.put("storeName", itemObj_.get("storeName").getAsString());
				itemObj.put("type", itemObj_.get("type").getAsString());
				itemObj.put("tradeValue", itemObj_.get("tradeValue").getAsInt());
				//暂时不用这个字段
//				JSONArray tradeArr_ = new JSONArray();
//				itemObj.put("tradeType", tradeArr_);
				dataArr.add(0,itemObj);
			}
			jsonObject.put("data", dataArr);
		}
		if (StringUtils.isEmpty(callback)) {
			model.put("jsonResult", jsonObject);
		} else {
			model.put("jsonResult", callback + "(" + jsonObject + ")");
		}
		modelAndView.setViewName("open/H5/jsonResults");
		return modelAndView;
	}
	
	/**
	 * 活动列表页面
	 */
	@RequestMapping(value = "/me/activityList", method = RequestMethod.GET)
	@ResponseBody
	public ModelAndView me_activityList(
			HttpServletRequest request, 
			HttpServletResponse response) {
		ModelAndView modelAndView = new ModelAndView();
		Map<String, Object> model = modelAndView.getModel();
		String mobile = CookieUtil.getCookieSet(request.getCookies()).get("mobile");
		String tenant_id = CookieUtil.getCookieSet(request.getCookies()).get("tenant_id");
		String callback = request.getParameter("callback");
		String startNumStr = request.getParameter("startNum");
		String limitStr = request.getParameter("limit");
		String tradeTypeStr = request.getParameter("tradeType");
		JSONObject jsonObject = new JSONObject();
		jsonObject.put("status", 200);
		jsonObject.put("message", "ok");
		JSONObject dataJson = new JSONObject();
		JSONArray allActivityArr = new JSONArray();
		BaseResultModel activityList = activityService.getActivityListBySys("0", "100", "1");
		if(activityList != null && activityList.getTotalCount() > 0){
			List<Map<String, Object>> activityListMap = (List<Map<String, Object>>) activityList.getData();
			for (int i = 0; i < activityListMap.size(); i++) {
				Map<String, Object> activityMap = activityListMap.get(i);
				JSONObject activityJson = new JSONObject();
				activityJson.put("head_pic", activityMap.get("head_pic"));
				activityJson.put("name", activityMap.get("name"));
				activityJson.put("content", activityMap.get("content"));
				activityJson.put("web_url", activityMap.get("web_url"));
				activityJson.put("end_time", activityMap.get("end_time"));
				allActivityArr.add(activityJson);
			}
		}
		dataJson.put("allActivity", allActivityArr);
		JSONArray joinAcivitiyArr = new JSONArray();
		List<BmCoupon> couponByPhone = iBmCouponService.findCouponByPhone(mobile);
		Set<Long> activityIds = new HashSet<Long>();
		if(couponByPhone != null && couponByPhone.size() > 0) {
			for (int i = 0; i < couponByPhone.size(); i++) {
				BmCoupon bmCoupon = couponByPhone.get(i);
				activityIds.add(bmCoupon.getActivityId());
			}
			if(activityIds.size() > 0) {
				try {
					List<BmActivity> findByActivityIds = iBmActivityService.findByActivityIds(new ArrayList<Long>(activityIds));
					for (int i = 0; findByActivityIds.size() > 0 && i < findByActivityIds.size(); i++) {
						BmActivity bmActivity = findByActivityIds.get(i);
						JSONObject activityJson = new JSONObject();
						activityJson.put("head_pic", bmActivity.getHead_pic());
						activityJson.put("name", bmActivity.getName());
						activityJson.put("content", bmActivity.getContent());
						activityJson.put("end_time", bmActivity.getEnd_time() == null?"": bmActivity.getEnd_time().toString());
						activityJson.put("web_url", bmActivity.getWebUrl());
						joinAcivitiyArr.add(activityJson);
					}
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		}
		dataJson.put("joinAcivitiy", joinAcivitiyArr);
		jsonObject.put("data", dataJson);
		if (StringUtils.isEmpty(callback)) {
			model.put("jsonResult", jsonObject);
		} else {
			model.put("jsonResult", callback + "(" + jsonObject + ")");
		}
		modelAndView.setViewName("open/H5/jsonResults");
		return modelAndView;
	}
}
