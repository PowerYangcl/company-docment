package cn.cecook.dao.business.service;

import cn.cecook.model.business.service.CriterionMedicineLog;

/**
 * 对药品库的操作日志
 * @author majie
 *
 */
public interface CriterionMedicineLogMapper {
	/**
	 * 添加日志信息
	 * @return
	 * majie
	 */
	public Integer addCriterionMedicineLog(CriterionMedicineLog criterionMedicineLog);
}
