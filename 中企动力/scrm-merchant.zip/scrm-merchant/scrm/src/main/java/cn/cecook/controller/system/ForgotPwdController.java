package cn.cecook.controller.system;


import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.bean.system.AccountModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.system.IForgotPwdService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.ConfigUtil;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.MD5Util;
import cn.cecook.uitls.StringUtils;

/**
 * 
 * @explain 
 * @author LeeX
 * @date 2017年5月31日
 */
@Controller
@RequestMapping("/api/forgot")
public class ForgotPwdController {

	@Resource
	IForgotPwdService forgotPwdService;
	//标记参数
	boolean falg;
	
	@RequestMapping(value = "/toNext" , method = RequestMethod.POST)
	public @ResponseBody Object toNext(HttpServletRequest request, HttpServletResponse response){ 
		//对象参数
    	ResultModel resultModel = new ResultModel();
    	AccountModel am = new AccountModel();
    	
		//获取参数
		String account = request.getParameter("account");
		String ver_code = request.getParameter("ver_code");
		String code_type = request.getParameter("code_type");
		
		//封装对传参对象
		am = new AccountModel();
		am.setAccount(account);
		am.setCode_type(code_type);
		am.setVer_code(ver_code);
		
		//传入service
		SysUser user = null;
		try {
			user = forgotPwdService.toNext(am);
		} catch (Exception e) {
			e.printStackTrace();
		}
		
		//处理结果
		if(user == null){
			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			return (resultModel);
		}
		
		//用户存在，将用户id和account放在cookie中返回
		Cookie accountCK = new Cookie("account", user.getAccount());
		Cookie userIdCK = new Cookie("uid", String.valueOf(user.getId()));
		Cookie tenantIdCK = new Cookie("tenant_id", user.getTenantId());
		Cookie flagCK = new Cookie("flag", "fg");
		
		accountCK.setPath("/");
		userIdCK.setPath("/");
		tenantIdCK.setPath("/");
		flagCK.setPath("/");
		
		response.addCookie(accountCK);
		response.addCookie(userIdCK);
		response.addCookie(tenantIdCK);
		response.addCookie(flagCK);
		
		//返回结果
		resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
		
		return (resultModel);
		
	} 
	
	
	
	
	
	
	/**
	 * 
	 * @explain 找回密码
	 * @author LeeX
	 * @date 2017年5月31日 上午8:42:18
	 */
	@RequestMapping(value = "/forgot_pwd" , method = RequestMethod.POST)
	public @ResponseBody Object forgotPwd(HttpServletRequest request, HttpServletResponse response){ 
		//对象参数
    	ResultModel resultModel = new ResultModel();
    	AccountModel am = new AccountModel();
    	
		//获取新密码
		String new_pwd = request.getParameter("new_pwd");
		
		// 从cookie中获取当前用户的uid
		Cookie[] cookies = request.getCookies();
		Map cookieSet = CookieUtil.getCookieSet(cookies);
		String flag = (String)cookieSet.get("flag");
		
		if(StringUtils.isBlank(flag)){
			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg("请先验证！");
			return (resultModel);
		}
		String id = (String)cookieSet.get("uid");
		if(id== null || "".equals(id)){
			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg("请刷新页面重试！");
			return (resultModel);
		}
		
		Long uid = Long.parseLong(id);
		//封装到am中
		am.setUid(uid);
		//密码二次加密
		new_pwd = MD5Util.encodeString(MD5Util.encodeString(new_pwd)+ConfigUtil.MD5_PWD_STR);
		//封装到am中
		am.setNew_pwd(new_pwd);
		
		//传参数到service
		try {
			falg = forgotPwdService.forgotPwd(am);
		} catch (Exception e) {
			falg = false;
			e.printStackTrace();
		}
		
		//处理返回结果
		if(!falg){
			resultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			resultModel.setError_msg("修改失败，请仔细核对账户和验证码！");
			return (resultModel);
		}
		
		resultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
		resultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
		
		return (resultModel);
	}
}
