package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.Date;

@Component
public class CodeModel implements Serializable{
    /*
     * 
     */
        //接收电话
        private String mobile;
        //验证码类型
        private String code_type;
        //注册用户输入的验证码
        private String check_code  ;
        //创建时间
        private Date create_time ;
        //删除时间
        private Date delete_time ;       
        //失效时间
        private Date expire_time ;
        //登录验证码
        private int is_used;
        //身份验证的验证码
        private Date using_time;
        //删除标记
        private int is_deleted;
        //注册发送的验证码
        private String ver_code_d;
        //公司电话
        private String phone;
        
        
        public String getPhone() {
			return phone;
		}
		public void setPhone(String phone) {
			this.phone = phone;
		}
		public String getVer_code_d() {
            return ver_code_d;
        }
        public void setVer_code_d(String ver_code_d) {
            this.ver_code_d = ver_code_d;
        }
        public String getMobile() {
            return mobile;
        }
        public void setMobile(String mobile) {
            this.mobile = mobile;
        }
        public String getCode_type() {
            return code_type;
        }
        public void setCode_type(String code_type) {
            this.code_type = code_type;
        }
        public String getCheck_code() {
            return check_code;
        }
        public void setCheck_code(String check_code) {
            this.check_code = check_code;
        }
        public Date getCreate_time() {
            return create_time;
        }
        public void setCreate_time(Date create_time) {
            this.create_time = create_time;
        }
        public Date getDelete_time() {
            return delete_time;
        }
        public void setDelete_time(Date delete_time) {
            this.delete_time = delete_time;
        }
        public Date getExpire_time() {
            return expire_time;
        }
        public void setExpire_time(Date expire_time) {
            this.expire_time = expire_time;
        }
        public int getIs_used() {
            return is_used;
        }
        public void setIs_used(int is_used) {
            this.is_used = is_used;
        }
        public Date getUsing_time() {
            return using_time;
        }
        public void setUsing_time(Date using_time) {
            this.using_time = using_time;
        }
        public int getIs_deleted() {
            return is_deleted;
        }
        public void setIs_deleted(int is_deleted) {
            this.is_deleted = is_deleted;
        }
		@Override
		public String toString() {
			return "CodeModel [mobile=" + mobile + ", code_type=" + code_type + ", check_code=" + check_code
					+ ", create_time=" + create_time + ", delete_time=" + delete_time + ", expire_time=" + expire_time
					+ ", is_used=" + is_used + ", using_time=" + using_time + ", is_deleted=" + is_deleted
					+ ", ver_code_d=" + ver_code_d + ", phone=" + phone + ", getPhone()=" + getPhone()
					+ ", getVer_code_d()=" + getVer_code_d() + ", getMobile()=" + getMobile() + ", getCode_type()="
					+ getCode_type() + ", getCheck_code()=" + getCheck_code() + ", getCreate_time()=" + getCreate_time()
					+ ", getDelete_time()=" + getDelete_time() + ", getExpire_time()=" + getExpire_time()
					+ ", getIs_used()=" + getIs_used() + ", getUsing_time()=" + getUsing_time() + ", getIs_deleted()="
					+ getIs_deleted() + ", getClass()=" + getClass() + ", hashCode()=" + hashCode() + ", toString()="
					+ super.toString() + "]";
		}
      




}
