package cn.cecook.controller.business.customer;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.model.business.customer.BcCustomerComponentStructure;
import cn.cecook.service.business.customer.ICustom_dataComponentStructureService;
import cn.cecook.uitls.CookieUtil;

/**
 * 
 *@explain
 * @author ZHIWEN
 * @data 2017年7月27日
 */
@Controller
@RequestMapping("/api/ComponentStructure")
public class Custom_dataComponentStructureController {
	
	@Autowired
	private ICustom_dataComponentStructureService componentStructureService;

	/**
	 * 
	 *@explain  insert 控件结构
	 * @author ZHIWEN
	 * @data 2017年7月27日
	 */
	 @RequestMapping(value="/insert_ComponentStructure" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
	public @ResponseBody Object insert_ComponentStructure( HttpServletRequest request,
			@RequestParam(value = "controlhierarchystrings",required = false)String controlhierarchystrings) {
		 
		 Map<Long, String> map = new HashMap<Long, String>();
		 JsonObject jsonObject = new JsonObject();   
		    //创建人id
	        Cookie[] cookies= request.getCookies();
	        String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
	        if (id!=null) {
	         Long	uid = Long.parseLong(id);
	         map.put(uid, controlhierarchystrings);
	         
	         int status = componentStructureService.insert_ComponentStructure(map);
		         if (status==1) {
		        	 jsonObject.addProperty("status", "0");
				} else {
					 jsonObject.addProperty("status", "1");
				}
	        
			}
	        else {
	        	 jsonObject.addProperty("status", "1");
			}
		 System.out.println(jsonObject.toString());
		return jsonObject.toString();
		
	}
	 
	 /**
		 * 
		 *@explain  Select 控件结构
		 * @author ZHIWEN
		 * @data 2017年7月27日
		 */
	 @RequestMapping(value="/Show_ComponentStructure" ,method = RequestMethod.POST,produces = "application/json;charset=UTF-8")
     public @ResponseBody Object Show_ComponentStructure(HttpServletRequest request){
		 //创建人id
	        Cookie[] cookies= request.getCookies();
	        String id= CookieUtil.getCookieSet(cookies).get("uid").toString();
	        JsonObject jsonObject = new JsonObject();
	        Gson gson = new Gson();
	        JsonParser jsonParser = new JsonParser();
	        if (id!=null) {
	         Long	uid = Long.parseLong(id);
	         ArrayList<BcCustomerComponentStructure> arlist =  componentStructureService.Select_ComponentStructure(uid);
		        if (arlist.size()>0) {
		        	 jsonObject.add("list",jsonParser.parse(gson.toJson(arlist)));
			         jsonObject.addProperty("error_code", "0");
			         jsonObject.addProperty("error_message", "成功");
				}else {
					 jsonObject.addProperty("error_code", "1");
			         jsonObject.addProperty("error_message", "失败");
				}
	         
	        }else {
				System.out.println("用户id不存在");
			}
		 System.out.println(jsonObject.toString());
		return jsonObject.toString();
	 }
}
