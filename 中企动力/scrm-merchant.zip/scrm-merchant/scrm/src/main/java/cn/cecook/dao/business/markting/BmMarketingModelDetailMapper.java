package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmMarketingModelDetail;
import cn.cecook.model.business.markting.BmMarketingModelDetailExample;

/**
 * 
* @explain 营销模型明细表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BmMarketingModelDetailMapper {
    int countByExample(BmMarketingModelDetailExample example);

    int deleteByExample(BmMarketingModelDetailExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmMarketingModelDetail record);

    int insertSelective(BmMarketingModelDetail record);

    List<BmMarketingModelDetail> selectByExample(BmMarketingModelDetailExample example);

    BmMarketingModelDetail selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmMarketingModelDetail record, @Param("example") BmMarketingModelDetailExample example);

    int updateByExample(@Param("record") BmMarketingModelDetail record, @Param("example") BmMarketingModelDetailExample example);

    int updateByPrimaryKeySelective(BmMarketingModelDetail record);

    int updateByPrimaryKey(BmMarketingModelDetail record);
}