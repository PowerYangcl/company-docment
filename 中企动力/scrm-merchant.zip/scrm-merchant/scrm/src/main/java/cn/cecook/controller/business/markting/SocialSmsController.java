package cn.cecook.controller.business.markting;

import java.io.UnsupportedEncodingException;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;
import org.springframework.web.multipart.MultipartFile;

import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.business.markting.BaseResultModel;
import cn.cecook.bean.business.markting.ClickFormBean;
import cn.cecook.bean.business.markting.StatisticsBean;
import cn.cecook.dao.business.markting.SocialSmsMapper;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.business.markting.SocialSms;
import cn.cecook.service.business.markting.SocialSmsService;
import cn.cecook.service.business.scan.ScanMemberGroupService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.DateUtils;
import cn.cecook.uitls.ErrorCodeConfigUtil;
import cn.cecook.uitls.ExportExcel;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.StringUtils;

@Controller
@RequestMapping("/social/sms")
public class SocialSmsController {

	@Autowired
	private SocialSmsService socialSmsService;
	@Autowired
	private SocialSmsMapper socailSmsDao;
	@Autowired
	private ScanMemberGroupService memberGroupService;

	/**
	 * 
	 * Title: create Description:创建
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/create")
	@ResponseBody
	public Object create(HttpServletRequest request,
			HttpServletResponse response) {

		SocialSms smsSocial = new SocialSms();
		String uid = request.getParameter("uid");
		String name = request.getParameter("name");
		String send_num = request.getParameter("send_num");
		String autograph = request.getParameter("autograph");
		String content = request.getParameter("content");
		String send_time = request.getParameter("send_time");
		String tag = request.getParameter("tag");
		String activity_id = request.getParameter("activity_id");
		String send_object = request.getParameter("send_object");
		String tenant_id = request.getParameter("tenant_id");
		String sendObjectType = request.getParameter("sendObjectType");
		String groupId = request.getParameter("groupId");
		String redisKey = request.getParameter("redisKey");
        
		System.out.println(send_object);
		System.out.println(send_num);

		if (!StringUtils.isEmpty(uid))
			smsSocial.setCreateId(Long.parseLong(uid));
		smsSocial.setTenantId(tenant_id);
		smsSocial.setName(name);
		smsSocial.setSendTime(send_time);
		smsSocial.setTag(tag);
		smsSocial.setContent(content);
		smsSocial.setAutograph(autograph);
		if (!StringUtils.isEmpty(sendObjectType))
			smsSocial.setSend_object_type(Integer.parseInt(sendObjectType));
		smsSocial.setGroup_id(groupId);
		if (!StringUtils.isEmpty(activity_id))
			smsSocial.setActivityId(Long.parseLong(activity_id));
		smsSocial.setSendObject(send_object);
		if (!StringUtils.isEmpty(send_num))
			smsSocial.setSendNum(Integer.parseInt(send_num));
		
		return (socialSmsService.create(smsSocial, redisKey));
	}
	
	
	@RequestMapping(value = "/createByAutomate")
	@ResponseBody
	public Object createByAutomate(HttpServletRequest request,
			HttpServletResponse response) {

		SocialSms smsSocial = new SocialSms();
		String uid = request.getParameter("uid");
		String name = request.getParameter("name");
		String autograph = request.getParameter("autograph");
		String content = request.getParameter("content");
		String tag = request.getParameter("tag");
		String activity_id = request.getParameter("activity_id");
		String tenant_id = request.getParameter("tenant_id");
		String equivalen_num = request.getParameter("equivalen_num");
		String type=request.getParameter("type");
		String template_id=request.getParameter("template_id");
		if (!StringUtils.isEmpty(equivalen_num))
			smsSocial.setEquivalen_num(Integer.parseInt(equivalen_num));
		if (!StringUtils.isEmpty(uid))
			smsSocial.setCreateId(Long.parseLong(uid));
		smsSocial.setTenantId(tenant_id);
		smsSocial.setName(name);
		smsSocial.setTag(tag);
		smsSocial.setContent(content);
		smsSocial.setAutograph(autograph);
		if (!StringUtils.isEmpty(activity_id))
			smsSocial.setActivityId(Long.parseLong(activity_id));
		if(!StringUtils.isEmpty(type))
			smsSocial.setType(Integer.parseInt(type));
		if(!StringUtils.isEmpty(template_id)) {
			smsSocial.setTemplateId(Integer.parseInt(template_id));
		}
		return socialSmsService.createByAutomate(smsSocial);
	}
	
	
	@RequestMapping(value = "/updateByAutomate")
	@ResponseBody
	public Object updateByAutomate(HttpServletRequest request,
			HttpServletResponse response) {

		SocialSms smsSocial = new SocialSms();
		String uid = request.getParameter("uid");
		String name = request.getParameter("name");
		String autograph = request.getParameter("autograph");
		String content = request.getParameter("content");
		String tag = request.getParameter("tag");
		String activity_id = request.getParameter("activity_id");
		String tenant_id = request.getParameter("tenant_id");
		String equivalen_num = request.getParameter("equivalen_num");
		String type=request.getParameter("type");
		String id=request.getParameter("id");
		if (!StringUtils.isEmpty(equivalen_num))
			smsSocial.setEquivalen_num(Integer.parseInt(equivalen_num));
		if (!StringUtils.isEmpty(uid))
			smsSocial.setCreateId(Long.parseLong(uid));
		smsSocial.setTenantId(tenant_id);
		smsSocial.setName(name);
		smsSocial.setTag(tag);
		smsSocial.setContent(content);
		smsSocial.setAutograph(autograph);
		if (!StringUtils.isEmpty(activity_id))
			smsSocial.setActivityId(Long.parseLong(activity_id));
		if(!StringUtils.isEmpty(type))
			smsSocial.setType(Integer.parseInt(type));
		if(!StringUtils.isEmpty(id))
			smsSocial.setId(Integer.parseInt(id));
		return socialSmsService.updateByAutomate(smsSocial);
	}
	

	/**
	 * 
	 * Title: update Description:更新
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/update")
	@ResponseBody
	public Object update(HttpServletRequest request,
			HttpServletResponse response) {

		SocialSms smsSocial = new SocialSms();

		String uid = request.getParameter("uid");
		String name = request.getParameter("name");
		String send_num = request.getParameter("send_num");
		String autograph = request.getParameter("autograph");
		String content = request.getParameter("content");
		String send_time = request.getParameter("send_time");
		String tag = request.getParameter("tag");
		String id = request.getParameter("id");
		String equivalen_num = request.getParameter("equivalen_num");
		String sendObjectType = request.getParameter("sendObjectType");
		String groupId = request.getParameter("groupId");
		String tenant_id = request.getParameter("tenant_id");
		String redisKey = request.getParameter("redisKey");
		String type=request.getParameter("type");
		if (!StringUtils.isEmpty(sendObjectType))
			smsSocial.setSend_object_type(Integer.parseInt(sendObjectType));
		smsSocial.setGroup_id(groupId);

		if (!StringUtils.isEmpty(uid))
			smsSocial.setCreateId(Long.parseLong(uid));
		if (!StringUtils.isEmpty(id))
			smsSocial.setId(Integer.parseInt(id));
		smsSocial.setName(name);
		smsSocial.setSendTime(send_time);
		smsSocial.setTag(tag);
		smsSocial.setContent(content);
		smsSocial.setAutograph(autograph);
		smsSocial.setTenantId(tenant_id);
		if (!StringUtils.isEmpty(equivalen_num))
			smsSocial.setEquivalen_num(Integer.parseInt(equivalen_num));
		if (!StringUtils.isEmpty(send_num))
			smsSocial.setSendNum(Integer.parseInt(send_num));
		if (!StringUtils.isEmpty(type))
			smsSocial.setType(Integer.parseInt(type));;

		return (socialSmsService.update(smsSocial, redisKey));
	}

	/**
	 * 
	 * Title: update Description:更新
	 * 
	 * @param request
	 * @param response
	 * @return
	 */
	@RequestMapping(value = "/update2")
	@ResponseBody
	public Object update2(HttpServletRequest request,
			HttpServletResponse response) {

		SocialSms smsSocial = new SocialSms();

		String uid = request.getParameter("uid");
		String name = request.getParameter("name");
		String send_num = request.getParameter("send_num");
		String autograph = request.getParameter("autograph");
		String content = request.getParameter("content");
		String send_time = request.getParameter("send_time");
		String send_time_type = request.getParameter("send_time_type");
		String tag = request.getParameter("tag");
		String activity_id = request.getParameter("activity_id");
		String id = request.getParameter("id");
		String activity_url = request.getParameter("activity_url");
		String send_status = request.getParameter("send_status");
		String equivalen_num = request.getParameter("equivalen_num");
		String sendObjectType = request.getParameter("sendObjectType");
		String groupId = request.getParameter("groupId");
		if (!StringUtils.isEmpty(equivalen_num))
			smsSocial.setEquivalen_num(Integer.parseInt(equivalen_num));
		if (!StringUtils.isEmpty(uid))
			smsSocial.setCreateId(Long.parseLong(uid));
		if (!StringUtils.isEmpty(id))
			smsSocial.setId(Integer.parseInt(id));
		if (!StringUtils.isEmpty(send_status)) {
			smsSocial.setSendStatus(Integer.parseInt(send_status));
		}
		if (!StringUtils.isEmpty(sendObjectType))
			smsSocial.setSend_object_type(Integer.parseInt(sendObjectType));
		if(!StringUtils.isEmpty(send_time_type))
			smsSocial.setSendTimeType(Integer.parseInt(send_time_type));
		smsSocial.setGroup_id(groupId);
		smsSocial.setName(name);
		smsSocial.setSendTime(send_time);
		smsSocial.setTag(tag);
		smsSocial.setContent(content);
		smsSocial.setAutograph(autograph);
		if (!StringUtils.isEmpty(activity_id)) {
			smsSocial.setActivityId(Long.parseLong(activity_id));
		} else {
			smsSocial.setActivityId((long) 0);
		}

		if (!StringUtils.isEmpty(send_num))
			smsSocial.setSendNum(Integer.parseInt(send_num));
		smsSocial.setActivity_url(activity_url);

		return (socialSmsService.update(smsSocial, ""));
	}

	/**
	 * 
	 * Title: detail Description:详情(包括分组数据)
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/detail")
	@ResponseBody
	public Object detail(String id) {

		return (socialSmsService.deteail(id));

	}
	
	

	/**
	 * 
	 * Title: delete Description:删除
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/delete")
	@ResponseBody
	public Object delete(String id, String tenant_id) {

		return (socialSmsService.delete(id, tenant_id));

	}

	/**
	 * 
	 * Title: deleteBatch Description:批量删除
	 * 
	 * @param ids
	 * @return
	 */
	@RequestMapping(value = "/deleteBatch")
	@ResponseBody
	public Object deleteBatch(String ids, String tenant_id) {
		System.out.println("----ids--->" + ids);

		return (socialSmsService.deleteBatch(ids, tenant_id));

	}

	/**
	 * 
	 * Title: activate Description:激活
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/activate")
	@ResponseBody
	public Object activate(String id) {

		return (socialSmsService.activate(id));

	}

	/**
	 * 
	 * Title: suspend Description:暂停
	 * 
	 * @param id
	 * @return
	 */
	@RequestMapping(value = "/suspend")
	@ResponseBody
	public Object suspend(String id) {

		return (socialSmsService.suspend(id));

	}

	/**
	 * 
	 * Title: getList Description:获取列表
	 * 
	 * @param startIndex
	 * @param PageSize
	 * @param keyWord
	 * @param status
	 * @param orderBy
	 * @return
	 */
	@RequestMapping(value = "/getList")
	@ResponseBody
	public Object getList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();

		String keyWord = "";
		String orderBy = "";
		String status = "";
		String type="";
		if (jsonObj.get("keyWord") != null) {
			keyWord = jsonObj.get("keyWord").getAsString();
		}
		if (jsonObj.get("orderBy") != null) {
			orderBy = jsonObj.get("orderBy").getAsString();
		}
		if (jsonObj.get("status") != null) {
			status = jsonObj.get("status").getAsString();
		}
		if (jsonObj.get("type") != null) {
			type = jsonObj.get("type").getAsString();
		}

		System.out.println("进来了----------》" + startIndex + "-------->"
				+ pageSize);
		return (socialSmsService.getList(startIndex, pageSize, keyWord, status,
				orderBy, draw,type));

	}

	/**
	 * 
	 * Title: getList Description:
	 * 
	 * @param startIndex
	 * @param PageSize
	 * @param keyWord
	 * @param status
	 * @param orderBy
	 * @return
	 */
	@RequestMapping(value = "/importPhone")
	@ResponseBody
	public Object importInfo(HttpServletRequest request,
			@RequestParam(required = false, value = "file") MultipartFile file) {

		String uid = request.getParameter("uid");
		String tenant_id = request.getParameter("tenant_id");
		String access_token = request.getParameter("access_token");
		String handle_type = request.getParameter("handleType");
		int handleType = 1;
		if (!StringUtils.isEmpty(handle_type)) {
			handleType = Integer.parseInt(handle_type);
		}
		return (socialSmsService.ImportPhone(file, access_token, uid,
				tenant_id, handleType));
	}

	/**
	 * 
	 * Title: TestSendMessage Description:提交审核内容发送短信
	 * 
	 * @param request
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/formal_send_sms")
	@ResponseBody
	public Object FormalSendMessage(String id, String tenant_id) {

		return (socialSmsService.FormalSendMessage(id, tenant_id));
	}

	/**
	 * 
	 * Title: TestSendMessage Description:测试发送短信
	 * 
	 * @param request
	 * @param file
	 * @return
	 */
	@RequestMapping(value = "/test_send_sms")
	@ResponseBody
	public Object TestSendMessage(String id, String tenant_id, String phone) {

		return (socialSmsService.TestSendMessage(id, phone, tenant_id));
	}

	/**
	 * 
	 * Title: Statistics Description:短信统计列表
	 * 
	 * @param param
	 * @return
	 */
	@RequestMapping(value = "/statistics")
	@ResponseBody
	public Object Statistics(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();

		String keyWord = "";
		String orderBy = "";
		String start_time = null;
		String end_time = null;
		if (jsonObj.get("keyWord") != null) {
			keyWord = jsonObj.get("keyWord").getAsString();
		}
		if (jsonObj.get("orderBy") != null) {
			orderBy = jsonObj.get("orderBy").getAsString();
		}
		if (jsonObj.get("start_time") != null) {
			start_time = jsonObj.get("start_time").getAsString();
		}
		if (jsonObj.get("end_time") != null) {
			end_time = jsonObj.get("end_time").getAsString();
		}

		System.out.println("进来了----------》" + startIndex + "-------->"
				+ pageSize);
		return (socialSmsService.SmsStatistics(startIndex, pageSize, keyWord,
				start_time, end_time, orderBy, draw));

	}

	// 导出短信统计报表
	@RequestMapping(value = "/exportStatisticsForm")
	@ResponseBody
	public Object exportStatisticsForm(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		BaseResultModel baseResultModel = new BaseResultModel();

		if (!MyCatFilter.getToken_Valid()) {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return (baseResultModel);
		}

		String keyWord = java.net.URLDecoder.decode(
				request.getParameter("keyWord"), "UTF-8");
		String orderBy = request.getParameter("orderBy");
		String start_time = request.getParameter("start_time");
		String end_time = request.getParameter("end_time");
		
		start_time=DateUtils.getDayStartTime(start_time);
		end_time=DateUtils.getDayEndTime(end_time);

		Map<String, Object> map = new HashMap<String, Object>();
		map.put("startTime", start_time);
		map.put("endTime", end_time);
		map.put("orderBy", orderBy);
		map.put("keyWord", keyWord);

		System.out.println("参数----》" + FastJsonUtil.createJsonString(map));
		ExportExcel<StatisticsBean> ee = new ExportExcel<StatisticsBean>();
		List<StatisticsBean> dataList = socailSmsDao.exportStatistics(map);
		System.out.println("datalist----->"
				+ FastJsonUtil.createJsonString(dataList));
		String[] headers = { "批次名称", "发送量", "点击量", "转化量", "转化日期" };
		String fileName = "短信统计"
				+ DateUtils.DateToString(new Date(), "yyyy-MM-dd");
		int state = ee.exportExcel(headers, dataList, fileName, response);
		if (state == 1) {
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			return (baseResultModel);
		} else {
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			return (baseResultModel);
		}

	}

	@RequestMapping(value = "/audit_approval")
	@ResponseBody
	public Object MessageAuditApproval(String id, String tenant_id) {
		return (socialSmsService.quarztSendMessage(id, tenant_id));
	}

	@RequestMapping(value = "/clickList")
	@ResponseBody
	public Object clickList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		int id = jsonObj.get("id").getAsInt();
		return (socialSmsService.clickList(startIndex, pageSize, draw, id));
	}

	@RequestMapping(value = "/converList")
	@ResponseBody
	public Object converList(@RequestBody String param) {
		System.out.println(param);
		JsonParser jsonParser = new JsonParser();
		JsonObject jsonObj = jsonParser.parse(param).getAsJsonObject();
		int startIndex = jsonObj.get("start").getAsInt();
		int pageSize = jsonObj.get("length").getAsInt();
		int draw = jsonObj.get("draw").getAsInt();
		int id = jsonObj.get("id").getAsInt();

		return (socialSmsService.converList(startIndex, pageSize, draw, id));
	}

	// 导出短信统计报表
	@RequestMapping(value = "/exportClickForm")
	@ResponseBody
	public Object exportClickForm(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		BaseResultModel baseResultModel = new BaseResultModel();

		if (!MyCatFilter.getToken_Valid()) {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return (baseResultModel);
		}

		String id = request.getParameter("id");

		List<ClickFormBean> dataList = socailSmsDao.exportClickList(Integer
				.parseInt(id));
		System.out.println("datalist----->"
				+ FastJsonUtil.createJsonString(dataList));
		String[] headers = { "姓名", "电话", "邮箱", "性别", "城市", "时间" };
		String fileName = "点击统计表单"
				+ DateUtils.DateToString(new Date(), "yyyy-MM-dd");
		ExportExcel<ClickFormBean> ee = new ExportExcel<ClickFormBean>();
		int state = ee.exportExcel(headers, dataList, fileName, response);
		if (state == 1) {
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			return (baseResultModel);
		} else {
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			return (baseResultModel);
		}

	}

	// 导出短信统计报表
	@RequestMapping(value = "/exportConverForm")
	@ResponseBody
	public Object exportConverForm(HttpServletRequest request,
			HttpServletResponse response) throws UnsupportedEncodingException {
		BaseResultModel baseResultModel = new BaseResultModel();

		if (!MyCatFilter.getToken_Valid()) {
			baseResultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
			baseResultModel
					.setError_msg(ErrorCodeConfigUtil.ERROR_MSG_ZQ_20028);
			return (baseResultModel);
		}

		String id = request.getParameter("id");

		List<ClickFormBean> dataList = socailSmsDao.exportConverList(Integer
				.parseInt(id));
		System.out.println("datalist----->"
				+ FastJsonUtil.createJsonString(dataList));
		String[] headers = { "姓名", "电话", "邮箱", "性别", "城市", "时间" };
		String fileName = "转化统计表单"
				+ DateUtils.DateToString(new Date(), "yyyy-MM-dd");
		ExportExcel<ClickFormBean> ee = new ExportExcel<ClickFormBean>();
		int state = ee.exportExcel(headers, dataList, fileName, response);
		if (state == 1) {
			baseResultModel.setError_code(ConfigStatusCode.SUCCESS_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.SUCCESS_MSG);
			return (baseResultModel);
		} else {
			baseResultModel.setError_code(ConfigStatusCode.FAILURE_CODE);
			baseResultModel.setError_msg(ConfigStatusCode.FAILURE_MSG);
			return (baseResultModel);
		}

	}

	// 导出短信统计报表
	@RequestMapping(value = "/non_approval")
	@ResponseBody
	public Object NonApproval(String cause, String id,String template_id) {
		return (socialSmsService.NonApproval(cause, id,template_id));
	}

	/**
	 * 
	 * Title: HotSmsBatch Description:报告大厅最热短信
	 * 
	 * @param start_time
	 * @param end_time
	 * @return
	 */
	@RequestMapping(value = "/hotSmsBatch")
	@ResponseBody
	public Object HotSmsBatch(String startIndex, String pageSize,
			String start_time, String end_time) {
		return (socialSmsService.HotSmsBatch(start_time, end_time, startIndex,
				pageSize));
	}
	
	
	@RequestMapping(value = "/send")
	@ResponseBody
	public Object send(String id, String sendTimeType, String sendTime,String redisKey,String taskId) {
		return socialSmsService.send(id, sendTimeType, sendTime,redisKey,taskId);
	}

	/**
	 * 
	* Title: auditApproval
	* Description:审核通过
	* @param id
	* @param tenant_id
	* @return
	 */
	@RequestMapping(value = "/auditApproval")
	@ResponseBody
	public Object auditApproval(String id, String tenant_id,String template_id) {
		return (socialSmsService.auditApproval(id, tenant_id,template_id));
	}
	
	@RequestMapping(value = "/auditApprovalByBJC")
	@ResponseBody
	public Object auditApprovalByBJC(String id, String taskId) {
		return (socialSmsService.auditApprovalByBJC(id, taskId));
	}
	
}
