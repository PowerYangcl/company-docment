package cn.cecook.bean.business.markting;

import org.springframework.stereotype.Component;

import cn.cecook.uitls.DateUtils;

import java.io.Serializable;
import java.util.Date;

@Component
public class WriteOffBean implements Serializable {

    /**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	/**
     * @Title: 
     * @Package
     * @Description:
     * @author peng
     * @date 2107/5/23 
     * @version V1.0
     */

    // 核销id
    private Long verification_id;

    // 核销手机号
    private String mobile;

    // 优惠券id
    private Long coupon_id;

    // 优惠券名称
    private String coupon_name;

    // 优惠券码
    private String coupon_code;

    // 0：核销；1：反核销
    private Long status;

    // 核销操作人id
    private Long action_user_id;

    // 核销时间
    private Date write_off_time;

    // 反核销原因
    private String reverse_reason;

    // 反核销操作人id
    private Long reverse_user_id;

    // 反核销时间
    private Date reverse_time;

    // 消费金额
    private Double consumption_amount;

    // 个人（消费）偏好
    private String consumption_preference;

    // 时间转换
    private String w_time;

    // 活动id
    private Long activity_id;

    //活动名称
    private String activity_name;
    
    // 反核销操作人
    private String reverse_name;

    // 顾客id
    private Long customer_id;

    // 核销时间
    private Date create_time;


    private String uid;

    private String tenant_id;

    public void setW_time(String w_time) {
        this.w_time = w_time;
    }

    public String getUid() {
        return uid;
    }

    public void setUid(String uid) {
        this.uid = uid;
    }

    public String getTenant_id() {
        return tenant_id;
    }

    public void setTenant_id(String tenant_id) {
        this.tenant_id = tenant_id;
    }

    public String getActivity_name() {
        return activity_name;
    }

    public void setActivity_name(String activity_name) {
        this.activity_name = activity_name;
    }

    public Date getCreate_time() {
        return create_time;
    }

    public void setCreate_time(Date create_time) {
        this.w_time = DateUtils.parseDateFormat(create_time);
        this.create_time = create_time;
    }

    public Long getCustomer_id() {
        return customer_id;
    }

    public void setCustomer_id(Long customer_id) {
        this.customer_id = customer_id;
    }

    public String getReverse_name() {
        return reverse_name;
    }

    public void setReverse_name(String reverse_name) {
        this.reverse_name = reverse_name;
    }

    

    public Long getActivity_id() {
        return activity_id;
    }

    public void setActivity_id(Long activity_id) {
        this.activity_id = activity_id;
    }

    public String getW_time() {
        return w_time;
    }

    public Long getVerification_id() {
        return verification_id;
    }

    public void setVerification_id(Long verification_id) {
        this.verification_id = verification_id;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public Long getCoupon_id() {
        return coupon_id;
    }

    public void setCoupon_id(Long coupon_id) {
        this.coupon_id = coupon_id;
    }

    public String getCoupon_name() {
        return coupon_name;
    }

    public void setCoupon_name(String coupon_name) {
        this.coupon_name = coupon_name;
    }

    public String getCoupon_code() {
        return coupon_code;
    }

    public void setCoupon_code(String coupon_code) {
        this.coupon_code = coupon_code;
    }

    public Long getStatus() {
        return status;
    }

    public void setStatus(Long status) {
        this.status = status;
    }

    public Long getAction_user_id() {
        return action_user_id;
    }

    public void setAction_user_id(Long action_user_id) {
        this.action_user_id = action_user_id;
    }

    public Date getWrite_off_time() {
        return write_off_time;
    }

    public void setWrite_off_time(Date write_off_time) {

        this.write_off_time = write_off_time;
    }

    public String getReverse_reason() {
        return reverse_reason;
    }

    public void setReverse_reason(String reverse_reason) {
        this.reverse_reason = reverse_reason;
    }

    public Long getReverse_user_id() {
        return reverse_user_id;
    }

    public void setReverse_user_id(Long reverse_user_id) {
        this.reverse_user_id = reverse_user_id;
    }

    public Date getReverse_time() {
        return reverse_time;
    }

    public void setReverse_time(Date reverse_time) {
        this.reverse_time = reverse_time;
    }

    public Double getConsumption_amount() {
        return consumption_amount;
    }

    public void setConsumption_amount(Double consumption_amount) {
        this.consumption_amount = consumption_amount;
    }

    public String getConsumption_preference() {
        return consumption_preference;
    }

    public void setConsumption_preference(String consumption_preference) {
        this.consumption_preference = consumption_preference;
    }

    @Override
    public String toString() {
        return "WriteOffBean [verification_id=" + verification_id + ", mobile=" + mobile + ", coupon_id=" + coupon_id
                        + ", coupon_name=" + coupon_name + ", coupon_code=" + coupon_code + ", status=" + status
                        + ", action_user_id=" + action_user_id + ", write_off_time=" + write_off_time
                        + ", reverse_reason=" + reverse_reason + ", reverse_user_id=" + reverse_user_id
                        + ", reverse_time=" + reverse_time + ", consumption_amount=" + consumption_amount
                        + ", consumption_preference=" + consumption_preference + ", w_time=" + w_time
                        + ", avtivity_id=" + activity_id + ", activity_name=" + activity_name + ", reverse_name="
                        + reverse_name + ", customer_id=" + customer_id + ", create_time=" + create_time + "]";
    }

  

}
