package cn.cecook.model.business.markting;

import org.springframework.stereotype.Component;

import cn.cecook.bean.business.markting.BaseResultModel;

import java.util.Date;

@Component
public class BmActivityModelDefined extends BaseResultModel {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

	// id
	private Integer id;

	// uuid
	private String uuid;

	// 租户ID
	private String tenantId;

	// 删除标记
	private Integer isDeleted;

	// 创建人ID
	private Long createId;

	// 创建时间
	private Date createTime;

	// 排序标示
	private String orderCode;

	// 删除时间
	private Date deleteTime;

	// 备注
	private String remarks;

	// 附件
	private String attachment;

	// 描述
	private String description;

	// 类型
	private String type;

	// 图片地址集合
	private String picUrl;

	// 文本信息
	private String textInfo;

	// 地址信息
	private String addressInfo;

	// 收集信息
	private String collectInfo;

	// 按钮样式
	private String buttonCss;

	// 按钮文字
	private String buttonText;

	// 页脚信息（二维码地址）
	private String footerInfo;

	// 背景音乐地址
	private String backgroundMusic;

	// 页面内容
	private String content;

	// 页面链接
	private String webUrl;

	// 标签名称
	private String name;

	// 模板标签
	private String tag;

	// 备用字段
	private String bak1;

	// 备用字段
	private String bak2;

	// 备用字段
	private String bak3;

	// 备用字段
	private String bak4;

	// 备用字段
	private String bak5;

	private String update_name;

	private String background_pic;

	private String weixin_qrcode;
	private String weibo_qrcode;
	
	private String thumbnail_pic;
	
	private String model_pic;
	
	private Integer status;
	private String create_username;
	
	private String theme_info;
	private String theme_info_color;
	private String text_info_color;

	public String getTheme_info() {
		return theme_info;
	}

	public void setTheme_info(String theme_info) {
		this.theme_info = theme_info;
	}

	public String getTheme_info_color() {
		return theme_info_color;
	}

	public void setTheme_info_color(String theme_info_color) {
		this.theme_info_color = theme_info_color;
	}

	public String getText_info_color() {
		return text_info_color;
	}

	public void setText_info_color(String text_info_color) {
		this.text_info_color = text_info_color;
	}

	public String getCreate_username() {
		return create_username;
	}

	public void setCreate_username(String create_username) {
		this.create_username = create_username;
	}

	public Integer getStatus() {
		return status;
	}

	public void setStatus(Integer status) {
		this.status = status;
	}

	public String getModel_pic() {
		return model_pic;
	}

	public void setModel_pic(String model_pic) {
		this.model_pic = model_pic;
	}

	public String getThumbnail_pic() {
		return thumbnail_pic;
	}

	public void setThumbnail_pic(String thumbnail_pic) {
		this.thumbnail_pic = thumbnail_pic;
	}

	public String getBackground_pic() {
		return background_pic;
	}

	public void setBackground_pic(String background_pic) {
		this.background_pic = background_pic;
	}

	public String getWeixin_qrcode() {
		return weixin_qrcode;
	}

	public void setWeixin_qrcode(String weixin_qrcode) {
		this.weixin_qrcode = weixin_qrcode;
	}

	public String getWeibo_qrcode() {
		return weibo_qrcode;
	}

	public void setWeibo_qrcode(String weibo_qrcode) {
		this.weibo_qrcode = weibo_qrcode;
	}

	public String getUpdate_name() {
		return update_name;
	}

	public void setUpdate_name(String update_name) {
		this.update_name = update_name;
	}

	public Integer getId() {
		return id;
	}

	public void setId(Integer id) {
		this.id = id;
	}

	public String getUuid() {
		return uuid;
	}

	public void setUuid(String uuid) {
		this.uuid = uuid == null ? null : uuid.trim();
	}

	public String getTenantId() {
		return tenantId;
	}

	public void setTenantId(String tenantId) {
		this.tenantId = tenantId == null ? null : tenantId.trim();
	}

	public Integer getIsDeleted() {
		return isDeleted;
	}

	public void setIsDeleted(Integer isDeleted) {
		this.isDeleted = isDeleted;
	}

	public Long getCreateId() {
		return createId;
	}

	public void setCreateId(Long createId) {
		this.createId = createId;
	}

	public Date getCreateTime() {
		return createTime;
	}

	public void setCreateTime(Date createTime) {
		this.createTime = createTime;
	}

	public String getOrderCode() {
		return orderCode;
	}

	public void setOrderCode(String orderCode) {
		this.orderCode = orderCode == null ? null : orderCode.trim();
	}

	public Date getDeleteTime() {
		return deleteTime;
	}

	public void setDeleteTime(Date deleteTime) {
		this.deleteTime = deleteTime;
	}

	public String getRemarks() {
		return remarks;
	}

	public void setRemarks(String remarks) {
		this.remarks = remarks == null ? null : remarks.trim();
	}

	public String getAttachment() {
		return attachment;
	}

	public void setAttachment(String attachment) {
		this.attachment = attachment == null ? null : attachment.trim();
	}

	public String getDescription() {
		return description;
	}

	public void setDescription(String description) {
		this.description = description == null ? null : description.trim();
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type == null ? null : type.trim();
	}

	public String getPicUrl() {
		return picUrl;
	}

	public void setPicUrl(String picUrl) {
		this.picUrl = picUrl == null ? null : picUrl.trim();
	}

	public String getTextInfo() {
		return textInfo;
	}

	public void setTextInfo(String textInfo) {
		this.textInfo = textInfo == null ? null : textInfo.trim();
	}

	public String getAddressInfo() {
		return addressInfo;
	}

	public void setAddressInfo(String addressInfo) {
		this.addressInfo = addressInfo == null ? null : addressInfo.trim();
	}

	public String getCollectInfo() {
		return collectInfo;
	}

	public void setCollectInfo(String collectInfo) {
		this.collectInfo = collectInfo == null ? null : collectInfo.trim();
	}

	public String getButtonCss() {
		return buttonCss;
	}

	public void setButtonCss(String buttonCss) {
		this.buttonCss = buttonCss == null ? null : buttonCss.trim();
	}

	public String getButtonText() {
		return buttonText;
	}

	public void setButtonText(String buttonText) {
		this.buttonText = buttonText == null ? null : buttonText.trim();
	}

	public String getFooterInfo() {
		return footerInfo;
	}

	public void setFooterInfo(String footerInfo) {
		this.footerInfo = footerInfo == null ? null : footerInfo.trim();
	}

	public String getBackgroundMusic() {
		return backgroundMusic;
	}

	public void setBackgroundMusic(String backgroundMusic) {
		this.backgroundMusic = backgroundMusic == null ? null : backgroundMusic
				.trim();
	}

	public String getContent() {
		return content;
	}

	public void setContent(String content) {
		this.content = content == null ? null : content.trim();
	}

	public String getWebUrl() {
		return webUrl;
	}

	public void setWebUrl(String webUrl) {
		this.webUrl = webUrl == null ? null : webUrl.trim();
	}

	public String getBak1() {
		return bak1;
	}

	public void setBak1(String bak1) {
		this.bak1 = bak1 == null ? null : bak1.trim();
	}

	public String getBak2() {
		return bak2;
	}

	public void setBak2(String bak2) {
		this.bak2 = bak2 == null ? null : bak2.trim();
	}

	public String getBak3() {
		return bak3;
	}

	public void setBak3(String bak3) {
		this.bak3 = bak3 == null ? null : bak3.trim();
	}

	public String getBak4() {
		return bak4;
	}

	public void setBak4(String bak4) {
		this.bak4 = bak4 == null ? null : bak4.trim();
	}

	public String getBak5() {
		return bak5;
	}

	public void setBak5(String bak5) {
		this.bak5 = bak5 == null ? null : bak5.trim();
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name == null ? null : name.trim();
	}

	public String getTag() {
		return tag;
	}

	public void setTag(String tag) {
		this.tag = tag == null ? null : tag.trim();
	}
}