package cn.cecook.bean.system;

import java.util.List;

public class ShortUrlListBean {
	/*
	 * private String url_short; private String url_long; private String type;
	 * public String getUrl_short() { return url_short; } public void
	 * setUrl_short(String url_short) { this.url_short = url_short; } public
	 * String getUrl_long() { return url_long; } public void setUrl_long(String
	 * url_long) { this.url_long = url_long; } public String getType() { return
	 * type; } public void setType(String type) { this.type = type; }
	 */
	private List<String> urlList;
	private int totalCOunt;
	private String error_code;

	public String getError_code() {
		return error_code;
	}

	public void setError_code(String error_code) {
		this.error_code = error_code;
	}

	public List<String> getUrlList() {
		return urlList;
	}

	public void setUrlList(List<String> urlList) {
		this.urlList = urlList;
	}

	public int getTotalCOunt() {
		return totalCOunt;
	}

	public void setTotalCOunt(int totalCOunt) {
		this.totalCOunt = totalCOunt;
	}

}
