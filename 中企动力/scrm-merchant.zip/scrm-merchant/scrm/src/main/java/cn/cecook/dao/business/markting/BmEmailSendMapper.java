package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmEmailSend;
import cn.cecook.model.business.markting.BmEmailSendExample;

public interface BmEmailSendMapper {
    int countByExample(BmEmailSendExample example);

    int deleteByExample(BmEmailSendExample example);

    int deleteByPrimaryKey(Long id);

    int insert(BmEmailSend record);

    int insertSelective(BmEmailSend record);

    List<BmEmailSend> selectByExample(BmEmailSendExample example);

    BmEmailSend selectByPrimaryKey(Long id);

    int updateByExampleSelective(@Param("record") BmEmailSend record, @Param("example") BmEmailSendExample example);

    int updateByExample(@Param("record") BmEmailSend record, @Param("example") BmEmailSendExample example);

    int updateByPrimaryKeySelective(BmEmailSend record);

    int updateByPrimaryKey(BmEmailSend record);
    
    List<BmEmailSend> getEmailRecordList(Map<String, Object> map);
}