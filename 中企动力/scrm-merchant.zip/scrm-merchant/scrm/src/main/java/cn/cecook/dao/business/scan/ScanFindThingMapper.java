package cn.cecook.dao.business.scan;

import java.sql.Timestamp;
import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.scan.ScanFindThing;
import cn.cecook.model.business.scan.ScanFindThingExample;
import cn.cecook.uitls.Pages;

public interface ScanFindThingMapper {
    long countByExample(ScanFindThingExample example);

    int deleteByExample(ScanFindThingExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ScanFindThing record);

    int insertSelective(ScanFindThing record);

    List<ScanFindThing> selectByExample(ScanFindThingExample example);

    ScanFindThing selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ScanFindThing record, @Param("example") ScanFindThingExample example);

    int updateByExample(@Param("record") ScanFindThing record, @Param("example") ScanFindThingExample example);

    int updateByPrimaryKeySelective(ScanFindThing record);

    int updateByPrimaryKey(ScanFindThing record);
    
    /**
     * 	根据ruleId获取最大时间
     * @param map
     * @return
     */
    Timestamp getMaxDate(Map<String, Object> map);
    
    /**
     * 	根据微博id，获取微博
     * @param status_id
     * @return
     */
    ScanFindThing getWeibo(Map<String, Object> map);
    
    /**
     * 分页
     * @param page
     * @return
     */
    List<Map<String, Object>> getPage(Pages<Map<String, Object>> page);
    int count(Map<String, Object> where);
    
    void delete(int id);
    
	/**
	 * 根据日期获取全部线索及其对应的挖掘用户
	 */
	List<Map<String, Object>> getExcavateThingNum(String startTime);
	
	/**
	 * 拿到所有挖掘事件的时间
	 * @return
	 */
	List<Map<String, Object>> getScanFindThing();
}