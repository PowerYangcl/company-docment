package cn.cecook.dao.business.automation;

import cn.cecook.model.business.automation.AutomationTaskRule;

/**
 * 自动化营销任务条件
 * @author majie
 *
 * 2018年1月22日-下午7:26:03
 */
public interface AutomationTaskRuleMapper {
	/**
	 * 添加自动化营销任务条件
	 * @return
	 * majie
	 */
	public Integer addAutomationTaskRule(AutomationTaskRule automationTaskRule);
	/**
	 * 根据id查询条件信息
	 * @param id
	 * @return
	 * majie
	 */
	public AutomationTaskRule selectById(Integer id);
	/**
	 * 根据pointId查询条件
	 * @return
	 * majie
	 */
	public AutomationTaskRule selectByPointId(Integer id);
	/**
	 * 根据模板id删除所有条件
	 * @return
	 */
	public Integer deleteByTemplate(Integer templateId);
}
