package cn.cecook.bean.system;

import org.springframework.stereotype.Component;

import java.io.Serializable;
import java.util.ArrayList;
import java.util.List;

@Component
public class PageBean implements Serializable {
	//公共参数
	private String account;
	
	private String uid;
	
	private String tenantId;
	
	private String accessToken;
	
	//分页参数
	//当前页
	private long currentPage = 1l;
	//每页显示条数
	private long pageNum = 10l;
	//查询索引
	private long index;
	//查询关键字
	private String keyword = null;
	//分页数据
	private List<Object> list = new ArrayList<Object>() ;
	//总条数
	private long count;
	//总页数   
	private long pageCount;
	
	
	
	/*
	 * set get
	 */
	public String getAccount() {
		return account;
	}
	public void setAccount(String account) {
		this.account = account;
	}
	public String getUid() {
		return uid;
	}
	public void setUid(String uid) {
		this.uid = uid;
	}
	public String getTenantId() {
		return tenantId;
	}
	public void setTenantId(String tenantId) {
		this.tenantId = tenantId;
	}
	public String getAccessToken() {
		return accessToken;
	}
	public void setAccessToken(String accessToken) {
		this.accessToken = accessToken;
	}
	public long getCurrentPage() {
		return currentPage;
	}
	public void setCurrentPage(long currentPage) {
		this.currentPage = currentPage;
	}
	public long getPageNum() {
		return pageNum;
	}
	public void setPageNum(long pageNum) {
		this.pageNum = pageNum;
	}
	public long getIndex() {
		return (currentPage - 1 ) * pageNum;
	}
	public void setIndex(long index) {
		this.index = index;
	}
	public String getKeyword() {
		return keyword;
	}
	public void setKeyword(String keyword) {
		this.keyword = keyword;
	}
	public List<Object> getList() {
		return list;
	}
	public void setList(List<Object> list) {
		this.list = list;
	}
	public long getCount() {
		return count;
	}
	public void setCount(long count) {
		this.pageCount = (count / pageNum)+1 ;
		this.count = count;
	}
	public long getPageCount() {
		return pageCount;
	}
	public void setPageCount(long pageCount) {
		this.pageCount = pageCount;
	}
	@Override
	public String toString() {
		return "PageBean [account=" + account + ", uid=" + uid + ", tenantId="
				+ tenantId + ", accessToken=" + accessToken + ", currentPage="
				+ currentPage + ", pageNum=" + pageNum + ", index=" + index
				+ ", keyword=" + keyword + ", list=" + list + ", count="
				+ count + ", pageCount=" + pageCount + "]";
	}
	
	
	
	
}
