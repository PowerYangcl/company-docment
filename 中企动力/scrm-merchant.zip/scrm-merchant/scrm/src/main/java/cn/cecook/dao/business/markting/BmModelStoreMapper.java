package cn.cecook.dao.business.markting;

import java.util.List;
import java.util.Map;

import cn.cecook.model.business.markting.BmModelStore;


public interface BmModelStoreMapper {

    int deleteByPrimaryKey(Long id);


    int insertSelective(BmModelStore record);


    List<Map<String,Object>> selectByPrimaryKey(Long id);


    int updateByPrimaryKeySelective(BmModelStore record);
    
    int updateDeleted(long id);

}