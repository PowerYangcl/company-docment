package cn.cecook.dao.business.customer;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.customer.BcCustomerAction;
import cn.cecook.model.business.customer.BcCustomerActionExample;
import cn.cecook.uitls.Pages;

/**
 * 客户行为表
* @explain 
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BcCustomerActionMapper {
    int countByExample(BcCustomerActionExample example);

    int deleteByExample(BcCustomerActionExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BcCustomerAction record);

    int insertSelective(BcCustomerAction record);

    List<BcCustomerAction> selectByExample(BcCustomerActionExample example);

    BcCustomerAction selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BcCustomerAction record, @Param("example") BcCustomerActionExample example);

    int updateByExample(@Param("record") BcCustomerAction record, @Param("example") BcCustomerActionExample example);

    int updateByPrimaryKeySelective(BcCustomerAction record);

    int updateByPrimaryKey(BcCustomerAction record);
    
    
    /**
     *  分页统计
     * @param page
     * @return
     */
    List<BcCustomerAction> getPage(Pages<BcCustomerAction> page);
    int count(Map<String, Object> map);
    
    /**
     *  客户第一次，最后一次消费和消费总额
     * @param map
     * @return
     */
    Map<String, Object> customerCost(Map<String, Object> map);
    
    /**
     *  客户聊天记录
     * @param map
     * @return
     */
    List<Map<String, Object>> customerChat(Map<String, Object> map);
    
    /**
     *  聊天备注
     * @param map
     * @return
     */
    List<Map<String, Object>> chatRemark(Map<String, Object> map);
    
    /**
     *  根据客户行为id，获取记录
     * @param id
     * @return
     */
    List<Map<String, Object>> getCustomerActionById(Map<String, Object> map);
    
    /**
     *  添加聊天备注
     * @param map
     */
    void addChatRemark(Map<String, Object> map);
    
    /**
     *  修改聊天备注
     * @param chatRemarkId
     */
    void updateChatRemark(Map<String, Object> map);
    
    /**
     *  添加聊天记录
     * @param map
     */
    void addCustomerChat(Map<String, Object> map);
    
    /**
     *  更改客户信息的处理状态-0：未处理；1：已处理
     * @param map
     */
    void changeStatus(Map<String, Object> map);
    
    /**
     * 客户资料分页
     * @param page
     * @return
     */
    List<BcCustomerAction> getCustomerActionPage(Pages<BcCustomerAction> page);
    
    /**
     *  获取核销信息
     * @param id
     * @return
     */
    Map<String, Object> getWriteOffById(int id);
}