package cn.cecook.controller.business.automation;

import java.util.Date;

import javax.annotation.Resource;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.automation.AutomationPointInfo;
import cn.cecook.service.business.automation.AutomationPointService;

/**
 * 模板节点控制器
 * @author majie
 *
 * 2018年1月24日-下午2:06:26
 */
@Controller
@RequestMapping("/api/AutomationPoint/")
public class AutomationPointController {
	@Resource 
	private AutomationPointService automationPointService;
	/**
	 * 根据模板id和节点id查询节点信息
	 * majie
	 */
	@RequestMapping("selectPointInfo")
	@ResponseBody
	public Object selectPointInfo(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.selectPointInfo(automationPointInfo);
	}
	/**
	 * 根据模板id查询所有节点
	 * majie
	 */
	@RequestMapping("selectPointByTemplateId")
	@ResponseBody
	public Object selectPointByTemplateId(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.selectTemplatePoint(automationPointInfo);
	}
	/**
	 * 修改节点信息
	 * majie
	 */
	@RequestMapping("updatePointInfo")
	@ResponseBody
	public Object updatePointInfo(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.updatePointInfo(automationPointInfo);
	}
	/**
	 * 添加自动化营销节点信息
	 * @return
	 * majie
	 */
	
	@RequestMapping("addAutomationPointInfo")
	@ResponseBody
	public Object addAutomationPointInfo(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		automationPointInfo.setCreateTime(new Date());
		automationPointInfo.setIsDeleted(0);
		return automationPointService.addAutomationPointInfo(automationPointInfo);
	}
	/**
	 * 添加自动化营销节点信息
	 * @return
	 * majie
	 */	
	@RequestMapping("validateType")
	@ResponseBody
	public Object validateType(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.validateType(automationPointInfo);
	}
	/**
	 * 查询模板下最大节点id和最大任务id
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param automationPointInfo
	 * @return
	 * majie
	 */
	@RequestMapping("findMax")
	@ResponseBody
	public Object findMax(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.findMax(automationPointInfo);
	}
	/**
	 * 校验模板是否满足规则
	 * @param uid
	 * @param access_token
	 * @param tenant_id
	 * @param automationPointInfo
	 * @return
	 */
	@RequestMapping("validateTemplate")
	@ResponseBody
	public Object validateTemplate(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.validateTemplate(automationPointInfo);
	}
	/*****公共库的预置模板
	/**
	 * 根据模板id查询所有节点
	 * majie
	 */
	@RequestMapping("selectTemplatePointByPublic")
	@ResponseBody
	public Object selectTemplatePointByPublic(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.selectTemplatePointByPublic(automationPointInfo);
	}
	/**
	 * 根据模板id和节点id查询节点信息
	 * majie
	 */
	@RequestMapping("selectPointInfoByPublic")
	@ResponseBody
	public Object selectPointInfoByPublic(@RequestParam(value = "uid",required = false)String uid,
			@RequestParam(value = "access_token",required = false)String access_token,
			@RequestParam(value = "tenant_id",required = false)String tenant_id,AutomationPointInfo automationPointInfo){
		return automationPointService.selectPointInfoByPublic(automationPointInfo);
	}
}
