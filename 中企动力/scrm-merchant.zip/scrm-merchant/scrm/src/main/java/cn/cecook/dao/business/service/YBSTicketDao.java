package cn.cecook.dao.business.service;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Options;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.ReqYBSTicket;

@Repository
public interface YBSTicketDao {

    @Insert("INSERT INTO ybs_ticket(ybsTicketId,brand_id,store_id,money,order_id,site_no,baseInfo) values (#{ybsTicketId},#{brand_id},#{store_id},#{money},#{order_id},#{site_no},#{baseInfo})")
    @Options(useGeneratedKeys = true, keyColumn = "id")
    int saveTicket(ReqYBSTicket reqYBSTicket);

}
