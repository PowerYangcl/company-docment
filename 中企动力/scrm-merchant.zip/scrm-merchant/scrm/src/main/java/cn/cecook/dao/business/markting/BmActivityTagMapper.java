package cn.cecook.dao.business.markting;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.markting.BmActivityTag;
import cn.cecook.model.business.markting.BmActivityTagExample;

/**
 * 
* @explain 活动标签表
* @author wschenyongyin
* @date 2017年5月22日
 */
public interface BmActivityTagMapper {
    int countByExample(BmActivityTagExample example);

    int deleteByExample(BmActivityTagExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(BmActivityTag record);

    int insertSelective(BmActivityTag record);

    List<BmActivityTag> selectByExample(BmActivityTagExample example);

    BmActivityTag selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") BmActivityTag record, @Param("example") BmActivityTagExample example);

    int updateByExample(@Param("record") BmActivityTag record, @Param("example") BmActivityTagExample example);

    int updateByPrimaryKeySelective(BmActivityTag record);

    int updateByPrimaryKey(BmActivityTag record);
}