package cn.cecook.dao.business.scan;

import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.business.scan.ScanKeywordStatistics;
import cn.cecook.model.business.scan.ScanKeywordStatisticsExample;

public interface ScanKeywordStatisticsMapper {
    long countByExample(ScanKeywordStatisticsExample example);

    int deleteByExample(ScanKeywordStatisticsExample example);

    int deleteByPrimaryKey(Integer id);

    int insert(ScanKeywordStatistics record);

    int insertSelective(ScanKeywordStatistics record);

    List<ScanKeywordStatistics> selectByExample(ScanKeywordStatisticsExample example);

    ScanKeywordStatistics selectByPrimaryKey(Integer id);

    int updateByExampleSelective(@Param("record") ScanKeywordStatistics record, @Param("example") ScanKeywordStatisticsExample example);

    int updateByExample(@Param("record") ScanKeywordStatistics record, @Param("example") ScanKeywordStatisticsExample example);

    int updateByPrimaryKeySelective(ScanKeywordStatistics record);

    int updateByPrimaryKey(ScanKeywordStatistics record);
    
    ScanKeywordStatistics getBy2Id(ScanKeywordStatistics record);

	List<ScanKeywordStatistics> getDayPeoChartList(String startTime,
                                                   String endTime, String id);

	List<ScanKeywordStatistics> getClueChart();
}