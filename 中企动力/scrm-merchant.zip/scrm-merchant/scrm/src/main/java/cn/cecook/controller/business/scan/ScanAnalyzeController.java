package cn.cecook.controller.business.scan;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.scan.ScanAnalyzeService;

@Controller
@RequestMapping("/scan/analyze")
public class ScanAnalyzeController {
	@Autowired
	private ScanAnalyzeService analyzeService;
	/**
	 * 发起活动量
	 * @return
	 */
	@RequestMapping(value="/activityCountTop10",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String activityCountTop10() {
		return analyzeService.activityCountTop10();
	}
	/**
	 * 参与活动人数
	 * @return
	 */
	@RequestMapping(value="/peopleCountTop10",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String peopleCountTop10() {
		return analyzeService.peopleCountTop10();
	}
	/**
	 * 会员增长量
	 * @return
	 */
	@RequestMapping(value="/growCountTop10",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String growCountTop10() {
		return analyzeService.growCountTop10();
	}
	/**
	 * 交易额
	 * @return
	 */
	@RequestMapping(value="/costTotalTop10",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String costTotalTop10() {
		return analyzeService.costTotalTop10();
	}
}