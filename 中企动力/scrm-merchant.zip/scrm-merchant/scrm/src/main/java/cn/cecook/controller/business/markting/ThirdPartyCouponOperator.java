package cn.cecook.controller.business.markting;

import java.io.BufferedReader;
import java.io.FileInputStream;
import java.io.InputStreamReader;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Component;

import com.mysql.fabric.xmlrpc.base.Array;

import cn.cecook.service.business.markting.ThirdpartyCouponService;
import cn.cecook.uitls.CSVUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Operator;

@Component
public class ThirdPartyCouponOperator implements Operator {

	@Autowired
	private ThirdpartyCouponService thirdpartyCouponService;
	
	@Override
	public void operate(String filePath,Map<String,Object> paramMap) {
		try {
			
			List<String> couponCodeList=new ArrayList<String>();
			System.out.println(FastJsonUtil.createJsonString(paramMap));
			BufferedReader is = new BufferedReader(new InputStreamReader(new FileInputStream(filePath), "gbk"));
			String lineStr = null;
			while(null != (lineStr = is.readLine())) {
				List<String> dealCSV = CSVUtil.dealCSV(lineStr);
				couponCodeList.addAll(dealCSV);
				System.out.println(dealCSV);
			}
			thirdpartyCouponService.importThirdPartyCouponCodeByBatch(couponCodeList, String.valueOf(paramMap.get("tenant_id")), Integer.parseInt(String.valueOf(paramMap.get("uid"))), Integer.parseInt(String.valueOf(paramMap.get("modelId"))));
			is.close();
		}catch (Exception e) {
			e.printStackTrace();
		}
	}
	
	
}