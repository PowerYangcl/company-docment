package cn.cecook.dao.business.service;

import java.util.List;

import org.apache.ibatis.annotations.Insert;
import org.apache.ibatis.annotations.Many;
import org.apache.ibatis.annotations.Options;
import org.apache.ibatis.annotations.Result;
import org.apache.ibatis.annotations.Results;
import org.apache.ibatis.annotations.Select;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.PosReceipts;
import cn.cecook.model.business.service.PosReceiptsDetail;

@Repository
public interface PosReceiptsDao {

    @Insert("INSERT INTO bm_pos_receipts(tenant_id,is_deleted,create_id,create_time,order_code,delete_time,remarks,attachment,bak1,bak2,bak3,bak4,bak5,receipt_number,receipt_price,trading_time,store_id,store_name,cashier_id,cashier_name,user_phone) values" +
            " (#{tenant_id},#{is_deleted},#{create_id},#{create_time},#{order_code},#{delete_time},#{remarks},#{attachment},#{bak1},#{bak2},#{bak3},#{bak4},#{bak5},#{receipt_number},#{receipt_price},#{trading_time},#{store_id},#{store_name},#{cashier_id},#{cashier_name},#{user_phone})")
    @Options(useGeneratedKeys = true, keyColumn = "id")
    int savePosReceipts(PosReceipts posReceipts);


    @Insert("INSERT INTO bm_pos_receipts_detail(tenant_id,is_deleted,create_id,create_time,order_code,delete_time,remarks,attachment,bak1,bak2,bak3,bak4,bak5,receipt_id,goods_id,goods_name,goods_units,purchase_quantity,unit_price,discount_price,total_price) values" +
            " (#{tenant_id},#{is_deleted},#{create_id},#{create_time},#{order_code},#{delete_time},#{remarks},#{attachment},#{bak1},#{bak2},#{bak3},#{bak4},#{bak5},#{receipt_id},#{goods_id},#{goods_name},#{goods_units},#{purchase_quantity},#{unit_price},#{discount_price},#{total_price})")
    @Options(useGeneratedKeys = true, keyColumn = "id")
    int savePosReceiptsDetail(PosReceiptsDetail posReceiptsDetail);


    @Select("select * from bm_pos_receipts where id > #{id}")
    @Results({
            @Result(id = true, column = "id", property = "id"),
            @Result(property = "posReceiptsDetails", column = "id",
                    many = @Many(select = "cn.cecook.dao.business.service.PosReceiptsDao.findDetailByReceipt_id"))
    })
    List<PosReceipts> findLaterById(int id);


    @Select("select * from bm_pos_receipts_detail where receipt_id = #{id}")
    List<PosReceiptsDetail> findDetailByReceipt_id(int id);

    @Select("select * from bm_pos_receipts where id = #{id}")
    @Results({
            @Result(id = true, column = "id", property = "id"),
            @Result(property = "posReceiptsDetails", column = "id",
                    many = @Many(select = "cn.cecook.dao.business.service.PosReceiptsDao.findDetailByReceipt_id"))
    })
    PosReceipts findById(int id);
}
