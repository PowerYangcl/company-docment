package cn.cecook.controller.business.markting;

import java.util.Map;

import javax.servlet.http.HttpServletResponse;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.JsonArray;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.service.business.markting.StatisticalReportService;
import cn.cecook.uitls.ConfigStatusCode;

/**
 * 统计报告
 * @author zhaoxin
 *
 */
@Controller
@RequestMapping("/social/statistical")
public class StatisticalReportController {
	Logger logger = LoggerFactory.getLogger(this.getClass());
	private JsonParser parser = new JsonParser();
	
	@Autowired
	private StatisticalReportService statisticalReportService;
	
	/**
	 * 总览统计
	 * @return
	 */
	@RequestMapping(value="/pandect",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String pandect(@RequestParam Map<String,Object> param) {
		JsonObject result = new JsonObject();
		try {
			JsonObject data = statisticalReportService.getPandect(param);
			result.add("data", data);
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error("StatisticalReportController.cardOpenCount()", e);
		}
		logger.debug("StatisticalReportController.pandect()", result.toString());
		return result.toString();
	}
	
	/**
	 * 每天的折线图数据
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/getLine",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getLine(@RequestParam Map<String,Object> param) {
		JsonObject result = new JsonObject();
		try {
			JsonObject data = statisticalReportService.getLine(param);
			result.add("data", data);
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error("StatisticalReportController.cardOpenCount()", e);
		}
		logger.debug("StatisticalReportController.getLine()", result.toString());
		return result.toString();
	}
	
	/**
	 * 柱状图
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/getBar",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getBar(@RequestParam Map<String,Object> param) {
		JsonObject result = new JsonObject();
		try {
			JsonArray data = statisticalReportService.getBar(param);
			result.add("data", data);
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error("StatisticalReportController.cardOpenCount()", e);
		}
		logger.debug("StatisticalReportController.getBar()", result.toString());
		return result.toString();
	}
	
	/**
	 * 饼图
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/getPie",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getPie(@RequestParam Map<String,Object> param) {
		JsonObject result = new JsonObject();
		try {
			JsonObject data = statisticalReportService.getPie(param);
			result.add("data", data);
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error("StatisticalReportController.cardOpenCount()", e);
		}
		logger.debug("StatisticalReportController.getPie()", result.toString());
		return result.toString();
	}
	
	/**
	 * 名片转化的会员分页显示
	 * @param param
	 * @return
	 */
	@RequestMapping(value="/getPageCardMember",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String getPageCardMember(@RequestBody String param) {
		JsonObject result = new JsonObject();
		try {
			JsonObject data = statisticalReportService.getPageCardMember(parser.parse(param).getAsJsonObject());
			result.add("data", data);
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error("StatisticalReportController.cardOpenCount()", e);
		}
		logger.debug("StatisticalReportController.getPageCardMember()", result.toString());
		return result.toString();
	}
	
	/**
	 * 标记联系
	 * @param couponId
	 * @return
	 */
	@RequestMapping(value="/markContacted",produces="text/plain;charset=UTF-8")
	@ResponseBody
	public String markContacted(int couponId) {
		JsonObject result = new JsonObject();
		try {
			result.addProperty("data", statisticalReportService.markContacted(couponId));
			result.addProperty("code", ConfigStatusCode.SUCCESS_CODE);
		}catch (Exception e) {
			result.addProperty("code", ConfigStatusCode.FAILURE_CODE);
			logger.error("StatisticalReportController.cardOpenCount()", e);
		}
		logger.debug("StatisticalReportController.markContacted()", result.toString());
		return result.toString();
	}
	
	/**
	 * 导出员工统计
	 * @param response
	 */
	@RequestMapping(value = "/exportEmployee",produces="text/plain;charset=UTF-8")
    public void exportEmployee(HttpServletResponse response) {
		try {
			statisticalReportService.exportEmployee(response);
		}catch (Exception e) {
			logger.error("StatisticalReportController.exportEmployee()", e);
		}
    }
	
	/**
	 * 导出门店统计
	 * @param response
	 */
	@RequestMapping(value = "/exportStore",produces="text/plain;charset=UTF-8")
    public void exportStore(HttpServletResponse response) {
		try {
			statisticalReportService.exportStore(response);
		}catch (Exception e) {
			logger.error("StatisticalReportController.exportStore()", e);
		}
    }
	
	/**
	 * 导出部门统计
	 * @param response
	 */
	@RequestMapping(value = "/exportDept",produces="text/plain;charset=UTF-8")
    public void exportDept(HttpServletResponse response) {
		try {
			statisticalReportService.exportDept(response);
		}catch (Exception e) {
			logger.error("StatisticalReportController.exportDept()", e);
		}
    }
	
	/**
	 * 导出名片转化的会员
	 * @param response
	 */
	@RequestMapping(value = "/exportCardMember",produces="text/plain;charset=UTF-8")
    public void exportCardMember(HttpServletResponse response) {
		try {
			statisticalReportService.exportCardMember(response);
		}catch (Exception e) {
			logger.error("StatisticalReportController.exportCardMember()", e);
		}
    }
}