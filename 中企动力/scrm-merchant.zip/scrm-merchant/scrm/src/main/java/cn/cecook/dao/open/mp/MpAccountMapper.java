package cn.cecook.dao.open.mp;

import java.util.Date;
import java.util.List;

import org.apache.ibatis.annotations.Param;

import cn.cecook.model.open.mp.MpAccount;

public interface MpAccountMapper {

	public int getCount();
	public int insertSelective(MpAccount mpAccount);
	public List<MpAccount> selectAll();
	public MpAccount selectMpAccountById(long id);
	public MpAccount selectMpAccountByUserName(String userName);
	public MpAccount selectMpAccountByUid(String uid);
	public MpAccount selectMpAccountByTenantId(@Param(value = "tenant_id") String tenantId);
	public int updateMpAccountByUid(@Param(value = "uid") String uid, @Param(value = "mpAccount") MpAccount mpAccount);
	public List<MpAccount> selectTokenTimeMoreTime(Date time);
	public void saveOrUpdate(MpAccount mpAccount);
	public void del(@Param(value = "tenant_id") String tenantId);
}
