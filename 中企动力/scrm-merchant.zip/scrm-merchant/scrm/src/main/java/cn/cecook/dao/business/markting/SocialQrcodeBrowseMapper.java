package cn.cecook.dao.business.markting;

import cn.cecook.model.business.markting.SocialQrcodeBrowse;

/**
 * 二维码扫码记录
 * @author majie
 *
 * 2017年12月21日-下午2:21:11
 */
public interface SocialQrcodeBrowseMapper {
	/**
	 * 添加记录
	 * @param socialQrcodeBrowse
	 * @return
	 * majie
	 */
	public Integer addSocialQrcodeBrowse(SocialQrcodeBrowse socialQrcodeBrowse);
}
