package cn.cecook.controller.system;


import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.List;
import java.util.Map;

import javax.annotation.Resource;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.google.gson.Gson;
import com.google.gson.JsonObject;
import com.google.gson.JsonParser;

import cn.cecook.bean.system.DepartmentManagementModel;
import cn.cecook.bean.system.DepartmentModel;
import cn.cecook.bean.system.ResultModel;
import cn.cecook.intercept.MyCatFilter;
import cn.cecook.model.system.SysDepartmentManagement;
import cn.cecook.model.system.SysUser;
import cn.cecook.service.system.IDepartmentManagementService;
import cn.cecook.uitls.ConfigStatusCode;
import cn.cecook.uitls.CookieUtil;
import cn.cecook.uitls.FastJsonUtil;
import cn.cecook.uitls.Pages;

/**
 * @author ZHIWEN
 * @explain
 * @data 2017年6月14日
 */

@Controller
@RequestMapping("/api/department")
public class DepartmentManagementController {
    @Resource
    IDepartmentManagementService departmentManagementService;

    /**
     * (查找)账户列表（含查询）
     *
     * @explain
     * @author sunny
     * @date 2017年6月15日
     */
    @RequestMapping(value = "/searchList", method = RequestMethod.POST)
    @ResponseBody
    public String searchList(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //从缓存中获取当前用户的id，即添加在列表中的bak3
        Cookie[] cookie = request.getCookies();
        //获取当前用户的租户ID
        String tenant_id = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().toString().equals("tenant_id")) { //获取键
                tenant_id = cook.getValue().toString();    //获取值
            }
        }
        //long bak3= Long.parseLong(request.getParameter("bak3"));
        //当前部门的ID,数据库中是LONG
        //long department_id=1;
        Long department_id = Long.parseLong(request.getParameter("department_id"));
        System.out.println("department_id>list>>>>>>>" + department_id);
        JsonObject js = new JsonObject();
        int startIndex = 0;
        if (!"".equals(request.getParameter("startIndex")) && request.getParameter("startIndex") != null) {
            startIndex = Integer.valueOf(request.getParameter("startIndex"));
        }
        int pageSize = 10;
        if (!"".equals(request.getParameter("pagesize")) && request.getParameter("pagesize") != null) {
            pageSize = Integer.valueOf(request.getParameter("pagesize"));
        }
        Map<String, Object> where = new HashMap<String, Object>();
        //orderby 查询出的用户ID
        String orderby = "sid";
        where.put("tenant_id", tenant_id);
        where.put("department_id", department_id);
        if (!"全部".equals(request.getParameter("keyWord")) && request.getParameter("keyWord") != null) {
            where.put("keyWord", request.getParameter("keyWord"));
        }
        if (!"全部".equals(request.getParameter("role")) && request.getParameter("role") != null) {
            where.put("roles", request.getParameter("role"));
        }
        //where.put("isDeleted", isDeleted);      
        System.out.println("where--->" + where);
        Pages<Map<String, Object>> page = departmentManagementService
                .list(new Pages<Map<String, Object>>(startIndex, pageSize, where, orderby));
        //System.out.println(page);
        Object map2 = departmentManagementService.findMember(department_id, tenant_id);
        Map<String, Object> map1 = departmentManagementService.findLeadId(department_id, tenant_id);
        Gson gs = new Gson();
        JsonParser jsonParser = new JsonParser();
        js.add("sysuserList", jsonParser.parse(gs.toJson(page.getItems())));
        js.addProperty("totalCount", page.getTotalCount());
        js.addProperty("startIndex", startIndex);
        js.add("leadInfo", jsonParser.parse(gs.toJson(map1)));
        js.add("memInfo", jsonParser.parse(gs.toJson(map2)));

        //js.addProperty("leadID", String.valueOf(departmentManagementService.findLeadId(department_id,tenant_id)));
        //System.out.println(departmentManagementService.findLeadId(department_id,tenant_id));
        //System.out.println(js.toString());
        return js.toString();
    }

    /**
     * 添加成员
     *
     * @explain
     * @author sunny
     * @date 2017年6月15日
     */
    @RequestMapping(value = "/addMembers", method = RequestMethod.POST)
    @ResponseBody
    public Object addMembers(HttpServletRequest request, HttpServletResponse response) throws Exception {
        //department_id
        //主管id  leader_id
        //成员id串
        DepartmentModel departmentModel = new DepartmentModel();
        long department_id = Long.parseLong(request.getParameter("department_id"));
        System.out.println("department_id>ADD>>>>>>>" + department_id);
        String sysuserId = request.getParameter("sysuserId");
        if (!"".equals(sysuserId) && sysuserId != null) {
            sysuserId = sysuserId.substring(0, sysuserId.length() - 1);
            String[] sysuserIdArr = sysuserId.split(",");
            List<String> sysuserIdList = new ArrayList<String>(Arrays.asList(sysuserIdArr));
            departmentModel.setSysuserIdList(sysuserIdList);
        } else {
            //删除所有在此部门下的成员
            List<String> sysuserIdList = new ArrayList<String>();
            departmentModel.setSysuserIdList(sysuserIdList);
        }
        if (!"".equals(request.getParameter("leader_id")) && request.getParameter("leader_id") != null) {
            long leader_id = Long.parseLong(request.getParameter("leader_id"));
            departmentModel.setLeader_id(leader_id);
        } else {
            long leader_id = 0;
            departmentModel.setLeader_id(leader_id);
        }
        departmentModel.setDepartment_id(department_id);
        ResultModel resultModel = departmentManagementService.addMembers(departmentModel);
        return (resultModel);
    }


    /**
     * @explain
     * @author LeeX
     * @date 2017年6月15日 下午4:06:15
     */
    @RequestMapping(value = "/delete", method = RequestMethod.POST)
    @ResponseBody
    public Object delete(HttpServletRequest request, HttpServletResponse response, DepartmentManagementModel department) throws Exception {

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        ResultModel resultModel = new ResultModel();
        if (!MyCatFilter.getToken_Valid()) {
            resultModel.setError_code(ConfigStatusCode.AFRESH_LOGIN);
            resultModel.setError_msg("请重新登录");
            return (resultModel);
        }
        Cookie[] cookies = request.getCookies();
        Map cookieSet = CookieUtil.getCookieSet(cookies);
        resultModel = departmentManagementService.delete(department, cookieSet);
        return (resultModel);
    }

    /**
     * @explain 创建子部门
     * @author ZHIWEN
     * @data 2017年6月16日
     */
    @RequestMapping(value = "/create", method = RequestMethod.POST)
    public @ResponseBody
    Object insert(DepartmentManagementModel departmentManagementModel,
                  @RequestParam(value = "node", required = true) String node,
                  @RequestParam(value = "parent_id", required = true) Long parent_id,
                  @RequestParam(value = "uid", required = false) Long uid,
                  @RequestParam(value = "access_token", required = false) String access_token,
                  @RequestParam(value = "tenant_id", required = false) String tenant_id,
                  HttpServletRequest request, HttpServletResponse response) {
        //System.out.println(node+"as");
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String retuString = null;
        DepartmentManagementModel dm = null;
        if (tenant_id == null) {
            departmentManagementModel.setError_code("1");
            departmentManagementModel.setError_msg("租户不存在");
            dm = departmentManagementModel;
        } else {
            System.out.println(tenant_id);
            departmentManagementModel.setParentDeptId(parent_id);
            departmentManagementModel.setBak1(node);
            System.out.println(departmentManagementModel.getBak1());
            departmentManagementModel.setTenantId(tenant_id);
            dm = departmentManagementService.insert_DepartmentManagement(departmentManagementModel);
        }

        return dm;

    }

    /**
     * @explain 更新部门
     * @author ZHIWEN
     * @data 2017年6月16日
     */
    @RequestMapping(value = "/update", method = RequestMethod.POST)
    public @ResponseBody
    Object update(DepartmentManagementModel departmentManagementModel,
                  @RequestParam(value = "uid", required = false) Long uid,
                  @RequestParam(value = "access_token", required = false) String access_token,
                  @RequestParam(value = "tenant_id", required = false) String tenant_id,
                  HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();

        System.out.println(tenant_id);

        if (tenant_id == null) {
            departmentManagementModel.setError_code("1");
            departmentManagementModel.setError_msg("租户不存在");

        } else {
            departmentManagementModel.setTenantId(tenant_id);
            departmentManagementModel = departmentManagementService.update_DepartmentManagement(departmentManagementModel);
        }


        return departmentManagementModel;

    }

    /**
     * @explain 部门数据结构回显
     * @author ZHIWEN
     * @data 2017年6月17日
     * 
     */
    
    @RequestMapping(value = "/show", method = RequestMethod.POST)
    public @ResponseBody
    Object show(
            @RequestParam(value = "uid", required = false) Long uid,
            @RequestParam(value = "access_token", required = false) String access_token,
            @RequestParam(value = "tenant_id", required = false) String tenant_id,
            HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String retuString = null;
        List<SysDepartmentManagement> sdm = null;
        if (tenant_id == null) {

        } else {
        	sdm = departmentManagementService.show_DepartmentManagement(tenant_id);
        }
        //System.out.println(tenant_id);
        //System.out.println(GsonTools.createJsonString(departmentManagementService.show_DepartmentManagement(tenant_id)));
        return sdm;
    }

    /**
     * @explain 部门浮窗显示
     * @author ZHIWEN
     * @data 2017年7月3日
     */
    @RequestMapping(value = "/showflow", method = RequestMethod.POST)
    public @ResponseBody
    Object showflow(
            @RequestParam(value = "uid", required = false) Long uid,
            @RequestParam(value = "access_token", required = false) String access_token,
            @RequestParam(value = "tenant_id", required = false) String tenant_id,
            @RequestParam(value = "bak1", required = false) String bak1,
            HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");

        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();

        String retuString = null;
        if (tenant_id == null) {

        } else {
            retuString = FastJsonUtil.createJsonString(departmentManagementService.showFlow_DepartmentManagement(uid, tenant_id, bak1));
        }
        return retuString;

    }

    /**
     * @explain 部门浮窗显示用户信息
     * @author ZHIWEN
     * @data 2017年7月3日
     */
    @RequestMapping(value = "/showflowforuser", method = RequestMethod.POST)
    public @ResponseBody
    Object showflowforuser(
            @RequestParam(value = "uid", required = false) Long uid,
            @RequestParam(value = "access_token", required = false) String access_token,
            @RequestParam(value = "tenant_id", required = false) String tenant_id,
            @RequestParam(value = "bak1", required = false) String bak1,
            HttpServletRequest request, HttpServletResponse response) {
        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        System.out.println("adasd");
        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();
        String retuString = null;
        if (tenant_id == null || id == null) {

        } else {
            uid = Long.parseLong(id);
            retuString = FastJsonUtil.createJsonString(departmentManagementService.showFlowforid_DepartmentManagement(uid));
        }

        return retuString;
    }

    /**
     * @explain 跟新部门前回显部门信息
     * @author ZHIWEN
     * @data 2017年6月20日
     */
    @RequestMapping(value = "/updateBefor", method = RequestMethod.POST)
    public @ResponseBody
    Object updateBefor(DepartmentManagementModel departmentManagementModel,
                       @RequestParam(value = "uid", required = false) Long uid,
                       @RequestParam(value = "access_token", required = false) String access_token,
                       @RequestParam(value = "tenant_id", required = false) String tenant_id,
                       @RequestParam(value = "id", required = false) String id,
                       HttpServletRequest request, HttpServletResponse response
    ) {

        response.setHeader("Access-Control-Allow-Origin", "*");
        response.setHeader("Access-Control-Allow-Methods", "GET,POST");
        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String retuString = null;
        if (tenant_id == null || id == null) {

        } else {
            System.out.println(tenant_id);
            departmentManagementModel.setTenantId(tenant_id);
            departmentManagementModel.setId(Long.parseLong(id.trim()));
            //System.out.println(GsonTools.createJsonString(departmentManagementService.update_DepartmentManagement_befor(departmentManagementModel)));
            retuString = FastJsonUtil.createJsonString(departmentManagementService.update_DepartmentManagement_befor(departmentManagementModel));
        }


        return retuString;

    }

    /**
     * @explain 获取第一条部门数据
     * @author ZHIWEN
     * @data 2017年6月17日
     */
    @RequestMapping(value = "/getOneData", method = RequestMethod.POST)
    public @ResponseBody
    Object getOneData(
            @RequestParam(value = "uid", required = false) Long uid,
            @RequestParam(value = "access_token", required = false) String access_token,
            @RequestParam(value = "tenant_id", required = false) String tenant_id,
            HttpServletRequest request) {
        Cookie[] cookies = request.getCookies();
        tenant_id = CookieUtil.getCookieSet(cookies).get("tenant_id").toString();
        String id = CookieUtil.getCookieSet(cookies).get("uid").toString();
        String reString = null;
        DepartmentManagementModel departmentManagementModel = new DepartmentManagementModel();
        if (tenant_id == null || id == null) {

            departmentManagementModel.setError_code("1");
            departmentManagementModel.setError_msg("租户不存在");
        } else {
            uid = Long.parseLong(id);
            SysUser sysUser = departmentManagementService.selectuserbyid(uid);

            departmentManagementModel = departmentManagementService.GetOneData_DepartmentManagement(tenant_id);
            if (sysUser != null) {
                departmentManagementModel.setBak3(sysUser.getName().toString());
            }
            reString = FastJsonUtil.createJsonString(departmentManagementModel);
        }
        return reString;
    }

    /**
     * 查询部门成员和主管的接口
     *
     * @explain
     * @author sunny
     * @date 2017年6月12日
     */
    @RequestMapping(value = "/selectML")
    @ResponseBody
    public String selectML(HttpServletRequest request, HttpServletResponse response) throws Exception {
        Cookie[] cookie = request.getCookies();
        //获取当前用户的租户ID
        String tenant_id = "";
        for (int i = 0; i < cookie.length; i++) {
            Cookie cook = cookie[i];
            if (cook.getName().toString().equals("tenant_id")) {
                tenant_id = cook.getValue().toString();
            }
        }
        Long department_id = Long.parseLong(request.getParameter("department_id"));
        System.out.println("department_id>list>>>>>>>" + department_id);
        JsonObject j = new JsonObject();
        Gson g = new Gson();
        if (department_id > 0) {

            Object map2 = departmentManagementService.findMember(department_id, tenant_id);
            Map<String, Object> map1 = departmentManagementService.findLeadId(department_id, tenant_id);
            JsonParser jsonParser = new JsonParser();
            System.out.println(map1);
            j.add("leadInfo", jsonParser.parse(g.toJson(map1)));
            j.add("memInfo", jsonParser.parse(g.toJson(map2)));

        } else {
            // 如果ID为空 返回错误信息
            System.out.println("部门id有误，查询失败");
        }
        System.out.println(j);
        return j.toString();
    }
    
	/**
	 * 根据当前部门ID，租户ID查询父节点是当前部门ID的所有记录
	 */
	@RequestMapping(value="/getAllChildNode" ,method = RequestMethod.POST)
	@ResponseBody
 	public Object getAllChildNode(@RequestParam(value = "bmIdForEdit",required = false)String bmIdForEdit,
		@RequestParam(value = "tenant_id",required = false)String tenant_id) {	
		return departmentManagementService.getAllChildNode(bmIdForEdit, tenant_id);
	}
 	
	/**
	 * 2017-12-22  许伟
	 * 根据当前租户ID查询父节点所有部门
	 */
	@RequestMapping(value="/getAllDepartment" ,method = RequestMethod.POST)
	@ResponseBody
 	public Object getAllDepartment(@RequestParam(value = "tenant_id",required = false)String tenant_id,
 			                       @RequestParam(value = "startIndex",required = false)String startIndex,
 			                       @RequestParam(value = "pageSize",required = false)String pageSize) {	
		return departmentManagementService.getAllChildNode(startIndex,pageSize,tenant_id);
	}
	/**
	 * 查询部门信息
	 */
	@RequestMapping(value="/getDatasDepartment" ,method = RequestMethod.POST)
	@ResponseBody
	public Object getDatasDepartment(@RequestParam(value = "tenant_id",required = false)String tenant_id,
             @RequestParam(value = "startIndex",required = false)String startIndex,
             @RequestParam(value = "pageSize",required = false)String pageSize){
		Map<String,Object> map=new HashMap<>();
		map.put("tenant_id", tenant_id);
		map.put("startIndex", startIndex);
		map.put("pageSize", pageSize);
		return departmentManagementService.getDatasDepartment(map);
	}
	
	/**
	 * 查询指定部门下的所有员工(包含子部门的员工)
	 */
	@RequestMapping(value="/getDatasDepartmentForId" ,method = RequestMethod.POST)
	@ResponseBody
	public Object getDatasDepartmentForId(@RequestParam(value = "tenant_id",required = false)String tenant_id,
			@RequestParam(value = "bmId",required = false)String bmId,@RequestParam(value = "bmName",required = false)String bmNeme){
		Map<String,Object> map=new HashMap<>();
		map.put("tenant_id", tenant_id);
		map.put("bmId", bmId);
		map.put("bmName",bmNeme);
		return departmentManagementService.getDatasDepartmentForId(map);
	}
}
