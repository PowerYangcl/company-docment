package cn.cecook.controller.api;


import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.model.business.service.ReqYBSTicket;
import cn.cecook.service.business.service.YBSTicketService;

/**
 * 此方法为接受亚博松小票插件数据类
 */
@Controller
@RequestMapping("/API/YBSTicket")
public class APITicketReceive {

    @Autowired
    private YBSTicketService ybsTicketService;

    /**
     * 接收亚博松小票推送信息并存储
     *
     * @param reqYBSTicket 亚博松小票对象
     * @return map
     */
    @RequestMapping(value = "/receiveTicket")
    @ResponseBody
    public Map<String, Object> receiveTicket(ReqYBSTicket reqYBSTicket) {

        Map<String, Object> resultMap = new HashMap<>();

        Map<String, Object> templateMap = new HashMap<>();

        String qrUrl = "" + "/payment/message/ticketError?reason=";

        System.out.println(reqYBSTicket.getBaseInfo());

        ybsTicketService.saveTicket(reqYBSTicket);

        templateMap.put("qrcode_text", "<qrcode data=\"" + qrUrl + "\" mode=\"img\" size=\"3\" />");
        resultMap.put("template", templateMap);
        resultMap.put("info", qrUrl);
        resultMap.put("url", qrUrl);
        return resultMap;
    }


}
