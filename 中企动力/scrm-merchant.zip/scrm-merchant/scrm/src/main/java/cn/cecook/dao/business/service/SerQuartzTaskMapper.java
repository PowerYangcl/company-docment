package cn.cecook.dao.business.service;

import java.util.List;
import java.util.Map;

import org.apache.ibatis.annotations.Param;
import org.springframework.stereotype.Repository;

import cn.cecook.model.business.service.SerQuartzTask;

@Repository("serQuartzTaskMapper")
public interface SerQuartzTaskMapper {

    int deleteByPrimaryKey(Integer id);

    int insertSelective(SerQuartzTask record);

    SerQuartzTask selectByPrimaryKey(Integer id);

    int updateByPrimaryKeySelective(SerQuartzTask record);

    int updateByPrimaryKey(SerQuartzTask record);
    
    int insertByBatch(List<SerQuartzTask> serQuartzTasks);
    
    List<SerQuartzTask> taskList(Map<String, Object> map);

    int updateStatus(@Param("id") int id, @Param("status") int status, @Param("tenantId") String tenantId);
    
    int quartzTaskNumByAutomateTaskId(int automateTaskId);
    
    int deleteTaskBatch(int automateTaskId);
}