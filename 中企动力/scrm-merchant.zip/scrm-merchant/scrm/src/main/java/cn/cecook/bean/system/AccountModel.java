package cn.cecook.bean.system;

import java.io.Serializable;
import java.util.List;

/**
 * 用户
 * 
 * @explain
 * @author sunny
 * @date 2017年5月27日
 */

public class AccountModel implements Serializable {
	// 账户
	private String account;
	// 密码
	private String password;
	// 口令
	private String access_token;
	// 登录验证码
	private String sms_code;
	// 新密码
	private String new_pwd;
	// 验证码
	private String ver_code;
	// 验证码类型
	private String code_type;
	// id主键
	private long id;
	// 用户ID
	private Long uid;
	// 租户ID
	private String tenant_id;
	// 错误描述
	private String error_msg;
	// 姓名
	private String name;
	// 邮件
	private String email;
	// 地区
	private String district_name;
	// 行业
	private String industry;
	// 公司
	private String company;
	// 公司编码
	private String company_code;
	// 职位
	private String job;
	// 个人爱好
	private String hobby;
	// 生成公司时的唯一id
	private long c_id;
	// 账户状态
	int status;
	// 角色集合
	private List<String> roleIdList;
	// 部门集合
	private List<String> storeIdList;
	// 删除标记
	int is_deleted;
	private long department_id;
	private String intro;
	// 员工编号
	private String jobNumber;
	private String type;
	
	private String phone;
	
	private Integer dataAuthTag;

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getIntro() {
		return intro;
	}

	public void setIntro(String intro) {
		this.intro = intro;
	}

	public long getDepartment_id() {
		return department_id;
	}

	public void setDepartment_id(long department_id) {
		this.department_id = department_id;
	}

	public int getIs_deleted() {
		return is_deleted;
	}

	public void setIs_deleted(int is_deleted) {
		this.is_deleted = is_deleted;
	}

	public int getStatus() {
		return status;
	}

	public void setStatus(int status) {
		this.status = status;
	}

	public List<String> getRoleIdList() {
		return roleIdList;
	}

	public void setRoleIdList(List<String> roleIdList) {
		this.roleIdList = roleIdList;
	}

	public long getC_id() {
		return c_id;
	}

	public void setC_id(long c_id) {
		this.c_id = c_id;
	}

	private String ten_login;

	public String getTen_login() {
		return ten_login;
	}

	public void setTen_login(String ten_login) {
		this.ten_login = ten_login;
	}

	public String getAccount() {
		return account;
	}

	public void setAccount(String account) {
		this.account = account;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getAccess_token() {
		return access_token;
	}

	public void setAccess_token(String access_token) {
		this.access_token = access_token;
	}

	public String getSms_code() {
		return sms_code;
	}

	public void setSms_code(String sms_code) {
		this.sms_code = sms_code;
	}

	public String getNew_pwd() {
		return new_pwd;
	}

	public void setNew_pwd(String new_pwd) {
		this.new_pwd = new_pwd;
	}

	public String getVer_code() {
		return ver_code;
	}

	public void setVer_code(String ver_code) {
		this.ver_code = ver_code;
	}

	public String getCode_type() {
		return code_type;
	}

	public void setCode_type(String code_type) {
		this.code_type = code_type;
	}

	public Long getUid() {
		return uid;
	}

	public void setUid(Long uid) {
		this.uid = uid;
	}

	public String getTenant_id() {
		return tenant_id;
	}

	public void setTenant_id(String tenant_id) {
		this.tenant_id = tenant_id;
	}

	public String getError_msg() {
		return error_msg;
	}

	public void setError_msg(String error_msg) {
		this.error_msg = error_msg;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public String getDistrict_name() {
		return district_name;
	}

	public void setDistrict_name(String district_name) {
		this.district_name = district_name;
	}

	public String getIndustry() {
		return industry;
	}

	public void setIndustry(String industry) {
		this.industry = industry;
	}

	public String getCompany() {
		return company;
	}

	public void setCompany(String company) {
		this.company = company;
	}

	public String getCompany_code() {
		return company_code;
	}

	public void setCompany_code(String company_code) {
		this.company_code = company_code;
	}

	public String getJob() {
		return job;
	}

	public void setJob(String job) {
		this.job = job;
	}

	public String getHobby() {
		return hobby;
	}

	public void setHobby(String hobby) {
		this.hobby = hobby;
	}

	public long getId() {
		return id;
	}

	public void setId(long id) {
		this.id = id;
	}

	public List<String> getStoreIdList() {
		return storeIdList;
	}

	public void setStoreIdList(List<String> storeIdList) {
		this.storeIdList = storeIdList;
	}

	@Override
	public String toString() {
		return "AccountModel [account=" + account + ", password=" + password
				+ ", access_token=" + access_token + ", sms_code=" + sms_code
				+ ", new_pwd=" + new_pwd + ", ver_code=" + ver_code
				+ ", code_type=" + code_type + ", id=" + id + ", uid=" + uid
				+ ", tenant_id=" + tenant_id + ", error_msg=" + error_msg
				+ ", name=" + name + ", email=" + email + ", district_name="
				+ district_name + ", industry=" + industry + ", company="
				+ company + ", company_code=" + company_code + ", job=" + job
				+ ", hobby=" + hobby + ", c_id=" + c_id + ", status=" + status
				+ ", roleIdList=" + roleIdList + ", is_deleted=" + is_deleted
				+ ", department_id=" + department_id + ", intro=" + intro
				+ ", ten_login=" + ten_login + "]";
	}

	public String getJobNumber() {
		return jobNumber;
	}

	public void setJobNumber(String jobNumber) {
		this.jobNumber = jobNumber;
	}

	public String getType() {
		return type;
	}

	public void setType(String type) {
		this.type = type;
	}

	public Integer getDataAuthTag() {
		return dataAuthTag;
	}

	public void setDataAuthTag(Integer dataAuthTag) {
		this.dataAuthTag = dataAuthTag;
	}

}
