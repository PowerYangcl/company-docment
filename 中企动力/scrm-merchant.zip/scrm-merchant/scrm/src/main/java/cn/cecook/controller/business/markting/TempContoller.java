package cn.cecook.controller.business.markting;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import cn.cecook.service.business.markting.TempService;
import cn.cecook.uitls.JspToHtmlUtils;

@Controller
@RequestMapping("/api/temp")
public class TempContoller {
	@Autowired
	private TempService tempService;
	@Value("#{configProperties['UplaodBaseUrl']}")
    private String UPLOAD_BASE_URL;
	@RequestMapping(value = "/sendCoupon")
	@ResponseBody
	public Object SendCoupon(String tenant_id){
		System.out.println("进来了---》");
		return (tempService.SendCoupon(tenant_id));
	}
	@RequestMapping(value = "/test")
	@ResponseBody
	public Object Test(String tenant_id,int smsNum){
		System.out.println("进来了---》");
		return (tempService.test(tenant_id,smsNum));
		
	}
	
	@RequestMapping(value = "/html")
	@ResponseBody
	public Object createHtml(){
		String path = JspToHtmlUtils.class.getClassLoader()
				.getResource("html/404.html").getPath();
		System.out.println(path);
		
		// 循环生成20个html文件
		for (int k = 0; k < 2; k++) {
			String url = path;// 模板文件地址
			String savepath = UPLOAD_BASE_URL+"/" + k + ".html";// 生成文件地址
			JspToHtmlUtils.JspToHtmlFile(url, savepath,null);
		}
		return null;
	}

}
